import scrapy

from scrapy.http import Request


from Zivame.settings import *

from Zivame.proxy import parse_proxy

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.101 Safari/537.36'
    }


class ZivameSpider(scrapy.Spider):
    name = 'zivame_link_crawler'
    base_urls = 'https://www.zivame.com'


    def start_requests(self):

        urls = 'https://www.zivame.com/beauty/makeup/lipsticks.html?trksrc=navbar&trkid=l2'
        yield Request(urls, callback=self.parse, headers = headers)


    def parse(self, response):

        product_links = response.xpath("//div[@class='front pos-relative']/a/@href").extract()  
        for link in product_links:
            product_url = self.base_urls+link
            print(product_url)
            item = {}
            item['product_url'] = product_url

            yield item
        next_page = response.xpath("//a[@class='nextPageLinkForSeo']/@href").extract()
        if next_page:
            next_page_url = next_page
            yield Request(next_page_url, headers=headers, callback=self.parse)

 