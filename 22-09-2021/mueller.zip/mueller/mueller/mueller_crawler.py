from xml.dom import minidom
import requests
import pymongo
from pymongo import MongoClient

MONGODB_DB = 'mueller'
MONGODB_COLLECTION = 'mueller_links'
client = MongoClient('localhost',27017)
db = client[MONGODB_DB]
db[MONGODB_COLLECTION].create_index([("product_url",1)], unique=True)


urls = ["https://www.mueller.at/sitemap/product/?index=1","https://www.mueller.at/sitemap/product/?index=2"]
for url in urls:
    response = requests.get(url)
# print(response.url)

    xmldoc = minidom.parseString(response.text)
    LOCS = xmldoc.getElementsByTagName('loc')
    for loc in LOCS:
        p_url = loc.childNodes[0].data
        item = {}
        item['product_url'] = p_url
        try:

            # print(item)
            db[MONGODB_COLLECTION].insert(dict(item))
                  
        except:
            pass 