# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class MuellerUrlItem(scrapy.Item):
    _id = scrapy.Field()
    url = scrapy.Field()

class MuellerItem(scrapy.Item):
    # define the fields for your item here like:
    _id = scrapy.Field()
    product_url = scrapy.Field()
    product_name = scrapy.Field()
    product_id = scrapy.Field()
    product_brand = scrapy.Field()
    product_price = scrapy.Field()
    priceCurrency = scrapy.Field()
    discount= scrapy.Field()
    image_url= scrapy.Field()
    breadcrumbs = scrapy.Field()
    is_sold_out = scrapy.Field()
    description = scrapy.Field()
    features = scrapy.Field()