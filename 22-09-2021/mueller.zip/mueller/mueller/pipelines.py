# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from pymongo import MongoClient
from mueller.items import MuellerUrlItem,MuellerItem
from scrapy.exceptions import DropItem


class MuellerPipeline:
    database = "mueller"
    collection1 = "mueller_data"
    collection2 = "mueller_links"

    def __init__(self):
        self.client = MongoClient('localhost',27017)
        self.db = self.client[self.database]
        self.coll1 = self.db[self.collection1]
        self.coll2 = self.db[self.collection2]
        # self.coll2.create_index([("url",1)], unique=True)

    def process_item(self, item, spider):
        if isinstance(item, MuellerItem):
            try:
                self.coll1.insert_one(item)
            except Exception:
                raise DropItem("Dropping duplicate item")
        if isinstance(item, MuellerUrlItem):
            try:
                self.coll2.insert_one(item)
            except Exception:
                raise DropItem("Dropping duplicate item")
        return item

    def close_spider(self,spider):
        self.client.close()
