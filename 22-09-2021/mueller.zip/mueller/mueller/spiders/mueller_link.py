import scrapy
from scrapy.http import Request
from ..items import MuellerUrlItem
from scrapy.shell import inspect_response

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,'
              '*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept - encoding': 'gzip, deflate, br',
    'accept-language':  'en-US,en;q=0.5',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) '
                  'Chrome/91.0.4472.101 Safari/537.36 '

}


class MuellerLinkSpider(scrapy.Spider):
    name = 'mueller_link'
    base_url = 'https://www.mueller.at'
    page_number = 2

    def start_requests(self):
        # url = 'https://www.mueller.at/parfuemerie/?show=all'
        # url='https://www.mueller.at/naturshop/?show=all'
        # url='https://www.mueller.at/drogerie/?show=all'
        url='https://www.mueller.at/parfuemerie/?p=2'
        yield Request(url, callback=self.parse_url, headers=headers)

#----------------------------------------
    # def parse(self, response):
    #     links = response.xpath('//li[@class="mu-all-categories__item"]/a/@href').extract()
    #     for link in links:
    #         link = response.url + link
    #         # print(link)
    #         yield Request(link, callback=self.parse_url, headers=headers)
#-------------------------------------------------

    # def parse(self,response):
    #     links = response.xpath('//div[@class="mu-all-categories__subcategory-flyout | mu-subcategory-flyout"]/div[1]//a[@class="mu-subcategory-flyout__footer-link"]/@href').extract()
    #     for link in links:
    #         if not link.startswith('https'):
    #             link = response.url + link
    #         yield Request(link, callback=self.parse_url, headers=headers)


    def parse_url(self,response):
        # inspect_response(response, self)
        # print(response.url)
        urls = response.xpath('//div[@class="mu-product-list__items"]//a/@href').extract()
        for url in urls:
            url = self.base_url + url

            item = MuellerUrlItem()
            item['url'] = url

            yield item

            total_pages = response.xpath('//div[@class="mu-pagination__pages"]//span/text()')[-1].extract()
            # print(total_pages)
            next_page = response.url.split('?')[0] + '?p=' + str(self.page_number)
            print(next_page)
            if self.page_number <= int(total_pages) :
                # print(self.page_number)
                yield Request(next_page, headers=headers, callback=self.parse_url)
                self.page_number += 1













