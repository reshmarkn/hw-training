import scrapy
from scrapy.http import Request
import json
from ..items import MuellerItem
import pika
import logging
# from scrapy.shell import inspect_response

logger = logging.getLogger('pika')
logger.propagate = False

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,'
              '*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept - encoding': 'gzip, deflate, br',
    'accept-language':  'en-US,en;q=0.5',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) '
                  'Chrome/91.0.4472.101 Safari/537.36 '

}

class MuellerParserSpider(scrapy.Spider):
    name = 'mueller_parser'

    def start_requests(self):
        # urls = ['https://www.mueller.at/p/hugo-man-shower-gel-284344/',
        # 'https://www.mueller.at/p/dado-sens-hypersensitive-make-up-6516974714/?itemId=2474730',
        # 'https://www.mueller.at/p/ein-deutsches-requiem-285583/']
        # for url in urls:
        #     yield Request(url, callback=self.parse, headers=headers)

        ##from queue##
        count = 1
        credentials = pika.PlainCredentials('guest','guest')
        connection = pika.BlockingConnection(pika.ConnectionParameters( host='localhost', socket_timeout=300))
        channel = connection.channel()
        while count <= 10:
            channel.basic_qos(prefetch_count=1)
            method, properties, url = channel.basic_get(queue='mueller')
            if not url.strip():
                break
            channel.basic_ack(delivery_tag=method.delivery_tag)
            url = str(url.strip(), encoding='utf-8')
            if url.strip():
                link = url
                yield Request(url=link.strip(), callback=self.parse, headers=headers)
                # print(url)
                count += 1
        connection.close()

    def parse(self, response):
        # inspect_response(response, self)
        data = response.xpath('//script[@type="application/ld+json"]/text()').extract_first()
        json_data = json.loads(data)

        name = json_data['name']
        product_id = json_data['sku']
        image = json_data['image']
        brand=json_data.get('brand',{}).get('name','')
        description = json_data['description']
        offers = json_data['offers'][0]
        price = offers['price']
        currency = offers['priceCurrency']
        availability = offers['availability']
        if availability is not None:
            stock = availability.split('/')[-1] 
            if stock.lower() ==  "instock" :
                    is_sold_out = False
            else:
                    is_sold_out = True

        breadcrumbs = response.xpath('//a[@itemprop="item"]/span//text()').extract()
        discount = response.xpath(
            '//div[@class="mu-product-price__percentage-saving"]/strong/text()').extract_first()
        rows = response.xpath('//div[@id="features"]//tbody[@class="mu-table__body"]/tr')
        features = {}
        for row in rows:
            key = row.xpath('td[1]/text()').extract_first().strip()
            value = row.xpath('td[2]/text()').extract_first().strip()
            features.update({key:value})

        #clean
        breadcrumbs = '>'.join([item.strip() for item in breadcrumbs])

        item = MuellerItem()
        item['product_url'] = response.url
        item['product_name'] = name 
        item['product_id'] = product_id
        item['product_brand'] = brand
        item['product_price'] = price
        item['priceCurrency'] = currency
        item['discount'] = discount
        item['image_url'] = image
        item['breadcrumbs'] = breadcrumbs
        item['is_sold_out'] = is_sold_out
        item['description'] = description
        item['features'] = features

        yield item


