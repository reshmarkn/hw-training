import scrapy

from scrapy.http import Request

from Gymboree.items import GymboreeLinkcrawlerItem

from scrapy.exceptions import CloseSpider

from Gymboree.settings import *

from Gymboree.proxy import parse_proxy

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.101 Safari/537.36'
    }


class GymboreeLinkCrawlerSpider(scrapy.Spider):
    name = 'gymboree_link_crawler'
    base_urls = 'https://www.gymboree.com'


    def start_requests(self):
        yield Request('https://www.gymboree.com/us/c/collections',callback=self.parse,headers=headers)

    def parse(self,response):
        
        category_links = response.xpath("//ol[@class='sc-gsTCUz dsuMfS sub-menu-category sub-menu-wrapper']/li//a/@href").extract() 
        for link in category_links:
            category_url = self.base_urls+link
            yield Request(category_url,callback = self.parse_links, headers=headers)   



    def parse_links(self, response):
       
        product_links = response.xpath("//div[@class='product-title-container']/a//@href").extract()
        for link in product_links:
            product_url = self.base_urls+link 
            item = GymboreeLinkcrawlerItem()
            item['product_url'] = product_url
            yield item

        

    