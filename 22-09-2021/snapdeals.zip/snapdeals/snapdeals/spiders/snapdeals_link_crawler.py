import pika
import scrapy
import logging
import json
from snapdeals.items import *
from snapdeals.settings import *
from pymongo import MongoClient
from scrapy.http import Request

headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
           'Accept-Encoding': 'gzip, deflate, br',
           'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
           'Upgrade-Insecure-Requests': '1',
           'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.87 Safari/537.36'}

logger = logging.getLogger('pika')
logger.propagate = False

MONGODB_DB = 'meesho_weekly_2021_07_29'
MONGODB_COLLECTION = 'snapdeal_com_urls_new'
client = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
try:
    client.admin.command("enablesharding", MONGODB_DB)
except:
    pass
try:
    client.admin.command(
        "shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION, key={'url': 1})
except:
    pass

db = client[MONGODB_DB]


class LinkCrawlerSpider(scrapy.Spider):
    name = 'snapdeals_link_crawler'
    handle_httpstatus_list = [503, 403]

    def start_requests(self):
        # urls = ['https://www.snapdeal.com/products/mens-tshirts-polos?sort=plrty#bcrumbLabelId:17',
        #         'https://www.snapdeal.com/products/casual-shirts?sort=plrty#bcrumbLabelId:191',
        #         'https://www.snapdeal.com/products/formal-shirts?sort=plrty#bcrumbLabelId:191',
        #         'https://www.snapdeal.com/products/partywear-shirts?sort=plrty#bcrumbLabelId:191',
        #         'https://www.snapdeal.com/products/men-apparel-jeans?sort=plrty#bcrumbLabelId:17',
        #         'https://www.snapdeal.com/products/men-apparel-trousers?sort=plrty#bcrumbLabelId:17',
        #         'https://www.snapdeal.com/products/men-apparel-sports-wear?sort=plrty#bcrumbLabelId:17',
        #         'https://www.snapdeal.com/products/men-apparel-trackpants-tracksuits?sort=plrty#bcrumbLabelId:17',
        #         'https://www.snapdeal.com/products/men-apparel-innerwear?sort=plrty#bcrumbLabelId:17',
        #         'https://www.snapdeal.com/products/men-apparel-suitings-shirtings?sort=plrty#bcrumbLabelId:17',
        #         'https://www.snapdeal.com/products/men-apparel-shorts-cargos?sort=plrty#bcrumbLabelId:17',
        #         'https://www.snapdeal.com/products/men-apparel-rainwear?sort=plrty#bcrumbLabelId:17',
        #         'https://www.snapdeal.com/products/mens-winter-wear-store?sort=plrty#bcrumbLabelId:17',
        #         ]

        # for url in urls:
        #     meta = {'position': 0}
        #     if url.strip():
        #         yield Request(url, headers=headers, callback=self.link_crawl, meta=meta, dont_filter=True)

        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        while True:
            connection = pika.BlockingConnection(pika.ConnectionParameters(
                credentials=credentials, host=QUEUE_IP, socket_timeout=300))
            channel = connection.channel()
            channel.basic_qos(prefetch_count=1)
            method, properties, url = channel.basic_get(queue=QUEUE_NAME1)
            if not url.strip():
                break
            channel.basic_ack(delivery_tag=method.delivery_tag)
            url = str(url, encoding='utf-8')
            meta = {'position': 0, 'pagination_url': '', 'size': 0,
                    'category_hierarchy': '', 'id_': '', 'page_slug2': ''}
            if url.strip():
                yield Request(url, headers=headers, callback=self.link_crawl, meta=meta, dont_filter=True)

    def link_crawl(self, response):
        position = response.meta.get('position')
        pagination_url = response.meta.get('pagination_url', '')
        size = response.meta.get('size')
        id_ = response.meta.get('id_')
        page_slug2 = response.meta.get('page_slug2')
        catagory_hierarchys = response.meta.get('category_hierarchy')
        if 'acors/json/product' in response.url:
            links = response.xpath(
                '//div[@class="product-hover-state "]/a/@href').extract()
            if links:
                for link in links:
                    position = int(position) + 1
                    link = response.urljoin(link)

                    items = SnapdealsLinkCrawlItem()
                    items['url'] = link
                    items['position'] = position
                    items['main_url'] = response.url
                    items['catagory_hierarchys'] = catagory_hierarchys
                    db[MONGODB_COLLECTION].insert(dict(items))
                size = int(size) + 20
                next_url = 'https://www.snapdeal.com/acors/json/product/get/search/' + \
                    str(id_) + '/' + str(size) + '/20?q=' + str(page_slug2)
                data = {'position': position, 'id_': id_, 'page_slug2': page_slug2,
                        'pagination_url': next_url, 'size': size, 'category_hierarchy': catagory_hierarchys}
                yield Request(next_url, headers=headers, callback=self.link_crawl, meta=data, dont_filter=True)

        else:
            LINK_XPATH = '//a[@class="dp-widget-link"]/@href'
            BREADCRUMBS_XPATH = '//div[@id="breadCrumbWrapper"]//span[@itemprop="title"]/text() | //div[@id="breadCrumbWrapper"]//span[@class="active-bread"]/text()'
            if not catagory_hierarchys:
                category_hierarchy = response.xpath(
                    BREADCRUMBS_XPATH).extract()
                category_hierarchy = category_hierarchy[1:]
                catagory_hierarchys = {}
                length = 1
                for items in category_hierarchy:
                    catagory_hierarchys.update(
                        {'l' + str(length): items})
                    if length == 4:
                        break
                    length += 1

            links = response.xpath(LINK_XPATH).extract()
            main_url = response.url
            if links:
                for link in links:
                    position = int(position) + 1
                    link = response.urljoin(link)

                    items = SnapdealsLinkCrawlItem()
                    items['url'] = link
                    items['position'] = position
                    items['main_url'] = response.url
                    items['catagory_hierarchys'] = catagory_hierarchys
                    db[MONGODB_COLLECTION].insert(dict(items))

                id_ = response.xpath(
                    '//input[@id="labelId"]/@value').extract_first("")
                page_slug2 = main_url.split('&q=')[-1]
                size = int(size) + 20
                next_url = 'https://www.snapdeal.com/acors/json/product/get/search/' + \
                    str(id_) + '/' + str(size) + '/20?q=' + str(page_slug2)
                data = {'position': position, 'id_': id_, 'page_slug2': page_slug2,
                        'pagination_url': next_url, 'size': size, 'category_hierarchy': catagory_hierarchys}
                yield Request(next_url, headers=headers, callback=self.link_crawl, meta=data, dont_filter=True)
        client.close()
