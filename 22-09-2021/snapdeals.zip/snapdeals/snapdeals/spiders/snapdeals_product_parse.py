# -*- coding: utf-8 -*-
import re
import pika
import json
import scrapy
import logging
from snapdeals.items import *
from snapdeals.settings import *
from datetime import datetime
from scrapy.http import Request
from pymongo import MongoClient
from snapdeals.proxy import parse_proxy


headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
           'Accept-Encoding': 'gzip, deflate, br',
           'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
           'Upgrade-Insecure-Requests': '1',
           'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.87 Safari/537.36'}

logger = logging.getLogger('pika')
logger.propagate = False
# MONGODB_DB = 'meesho_weekly_2021_07_22'
MONGODB_DB = 'meesho_weekly_2021_07_29'
MONGODB_COLLECTION = 'snapdeal_com_data'
client = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
try:
    client.admin.command("enablesharding", MONGODB_DB)
except:
    pass
try:
    client.admin.command(
        "shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION, key={'product_url': 1}, unique=True)
except:
    pass
db = client[MONGODB_DB]


class ProductParserSpider(scrapy.Spider):
    name = 'product_parser_snapdeals'

    def start_requests(self):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        while True:
            connection = pika.BlockingConnection(pika.ConnectionParameters(
                credentials=credentials, host=QUEUE_IP, socket_timeout=300))
            channel = connection.channel()
            channel.basic_qos(prefetch_count=1)
            method, properties, body = channel.basic_get(
                queue=QUEUE_NAME)
            data = json.loads(body.decode("utf-8"))
            if data:
                url = data.get('url')
                meta = data
                if url.strip():
                    yield Request(url,  headers=headers, callback=self.product_parse, meta=meta, dont_filter=True)
            channel.basic_ack(delivery_tag=method.delivery_tag)
        connection.close()

        # url = "https://www.snapdeal.com/product/canary-london-green-blazer/686724321070"

    def product_parse(self, response):
        position = response.meta.get('position')
        main_url = response.meta.get('main_url')
        category = response.meta.get('category_hierarchy')
        deliverable = response.meta.get('deliverable')
        product_url = response.meta.get('url')
        TITLE_XPATH = '//h1[@itemprop="name"]/text()'
        PRICE_XPATH = '//input[@id="productPrice"]/@value'
        PRICE_XPATH_2 = '//span[@itemprop="price"]/text()'
        BRAND_XPATH = '//input[@id="brandName"]/@value'
        COLOR_XPATH = '//h1/span//text()'
        BREADCRUMBS_XPATH = '//div[@id="breadCrumbWrapper"]//span[@itemprop="title"]/text() | //div[@id="breadCrumbWrapper"]//span[@class="active-bread"]/text()'
        RATING_COUNT_XPATH = '//span[@itemprop="ratingCount"]/text()'
        AVERAGE_RATING_XPATH = '//span[@itemprop="ratingValue"]/text()'
        SELLER_XPATH = '//a[@class="pdp-e-seller-info-name reset-margin fnt-14"]/text()'
        OFFER_XPATH = '//span[@class="pdp-e-i-MRP-r-dis"]/text()'
        # SIZE_XPATH = '//div[@id="sizeChartData"]/text()'
        STOCK_AVAILABILITY_XPATH = '//div[@id="add-cart-button-id"]/span[@class="intialtext"]/text()'
        MRP_XPATH = '//div[@class="pdp-e-i-MRP  "]//s[@class="strike"]/span/text()'
        REVIEW_XPATH = '//span[@itemprop="reviewCount"]/text()'
        PRODUCT_ID_XPATH = '//input[@id="productId"]/@value'
        DELIVERY_DATE_XPATH = '//p[@class="expect-delvry "]/span/text()'
        IMAGE_XPATH = '//section[@class="pdp-section clearfix"]//img[@itemprop="image"]/@src'
        DELIVERY_COST_XPATH = '//input[@id="shippingCharges"]/@value'

        PRODUCT_DETIALS_XPATH = '//div[@class="spec-body p-keyfeatures"]/ul[@class="dtls-list clear"]/li/span/text()'
        COLOR_AVAILABILITY_XPATH = '//div//li[contains(@id,"color")]//text()'

        name = response.xpath(TITLE_XPATH).extract()
        brand = response.xpath(BRAND_XPATH).extract()
        mrp = response.xpath(MRP_XPATH).extract()
        price = response.xpath(PRICE_XPATH).extract()
        breadcrumbs_detials = response.xpath(BREADCRUMBS_XPATH)
        average_rating = response.xpath(AVERAGE_RATING_XPATH).extract()
        count = response.xpath(RATING_COUNT_XPATH).extract()
        review_count = response.xpath(REVIEW_XPATH).extract()
        seller_name = response.xpath(SELLER_XPATH).extract()
        offer = response.xpath(OFFER_XPATH).extract()
        product_id = response.xpath(PRODUCT_ID_XPATH).extract_first('')
        image = response.xpath(IMAGE_XPATH).extract()
        delivery_date = response.xpath(DELIVERY_DATE_XPATH).extract()
        delivery_cost = response.xpath(DELIVERY_COST_XPATH).extract()
        # size = response.xpath(SIZE_XPATH).extract()

        color = response.xpath(COLOR_XPATH).extract()
        product_detials = response.xpath(PRODUCT_DETIALS_XPATH).extract()

        title = [x.strip() for x in name if x.strip()]
        title = ''.join(title)
        brand = brand[0].strip() if brand else 'N/A'
        price = price[0].strip().replace(
            '₹', '').replace(',', '') if price else 'N/A'
        if mrp:
            mrp = mrp[0].strip().replace(',', '')
        else:
            mrp = price

        if mrp:
            mrp = float(mrp)
        else:
            mrp = float(0)

        if price:
            price = float(price)
        else:
            price = float(0)

        breadcrumbs_list = response.xpath(BREADCRUMBS_XPATH).extract()
        breadcrumbs_list = breadcrumbs_list[1:]
        breadcrumbs = {}
        length = 1
        for items in breadcrumbs_list:
            breadcrumbs.update(
                {'l'+str(length): items})
            if length == 4:
                break
            length += 1

        if not breadcrumbs:
            breadcrumbs = category
        average_rating = average_rating[0].strip() if average_rating else 0
        rating = count[0].split(' ratings')[0] if count else 0
        review_count = review_count[0] if review_count else '0'
        if review_count == 0:
            review_count = '0'
        # size_list = []
        size_list = response.xpath(
            '//div[@class="attr-val"]//text()').extract()
        # if size:
        #     size_json = json.loads(size[0])
        #     for s in size_json:
        #         size_ = size_json.get(s)
        #         if 'Size' not in size_[0] and 'SIZE' not in size_[0]:
        #             size_list.append(size_[0])
        #             print(size_list,'999999999999')
        # else:
        # size_re = re.findall("\[.*?\]",size[0])
        # sizes = [x.replace('[",",",","]','') for x in size_re if x.strip()]
        # sizes = [x.strip() for x in sizes if x.strip()]
        # for s in sizes:
        #     if 'SIZE' not in s and 'Size' not in s:
        #         size_ = s.replace("[","").replace("]","").replace("\"","").replace('"','').split(",")
        #         size_new = ', '.join(size_)
        #         print(size_new,'llllllllllllll')
        #         size_list.append(size_new)
        #         print(size_list,'55555555555555')

        # else:
        #     size_list = 'N/A'

        if average_rating:
            average_rating = float(average_rating)
        else:
            average_rating = float(0)

        if review_count:
            review_count = int(review_count)
        else:
            review_count = 0
        if rating:
            rating = int(rating)
        else:
            rating = 0

        seller_name = seller_name[0].strip() if seller_name else 'N/A'
        if offer:
            offer = offer[0].strip().replace('off', '')
            if offer:
                offer = offer + '%'
        else:
            offer = 'N/A'

        color = 'N/A'
        product_detials1 = {}
        for item in product_detials:
            if 'Color' in item:
                color = item.split(':')[1]
            data = item.strip().split(':')
            if len(data) > 1:
                product_detials1[data[0].replace('.', '')] = data[1]

        other_images = []
        if image:
            image_url = image[0]
            if len(image) > 1:
                other_images = image[1:]
            else:
                other_images = 'N/A'
        else:
            image_url = 'N/A'
            other_images = 'N/A'

        delivery_date = delivery_date[0].strip() if delivery_date else 'N/A'
        if delivery_cost:
            delivery_cost = "".join(delivery_cost)
            delivery_cost = delivery_cost.replace('₹', '')
            delivery_cost = int(delivery_cost)
            if delivery_cost == 9:
                delivery_cost = 0
            else:
                delivery_cost = 0
        else:
            delivery_cost = 0

        # product_url = response.url

        color_availability = 'N/A'

        stock_availability_text = response.xpath(
            STOCK_AVAILABILITY_XPATH).extract()
        stock_availability_text = ' '.join(
            ' '.join(stock_availability_text).split()).strip() if stock_availability_text else 'N/A'
        stock_availability_text = stock_availability_text.lower()
        if 'add to cart' in stock_availability_text:
            stock_availability = 'Available'
        else:
            stock_availability = 'Unavailable'

        if stock_availability == 'Available':
            sold_out = 'false'
        else:
            sold_out = 'true'

        last_visited = datetime.now(
        ).isoformat().split('.', 1)[0].replace('T', ' ')
        # if deliverable == '':
        #     deliverable = 'Deliverable'
        others = {'brand_name': str(brand), 'other_images': other_images, 'colour': color, 'sizes_available': size_list, 'colors_available': color_availability,
                  'description': product_detials1, 'review_count': review_count, 'seller_name': str(seller_name),
                  'stock_availability': stock_availability
                  }

        item_data = SnapdealsItem()
        item_data['catalog_name'] = title
        item_data['catalog_id'] = product_id
        item_data['product_id'] = product_id
        item_data['source'] = 'snapdeal'
        item_data['scraped_date'] = last_visited
        item_data['product_name'] = str(title)
        item_data['image_url'] = image_url
        item_data['category_hierarchy'] = breadcrumbs
        item_data['product_price'] = price
        item_data['arrival_date'] = 'N/A'
        item_data['shipping_charges'] = delivery_cost
        item_data['is_sold_out'] = sold_out
        item_data['discount'] = offer
        item_data['mrp'] = mrp
        item_data['page_url'] = 'N/A'
        item_data['product_url'] = product_url
        item_data['number_of_ratings'] = rating
        item_data['avg_rating'] = average_rating
        item_data['position'] = position
        item_data['country_code'] = 'IN'
        item_data['others'] = others
        logging.warning(item_data)
        db[MONGODB_COLLECTION].insert(dict(item_data, check_keys=False))
        client.close()
