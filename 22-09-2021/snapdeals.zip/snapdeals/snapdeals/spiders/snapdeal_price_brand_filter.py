import scrapy
from snapdeals.items import *
from snapdeals.settings import *
import re
from snapdeals.proxy import parse_proxy
import os
import sys
import pika
import logging
import json
from scrapy.http import Request

from pymongo import MongoClient

headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
           'Accept-Encoding': 'gzip, deflate, br',
           'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
           'Upgrade-Insecure-Requests': '1',
           'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.87 Safari/537.36'}
logger = logging.getLogger('pika')
logger.propagate = False
MONGODB_DB = 'meesho_weekly_2021_07_29'
MONGODB_COLLECTION = 'snapdeal_com_pricesplit'
client = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
try:
    client.admin.command("enablesharding", MONGODB_DB)
except:
    pass
try:
    client.admin.command(
        "shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION, key={'_id': 1}, unique=True)
except:
    pass
db = client[MONGODB_DB]


class SnapDealSpider(scrapy.Spider):
    name = 'snapdeal_brand_filter'

    def start_requests(self):
        start_urls = [
            'https://www.snapdeal.com/products/women-apparel-suits?sort=plrty',
            'https://www.snapdeal.com/products/mens-tshirts-polos?sort=plrty',
            'https://www.snapdeal.com/products/casual-shirts?sort=plrty',
            'https://www.snapdeal.com/products/formal-shirts?sort=plrty',
            'https://www.snapdeal.com/products/men-apparel-jeans?sort=plrty',
            'https://www.snapdeal.com/products/men-apparel-trousers?sort=plrty',
            'https://www.snapdeal.com/products/men-apparel-sports-wear?sort=plrty',
            'https://www.snapdeal.com/products/men-apparel-trackpants-tracksuits?sort=plrty',
            'https://www.snapdeal.com/products/men-apparel-innerwear?sort=plrty',
            'https://www.snapdeal.com/products/men-apparel-suitings-shirtings?sort=plrty',
            'https://www.snapdeal.com/products/men-apparel-shorts-cargos?sort=plrty',
            'https://www.snapdeal.com/products/mens-winter-wear-store?sort=plrty', ]
        for start_url in start_urls:
            yield scrapy.Request(start_url, headers=headers, callback=self.parse, meta={'start_url': start_url}, dont_filter=True)
        # credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        # while True:
        #     connection = pika.BlockingConnection(pika.ConnectionParameters(
        #         credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        #     channel = connection.channel()
        #     channel.basic_qos(prefetch_count=1)
        #     method, properties, body = channel.basic_get(queue=QUEUE_NAME)
        #     channel.basic_ack(delivery_tag=method.delivery_tag)
        #     data = json.loads(body.decode('utf-8'))
        #     if data:
        #         url = data.get('url')
        #         meta = {'position': 0,'pagination_url':data.get('pagination_url',''),'size':0,'category_hierarchy':'','high_price_new': 3025, 'low_price_new': 229}
        #         if url.strip():
        #             yield Request(url, headers=headers, callback=self.split_parse, meta=meta, dont_filter=True)

    def parse(self, response):
        start_url = response.meta.get('start_url')
        low_price = response.xpath(
            '//span[@class="from-price-text"]//text()').extract()
        low_price = low_price[0].replace('Rs. ', '')
        low_price = int(low_price)
        high_price = response.xpath(
            '//span[@class="to-price-text"]//text()').extract()
        high_price = high_price[0].replace('Rs. ', '')
        high_price = int(high_price)
        yield scrapy.Request(start_url, headers=headers, callback=self.split_parse, dont_filter=True, meta={'position': 0, "main_url": start_url, "high_price_new": high_price, "low_price_new": low_price, "start_url": start_url})

    def split_parse(self, response):
        # print("@@@@@@@@ looping @@@@@@@@@")
        low_price_new = response.meta.get('low_price_new')
        high_price_new = response.meta.get('high_price_new')
        position = response.meta.get('position')
        start_url = response.meta.get('start_url')
        main_url = response.meta.get('main_url')
        low_price1 = response.xpath(
            '//span[@class="from-price-text"]//text()').extract()
        low_price1 = low_price1[0].replace('Rs. ', '')
        low_price1 = int(low_price1)
        high_price1 = response.xpath(
            '//span[@class="to-price-text"]//text()').extract()
        high_price1 = high_price1[0].replace('Rs. ', '')
        high_price1 = int(high_price1)
        # pagination_url = response.meta.get('pagination_url','')
        # size = response.meta.get('size')
        # catagory_hierarchys = ''
        # catagory_hierarchys = response.meta.get('category_hierarchy')

        if response.status == 200 and low_price_new == low_price1 and high_price_new == high_price1:

            SPLIT_XPATH = '//span[@class="category-count"]//text()'

            split_urls = response.xpath(SPLIT_XPATH).extract()

            if split_urls:

                product_count = split_urls[0].replace(
                    '\r', '').replace('\t', '').replace('\n', '')
                product_count = product_count.split(
                    '+')[0].replace('(', '').replace('Items)', '').replace('Item)', '')
                product_count = int(product_count.replace(',', ' '))
                # print(product_count, '111111111111111')

                if product_count >= 2000:
                    # checking count less than 2000

                    high_price = high_price_new

                    low_price = low_price_new
                    # print(low_price, high_price, '2222222222222')
                    if round(high_price - low_price, 2) > 1:

                        avg_price = round(int(low_price + high_price) / 2)

                        split_prices = [(low_price, avg_price),

                                        (avg_price + 1, high_price)]
                        # print(split_prices, '111111111111111111111')

                        for low_price_new, high_price_new in split_prices:
                            if high_price_new > low_price_new:
                                direct_url = start_url + '&q=Price%3A' + \
                                    str(low_price_new) + '%2C' + \
                                    str(high_price_new) + '%7C'
                                yield scrapy.Request(direct_url, headers=headers, callback=self.split_parse, dont_filter=True, meta={'position': position, "main_url": main_url, 'low_price_new': low_price_new, 'high_price_new': high_price_new, "start_url": start_url})
                    else:
                        # if greater than 2000 filetring with brands
                        # print('start filetring with brands.....######')
                        filters = response.xpath(
                            '//input[contains(@value,"filters")]/@value').extract_first()
                        filters_data = json.loads(filters)
                        for data in filters_data.get('filters'):
                            if data.get('name') == 'Brand':
                                for values in data.get('displayValues'):
                                    brand = values.get('value')
                                    value = "Price:" + \
                                        str(low_price) + "," + \
                                        str(high_price) + \
                                        "|Brand:" + brand + "|"
                                    params = {"q": value}
                                    yield scrapy.FormRequest(main_url, headers=headers, callback=self.split_parse, formdata=params, method="GET", meta={'position': position, "main_url": main_url, 'low_price_new': low_price_new, 'high_price_new': high_price_new, "start_url": start_url})
                else:
                    print(product_count, 'item to collection')
                    url = response.url
                    items = SnapdealsLinkCrawlItem()
                    items['url'] = url
                    db[MONGODB_COLLECTION].insert(dict(items))
                    # print(url)
        client.close()
