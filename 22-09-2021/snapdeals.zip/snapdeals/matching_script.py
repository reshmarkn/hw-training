from pymongo import MongoClient
import pymongo

client = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')

DB_NAME = "SQS_Testing_snapdeals09_14"
col_up = "snapdeal_com_data_09_14"
col_match = "snapdeal_com_link_crawl_data_09_14"
filist = ['position']

db = client[DB_NAME]
entry = []
for i in db[col_match].find({}):
    entry.append(i)

for item in entry:
    itemdict = dict()

    for i in filist:
        print(i, '###')
        itemdict[i] = item.get(i)

    url = item['url']

    client = MongoClient(
        'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
    db = client[DB_NAME]

    db[col_up].update_one({'product_url': url}, {"$set": itemdict})
    print(url, itemdict)
