from pymongo import MongoClient
from datetime import datetime
import csv
import json
import requests
import subprocess
from bson import objectid, json_util
import pytz
import re
import ast

# DB_NAME = 'meesho_weekly_2021_07_29'
DB_NAME = 'SQS_Testing_snapdeals09_14'

db = client = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')[DB_NAME]
# MONGODB_COLLECTION_PRODUCT = 'snapdeal_com_data'
MONGODB_COLLECTION_PRODUCT = 'snapdeal_com_data_09_14'

today = str(datetime.now(pytz.timezone('Asia/Kolkata'))
            ).split(' ')[0].replace('-', '_')
COLLECTION_NAME = MONGODB_COLLECTION_PRODUCT + '_' + today
file_name = today.replace('_', '-')

# COLLECTION_NAME = 'snapdeal_com_data'
COLLECTION_NAME = 'snapdeal_com_data_09_14'


print(COLLECTION_NAME)
file = open('snapdeal_' + file_name, 'a')
writer = csv.writer(file, delimiter=";",
                    quoting=csv.QUOTE_NONE, quotechar="")
# fields = ['others']
# file.write('competitor_price;competitor_image_url;product_name;available_sizes;description_map;source;shipping_charge;l1_name;l2_name;l3_name;scraped_date;description;product_id;source_url;seller_name;seller_link;seller_city;catalog_name;catalog_id;position'+'\n')
fields = ['product_id', 'catalog_name', 'catalog_id', 'source', 'scraped_date', 'product_name',
          'image_url', 'category_hierarchy', 'product_price', 'arrival_date',
          'shipping_charges', 'is_sold_out', 'discount', 'mrp', 'page_url', 'product_url', 'number_of_ratings', 'avg_rating',
          'position', 'country_code', 'others']
writer.writerow(fields)
count = 0
limit = 50000
number = 1
# file = open(file_name+'.csv', 'a')
# writer = csv.writer(file, delimiter=";", quotechar='"', doublequote=False)

for item in db[COLLECTION_NAME].find(no_cursor_timeout=True):
    # for item in range(db[COLLECTION_NAME][:250:
    # item = db.product_sample_data_final_1.find_one(
    #     {'product_id': 'SARFD95YHPHYXDWP'})
    product_id = item.get('product_id', '')
    catalog_name = item.get('product_name', '').replace(
        ';', '').replace('\\', '').replace('"', '\\"')
    catalog_name = ' '.join(catalog_name.split()).replace('é', 'e')
    catalog_id = item.get('product_id', '')
    # if catalog_id == '':
    #     catalog_id = 'N/A'
    source = item.get('source', '').lower()
    scraped_date = item.get('scraped_date', '')
    product_name = item.get('product_name', '').replace(
        ';', '').replace('\\', '').replace('"', '\\"').replace('é', 'e')
    product_name = ' '.join(product_name.split())
    image_url = item.get('image_url', '')
    category_hierarchy = item.get('category_hierarchy', '')
    product_price = item.get('product_price', '')
    deliverable = item.get('Deliverable/Undeliverable', '')
    # print(product_price)
    product_price = str(product_price).replace(',', '').replace('%', '')
    if product_price != 'N/A':
        product_price = float(product_price)
    if product_price == '0%':
        product_price = 'N/A'
    if product_price == 0:
        product_price = 'N/A'
    arrival_date = item.get('arrival_date', '')
    if not arrival_date:
        arrival_date = 'N/A'
    shipping_charges = item.get('shipping_charges', '')
    shipping_charges = str(shipping_charges).replace('₹', '')
    shipping_charges = int(shipping_charges)
    # if shipping_charges == 0:
    #     shipping_charges = 'N/A'
    is_sold_out = item.get('is_sold_out', '')
    is_sold_out = is_sold_out.lower()
    discounts = item.get('discount', '')
    discount = discounts
    if discount == '0%':
        discount = 'N/A'
    # if '%' not in str(discount):
    #     discount = str(discount)+'%'
    # if discount == 0:
    #     discount = '0%'
    mrp = item.get('mrp', '')
    mrp = str(mrp).replace(',', '').replace('%', '')
    if mrp != 'N/A':
        mrp = float(mrp)
    if mrp == 0:
        mrp = 'N/A'
    page_url = str(item.get('page_url', ''))
    if not page_url:
        page_url = 'N/A'
    product_url = str(item.get('product_url', ''))
    number_of_ratings = item.get('number_of_ratings', '')
    number_of_ratings = str(number_of_ratings).replace(',', '')
    number_of_ratings = int(number_of_ratings)
    # if number_of_ratings == 0:
    #     number_of_ratings = 'N/A'
    avg_rating = item.get('avg_rating', '')
    avg_rating = float(avg_rating)
    # if avg_rating == 0:
    #     avg_rating = 'N/A'
    # if not avg_rating:
    #     avg_rating = 0
    position = item.get('position', '')
    position = str(position).replace(',', '')
    position = int(position)
    others = item.get('others', '')
    country_code = 'IN'
    # others['deliverable/undeliverable'] = deliverable
    # print(item['others'].keys())
    # print(others['description'])
    # others = str(item.get('others', ''))
    # other = json.dumps(others)
    # other = other.replace(';', '').replace(r'\\x83Ã', '').replace(
    #     r'\\x82Ã', '').replace(r'\\x8', '').replace('Ã', '')
    # print('^^^^^^^^^^^^^^^^^^^^^^', other)
    # check = item.get('others').get('description')
    # print(check)

    # description = ast.literal_eval(item['others']['description'])
    description = item['others']['description']

    for key, value in description.items():
        description[key] = re.sub(r'[^\x00-\x7F]+', '', value)
    item['others']['description'] = description
    if description == {}:
        description = 'N/A'
    # size = item['others']['sizes_available']
    # if size != 'N/A':
    #     print(size)
    #     sizes = size.replace('[', '').replace(']', '').replace("'", '')
    #     item['others']['sizes_available'] = sizes.split(',')
    # color = item['others']['colors_available']
    # if color != 'N/A':
    #     colors = ast.literal_eval(color)
    # colors = color.replace('[', '').replace(']', '').replace(
    #     "'", '').replace('\\', ' ').replace('./', '')
    # colors = colors.split(',')
    # colors = [content.strip() for content in colors if content.strip()]
    # colors = list(filter(None, colors))
    # item['others']['colors_available'] = colors
    # print(colors)
    check = item['others']['description']
    if check:
        descriptions = item['others']['description']
        descriptions = {' '.join(str(key).split()): ' '.join(
            str(value).split()) for key, value in descriptions.items()}
        descriptions = {str(key).replace('\\', ' ').replace('é', 'e'): str(value).replace(
            '\\', ' ').replace('é', 'e') for key, value in descriptions.items()}
        item['others']['description'] = descriptions
    if check == {}:
        item['others']['description'] = 'N/A'
    colors_available = item['others']['colors_available']
    if colors_available != 'N/A':
        colors_available = [' '.join(colors.split())
                            for colors in colors_available]
        item['others']['colors_available'] = colors_available
    # print(item['others']['colors_available'])
    # print('AAAAAAAAA', type(description))
    # other = others.replace(r'\\x83Ã', '').replace(r'\\x82Â', '').replace(r'\\x82Ã', '').replace(r'\\x83Â', '').replace(
    #     r'\\x80Ã', '').replace(r'\\x80Ã', '').replace(r'¢Ã', '').replace(r'\x9d', '').replace(r'Ã', '').replace(r'\\Ã', '').replace('\\3Â', '').replace('\\2Â', '').replace('3Â', '').replace('2Â', '')
    # print('!!!!!!!!!!!!!!!!!!!!', other)
    # others = json.loads(other)
    if '&' in product_id:
        product_id = product_id.split('&')[0]
    if '&' in catalog_id:
        catalog_id = catalog_id.split('&')[0]
    # others = dict(map(str.strip, x) for x in others.items())
    # others = {key.strip(): item.strip() for key, item in others.items()}
    # others = json.dumps(others).replace(';', '')
    others = json.dumps(others, ensure_ascii=False)
    others = others.replace(';', '').replace('\\\\\\', '').replace('\\\\', '')

    # others = ' '.join(others).strip()
    # others = json.loads(others)
    if category_hierarchy != 'N/A':
        category_hierarchy = json.dumps(category_hierarchy)
        category_hierarchy = category_hierarchy.replace(';', '')
        category_hierarchys = json.loads(category_hierarchy)
        category_hierarchy = {}
        for key in sorted(category_hierarchys.keys()):
            if key <= 'l4':
                category_hierarchy.update({key: category_hierarchys[key]})
        category_hierarchy = json.dumps(category_hierarchy, sort_keys=True)
        category_hierarchy = category_hierarchy.replace('é', 'e')
        # print(category_hierarchy)
    # with open('flipkart_2019_12_05_others.txt', 'a') as f7:
    #     f7.write(others + '\n')

    # with open('category_hierarchy_12_05.txt', 'a') as f8:
    #     f8.write(category_hierarchy + '\n')
    # if category_hierarchy != 'N/A':
    #     category_hierarchy = json.dumps(category_hierarchy)
    #     category_hierarchy = category_hierarchy.replace(';', '')
        # category_hierarchy = json.loads(category_hierarchy)
    data = [product_id, catalog_name, catalog_id, source, scraped_date, product_name,
            image_url, category_hierarchy, product_price, arrival_date,
            shipping_charges, is_sold_out, discount, mrp, page_url, product_url, number_of_ratings, avg_rating,
            position, country_code, others]
    # row_data = ';'.join(data)+'\n'
    # count += 1
    # if count != limit:

    #     writer.writerow(data)
    # # file.write(row_data)
    # else:
    #     number += 1
    #     file = open(file_name+'_'+str(number)+'.csv', 'a')

    # # file.write('competitor_price;competitor_image_url;product_name;available_sizes;description_map;source;shipping_charge;l1_name;l2_name;l3_name;scraped_date;description;product_id;source_url;seller_name;seller_link;seller_city;catalog_name;catalog_id;position'+'\n')
    #     fields = ['product_id', 'catalog_name', 'catalog_id', 'source', 'scraped_date', 'product_name',
    #               'image_url', 'category_hierarchy', 'product_price', 'arrival_date',
    #               'shipping_charges', 'is_sold_out', 'discount', 'mrp', 'page_url', 'product_url', 'number_of_ratings', 'avg_rating',
    #               'position', 'others']
    # print(data)
    if product_name:
        if len(product_name) < 500 and len(product_url) < 500:

            writer.writerow(data)
#     # limit += 50000

file.close()
# limit += 50000
files = 'snapdeal_' + file_name
new_filename = files + '.csv'
subprocess.Popen('native2ascii -encoding UTF-8 -reverse %s   %s ' %
                 (files, new_filename), shell=True)


# a = db.snapdeal_com_data_08_17.find({"position":""}).count()
