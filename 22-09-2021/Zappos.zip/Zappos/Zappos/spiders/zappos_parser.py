import scrapy
from scrapy.http import Request
from scrapy.exceptions import CloseSpider
from ..items import ZapposparserItem
import pika
import logging
import requests

logger = logging.getLogger('pika')
logger.propagate = False

headers = {
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "accept-encoding": "gzip, deflate, br",
        "accept-language": "en-US,en;q=0.9",
        "upgrade-insecure-requests": "1",
        "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36"
        }



class ZapposSpider(scrapy.Spider):
    name = 'zappos_parser'

    def start_requests(self):
        credentials = pika.PlainCredentials('guest','guest')
        connection = pika.BlockingConnection(pika.ConnectionParameters( host='localhost', socket_timeout=300))
        channel = connection.channel()
        while True:
            channel.basic_qos(prefetch_count=1)
            method, properties, url = channel.basic_get(queue='zapos')
            if not url.strip():
                break
            channel.basic_ack(delivery_tag=method.delivery_tag)
            url = str(url.strip(), encoding='utf-8')
            if url.strip():
                link = url
                # link = url.split('--')[0]
                # category = url.split('--')[1]
                # meta = {'category':category}
                yield Request(url=link.strip(), callback=self.parse, headers=headers)
            break
            
        connection.close()
    
    def parse(self, response):
        
        #XPATH

        product_brand = response.xpath("//*[@id='overview']/h1/div/span[1]/a/span/text()").extract_first()
        product_name = response.xpath("//*[@id='overview']/h1/div/span[2]/text()").extract_first()
        product_price = response.xpath("//div[@id='productRecap']/div/div[2]//div/div/div/div/span[1]/span//text()").extract()
        product_discount = response.xpath("//div[@id='productRecap']/div/div[2]//div/div/div/div/span[2]/span[1]//text()").extract()
        product_MSRP = response.xpath("//div[@id='productRecap']/div/div[2]//div/div/div/div/span[2]/span[2]/span[2]//text()").extract_first()
        available_colours = response.xpath("//select[@id='pdp-color-select']/option//text()").extract()
        product_reviews = response.xpath("//a[@href='/product/review/9399689']/span[2]//text()").extract()
        product_image = response.xpath("//div[@id='productImages']/div/div/div/div/div/button/span/img/@src").extract_first()
        product_description =  response.xpath('//div[@itemprop="description"]//div/ul/li/text()').extract()

        
       #  #CLEAN

       #  product_price = ''.join(product_price).replace('$','') if product_price else ''
       #  product_discount = ''.join(product_discount) if product_discount else ''
       #  product_MSRP = ''.join(product_MSRP).replace('$','') if product_MSRP else ''
       #  product_reviews = ''.join(product_reviews).replace('$','') if product_reviews else ''
       #  product_description = ''.join(product_description) if product_description else ''

       #  item = ZapposparserItem()
        
       #  item['PRODUCT_BRAND'] = product_brand
       #  item['PRODUCT_NAME'] = product_name
       #  item['PRODUCT_PRICE'] = product_price
       #  item['PRODUCT_DISCOUNT'] = product_discount
       #  item['PRODUCT_MSRP'] = product_MSRP
       #  item['AVAILABLE_COLOURS'] = available_colours
       #  item['PRODUCT_REVIEWS'] = product_reviews
       #  item['PRODUCT_IMAGE'] = product_image
       #  item['PRODUCT_DESCRIPTION'] = product_description
        
       #  yield item
    