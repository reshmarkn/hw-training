# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class WayfairItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()

    def __setitem__(self, key, value):
        self._values[key] = value
        self.fields[key] = {}


class WayfairLink(scrapy.Item):
    def __setitem__(self, key, value):
        self._values[key] = value
        self.fields[key] = {}


class WayfairLinkfail(scrapy.Item):
    def __setitem__(self, key, value):
        self._values[key] = value
        self.fields[key] = {}


class WayfairRedirectLink(scrapy.Item):
    def __setitem__(self, key, value):
        self._values[key] = value
        self.fields[key] = {}


class WayfairItemPart1(scrapy.Item):
    def __setitem__(self, key, value):
        self._values[key] = value
        self.fields[key] = {}
