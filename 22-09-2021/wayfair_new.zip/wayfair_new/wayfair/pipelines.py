import pymongo
from scrapy.exceptions import DropItem
from wayfair.items import *
from wayfair.settings import *
from pymongo import MongoClient
import logging

logging.getLogger().setLevel(logging.INFO)


def CentralPipeline():
    client = MongoClient(MONGO_URL)
    try:
        client.admin.command(
            "enablesharding", MONGO_DB)
        client.admin.command(
            "shardcollection", MONGO_DB + '.' + PRODUCT_URLS, key={'url': 1}, unique=True)
        client.admin.command(
            "shardcollection", MONGO_DB + '.' + PRODUCT_DATA, key={'URL': 1}, unique=True)
    except:
        pass

    db = client[MONGO_DB]
    return db

# MONGO_REDIRECT = 'wayfair_redirect_urls'
# #MONGO_LINK_COLLECTION = 'office_furniture'
# MONGO_PRODUCT_COLLECTION = 'wayfair_data_19_06_2020'
# MONGO_PRODUCT_FAIL = 'wayfair_product_fail_16_07_20'
# MONGO_PART_ONE_COLLECTION = 'wayfair_part_one_products'


# class WayfairPipeline(object):
#     def __init__(self):
#         self.client = MongoClient(MONGO_URI)
#         self.db = self.client[MONGO_DB]
#         self.db_fail = self.client[MONGO_FAIL]
#         self.db_part_one = self.client[MONGO_PART_ONE]
#         #self.db[MONGO_LINK_COLLECTION].create_index('url', unique=True)
#         self.db[MONGO_PRODUCT_COLLECTION].create_index('URL', unique=True)
#         self.db_fail[MONGO_PRODUCT_FAIL].create_index('url', unique=True)

#     def process_item(self, item, spider):
#         # if isinstance(item, WayfairLink):

#         #     try:
#         #         self.db[MONGO_LINK_COLLECTION].insert(dict(item))
#         #     except:
#         #         raise DropItem("Dropping duplicate item")

#         if isinstance(item, WayfairItem):
#             try:
#                 self.db[MONGO_PRODUCT_COLLECTION].insert(dict(item))
#             except:
#                 raise DropItem("Dropping duplicate item")

#         if isinstance(item, WayfairLinkfail):
#             try:
#                 self.db_fail[MONGO_PRODUCT_FAIL].insert(dict(item))
#             except:
#                 raise DropItem("Dropping duplicate item")

#         if isinstance(item, WayfairRedirectLink):
#             try:
#                 self.db[MONGO_REDIRECT].insert(dict(item))
#             except:
#                 raise DropItem("Dropping duplicate item")

#         if isinstance(item, WayfairItemPart1):
#             try:
#                 self.db_part_one[MONGO_PART_ONE_COLLECTION].insert(dict(item))
#             except:
#                 raise DropItem("Dropping duplicate item")

#         return item
