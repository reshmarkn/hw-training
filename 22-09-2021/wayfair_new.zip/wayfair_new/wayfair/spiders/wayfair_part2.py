import scrapy
from wayfair.items import *
from datetime import datetime
from pymongo import MongoClient
from wayfair.settings import *
from scrapy.shell import inspect_response
from scrapy.http import Request, FormRequest
import re
import json
import pika
import requests
import logging

MONGO_URI = 'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017'
MONGO_PART_ONE = 'daria_wayfair_part_one'
db = MongoClient(MONGO_URI)[MONGO_PART_ONE]
MONGO_PART_ONE_COLLECTION = 'wayfair_part_one_products'


class WayfairSpider(scrapy.Spider):
    name = 'wayfair_spider_part2'
    handle_httpstatus_list = [200, 404]

    def start_requests(self):
        for item in db[MONGO_PART_ONE_COLLECTION].find(no_cursor_timeout=True):
            product_url = item.get('URL')
            sku = item.get('Manufacturer Part Number')
            options = item.get('selectedOptions')

            url = 'https://www.wayfair.com/graphql?queryPath=specifications_queries~0%23prop65_queries~1'

            headers = {
                "accept": "application/json",
                "accept-encoding": "gzip, deflate, br",
                "accept-language": "en-GB,en-US;q=0.9,en;q=0.8,ml;q=0.7",
                "content-type": "application/json",
                "origin": "https://www.wayfair.com",
                "referer": product_url,
                "use-path": "true",
                "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36",
                "x-parent-txid": "I+F9Ol6F84spIwwP/+KMAg="
            }

            payload = '{"query":"specifications_queries~0#prop65_queries~1","variables":{"sku":"' + \
                sku+'","selectedOptionIds":['+options+']}}'

            meta = {'product_url': product_url}

            yield FormRequest(url=url, headers=headers, method="POST", body=payload, callback=self.parse_product_data, meta=meta)

    def parse_product_data(self, response):
        origin = {}
        if response.status == 200:
            a = json.loads(response.body_as_unicode())
            specific = ''
            jspecific = ''
            jspecific = a.get('data')
            if jspecific:
                specific = jspecific.get('product').get('displayInfo').get(
                    'specificationCategories')[0].get('specifications')
                if specific:
                    for s in specific:
                        for j in s:
                            if j["title"] == "Country of Origin":
                                Country_of_Origin = j["value"]
                                Country_of_Origin = Country_of_Origin if Country_of_Origin else ""
                                origin.update(
                                    {"Country_of_Origin": Country_of_Origin})
                                print('////////////////////')
        # db.MONGO_PART_ONE_COLLECTION.update({'URL': response.meta.get('product_url')}, {$set: {'Country of Origin': origin.get('Country_of_Origin')}})
        db.MONGO_PART_ONE_COLLECTION.update({},
                                            {"$set": {'Country of Origin': origin.get(
                                                'Country_of_Origin')}})

        # db.fearlessData.update({"Country": "Canada"}, {
        #                        "$set": {"Type": "Canadian_Wedding_2"}}, {"multi": true})
