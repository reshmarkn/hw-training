import scrapy
from wayfair.items import *
from datetime import datetime
from pymongo import MongoClient
from wayfair.settings import *
from scrapy.shell import inspect_response
from scrapy.http import Request, FormRequest
import re
import json
import pika
import requests
# from wayfair.proxy import parse_proxy
from scrapy.selector import Selector
import requests
import random
import logging
import cloudscraper

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False
logger = logging.getLogger(__name__)

USER_AGENT_LIST = ['Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
                   'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/600.8.9 (KHTML, like Gecko) Version/8.0.8 Safari/600.8.9',
                   'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
                   'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0',
                   'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:40.0) Gecko/20100101 Firefox/40.0',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
                   'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko',
                   'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
                   'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
                   'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/600.7.12 (KHTML, like Gecko) Version/8.0.7 Safari/600.7.12',
                   'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:40.0) Gecko/20100101 Firefox/40.0',
                   'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0',
                   'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0',
                   'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36',
                   'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36',
                   'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36',
                   'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
                   'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36',
                   'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0',
                   'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
                   'Mozilla/5.0 (Windows NT 6.1; rv:40.0) Gecko/20100101 Firefox/40.0',
                   'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
                   'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36',
                   'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
                   'Mozilla/5.0 (Windows NT 5.1; rv:40.0) Gecko/20100101 Firefox/40.0',
                   'Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko',
                   'Mozilla/5.0 (iPad; CPU OS 8_4_1 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H321 Safari/600.1.4',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.9; rv:40.0) Gecko/20100101 Firefox/40.0',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.8.9 (KHTML, like Gecko) Version/7.1.8 Safari/537.85.17',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
                   'Mozilla/5.0 (X11; Linux x86_64; rv:40.0) Gecko/20100101 Firefox/40.0',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.5.17 (KHTML, like Gecko) Version/8.0.5 Safari/600.5.17',
                   'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.130 Safari/537.36',
                   'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:39.0) Gecko/20100101 Firefox/39.0',
                   'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:38.0) Gecko/20100101 Firefox/38.0',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3',
                   'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko',
                   'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/44.0.2403.89 Chrome/44.0.2403.89 Safari/537.36',
                   'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36',
                   'Mozilla/5.0 (iPad; CPU OS 8_4 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H143 Safari/600.1.4',
                   'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)']
ua = random.choice(USER_AGENT_LIST)

HEADERS = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
    "accept-encoding": "gzip, deflate, br",
    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8,ml;q=0.7",
    "cache-control": "max-age=0",
    "upgrade-insecure-requests": "1",
    # "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36"
    "user-agent": ua
}


MONGODB_DB = 'daria_mathew_wayfair_25_06_2020'
MONGODB_COLLECTION_PYTHON = 'wayfair_python'
MONGODB_COLLECTION_FAILED = 'wayfair_python_fail'
MONGO_URI = 'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017'
db = MongoClient(MONGO_URI)[MONGODB_DB]


QUEUE_HOST = '159.89.47.171'
QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'
QUEUE_NAME = 'ha.wayfair_python_test'

try:
    client.admin.command(
        "shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION_FAILED, key={'part_number': 1}, unique=True)
except:
    pass


class WayfairSpider(scrapy.Spider):
    name = 'wayfair_spider_python'

    def start_requests(self):
        global ua

        PROXY_LIST = requests.get('http://68.183.58.145/stormproxies',
                                  headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
        # PROXY_LIST = requests.get('http://68.183.58.145/torproxies',
        #                           headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()

        PROXY = random.choice(PROXY_LIST)
        proxy_url = "http://%s" % PROXY
        proxies = {"http": "http://%s" % PROXY,
                   "https": "http://%s" % PROXY}
        logger.debug("Proxy added")
        # scraper = cloudscraper.create_scraper(
        #     browser={
        #         'custom': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'}

        # )

        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        while True:
            connection = pika.BlockingConnection(pika.ConnectionParameters(
                credentials=credentials, host=QUEUE_HOST, socket_timeout=300))
            channel = connection.channel()
            channel.basic_qos(prefetch_count=1)
            method, properties, url = channel.basic_get(queue=QUEUE_NAME)
            if not url:
                logging.warning('Queue completed.')
                break
            url = str(url.strip(), encoding='utf-8')
            channel.basic_ack(delivery_tag=method.delivery_tag)
            if url:
                url = url.strip()
                session = requests.session()
                response = session.get(
                    url=url, headers=HEADERS, proxies=proxies)
                #response = scraper.get(url, headers=HEADERS, proxies=proxies)
                self.parse(response, url, session, ua)
        connection.close()
        # url = "https://www.wayfair.com/appliances/pdp/cafe-30-56-cu-ft-smart-freestanding-gas-range-with-griddle-geca1162.html"

        # response = requests.get(url=url, headers=HEADERS, proxies=proxies)
        #response = scraper.get(url, headers=HEADERS, proxies=proxies)

        #self.parse(response, url)

    def parse(self, response, url, session, ua):
        dataget = url
        if response.status_code == 200:
            dataget = url
            reurl = response.url
            if dataget == reurl:
                sel = Selector(text=response.content)
                # captche = sel.xpath(
                #     '//h1[@class="Captcha-title"]/text()').extract_first()

                VENDOR_XPATH = '//meta[@property="og:upc"]/@content'

                TITLE = '//meta[@property="og:title"]/@content'

                PRICE = '//div[@class="BasePriceBlock"]/span/text()|//div[@class="StandardPriceBlock"]/div[@class="BasePriceBlock BasePriceBlock--highlight"]/span/text()'
                price = sel.xpath(PRICE).extract_first()
                Price = price.replace('$', '') if price else ""

                BREAD_CRUM_XPATH = '//ol[@class="Breadcrumbs-list"]'
                CATOGORY_XPATH = 'li/a/text()'

                Brand_Name = ''.join(re.findall(
                    '"brand":"(.*?)"', str(response.content)))
                Brand_Name = Brand_Name.strip() if Brand_Name else ""

                Vendor = sel.xpath(VENDOR_XPATH).extract_first()
                Vendor_Seller_Part_Number = Vendor.strip() if Vendor else ""

                Name = sel.xpath(TITLE).extract_first()
                Item_Name = Name.strip() if Name else ""

                Description = sel.xpath(
                    '//div[@class="ProductOverviewInformation-content"]//text()').extract()
                Full_Product_Description = ''.join(Description)

                product_url = response.url

                date_crawled = (datetime.now()).strftime("%Y-%m-%dT%H:%M:%S")

                available = re.findall(
                    '"availability":"(.*?)"', str(response.content))
                if available:
                    instock = available[0].split('/')[-1]
                else:
                    instock = ''

                add_to_cart = sel.xpath(
                    '//button[@id="btn-add-to-cart"]/span[@class="Button-content"]/text()').extract()
                if add_to_cart:
                    cart = "".join(add_to_cart)
                else:
                    cart = ''

                if instock == "InStock" and cart == "Add to Cart":
                    Availability = 'available'
                else:
                    Availability = 'not available'

                bread_crum = sel.xpath(BREAD_CRUM_XPATH)
                for b in bread_crum:
                    product_cat = b.xpath(CATOGORY_XPATH).extract()
                    product_category = ' > '.join(product_cat)
                    product_category = product_category if product_category else ''

                meta = {"Brand_Name": Brand_Name, "Availability": Availability,
                        "Vendor_Seller_Part_Number": Vendor_Seller_Part_Number, "Item_Name": Item_Name, "Full_Product_Description": Full_Product_Description, "Price": Price, "product_url": product_url, "date_crawled": date_crawled, "product_category": product_category}

                sku = re.findall('"sku":"(.*?)"', str(response.content))[0]

                # selectedOptions = re.findall(
                #     '"selectedOptions":"(.*?)"', str(response.text))
                # re.findall("selectedOptions\":\[\"(.*?)\"\]",str(response.content))
                selectedOptions = sel.xpath(
                    '//input[contains(@name,"option_ids[]")]/@value').extract()
                options = ''.join(selectedOptions)

                url_ = 'https://www.wayfair.com/graphql?queryPath=specifications_queries~0%23prop65_queries~1'

                headers = {
                    "accept": "application/json",
                    "accept-encoding": "gzip, deflate, br",
                    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8,ml;q=0.7",
                    "content-type": "application/json",
                    "origin": "https://www.wayfair.com",
                    "referer": product_url,
                    "use-path": "true",
                    # "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36",
                    # "x-parent-txid": "I+F9Ol6F84spIwwP/+KMAg="
                    "user-agent": ua
                }

                payload = '{"query": "specifications_queries~0#prop65_queries~1", "variables": {"sku": "' + \
                    sku+'", "selectedOptionIds": ['+options+']}}'

                PROXY_LIST = requests.get('http://68.183.58.145/stormproxies',
                                          headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
                # PROXY_LIST = requests.get('http://68.183.58.145/torproxies',
                #                           headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
                PROXY = random.choice(PROXY_LIST)
                proxy_url = "http://%s" % PROXY
                proxies = {"http": "http://%s" % PROXY,
                           "https": "http://%s" % PROXY}
                logger.debug("Proxy added")
                # scraper = cloudscraper.create_scraper(
                #     browser={
                #         'custom': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'}

                # )
                # json_response = scraper.post(
                #     url_, headers=headers, data=payload, proxies=proxies)

                try:
                    response = session.post(
                        url=url_, headers=headers, data=payload, proxies=proxies)
                    # json_response = scraper.get(
                    #     url_, headers=headers, data=payload)
                except:
                    response = session.post(
                        url=url_, headers=headers, data=payload, proxies=proxies)
                    # json_response = scraper.get(
                    #     url_, headers=headers, data=payload)

                self.last_data(response, meta)
            else:
                part = dataget.split('-')[-1].replace('.html', '')
                url_item = WayfairLinkfail()
                url_item['url'] = dataget
                url_item['status_code'] = response.status_code
                url_item['part_number'] = part
                db[MONGODB_COLLECTION_FAILED].insert(dict(url_item))
        else:
            part = dataget.split('-')[-1].replace('.html', '')
            url_item = WayfairLinkfail()
            url_item['url'] = dataget
            url_item['status_code'] = response.status_code
            url_item['part_number'] = part
            db[MONGODB_COLLECTION_FAILED].insert(dict(url_item))

    def last_data(self, response, meta):
        #inspect_response(response, self)
        origin = {}
        Vendor_Seller_Part_Number = meta.get(
            'Vendor_Seller_Part_Number')
        url = meta.get('product_url')

        if response.status_code == 200:
            a = json.loads(str(response.content, encoding='utf-8'))
            specific = ''
            jspecific = ''
            jspecific = a.get('data')
            if jspecific:
                specific = jspecific.get('product').get('displayInfo').get(
                    'specificationCategories')[0].get('specifications')
                if specific:
                    for s in specific:
                        for j in s:
                            if j["title"] == "Country of Origin":
                                Country_of_Origin = j["value"]
                                Country_of_Origin = Country_of_Origin if Country_of_Origin else ""
                                origin.update(
                                    {"Country_of_Origin": Country_of_Origin})

                    if Vendor_Seller_Part_Number and origin.get('Country_of_Origin'):
                        item_data = WayfairItem()
                        item_data['URL'] = meta.get('product_url')
                        item_data['Item Name'] = meta.get('Item_Name')
                        item_data['Price'] = meta.get('Price')
                        item_data['Product Category'] = meta.get(
                            'product_category')
                        item_data['Full Product Description'] = meta.get(
                            'Full_Product_Description')
                        item_data['Company Name'] = 'wayfair'
                        item_data['Manufacturer Name'] = meta.get(
                            'Brand_Name')
                        item_data['Vendor/Seller Part Number'] = meta.get(
                            'Vendor_Seller_Part_Number')
                        item_data['Date Crawled'] = meta.get(
                            'date_crawled')
                        item_data['Model Number'] = ''
                        item_data['Manufacturer Part Number'] = meta.get(
                            'Vendor_Seller_Part_Number')
                        item_data['Country of Origin'] = origin.get(
                            'Country_of_Origin')
                        item_data['Unit of Issue (UOI)'] = ''
                        item_data['QTY Per UOI'] = ''
                        item_data['UPC'] = ''
                        item_data['Brand Name'] = meta.get(
                            'Brand_Name')
                        item_data['Availability'] = meta.get('Availability')
                        db[MONGODB_COLLECTION_PYTHON].insert(dict(item_data))

                        print(item_data)
                    else:
                        rurl = meta.get('product_url')
                        part = rurl.split('-')[-1].replace('.html', '')
                        url_item = WayfairLinkfail()
                        url_item['url'] = response.meta.get('url')
                        url_item['status_code'] = response.status_code
                        url_item['part_number'] = part
                        db[MONGODB_COLLECTION_FAILED].insert(dict(url_item))

            else:
                jspecific = ''
                rurl = meta.get('product_url')
                part = rurl.split('-')[-1].replace('.html', '')
                url_item = WayfairLinkfail()
                url_item['url'] = rurl
                url_item['status_code'] = response.status_code
                url_item['part_number'] = part
                db[MONGODB_COLLECTION_FAILED].insert(dict(url_item))
        else:
            rurl = meta.get('product_url')
            part = rurl.split('-')[-1].replace('.html', '')
            url_item = WayfairLinkfail()
            url_item['url'] = rurl
            url_item['status_code'] = response.status_code
            url_item['part_number'] = part
            db[MONGODB_COLLECTION_FAILED].insert(dict(url_item))
