import scrapy

from scrapy.http import Request, FormRequest
from wayfair.settings import *
from wayfair.proxy import parse_proxy
from scrapy.shell import inspect_response
from wayfair.items import *
import re


HEADERS = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
    "accept-encoding": "gzip, deflate, br",
    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8,ml;q=0.7",
    "cache-control": "max-age=0",
    "upgrade-insecure-requests": "1",
    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36"
}


class WayfairSpider(scrapy.Spider):

    name = 'wayfair_crawler'
    handle_httpstatus_list = [200, 504]

    def start_requests(self):
        # storage_extra = ['https://www.wayfair.com/storage-organization/sb0/wood-storage-cabinets-c1868698.html',
        #                  'https://www.wayfair.com/storage-organization/sb0/metal-storage-cabinets-c1868699.html',
        #                  'https://www.wayfair.com/storage-organization/sb0/metal-storage-systems-c1868702.html',
        #                  'https://www.wayfair.com/storage-organization/sb0/plastic-storage-cabinets-c1868700.html',
        #                  'https://www.wayfair.com/storage-organization/sb0/wood-storage-systems-c1868701.html']
        # for s in storage_extra:
        #     yield Request(url=s, headers=HEADERS, callback=self.parse_product_page)

        # .......................................................................
        # extra url in storage organization
        # ladder_url_storage = 'https://www.wayfair.com/storage-organization/cat/ladders-step-stools-c421860.html'
        # yield Request(url=ladder_url_storage, headers=HEADERS, callback=self.storage_parse_next)
        # ...............................................
        url = 'https://www.wayfair.com/furniture/cat/furniture-c45974.html'

        # url_list = ['https://www.wayfair.com/appliances/cat/appliances-c215602.html', 'https://www.wayfair.com/storage-organization/cat/garage-tool-storage-c421299.html',
        #             'https://www.wayfair.com/furniture/cat/office-furniture-c332627.html', 'https://www.wayfair.com/outdoor/cat/outdoor-c32334.html']
        # ...........................................................
        if "storage-organization" in url:
            yield Request(url=url, headers=HEADERS, callback=self.storage_parse_next)
        else:
            yield Request(url=url, headers=HEADERS, callback=self.parse_category)

    def storage_parse_next(self, response):
        #inspect_response(response, self)
        resurl = response.url

        if response.status == 200:
            sub_cat = response.xpath(
                '//div[@class="Grid Grid--fullBleed Grid--useNewBreakpoints u-flexWrap"]/div/div/a/@href').extract()
            for sub_link in sub_cat:
                yield Request(url=sub_link, headers=HEADERS, callback=self.parse_product_page)

    def parse_category(self, response):

        #inspect_response(response, self)
        page_url = response.url

        if response.status == 200:

            if "furniture" in page_url:
                main = response.xpath(
                    '//div[@id="332627"]/div/article/div[@class="pl-MultiCarousel CategoryCarousel-carousel"]/div/ul/li/a/@href').extract()

            elif "appliances" in page_url:

                main = response.xpath(
                    '//div[@class="CategoryRowNavigation"]//ul/li/a/@href').extract()

            elif "outdoor" in page_url:

                main = response.xpath(
                    '//div[@class="CategoryRowNavigation"]//ul/li/a/@href').extract()

            urls = [u for u in main if u != '/']

            for each_url in urls:
                if 'https://www.wayfair.com' in each_url:
                    url = each_url
                    yield Request(url=url, headers=HEADERS, callback=self.parse_product_page)
                else:
                    url = 'https://www.wayfair.com' + each_url
                    # yield Request(url=url, headers=HEADERS, callback=self.outdoor_parse_next)
                    # yield Request(url=url, headers=HEADERS, callback=self.appliance_parse_next)
                    # for furniture..............................
                    yield Request(url=url, headers=HEADERS, callback=self.parse_next)

    def outdoor_parse_next(self, response):

        resurl = response.url

        if response.status == 200:
            sub_cat = response.xpath(
                '//div[@class="Grid Grid--fullBleed Grid--useNewBreakpoints u-flexWrap"]/div/div/a/@href').extract()
            for sub_link in sub_cat:
                yield Request(url=sub_link, headers=HEADERS, callback=self.parse_product_page)

    def appliance_parse_next(self, response):

        resurl = response.url

        if response.status == 200:
            sub_cat = response.xpath(
                '//div[@class="Grid Grid--fullBleed Grid--useNewBreakpoints u-flexWrap"]/div/div/a/@href').extract()
            if sub_cat:
                for sub_link in sub_cat:
                    yield Request(url=sub_link, headers=HEADERS, callback=self.parse_product_page)
            else:

                app_urls = response.xpath(
                    '//div[@class="pl-MultiCarousel-innerWrap"]')[0]

                a_urls = app_urls.xpath('ul/li/a/@href').extract()
                a_urls = [a for a in a_urls if a != '/']

                for app in a_urls:
                    if 'https://www.wayfair.com' in app:
                        appliance_url = app

                        yield Request(url=appliance_url, headers=HEADERS, callback=self.parse_product_page)
                    else:

                        app_url = 'https://www.wayfair.com' + app

                        yield Request(url=app_url, headers=HEADERS, callback=self.appliance_parse_next)

    # def appliance_parse_next(self, response):

    #     resurl = response.url

    #     if response.status == 200:
    #         sub_cat = response.xpath(
    #             '//div[@class="Grid Grid--fullBleed Grid--useNewBreakpoints u-flexWrap"]/div/div/a/@href').extract()
    #         for sub_link in sub_cat:

    #             yield Request(url=sub_link, headers=HEADERS, callback=self.parse_product_page)

    def parse_next(self, response):

        resurl = response.url

        if response.status == 200:
            sub_cat = response.xpath(
                '//div[@class="Grid Grid--fullBleed Grid--useNewBreakpoints u-flexWrap"]/div/div/a/@href').extract()
            for sub_link in sub_cat:
                yield Request(url=sub_link, headers=HEADERS, callback=self.parse_product_page)

    def parse_product_page(self, response):
        # print('44444444444444444444444444444444')
        #inspect_response(response, self)
        #url = response.url

        next_page = response.xpath(
            '//a[@aria-label="Next"]/@href').extract()
        next_page_link = ''.join(next_page)
        psource = re.findall('\[{"sku":.*"units":".*?\]', str(response.body))
        purl = re.findall('"url":"(.*?)"', str(psource))
        for p in purl:
            prourl = p.replace('\\\\\\\\', '').replace('\\\\', '')
            part = prourl.split('-')[-1].replace('.html', '')
            url_item = WayfairLink()
            url_item['url'] = prourl
            url_item['part_number'] = part
            print(url_item)
            # yield url_item

        # product = response.xpath(
        #     '//div[@class="Grid Grid--fullBleed Grid--useNewBreakpoints u-flexWrap"]/div[@data-hb-id="pl_column"]')
        # for product_data in product:
        #     link_ = product_data.xpath(
        #         'div[@class="ProductCard-container"]/a/@href').extract()
        #     for each_link in link_:
        #         url_item = WayfairLink()
        #         url_item['url'] = each_link
        #         yield url_item

        if next_page:
            yield Request(url=next_page_link, headers=HEADERS, callback=self.parse_product_page)
