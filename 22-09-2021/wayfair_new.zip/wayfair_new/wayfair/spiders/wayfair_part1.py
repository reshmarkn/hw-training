import scrapy
from wayfair.items import *
from datetime import datetime
from pymongo import MongoClient
from wayfair.settings import *
from scrapy.shell import inspect_response
from scrapy.http import Request, FormRequest
import re
import json
import pika
import requests
import logging

HEADERS = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
    "accept-encoding": "gzip, deflate, br",
    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8,ml;q=0.7",
    "cache-control": "max-age=0",
    "upgrade-insecure-requests": "1",
    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36"
}

#db = MongoClient(MONGO_URI)[MONGO_DB]


# QUEUE_HOST = '159.89.47.171'
# QUEUE_USER = 'datahut'
# QUEUE_PASS = 'datahutqueue123'
# QUEUE_NAME = 'ha.wayfair_url'


class WayfairSpider(scrapy.Spider):
    name = 'wayfair_spider_part1'
    handle_httpstatus_list = [200, 404]

    def start_requests(self):

        # credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        # while True:
        #     connection = pika.BlockingConnection(pika.ConnectionParameters(
        #         credentials=credentials, host=QUEUE_HOST, socket_timeout=300))
        #     channel = connection.channel()
        #     channel.basic_qos(prefetch_count=1)
        #     method, properties, url = channel.basic_get(queue=QUEUE_NAME)
        #     if not url:
        #         logging.warning('Queue completed.')
        #         break
        #     url = str(url.strip(), encoding='utf-8')
        #     channel.basic_ack(delivery_tag=method.delivery_tag)
        #     if url:
        #         url = url.strip()
        #         meta = {'url': url}
        #         yield Request(url, headers=HEADERS, callback=self.parse, meta=meta)
        # connection.close()

        # errback=self.errback_httpbin(url)

        url_ = ['https://www.wayfair.com/outdoor/pdp/fleur-de-lis-living-baragrey-5-piece-dining-set-with-cushions-fdll8604.html']
        for url in url_:
            meta = {'url': url}
            yield Request(url, headers=HEADERS, callback=self.parse, meta=meta)

    def parse(self, response):
        #inspect_response(response, self)
        rurl = response.meta.get('url')
        if response.status == 200:
            dataget = response.meta.get('url')
            reurl = response.url
            # captche = response.xpath(
            #     '//h1[@class="Captcha-title"]/text()').extract_first().strip()

            if dataget == reurl:

                VENDOR_XPATH = '//meta[@property="og:upc"]/@content'
                TITLE = '//meta[@property="og:title"]/@content'

                PRICE = '//div[@class="BasePriceBlock"]/span/text()|//div[@class="StandardPriceBlock"]/div[@class="BasePriceBlock BasePriceBlock--highlight"]/span/text()'

                price = response.xpath(PRICE).extract_first()
                Price = price.replace('$', '') if price else ""

                BREAD_CRUM_XPATH = '//ol[@class="Breadcrumbs-list"]'
                CATOGORY_XPATH = 'li/a/text()'

                manufacturer_name = ''.join(re.findall(
                    '"brand":"(.*?)"', str(response.body)))
                manufacturer_name = manufacturer_name.strip() if manufacturer_name else ""

                Brand_Name = ''.join(re.findall(
                    '"brand":"(.*?)"', str(response.body)))
                Brand_Name = Brand_Name.strip() if Brand_Name else ""

                Manufacturer_Part_Number = re.findall(
                    '"partNumberToShow":"(.*?)"', str(response.body))[0]
                Manufacturer_Part_Number = Manufacturer_Part_Number.strip(
                ) if Manufacturer_Part_Number else ""

                Vendor = response.xpath(VENDOR_XPATH).extract_first()
                Vendor_Seller_Part_Number = Vendor.strip() if Vendor else ""

                Name = response.xpath(TITLE).extract_first()
                Item_Name = Name.strip() if Name else ""

                Description = response.xpath(
                    '//div[@class="ProductOverviewInformation-content"]//text()').extract()
                Full_Product_Description = ''.join(Description)

                product_url = response.url

                date_crawled = (datetime.now()).strftime("%Y-%m-%dT%H:%M:%S")

                available = re.findall(
                    '"availability":"(.*?)"', str(response.body))
                if available:
                    instock = available[0].split('/')[-1]
                else:
                    instock = ''

                add_to_cart = response.xpath(
                    '//button[@id="btn-add-to-cart"]/span[@class="Button-content"]/text()').extract()
                if add_to_cart:
                    cart = "".join(add_to_cart)
                else:
                    cart = ''

                if instock == "InStock" and cart == "Add to Cart":
                    Availability = 'available'
                else:
                    Availability = 'not available'

                bread_crum = response.xpath(BREAD_CRUM_XPATH)
                for b in bread_crum:
                    product_cat = b.xpath(CATOGORY_XPATH).extract()
                    product_category = ' > '.join(product_cat)

                sku = re.findall('"sku":"(.*?)"', str(response.body))[0]

                selectedOptions = re.findall(
                    '"selectedOptions":"(.*?)"', str(response.body))

                options = ''.join(selectedOptions)

                item_data1 = WayfairItemPart1()
                item_data1['URL'] = product_url
                item_data1['Item Name'] = Item_Name
                item_data1['Price'] = Price
                item_data1['Product Category'] = product_category
                item_data1['Full Product Description'] = Full_Product_Description
                item_data1['Company Name'] = 'wayfair'
                item_data1['Manufacturer Name'] = manufacturer_name
                item_data1['Vendor/Seller Part Number'] = Vendor_Seller_Part_Number
                item_data1['Date Crawled'] = date_crawled
                item_data1['Model Number'] = ''
                item_data1['Manufacturer Part Number'] = Vendor_Seller_Part_Number
                item_data1['sku'] = sku
                item_data1['selectedOptions'] = options
                item_data1['Unit of Issue (UOI)'] = ''
                item_data1['QTY Per UOI'] = ''
                item_data1['UPC'] = ''
                item_data1['Brand Name'] = Brand_Name
                item_data1['Availability'] = Availability

                yield item_data1
