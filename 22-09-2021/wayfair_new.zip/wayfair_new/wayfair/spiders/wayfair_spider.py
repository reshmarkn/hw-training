# -*- coding: utf-8 -*-
import scrapy
from wayfair.items import *
from datetime import datetime
from pymongo import MongoClient
from wayfair.settings import *
from scrapy.shell import inspect_response
from scrapy.http import Request, FormRequest
import re
import json
import pika
import requests
import logging

HEADERS = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
    "accept-encoding": "gzip, deflate, br",
    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8,ml;q=0.7",
    # "cache-control": "max-age=0",
    "upgrade-insecure-requests": "1",
    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36"
}

# db = MongoClient(MONGO_URI)[MONGO_DB]


QUEUE_HOST = '159.89.47.171'
QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'
QUEUE_NAME = 'ha.wayfair_url'


class WayfairSpider(scrapy.Spider):
    name = 'wayfair_spider'
    handle_httpstatus_list = [200, 404]

    def start_requests(self):

        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        while True:
            connection = pika.BlockingConnection(pika.ConnectionParameters(
                credentials=credentials, host=QUEUE_HOST, socket_timeout=300))
            channel = connection.channel()
            channel.basic_qos(prefetch_count=1)
            method, properties, url = channel.basic_get(queue=QUEUE_NAME)
            if not url:
                logging.warning('Queue completed.')
                break
            url = str(url.strip(), encoding='utf-8')
            channel.basic_ack(delivery_tag=method.delivery_tag)
            if url:
                url = url.strip()
                meta = {'url': url}
                yield Request(url, headers=HEADERS, callback=self.parse, meta=meta)
        connection.close()

        #errback = self.errback_httpbin(url)

        # url_ = ["https://www.wayfair.com/lighting/pdp/ebern-designs-oil-rubbed-bronze-1-bulb-outdoor-bulkhead-light-w002580957.html",
        #         "https://www.wayfair.com/outdoor/pdp/trinx-metal-girl-garden-art-w003032505.html", "https://www.wayfair.com/furniture/pdp/latitude-run-araceliz-7068-h-x-4724-w-etagere-bookcase-w003232150.html"]
        # for url in url_:
        #     meta = {'url': url}
        #     yield Request(url, headers=HEADERS, callback=self.parse, meta=meta)

    def parse(self, response):
        #inspect_response(response, self)
        rurl = response.meta.get('url')
        if response.status == 200:
            dataget = response.meta.get('url')
            reurl = response.url
            # captche = response.xpath(
            #     '//h1[@class="Captcha-title"]/text()').extract_first().strip()

            if dataget == reurl:

                VENDOR_XPATH = '//meta[@property="og:upc"]/@content'
                TITLE = '//meta[@property="og:title"]/@content'

                PRICE = '//div[@class="BasePriceBlock"]/span/text()|//div[@class="StandardPriceBlock"]/div[@class="BasePriceBlock BasePriceBlock--highlight"]/span/text()'

                price = response.xpath(PRICE).extract_first()
                Price = price.replace('$', '') if price else ""

                BREAD_CRUM_XPATH = '//ol[@class="Breadcrumbs-list"]'
                CATOGORY_XPATH = 'li/a/text()'

                manufacturer_name = ''.join(re.findall(
                    '"brand":"(.*?)"', str(response.body)))
                manufacturer_name = manufacturer_name.strip() if manufacturer_name else ""

                Brand_Name = ''.join(re.findall(
                    '"brand":"(.*?)"', str(response.body)))
                Brand_Name = Brand_Name.strip() if Brand_Name else ""

                Manufacturer_Part_Number = re.findall(
                    '"partNumberToShow":"(.*?)"', str(response.body))[0]
                Manufacturer_Part_Number = Manufacturer_Part_Number.strip(
                ) if Manufacturer_Part_Number else ""

                Vendor = response.xpath(VENDOR_XPATH).extract_first()
                Vendor_Seller_Part_Number = Vendor.strip() if Vendor else ""

                Name = response.xpath(TITLE).extract_first()
                Item_Name = Name.strip() if Name else ""

                Description = response.xpath(
                    '//div[@class="ProductOverviewInformation-content"]//text()').extract()
                Full_Product_Description = ''.join(Description)

                product_url = response.url

                date_crawled = (datetime.now()).strftime("%Y-%m-%dT%H:%M:%S")

                available = re.findall(
                    '"availability":"(.*?)"', str(response.body))
                if available:
                    instock = available[0].split('/')[-1]
                else:
                    instock = ''

                add_to_cart = response.xpath(
                    '//button[@id="btn-add-to-cart"]/span[@class="Button-content"]/text()').extract()
                if add_to_cart:
                    cart = "".join(add_to_cart)
                else:
                    cart = ''

                if instock == "InStock" and cart == "Add to Cart":
                    Availability = 'available'
                else:
                    Availability = 'not available'

                bread_crum = response.xpath(BREAD_CRUM_XPATH)
                for b in bread_crum:
                    product_cat = b.xpath(CATOGORY_XPATH).extract()
                    product_category = ' > '.join(product_cat)

                    meta = {"manufacturer_name": manufacturer_name, "Brand_Name": Brand_Name, "Manufacturer_Part_Number": Manufacturer_Part_Number,
                            "Vendor_Seller_Part_Number": Vendor_Seller_Part_Number, "Item_Name": Item_Name, "Full_Product_Description": Full_Product_Description, "Price": Price, "product_url": product_url, "date_crawled": date_crawled, "product_category": product_category, "Availability": Availability}

                sku = re.findall('"sku":"(.*?)"', str(response.body))[0]

                selectedOptions = re.findall(
                    '"selectedOptions":"(.*?)"', str(response.body))

                options = ''.join(selectedOptions)

                url = 'https://www.wayfair.com/graphql?queryPath=specifications_queries~0%23prop65_queries~1'

                headers = {
                    "accept": "application/json",
                    "accept-encoding": "gzip, deflate, br",
                    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8,ml;q=0.7",
                    "content-type": "application/json",
                    "origin": "https://www.wayfair.com",
                    "referer": product_url,
                    "use-path": "true",
                    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36",
                    "x-parent-txid": "I+F9Ol6F84spIwwP/+KMAg="
                }

                payload = '{"query":"specifications_queries~0#prop65_queries~1","variables":{"sku":"' + \
                    sku + '","selectedOptionIds":[' + options + ']}}'

                yield FormRequest(url=url, headers=headers, method="POST", body=payload, callback=self.parse_new, meta=meta)
            else:
                if "redir" in reurl:
                    redirect_item = WayfairRedirectLink()
                    redirect_item['url'] = rurl
                    yield redirect_item
                else:
                    part = rurl.split('-')[-1].replace('.html', '')
                    url_item = WayfairLinkfail()
                    url_item['url'] = rurl
                    url_item['status_code'] = response.status
                    url_item['part_number'] = part
                    yield url_item
        else:
            part = rurl.split('-')[-1].replace('.html', '')
            url_item = WayfairLinkfail()
            url_item['url'] = rurl
            url_item['status_code'] = response.status
            url_item['part_number'] = part
            yield url_item

    def parse_new(self, response):
        origin = {}
        Vendor_Seller_Part_Number = response.meta.get(
            'Vendor_Seller_Part_Number')
        url = response.meta.get('product_url')

        if response.status == 200:
            a = json.loads(response.body_as_unicode())
            specific = ''
            jspecific = ''
            jspecific = a.get('data')
            if jspecific:
                specific = jspecific.get('product').get('displayInfo').get(
                    'specificationCategories')[0].get('specifications')
                if specific:
                    for s in specific:
                        for j in s:
                            if j["title"] == "Country of Origin" or j["title"] == "Country of Origin - Additional Details":
                                Country_of_Origin = j["value"]
                                origin.update(
                                    {"Country_of_Origin": Country_of_Origin})
                            else:
                                Country_of_Origin = ''

                    # if Vendor_Seller_Part_Number and origin.get('Country_of_Origin'):
                    if Vendor_Seller_Part_Number:
                        item_data = WayfairItem()
                        item_data['URL'] = response.meta.get('product_url')
                        item_data['Item Name'] = response.meta.get('Item_Name')
                        item_data['Price'] = response.meta.get('Price')
                        item_data['Product Category'] = response.meta.get(
                            'product_category')
                        item_data['Full Product Description'] = response.meta.get(
                            'Full_Product_Description')
                        item_data['Company Name'] = 'wayfair'
                        item_data['Manufacturer Name'] = response.meta.get(
                            'manufacturer_name')
                        item_data['Vendor/Seller Part Number'] = response.meta.get(
                            'Vendor_Seller_Part_Number')
                        item_data['Date Crawled'] = response.meta.get(
                            'date_crawled')
                        item_data['Model Number'] = ''
                        item_data['Manufacturer Part Number'] = response.meta.get(
                            'Vendor_Seller_Part_Number')
                        item_data['Country of Origin'] = origin.get(
                            'Country_of_Origin')
                        item_data['Unit of Issue (UOI)'] = ''
                        item_data['QTY Per UOI'] = ''
                        item_data['UPC'] = ''
                        item_data['Brand Name'] = response.meta.get(
                            'Brand_Name')
                        item_data['Availability'] = response.meta.get(
                            "Availability")

                        yield item_data
                    else:
                        part = url.split('-')[-1].replace('.html', '')
                        url_item = WayfairLinkfail()
                        url_item['url'] = response.meta.get('product_url')
                        url_item['status_code'] = response.status
                        url_item['part_number'] = part
                        yield url_item

                else:
                    rurl = response.meta.get('product_url')
                    part = rurl.split('-')[-1].replace('.html', '')
                    url_item = WayfairLinkfail()
                    url_item['url'] = rurl
                    url_item['status_code'] = response.status
                    url_item['part_number'] = part
                    yield url_item

            else:
                jspecific = ''
                rurl = response.meta.get('product_url')
                part = rurl.split('-')[-1].replace('.html', '')
                # self.errback_httpbin(rurl)
                # logging.warning("requeed QQQQQQQQQQQQQQQQQQQQQQQQQQQQQ")
                url_item = WayfairLinkfail()
                url_item['url'] = rurl
                url_item['status_code'] = response.status
                url_item['part_number'] = part
                yield url_item
        else:
            rurl = response.meta.get('product_url')
            part = rurl.split('-')[-1].replace('.html', '')
            # self.errback_httpbin(rurl)
            # logging.warning("requeed QQQQQQQQQQQQQQQQQQQQQQQQQQQQQ")
            url_item = WayfairLinkfail()
            url_item['url'] = rurl
            url_item['status_code'] = response.status
            url_item['part_number'] = part
            yield url_item

    def errback_httpbin(self, rurl):
        logging.warning("requeed QQQQQQQQQQQQQQQQQQQQQQQQQQQQQ")
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_HOST, socket_timeout=600))
        channel = connection.channel()
        channel.queue_declare(queue=QUEUE_NAME, durable=True)
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=rurl)
        connection.close()
