import scrapy
from scrapy.http import Request
import re


headers = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    "accept-encoding": "gzip, deflate",
    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
    "upgrade-insecure-requests": "1",
    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36"
    # "user-agent": random.choice(USER_AGENT_LIST)
}
base_url ='https://www.bipa.at'

class BipaSpider(scrapy.Spider):
    name = 'bipa_link_crawler'

    def start_requests(self):

        category_links = ['https://www.bipa.at/make-up']
        
        for category in category_links:
            
            categories = category
            yield Request(categories,callback = self.parse,headers = headers)

    def parse(self,response):

        # XPATH
        XPATH1 = (''.join(response.xpath('//div[@class="col-12 bg-white"]/div[2]//div[@class="roundtile__content"]/a/@href').extract()))
        link = ''.join(re.findall(r'.*\b=SALE',XPATH1))
        links = base_url+link  

        yield Request(links,callback = self.parse_category, headers = headers)

    def parse_category(self,response):
        
        category_list = response.xpath("//a[@class='listingchange']/@href").extract()  
        for link in category_list :
            url = base_url+link
            yield Request(url,callback = self.parse_links ,headers = headers)
    
    def parse_links(self,response):
        
        sub_category_links = response.xpath("//a[@class='listingchange']/@href").extract()
        for url in sub_category_links:
            links = base_url+ url
            yield Request(links, callback = self.parse_product_links, headers = headers)

    def parse_product_links(self,response):
        
        product_links = response.xpath("//a[@class='stretched-link']/@href").extract() 
        for link in product_links:
            product_url = base_url+link 
            
            item = {}
            item['product_url'] = product_url
            yield item


# (response.xpath("//a[@class='listingchange']/@href"
# response.xpath("//a[@class='stretched-link']/@href").extract()   
# response.xpath("//a[@class='listingchange']/@href").extract()   (sale)   
# v = re.findall(r'.*\b=SALE',c)  
# v = re.findall(r'.*\b=Aktion',c)  

#         category_links = ['https://www.bipa.at/make-up','https://www.bipa.at/mode/themen?srule=Neu%20eingetroffen&start=0&sz=60','https://www.bipa.at/parfum','https://www.bipa.at/pflege','https://www.bipa.at/haar','https://www.bipa.at/baby-und-kind','https://www.bipa.at/love','https://www.bipa.at/gesundheit','https://www.bipa.at/ernaehrung','https://www.bipa.at/tier','https://www.bipa.at/haushalt']
#         