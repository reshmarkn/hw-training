from xml.dom import minidom
import requests
import pymongo
from pymongo import MongoClient
MONGODB_DB = 'BIPA'
MONGODB_COLLECTION = 'bipa_product_links'
client = MongoClient('localhost',27017)

db = client[MONGODB_DB]
db[MONGODB_COLLECTION].create_index([("product_url",1)], unique=True)

url = "https://www.bipa.at/sitemap_0.xml"
response = requests.get(url)

xmldoc = minidom.parseString(response.text)
LOCS = xmldoc.getElementsByTagName('loc')
for loc in LOCS:
    p_url = loc.childNodes[0].data
    if '/B3' in p_url:
        # print(p_url)
        item = {}
        item['product_url'] = p_url
        print(item)
        db[MONGODB_COLLECTION].insert(dict(item))

