import scrapy

from scrapy.http import Request

from datetime import date

import json

today = str(date.today())

headers = {
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "accept-encoding": "gzip, deflate, br",
        "accept-language": "en-US,en;q=0.9",
        "upgrade-insecure-requests": "1",
        "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36"
        }

domain = 'https://www.limeroad.com'

class LimeroadParserSpider(scrapy.Spider):
    name = 'limeroad_parser'
   
    start_urls = ['https://www.limeroad.com/clothing/ethnic-wear/sets?src_id=navdeskEthnicSets__002']


    def start_requests(self):

        links = ['https://www.limeroad.com/blue-rayon-jaipur-fashion-mode-p17635640?imgIdx=3&src_id=navdeskEthnicSets__002','https://www.limeroad.com/beige-chanderi-ardozaa-p17782870?imgIdx=3&src_id=navdeskEthnicSets__002']
        for url in links:
            yield Request(url, headers = headers)
    
    def parse(self, response):
        #XPATH
        
        product_id = response.xpath("//div[@class='dIb vT c6']/text()").extract_first()
        product_url = response.url
        product_name = response.xpath('//h1/text()').extract_first()
        
        image = response.xpath('//script[@type="application/ld+json"]/text()').get()
        json_data = json.loads(image)
        image_url = json_data.get('image')[0]

        availability = response.xpath('//script[@type="application/ld+json"]/text()').get()
        json_data = json.loads(availability)
        availability= json_data.get('offers',{}).get('availability','')
        var1 = availability.split('/')[-1]
        if var1.lower() ==  "instock" :
            is_sold_out = False
        else:
            is_sold_out = True
        
        
        product_price = response.xpath("//span[@class='sell']/text()").extract_first()
        product_discount = response.xpath("//span[@class='per']/text()").extract_first()
        product_mrp = response.xpath("//span[@class='mrp']/text()").extract_first()
        average_rating = response.xpath("//div[@class='c6 fs12 p40 taL ttC dT']/div[1]/text()").extract_first() 
        category_hierarchy = response.xpath("//ul[@itemtype='http://schema.org/BreadcrumbList']/li/a /span/text()").extract() 
        


        #CLEAN

        category_hierarchy= ''.join(category_hierarchy) if category_hierarchy else ''
    
        item = {}
        
        item['product_id'] = product_id
        item['source'] = domain
        item['scraped_date'] = today
        item['product_name'] = product_name
        item['image_url'] = image_url
        item['category_hierarchy'] = category_hierarchy
        item['product_price'] = product_price
        item['arrival_date'] = ''
        item['shipping_charges'] = ''
        item['is_sold_out'] = is_sold_out
        item['discount'] = product_discount
        item['mrp'] = product_mrp
        item['product_url'] = product_url
        item['number_of_ratings'] = 0
        item['avg_rating '] = average_rating 
        item['position'] = ''
        item['country_code'] = 'IN'
        
        yield item
  