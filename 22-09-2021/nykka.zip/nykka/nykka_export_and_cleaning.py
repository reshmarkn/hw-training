from pymongo import MongoClient
from datetime import datetime
import csv
import json
import requests
import subprocess
from bson import objectid, json_util
import pytz
import re
import ast


DB_NAME = 'meesho_nykka_sample'
db = MongoClient('mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')[DB_NAME]
MONGODB_COLLECTION_PRODUCT = 'nykaa_data_2021_08_23'

today = str(datetime.now(pytz.timezone('Asia/Kolkata'))
            ).split(' ')[0].replace('-', '_')
COLLECTION_NAME = MONGODB_COLLECTION_PRODUCT + '_' + today
file_name = today.replace('_', '-')

COLLECTION_NAME = 'nykaa_data_2021_08_23'


print(COLLECTION_NAME)
file = open('nykaa_' + file_name, 'a')
writer = csv.writer(file, delimiter=";",
                    quoting=csv.QUOTE_NONE, quotechar="")
# fields = ['others']
# file.write('competitor_price;competitor_image_url;product_name;available_sizes;description_map;source;shipping_charge;l1_name;l2_name;l3_name;scraped_date;description;product_id;source_url;seller_name;seller_link;seller_city;catalog_name;catalog_id;position'+'\n')
fields = ['product_id', 'catalog_name', 'catalog_id', 'source', 'scraped_date', 'product_name',
          'image_url', 'category_hierarchy', 'product_price', 'arrival_date',
          'shipping_charges', 'is_sold_out', 'discount', 'mrp', 'page_url', 'product_url', 'number_of_ratings', 'avg_rating',
          'position', 'country_code', 'others']
writer.writerow(fields)
count = 0
limit = 50000
number = 1
# file = open(file_name+'.csv', 'a')
# writer = csv.writer(file, delimiter=";", quotechar='"', doublequote=False)

for item in db[COLLECTION_NAME].find(no_cursor_timeout=True):
    # for item in range(db[COLLECTION_NAME][:250:
    # item = db.product_sample_data_final_1.find_one(
    #     {'product_id': 'SARFD95YHPHYXDWP'})
    product_id = item.get('product_id', '')
    catalog_name = item.get('product_name', '').replace(
        ';', '').replace('\\', '').replace('"', '\\"')
    catalog_name = ' '.join(catalog_name.split()).replace('é', 'e')
    catalog_id = item.get('product_id', '')
    # if catalog_id == '':
    #     catalog_id = 'N/A'
    source = item.get('source', '').lower()
    scraped_date = item.get('scraped_date', '')
    product_name = item.get('product_name', '').replace(
        ';', '').replace('\\', '').replace('"', '\\"').replace('é', 'e')
    product_name = ' '.join(product_name.split())
    image_url = item.get('image_url', '')
    category_hierarchy = item.get('category_hierarchy', '')
    product_price = item.get('product_price', '')
    deliverable = item.get('Deliverable/Undeliverable', '')
    # print(product_price)
    product_price = str(product_price).replace(',', '').replace('%', '')
    if product_price != 'N/A':
        product_price = float(product_price)
    if product_price == '0%':
        product_price = 'N/A'
    if product_price == 0:
        product_price = 'N/A'
    arrival_date = item.get('arrival_date', '')
    if not arrival_date:
        arrival_date = 'N/A'
    shipping_charges = item.get('shipping_charges', '')
    shipping_charges = str(shipping_charges).replace('₹', '')
    shipping_charges = int(shipping_charges)
    if product_price != 'N/A':
        if product_price < 1000:
            shipping_charges = shipping_charges
        else:
            shipping_charges = 0
    is_sold_out = item.get('is_sold_out', '')
    is_sold_out = (str(is_sold_out)).lower()
    discount = item.get('discount', '')
    if discount == 0:
        discount = 'N/A'
    # elif "% off" in discount:
    #     discount = (discount.split(' % off')[0]) + ' %'
    else:
        discount = discount.replace('off', '')

    mrp = item.get('mrp', '')
    mrp = str(mrp).replace(',', '').replace('%', '')
    if mrp != 'N/A':
        mrp = float(mrp)
    if mrp == 0:
        mrp = 'N/A'
    page_url = str(item.get('page_url', ''))
    if not page_url:
        page_url = 'N/A'
    product_url = str(item.get('product_url', ''))
    product_url = product_url.split('?')[0]
    number_of_ratings = item.get('number_of_ratings', '')
    number_of_ratings = str(number_of_ratings).replace(',', '')
    number_of_ratings = int(number_of_ratings)

    avg_rating = item.get('avg_rating', '')
    avg_rating = float(avg_rating)

    position = item.get('position', '')
    position = str(position).replace(',', '')
    position = int(position)
    country_code = 'IN'
    others = item.get('others', '')

    others = json.dumps(others, ensure_ascii=False)
    others = others.replace(';', '').replace('\\\\\\', '').replace('\\\\', '')

    if category_hierarchy != 'N/A':
        category_hierarchy = json.dumps(category_hierarchy)
        category_hierarchy = category_hierarchy.replace(';', '')
        category_hierarchys = json.loads(category_hierarchy)
        category_hierarchy = {}
        for key in sorted(category_hierarchys.keys()):
            if key <= 'l4':
                category_hierarchy.update({key: category_hierarchys[key]})
        category_hierarchy = json.dumps(category_hierarchy, sort_keys=True)
        category_hierarchy = category_hierarchy.replace('é', 'e')

    data = [product_id, catalog_name, catalog_id, source, scraped_date, product_name,
            image_url, category_hierarchy, product_price, arrival_date,
            shipping_charges, is_sold_out, discount, mrp, page_url, product_url, number_of_ratings, avg_rating,
            position, country_code, others]

    if product_name:
        if len(product_name) < 500 and len(product_url) < 500:

            writer.writerow(data)
#     # limit += 50000

file.close()
# limit += 50000
files = 'nykaa_' + file_name
new_filename = files + '.csv'
subprocess.Popen('native2ascii -encoding UTF-8 -reverse %s   %s ' %
                 (files, new_filename), shell=True)
