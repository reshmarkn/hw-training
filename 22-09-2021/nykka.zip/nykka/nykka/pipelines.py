from scrapy.exceptions import DropItem
from nykka.items import *
from nykka.settings import *
import pymongo
from pymongo import MongoClient


class NykkaPipeline(object):

    def __init__(self, settings):
        self.mongo_uri = settings.get('MONGO_URI')
        self.mongo_db = settings.get('MONGO_DB')
        self.mongo_link_collection = settings.get(
            'MONGO_LINK_COLLECTION')
        self.mongo_product_collection = settings.get(
            'MONGO_PRODUCT_COLLECTION')
        self.dup_key = settings.get('DUP_KEY', '_id')

    @classmethod
    def from_crawler(cls, crawler):
        return cls(
            settings=crawler.settings
        )

    def open_spider(self, spider):
        self.client = pymongo.MongoClient(self.mongo_uri)
        self.db = MongoClient(self.mongo_uri)[self.mongo_db]
        try:
            self.db[self.mongo_product_collection].create_index(
                self.dup_key, unique=True)
        except:
            pass
        try:
            self.db[self.mongo_link_collection].create_index(
                'child_url', unique=True)
        except:
            pass
        try:
            self.client.admin.command(
                "enablesharding", self.mongo_db)
            self.client.admin.command("shardcollection", self.mongo_collection, key={
                                      dup_key: 1}, unique=True)
        except:
            pass
            # self.client = MongoClient(
            #     'mongodb://datahut:cGFzc21lMTIz@64.225.9.179:27017')
            # try:
            #     self.db[self.mongo_collection].create_index(
            #         self.dup_key, unique=True)
            # except:
            #     pass

    def close_spider(self, spider):
        self.client.close()

    def process_item(self, item, spider):
        if isinstance(item, NykkaLinkItem):

            try:
                self.db[self.mongo_link_collection].insert(dict(item))
            except:
                raise DropItem("Dropping duplicate item")

        if isinstance(item, NykkaProductItem):
            try:
                self.db[self.mongo_product_collection].insert(dict(item))
            except:
                raise DropItem("Dropping duplicate item")

        return item
