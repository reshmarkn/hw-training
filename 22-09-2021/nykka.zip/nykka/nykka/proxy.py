import logging
import random
import requests

logger = logging.getLogger(__name__)


def parse_proxy():
    # PROXY_LIST = ['51.159.3.47:2061']  # Indian proxy
    # PROXY_LIST = ['167.71.238.159:80']
    # PROXY_LIST = ['117.254.59.70:8080', '122.102.28.160:53281']
    # PROXY_LIST = [
    #     '43.227.129.193:83',
    #     '45.250.226.56:8080',
    #     '45.250.226.48:8080',
    #     '43.224.8.124:6666',
    #     '103.220.214.106:8080',
    #     '103.89.235.29:84',
    #     '103.224.39.2:83',
    #     '103.209.64.19:6666',
    #     '103.240.161.101:6666',
    # ]
    PROXY_LIST = requests.get('http://68.183.58.145/stormproxies?',
                              headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
    # PROXY_LIST = requests.get('http://68.183.58.145/microleaves',
    #                           headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
    # PROXY_LIST = requests.get('http://68.183.58.145/torproxies?',
    #                           headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()

    PROXY = random.choice(PROXY_LIST)
    proxy_url = "http://%s" % PROXY
    proxies = {"http": "http://%s" % PROXY, "https": "http://%s" % PROXY}
    logger.debug("Proxy added")
    return {'proxies': proxies, 'proxy_url': proxy_url}
