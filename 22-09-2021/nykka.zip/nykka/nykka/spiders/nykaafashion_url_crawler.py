# -*- coding: utf-8 -*-
import scrapy
from scrapy.http import Request
import json
from pymongo import MongoClient
import re
import json
from nykka.items import *
from nykka.settings import *
import requests
from scrapy.shell import inspect_response

headers = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    "accept-encoding": "gzip, deflate, br",
    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
    "upgrade-insecure-requests": "1",
    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) snap Chromium/80.0.3987.100 Chrome/80.0.3987.100 Safari/537.36"
}
BASE_URL = 'https://www.nykaafashion.com'
MONGODB_DB = 'meesho_2021_02_25'
MONGODB_COLLECTION = 'nykaafashion_links_2021_02_25'


client = MongoClient('mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
try:
    client.admin.command("enablesharding", MONGODB_DB)
except:
    pass
try:
    client.admin.command(
        "shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION, key={'_id': 1})
except:
    pass
db = client[MONGODB_DB]


class NykkaUrlCrawlerSpider(scrapy.Spider):
    name = 'nykkafashion_url_crawler'

    def start_requests(self):
        main_url = 'https://www.nykaafashion.com/indianwear/salwar-suits-and-sets/c/69'
        catagory_hierarchys = {}
        list_ = main_url.split('/')
        catagory_hierarchys.update({'l1': list_[3], 'l2': list_[4]})
        position = 0
        url = 'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=69&PageSize=12&sort=popularity&currentPage=1&filter_format=v2'
        try:
            response = requests.get(url, headers=headers)
        except:
            response = ''
        if response and response.status_code == 200:
            json_data = json.loads(response.text)
            total_count = json_data.get('response').get('count')
            pagination_limit = total_count / 12
            pagination_limit = int(pagination_limit)
            for page in range(1, pagination_limit):
                api_url = 'https://www.nykaafashion.com/rest/appapi/V2/categories/products?categoryId=69&PageSize=12&sort=popularity&currentPage=' + \
                    str(page) + '&filter_format=v2'
                meta = {"main_url": main_url,
                        'position': position, "catagory_hierarchys": catagory_hierarchys}
                yield Request(api_url, headers=headers, callback=self.parse, dont_filter=True, meta=meta)

    def parse(self, response):
        main_url = response.meta.get('main_url')
        position = response.meta.get('position')
        next_url = response.meta.get('next_url')
        catagory_hierarchys = response.meta.get('catagory_hierarchys')
        json_data = json.loads(response.body_as_unicode())
        products_data = json_data.get('response').get('products')
        if products_data:
            for data in products_data:
                position = position + 1
                item = NykkaFashionItem()
                item['child_url'] = BASE_URL + data.get('actionUrl', '')
                item['main_url'] = main_url
                item['position'] = position
                item['catagory_hierarchys'] = catagory_hierarchys
                item['page_url'] = response.url
                yield item
                try:
                    db[MONGODB_COLLECTION].insert(dict(item))
                except:
                    pass
        client.close()