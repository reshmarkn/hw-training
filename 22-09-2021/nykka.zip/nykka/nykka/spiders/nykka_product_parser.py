# -*- coding: utf-8 -*-
import scrapy
from scrapy.http import Request
from pymongo import MongoClient
import pymongo
import re
from scrapy import Selector
from datetime import datetime
import json
import pika
import logging
from nykka.items import *
from nykka.settings import *

logger = logging.getLogger('pika')
logger.propagate = False

headers = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    "accept-encoding": "gzip, deflate, br",
    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
    "upgrade-insecure-requests": "1",
    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) snap Chromium/80.0.3987.100 Chrome/80.0.3987.100 Safari/537.36"
}
BASE_URL = 'https://www.nykaa.com'
QUEUE_IP = '159.89.47.171'
QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'
QUEUE_NAME = 'ha.nykaa'


class NykkaProductParserSpider(scrapy.Spider):
    name = 'nykka_product_parser'

    def start_requests(self):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        while True:
            connection = pika.BlockingConnection(pika.ConnectionParameters(
                credentials=credentials, host=QUEUE_IP, socket_timeout=300))
            channel = connection.channel()
            channel.basic_qos(prefetch_count=1)
            method, properties, body = channel.basic_get(
                queue=QUEUE_NAME)
            data = json.loads(body.decode("utf-8"))
            if data:
                main_url = data.get('main_url')
                catagory_hierarchys = data.get('catagory_hierarchys')
                page_url = data.get('page_url')
                child_url = data.get('child_url')
                position = data.get('position')
                if child_url:
                    meta = {"main_url": main_url, 'position': position,
                            'child_url': child_url, 'page_url': page_url, 'catagory_hierarchys': catagory_hierarchys}
                    yield Request(url=child_url, headers=headers, meta=meta, callback=self.parse, dont_filter=True, errback=lambda x: self.errback_httpbin(x, data))
            channel.basic_ack(delivery_tag=method.delivery_tag)
            connection.close()

    def parse(self, response):
        main_url = response.meta.get('main_url')
        position = response.meta.get('position')
        page_url = response.meta.get('page_url')
        catagory_hierarchys = response.meta.get('catagory_hierarchys')
        product_name_xpath = '//h1[@itemprop="name"]/text()'
        product_price_xpath = '//meta[@itemprop="price"]/@content'
        mrp_xpath = '//span[@class="mrp-price"]/text()'
        avg_rating_xpath = '//meta[@itemprop="ratingValue"]/@content'
        number_of_ratings_xpath = '//meta[@itemprop="ratingCount"]/@content'
        review_count_xpath = '//meta[@itemprop="reviewCount"]/@content'
        currency_xpath = '//meta[@itemprop="priceCurrency"]/@content'
        main_image_xpath = '//meta[@itemprop="image"]/@content'
        images_xpath = '//div[@class="slick-thumb"]//div[contains(@class,"slick-slide slick")]//img/@src'
        discount_xpath = '//div[@class="clearfix product-des__details"]//div[@class="discount-info"]/span/text()'
        is_sold_out_xpath = '//div[@class="col-md-7 col-sm-7 product-description-wrap"]//text()'
        category_hierarchy_xpath = '//script[contains(text(),"primary_categories")]//text()'
        sold_by_xpath = '//span[@class="sold-by"]/@title'

        product_name = response.xpath(product_name_xpath).extract()
        product_price = response.xpath(product_price_xpath).extract()
        mrp = response.xpath(mrp_xpath).extract()
        avg_rating = response.xpath(avg_rating_xpath).extract()
        number_of_ratings = response.xpath(number_of_ratings_xpath).extract()
        review_count = response.xpath(review_count_xpath).extract()
        currency = response.xpath(currency_xpath).extract()
        main_image = response.xpath(main_image_xpath).extract()
        images = response.xpath(images_xpath).extract()
        discount = response.xpath(discount_xpath).extract()
        is_sold_out = response.xpath(is_sold_out_xpath).extract()
        category_hierarchy = response.xpath(
            category_hierarchy_xpath).extract_first('')
        sold_by = response.xpath(sold_by_xpath).extract()

        product_name = product_name[0].strip() if product_name else ''
        product_price = float(product_price[0].strip()) if product_price else 0
        mrp = float(mrp[1].strip()) if mrp else 0
        avg_rating = float(avg_rating[0].strip()) if avg_rating else 0
        review_count = int(review_count[0].strip()) if review_count else 0
        number_of_ratings = int(number_of_ratings[0].strip(
        )) if number_of_ratings else 0
        currency = currency[0].strip() if currency else ''
        main_image = main_image[0].strip() if main_image else ''
        images = list(map(lambda x: x.replace(
            'w-50,h-50', 'w-800,h-800'), images)) if images else ''

        discount = ' '.join(discount).strip() if discount else 'N/A'
        is_sold_out = ''.join(is_sold_out) if is_sold_out else ''
        if 'ADD TO BAG' in is_sold_out:
            is_sold_out = False
        else:
            is_sold_out = True

        sold_by = sold_by[0].strip() if sold_by else ''

        product_url = response.url
        product_id = int(
            "".join(re.findall(r'skuId=\d+', product_url)).replace("skuId=", ""))

        last_visited = datetime.now().isoformat().split('.', 1)[
            0].replace('T', ' ')
        item = NykkaProductItem()
        item['product_id'] = product_id
        item['catalog_name'] = product_name
        item['catalog_id'] = product_id
        item['source'] = 'nykaa'
        item['scraped_date'] = last_visited
        item['product_name'] = product_name
        item['image_url'] = main_image
        item['category_hierarchy'] = catagory_hierarchys
        item['product_price'] = product_price
        item['arrival_date'] = 'N/A'
        item['shipping_charges'] = 99
        item['is_sold_out'] = is_sold_out
        item['discount'] = discount
        item['mrp'] = mrp if mrp else product_price
        item['page_url'] = 'N/A'
        item['product_url'] = product_url
        item['number_of_ratings'] = number_of_ratings
        item['avg_rating'] = avg_rating
        item['position'] = position
        item['others'] = {'other_images': images,
                          'review_count': review_count, 'sold_by': sold_by}
        yield item

    def errback_httpbin(self, failure, data):
        credentials = pika.PlainCredentials(
            QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=3000))
        channel = connection.channel()
        channel.queue_declare(
            queue=QUEUE_NAME, durable=True)
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=json.dumps(data))
        connection.close()


# product_id
# catalog_name
# catalog_id
# source
# scraped_date
# product_name
# image_url
# category_hierarchy
# product_price
# arrival_date
# shipping_charges
# is_sold_out
# discount
# mrp
# page_url
# product_url
# number_of_ratings
# avg_rating
# position
# Deliverable/Undeliverable
# others
