# -*- coding: utf-8 -*-
import scrapy
from scrapy.http import Request
from pymongo import MongoClient
import pymongo
import re
from scrapy import Selector
from datetime import datetime
import json
import pika
import logging
from nykka.items import *
from nykka.settings import *
from scrapy.shell import inspect_response
from nykka.proxy import *
logger = logging.getLogger('pika')
logger.propagate = False

headers = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    "accept-encoding": "gzip, deflate, br",
    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
    "upgrade-insecure-requests": "1",
    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) snap Chromium/80.0.3987.100 Chrome/80.0.3987.100 Safari/537.36"
}
BASE_URL = 'https://www.nykaa.com'
QUEUE_IP = '159.89.47.171'
QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'
# QUEUE_NAME = 'ha.nykaafashion'
QUEUE_NAME = 'ha.nykaafashion_meesho'

MONGODB_DB = 'meesho_2021_02_25'
MONGODB_COLLECTION = 'nykaafashion_datas_2021_02_25'

cookies = {'country_code': 'in',
           'symbol': '%u20B9'}
client = MongoClient('mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
try:
    client.admin.command("enablesharding", MONGODB_DB)
except:
    pass
try:
    client.admin.command(
        "shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION, key={'product_url': 1}, unique=True)
except:
    pass
db = client[MONGODB_DB]


class NykkaProductParserSpider(scrapy.Spider):
    name = 'nykkaafashion_product_parser'

    def start_requests(self):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        while True:
            connection = pika.BlockingConnection(pika.ConnectionParameters(
                credentials=credentials, host=QUEUE_IP, socket_timeout=300))
            channel = connection.channel()
            channel.basic_qos(prefetch_count=1)
            method, properties, body = channel.basic_get(
                queue=QUEUE_NAME)
            data = json.loads(body.decode("utf-8"))
            if data:
                main_url = data.get('main_url')
                catagory_hierarchys = data.get('catagory_hierarchys')
                page_url = data.get('page_url')
                child_url = data.get('child_url')
                position = data.get('position')
                if child_url:
                    child_url = child_url.replace(
                        'https://www.nykaafashion.comhttps', 'https')
                    #print(child_url, '11111111111111111111111111')
                    meta = {"main_url": main_url, 'position': position,
                            'child_url': child_url, 'page_url': page_url, 'catagory_hierarchys': catagory_hierarchys}
                    yield Request(url=child_url, headers=headers, cookies=cookies, meta=meta, callback=self.parse, dont_filter=True, errback=lambda x: self.errback_httpbin(x, data))
            channel.basic_ack(delivery_tag=method.delivery_tag)
        connection.close()
        # child_url = 'https://www.nykaafashion.com/yufta-women-green-maroon-printed-kurta-with-palazzo-set-of-2/p/617020'
        # meta = {"main_url": '', 'position': '',
        #                     'child_url': child_url, 'page_url': '', 'catagory_hierarchys': ''}
        # yield Request(url=child_url, headers=headers, meta=meta, cookies=cookies, callback=self.parse, dont_filter=True,)

    def parse(self, response):

        main_url = response.meta.get('main_url')
        position = response.meta.get('position')
        page_url = response.meta.get('page_url')
        catagory_hierarchys = response.meta.get('catagory_hierarchys')
        product_name_xpath = '//h1/div/text()'
        product_price_xpath = '//div[@class="css-z806i6 e4picg40"]/span/text() | //div[@class=" css-z806i6 e4picg40"]/span/text() | //span[@class=" css-nt79bs e4picg41"]/text() | //div[@class="css-3sinjb e4picg40"]/span/text()'
        is_sold_out_xpath = '//button[@class="eod320a0 css-j82gsu eym69qs0"]/text()'

        mrp_xpath = '//div[@class="css-z806i6 e4picg40"]/span[2]/text() | //div[@class=" css-z806i6 e4picg40"]/span[2]/text() | //span[@class=" css-43auj5 e4pig42"]/text() | //div[@class="css-3sinjb e4picg40"]/span/text()'

        discount_xpath = '//div[@class="css-z806i6 e4picg40"]/span[3]/text() | //div[@class=" css-z806i6 e4picg40"]/span[3]/text() | //span[@class="css-n9ao2b e4picg45"]/text()'

        avg_rating_xpath = '//meta[@itemprop="ratingValue"]/@content'
        number_of_ratings_xpath = '//meta[@itemprop="ratingCount"]/@content'
        review_count_xpath = '//meta[@itemprop="reviewCount"]/@content'
        currency_xpath = '//meta[@itemprop="priceCurrency"]/@content'
        main_image_xpath = '//meta[@itemprop="image"]/@content'
        images_xpath = '//div[@class="slick-thumb"]//div[contains(@class,"slick-slide slick")]//img/@src'
        category_hierarchy_xpath = '//script[contains(text(),"primary_categories")]//text()'

        sold_by_div = '//div[@class="description-accordion"]/div'
        key_xpath = 'div[@class="prod-info-header css-m1a0e7 ez6ebqp2"]/text()'
        value_xpath = 'div[@class="css-1afl7ic ez6ebqp3"]/text() | div[@class="css-3k9fjh ez6ebqp3"]/text()'
        script_xpath = '//script[@type="application/ld+json"]/text()'

        currency = re.findall(r'priceCurrency":"(.*?)"', str(response.text))
        currency = ''.join(currency).strip() if currency else 'N/A'
        product_name = response.xpath(product_name_xpath).extract()
        product_price = response.xpath(product_price_xpath).extract()

        mrp = response.xpath(mrp_xpath).extract()
        avg_rating = response.xpath(avg_rating_xpath).extract()
        number_of_ratings = response.xpath(number_of_ratings_xpath).extract()
        review_count = response.xpath(review_count_xpath).extract()
        images = response.xpath(images_xpath).extract()
        discount = response.xpath(discount_xpath).extract()
        is_sold_out = response.xpath(is_sold_out_xpath).extract()
        category_hierarchy = response.xpath(
            category_hierarchy_xpath).extract_first('')

        description = 'N/A'
        sold_by = 'N/A'

        division = response.xpath(sold_by_div)
        for div in division:
            key = div.xpath(key_xpath).extract_first('')
            value = div.xpath(value_xpath).extract()
            value = ''.join(value).strip() if value else ''
            if key == 'Sold By':
                sold_by = value
            if key == 'Description':
                description = value

        main_image = ''
        script_ = response.xpath(script_xpath).extract_first('')
        script_json = json.loads(script_) if script_ else ''
        if script_json:
            main_image = script_json.get('image', '')

        product_name = product_name[0].strip() if product_name else ''
        product_price = float(product_price[0].replace(
            ',', '').strip()) if product_price else 0
        mrp = float(mrp[0].replace(',', '').strip()) if mrp else 0

        images_list = ''.join(re.findall(
            r'productMedia.*?":.*?]', str(response.text))).strip().replace('\\', '')
        other_images = re.findall(
            r'url":"(.*?)"', images_list) if images_list else []

        avg_rating = 0
        review_count = '0'
        number_of_ratings = 0

        discount = ' '.join(discount).replace(
            'Off', '').replace('%', '').strip() if discount else 'N/A'
        is_sold_out = ''.join(is_sold_out) if is_sold_out else ''
        if 'Add to bag' in is_sold_out:
            is_sold_out = False
        else:
            is_sold_out = True

        product_url = response.url
        product_id = product_url.rsplit('/', 1)[-1]

        last_visited = datetime.now().isoformat().split('.', 1)[
            0].replace('T', ' ')

        if product_name:

            item = NykkaFashionProductItem()
            item['product_id'] = product_id
            item['catalog_name'] = product_name
            item['catalog_id'] = product_id
            item['source'] = 'nykaafashion'
            item['scraped_date'] = last_visited
            item['product_name'] = product_name
            item['image_url'] = main_image
            item['category_hierarchy'] = catagory_hierarchys
            item['product_price'] = product_price
            item['arrival_date'] = 'N/A'
            item['shipping_charges'] = 99
            item['is_sold_out'] = is_sold_out
            item['discount'] = discount
            item['mrp'] = mrp if mrp else product_price
            item['page_url'] = 'N/A'
            item['product_url'] = product_url
            item['number_of_ratings'] = number_of_ratings
            item['avg_rating'] = avg_rating
            item['position'] = position
            item['others'] = {'other_images': other_images,
                              'review_count': review_count, 'sold_by': sold_by}
            print(item, '///////////////////')
            try:
                db[MONGODB_COLLECTION].insert(dict(item))
            except:
                pass
        client.close()
        # print(item)
        # yield item

    def errback_httpbin(self, failure, data):
        credentials = pika.PlainCredentials(
            QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=3000))
        channel = connection.channel()
        channel.queue_declare(
            queue=QUEUE_NAME, durable=True)
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=json.dumps(data))
        connection.close()
