# -*- coding: utf-8 -*-
import scrapy
from scrapy.http import Request
import json
from pymongo import MongoClient
import re
import json
from nykka.items import *
from nykka.settings import *
import requests
import random
import logging

headers = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    "accept-encoding": "gzip, deflate",
    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
    "upgrade-insecure-requests": "1",
    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36"
    # "user-agent": random.choice(USER_AGENT_LIST)
}
BASE_URL = 'https://www.nykaa.com'

handle_httpstatus_list = [500, 200, 403]


class NykkaUrlCrawlerSpider(scrapy.Spider):
    name = 'nykka_url_crawler'

    def start_requests(self):
        main_urls = [
            "https://www.nykaa.com/personal-care/bath-and-shower/c/35?ptype=lst&id=35&root=nav_2&dir=desc&order=popularity",
            "https://www.nykaa.com/makeup/face/c/13?ptype=lst&id=13&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/makeup/eyes/c/14?ptype=lst&id=14&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/makeup/lips/c/15?ptype=lst&id=15&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/makeup/nails/c/16?ptype=lst&id=16&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/makeup/makeup-kits/c/1448?ptype=lst&id=1448&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/makeup/tools-brushes/c/217",
            # "https://www.nykaa.com/hair-care/hair/c/25?root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/hair-care/tools-and-accessories/c/219?ptype=lst&id=219&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/hair-care/hair-styling/c/28?ptype=lst&id=28&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/skin/cleansers/c/8378?root=nav_2",
            # "https://www.nykaa.com/skin/toners/c/8391?root=nav_2",
            # "https://www.nykaa.com/skin/moisturizers/c/8393?root=nav_2",
            # "https://www.nykaa.com/skin/masks/c/8399?root=nav_2",
            # "https://www.nykaa.com/skin/eye-care/c/8402?root=nav_2",
            # "https://www.nykaa.com/skin/lip-care/c/8408?root=nav_2",
            # "https://www.nykaa.com/skin/neck-creams/c/8412?root=nav_2",
            # "https://www.nykaa.com/skin/body-care/c/8417?root=nav_2",
            # "https://www.nykaa.com/skin/sun-care/c/8428?root=nav_2",
            # "https://www.nykaa.com/skin/hands-feet/c/8431?root=nav_2",
            # "https://www.nykaa.com/skin/kits-combos/c/8435?root=nav_2",
            # "https://www.nykaa.com/skin/shop-by-concern/c/8440?root=nav_2",
            # "https://www.nykaa.com/personal-care/bath-and-shower/c/35?ptype=lst&id=35&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/personal-care/body/c/36?ptype=lst&id=36&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/personal-care/face/c/1381?ptype=lst&id=1381&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/personal-care/hands-and-feet/c/37?ptype=lst&id=37&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/personal-care/eye-care/c/6907?ptype=lst&id=6907&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/personal-care/feminine-hygiene/c/1648?ptype=lst&id=1648&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/personal-care/tools-accessories/c/1643?ptype=lst&id=1643&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/personal-care/men-s-grooming/c/1552?ptype=lst&id=1552&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/personal-care/home-and-health/c/1639?ptype=lst&id=1639&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/mom-and-baby/baby-care/c/63?ptype=lst&id=63&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/mom-and-baby/maternity-care/c/634?ptype=lst&id=634&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/mom-and-baby/maternity-wear/c/6916?root=nav_2&dir=desc&order=popularity&ptype=lst&id=6916",
            # "https://www.nykaa.com/wellness/health-supplements/c/672?ptype=lst&id=672&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/wellness/weight-management/c/736?ptype=lst&id=736&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/wellness/sports-nutrition/c/727?ptype=lst&id=727&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/wellness/sexual-wellness/c/1655?ptype=lst&id=1655&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/personal-care-appliances/hair-styling-tools/c/1385?ptype=lst&id=1385&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/personal-care-appliances/hair-removal-tools/c/1384?ptype=lst&id=1384&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/personal-care-appliances/shaving-tools/c/1403?ptype=lst&id=1403&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/personal-care-appliances/face-skin-tools/c/1402?ptype=lst&id=1402&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/natural/skin/c/9565?root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/natural/skin/c/9565?root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/natural/body-care/c/9605?ptype=lst&id=548&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/natural/hair/c/9597?root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/natural/aromatherapy/c/9614?root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/natural/makeup/c/9585?root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/mens/shaving/c/1286?ptype=lst&id=1286&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/mens/beard-care/c/1921",
            # "https://www.nykaa.com/mens/hair-care/c/1292?ptype=lst&id=1292&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/mens/skin-care/c/1300?ptype=lst&id=1300&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/mens/bath-body/c/1310?ptype=lst&id=1310&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/mens/fragrance/c/1321?root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/mens/shop-by-concern/c/6524?root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/mens/wellness/c/1325?ptype=lst&id=1325&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/fragrance/women/c/54?ptype=lst&id=54&root=nav_2&dir=desc&order=popularity",
            # "https://www.nykaa.com/fragrance/men/c/55?ptype=lst&id=55&root=nav_2&dir=desc&order=popularity"
            ]
        for main_url in main_urls:
            position = 0
            next_url = main_url
            category_url = "https://www.nykaa.com/app-api/index.php/products/getBreadCrumb?id=" + \
                ("".join(re.findall(r'/c/\d+', main_url)).replace("/c/", ""))
            try:
                category_response = requests.get(category_url, headers=headers)
            except:
                category_response = {}
            category_response = category_response.json()
            catagory_hierarchys = {}
            length = 1
            for item in category_response.get('response'):
                catagory_hierarchys.update(
                    {'l' + str(length): item.get('key')})
                if length == 4:
                    break
                length += 1

            meta = {"main_url": main_url,
                    'position': position, 'next_url': next_url, "catagory_hierarchys": catagory_hierarchys}
            yield Request(main_url, headers=headers, callback=self.parse, dont_filter=True, meta=meta)

    def parse(self, response):
        if response.status == 200:
            main_url = response.meta.get('main_url')
            position = response.meta.get('position')
            next_url = response.meta.get('next_url')
            catagory_hierarchys = response.meta.get('catagory_hierarchys')
            links_xpath = '//div[@class="product-list-box card desktop-cart"]/a/@href'
            links = response.xpath(links_xpath).extract()
            if links:
                for link in links:
                    position = position + 1
                    item = NykkaLinkItem()
                    item['child_url'] = BASE_URL + link
                    item['main_url'] = main_url
                    item['position'] = position
                    item['catagory_hierarchys'] = catagory_hierarchys
                    item['page_url'] = response.url
                    yield item
                next_page_link_xpath = '//link[@rel="next"]/@href'
                next_page_link = response.xpath(
                    next_page_link_xpath).extract_first("")
                if next_page_link:
                    next_page_link = next_page_link
                    meta = {"main_url": main_url, 'position': position,
                            'next_url': next_page_link, "catagory_hierarchys": catagory_hierarchys}
                    yield Request(next_page_link, headers=headers, callback=self.parse, dont_filter=True, meta=meta)
                    # try:
                    #     yield Request(next_url, headers=headers, callback=self.parse, dont_filter=True, meta=meta)
                    # except:
                    #     try:
                    #         yield Request(next_url, headers=headers, callback=self.parse, dont_filter=True, meta=meta)
                    #     except:
                    #         logging.warning(response.url)

        else:
            next_url = response.meta.get('next_url')
            meta = {"main_url": response.meta.get('main_url'),
                    'position': response.meta.get('position'), 'next_url': response.meta.get('next_url'), "catagory_hierarchys": response.meta.get('catagory_hierarchys')}
            try:
                yield Request(next_url, headers=headers, callback=self.parse, dont_filter=True, meta=meta)
            except:
                try:
                    yield Request(next_url, headers=headers, callback=self.parse, dont_filter=True, meta=meta)
                except:
                    logging.warning(response.url)
