import csv
import re
import json
import logging
import sys
file_name = input('Enter CSV file: ')

# file_name = sys.argv[1]
logging.basicConfig(filename=file_name + ".log", level=logging.INFO)

FIELD = {'product_id': 'product_id',
         'catalog_name': 'catalog_name',
         'catalog_id': 'catalog_id',
         'source': 'source',
         'scraped_date': 'scraped_date',
         'product_name': 'product_name',
         'image_url': 'image_url',
         'category_hierarchy': 'category_hierarchy',
         'product_price': 'product_price',
         'arrival_date': 'arrival_date',
         'shipping_charges': 'shipping_charges',
         'is_sold_out': 'is_sold_out',
         'discount': 'discount',
         'mrp': 'mrp',
         'page_url': 'page_url',
         'product_url': 'product_url',
         'number_of_ratings': 'number_of_ratings',
         'avg_rating': 'avg_rating',
         'position': 'position',
         'others': 'others'}


def check_one(data, position):
    """[fields:- product_id, catelog_id, source, discount][checking:- empty, datatype, length]"""
    if data and isinstance(data, str) and len(data) < 40:
        pass
    else:
        raise ValueError('ValueError', position)


def check_two(data, position):
    """[fields:- catalog_name, product_name][checking:- empty, datatype, length]"""
    if data and isinstance(data, str) and len(data) <= 500:
        pass
    else:
        raise ValueError('ValueError', position)


def date_check(data, position):
    """[fields:- scraped_date, arrival_date][checking:- date format]"""

    if re.match(r"\d\d\d\d-\d\d-\d\d \d\d:\d\d:\d\d", data):
        pass
    else:
        raise ValueError('ValueError', position)


def float_check(data, position):
    """[fields:- product_price, shipping_charges, mrp, avg_rating][checking:- datatype]"""
    if isinstance(float(data), float):
        pass
    else:
        raise ValueError('ValueError', position)


def int_check(data, position):
    """[fields:- number_of_ratings, position][checking:- datatype]"""
    if isinstance(data, int):
        pass
    else:
        raise ValueError('ValueError', position)


def image_check(data, position):
    """[fields:- image_url][checking:- text matching, length]"""
    if len(data) < 500:
        pass
    else:
        raise ValueError('ValueError', position)


def url_check(data, position):
    """[fields:- page_url, product_url][checking:- text matching, length]"""
    if len(data) < 500:
        pass
    else:
        raise ValueError('ValueError', position)


def bool_check(data, position):
    """[fields:- is_sold_out][checking:- text matching]"""
    if data == 'true' or data == 'false':
        pass
    else:
        raise ValueError('ValueError', position)


def category_hierarchy(data, position):
    """[fields:- category_hierarchy][checking:- json data, length]"""
    if json.loads(data) and len(data) < 500:
        d = json.loads(data)
        # for key, value in d.items():
        #     value = ''.join(value.split()).replace('&', '')
        #     if value.isalnum():
        #         pass
        #     else:
        #         raise ValueError(value, position)

    else:
        raise ValueError('ValueError', position)
    # for key, value in data.items():
    #     if value.isalnum():
    #         pass
    #     else:
    #         raise ValueError('non alphanumeric character', position)


def others_check(data, position):
    """[fields:- others][checking:- json data, length, empty]"""
    if json.loads(data) and len(data) < 15000:
        others_json = json.loads(data)
        for data in others_json:
            if others_json[data]:
                pass

            else:
                raise ValueError(
                    'empty values in others field', position, data)

    else:
        raise ValueError('ValueError', position)


def error_log(function_name, data, position, field_name):
    try:

        function_name(data, position)
    except Exception as e:
        invalid_data = 'Position: ' + str(position), 'Error: ' + \
            str(e), 'field_name: ' + field_name
        logging.error(str(invalid_data))


def error_log_1(function_name, data, position, field_name):
    try:
        function_name(float(data), position)
    except Exception as e:
        invalid_data = 'Position: ' + str(position), 'Error: ' + \
            str(e), 'field_name: ' + field_name
        logging.error(str(invalid_data))


def error_log_2(function_name, data, position, field_name):
    try:
        function_name(int(data), position)
    except Exception as e:
        invalid_data = 'Position: ' + str(position), 'Error: ' + \
            str(e), 'field_name: ' + field_name
        logging.error(str(invalid_data))


# file_name = input('Enter CSV file: ')
with open(file_name + ".csv") as csvfile:

    READER = csv.reader(csvfile, delimiter=';')
    position = 0
    for data_row in READER:
        position = position + 1
        if position > 1:
            if len(data_row) == 21:
                # length_csv(data_row, position)
                error_log(check_one, data_row[0], position,
                          FIELD['product_id'])  # product_id
                error_log(check_two, data_row[1], position,
                          FIELD['catalog_name'])  # catalog_name
                error_log(check_one, data_row[2], position,
                          FIELD['catalog_id'])  # catalog_id
                error_log(check_one, data_row[3],
                          position, FIELD['source'])  # source
                error_log(date_check, data_row[4],
                          position, FIELD['scraped_date'])  # scraped_date
                error_log(check_two, data_row[5], position,
                          FIELD['product_name'])  # product_name
                # image_url
                error_log(image_check,
                          data_row[6], position, FIELD['image_url'])
                if 'N/A' in data_row[7]:
                    pass
                else:
                    error_log(category_hierarchy,
                              data_row[7], position, FIELD['category_hierarchy'])  # category_hierarchy
                # product_price
                if 'N/A' in data_row[8]:
                    pass
                else:
                    error_log_1(float_check,
                                data_row[8], position, FIELD['product_price'])
                # arrival_date
                # error_log(date_check_fn, data_row[9],
                #          position, FIELD['arrival_date'])
                # shipping_charges
                error_log_1(float_check,
                            data_row[10], position, FIELD['shipping_charges'])
                # is_sold_out
                error_log(bool_check, data_row[11],
                          position, FIELD['is_sold_out'])
                if 'N/A' in data_row[12]:
                    pass
                else:
                    error_log(check_one, data_row[12],
                              position, FIELD['discount'])  # discount
                if 'N/A' in data_row[13]:
                    pass
                else:
                    error_log_1(float_check,
                                data_row[13], position, FIELD['mrp'])  # mrp
                # url_check_fn(data_row[14], position)  # page_url
                # product_url
                error_log(url_check, data_row[15],
                          position, FIELD['product_url'])
                # number_of_ratings
                error_log_2(int_check, data_row[16],
                            position, FIELD['number_of_ratings'])
                # avg_rating
                error_log_1(float_check,
                            data_row[17], position, FIELD['avg_rating'])
                # position
                error_log_2(
                    int_check, data_row[18], position, FIELD['position'])
                error_log(others_check, data_row[20],
                          position, FIELD['others'])  # others

            else:
                raise TypeError('TypeError', position)


def error_by_line(line, index):
    try:
        if '\\' in line and '\\"' not in line:
            logging.error('Backslash in data ' + str(index))
    except Exception as e:
        logging.error('Backslash in data' + str(e))


def line_by_line():
    with open(file_name + ".csv") as csvfile:
        for index, line in enumerate(csvfile):
            error_by_line(line, index)
            # if '\\' in line and '\\"' not in line:
            #     raise TypeError('Backslash in data', indx, line)


line_by_line()
