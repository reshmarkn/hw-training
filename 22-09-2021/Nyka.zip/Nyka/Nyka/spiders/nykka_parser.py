import scrapy
from scrapy.http import Request
from pymongo import MongoClient
import pymongo
import re
from scrapy import Selector
from datetime import datetime
import json
import pika
import logging
import random
import requests
from scrapy.exceptions import CloseSpider
from Nyka.items import NykkaparserItem
from Nyka.proxy import parse_proxy
from Nyka.settings import *



logger = logging.getLogger('pika')
logger.propagate = False

headers = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    "accept-encoding": "gzip, deflate, br",
    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
    "upgrade-insecure-requests": "1",
    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) snap Chromium/80.0.3987.100 Chrome/80.0.3987.100 Safari/537.36"
}
BASE_URL = 'https://www.nykaa.com'

class NykkaProductParserSpider(scrapy.Spider):
    name = 'nykka_parser'

    def start_requests(self):

        PROXY_LIST = requests.get("http://68.183.58.145/torproxies", headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
        PROXY = random.choice(PROXY_LIST)
        proxies = {"http": "http://%s" % PROXY, "https": "https://%s" % PROXY}

        credentials = pika.PlainCredentials('guest','guest')
        connection = pika.BlockingConnection(pika.ConnectionParameters( host='localhost', socket_timeout=300))
        channel = connection.channel()
        
        while True:
            channel.basic_qos(prefetch_count=1)
            method, properties, url = channel.basic_get(queue='nyka')
            if not url.strip():
                break
            channel.basic_ack(delivery_tag=method.delivery_tag)
            url = str(url.strip(), encoding='utf-8')
            if url.strip():
                link = url
                yield Request(url=link.strip(), callback=self.parse, headers=headers)

        connection.close()

    def parse(self, response):
        main_url = response.meta.get('main_url')
        position = response.meta.get('position')
        page_url = response.meta.get('page_url')
        catagory_hierarchys = response.meta.get('catagory_hierarchys')
        product_name_xpath = '//h1[@itemprop="name"]/text()'
        product_price_xpath = '//meta[@itemprop="price"]/@content'
        mrp_xpath = '//span[@class="mrp-price"]/text()'
        avg_rating_xpath = '//meta[@itemprop="ratingValue"]/@content'
        number_of_ratings_xpath = '//meta[@itemprop="ratingCount"]/@content'
        review_count_xpath = '//meta[@itemprop="reviewCount"]/@content'
        currency_xpath = '//meta[@itemprop="priceCurrency"]/@content'
        main_image_xpath = '//meta[@itemprop="image"]/@content'
        images_xpath = '//div[@class="slick-thumb"]//div[contains(@class,"slick-slide slick")]//img/@src'
        discount_xpath = '//div[@class="clearfix product-des__details"]//div[@class="discount-info"]/span/text()'
        is_sold_out_xpath = '//div[@class="col-md-7 col-sm-7 product-description-wrap"]//text()'
        category_hierarchy_xpath = '//script[contains(text(),"primary_categories")]//text()'
        sold_by_xpath = '//span[@class="sold-by"]/@title'

        product_name = response.xpath(product_name_xpath).extract()
        product_price = response.xpath(product_price_xpath).extract()
        mrp = response.xpath(mrp_xpath).extract()
        avg_rating = response.xpath(avg_rating_xpath).extract()
        number_of_ratings = response.xpath(number_of_ratings_xpath).extract()
        review_count = response.xpath(review_count_xpath).extract()
        currency = response.xpath(currency_xpath).extract()
        main_image = response.xpath(main_image_xpath).extract()
        images = response.xpath(images_xpath).extract()
        discount = response.xpath(discount_xpath).extract()
        is_sold_out = response.xpath(is_sold_out_xpath).extract()
        category_hierarchy = response.xpath(
            category_hierarchy_xpath).extract_first('')
        sold_by = response.xpath(sold_by_xpath).extract()

        product_name = product_name[0].strip() if product_name else ''
        product_price = float(product_price[0].strip()) if product_price else 0
        mrp = float(mrp[1].strip()) if mrp else 0
        avg_rating = float(avg_rating[0].strip()) if avg_rating else 0
        review_count = int(review_count[0].strip()) if review_count else 0
        number_of_ratings = int(number_of_ratings[0].strip(
        )) if number_of_ratings else 0
        currency = currency[0].strip() if currency else ''
        main_image = main_image[0].strip() if main_image else ''
        images = list(map(lambda x: x.replace(
            'w-50,h-50', 'w-800,h-800'), images)) if images else ''

        discount = ' '.join(discount).strip() if discount else 'N/A'
        is_sold_out = ''.join(is_sold_out) if is_sold_out else ''
        if 'ADD TO BAG' in is_sold_out:
            is_sold_out = False
        else:
            is_sold_out = True

        sold_by = sold_by[0].strip() if sold_by else ''

        product_url = response.url
        product_id = int(
            "".join(re.findall(r'skuId=\d+', product_url)).replace("skuId=", ""))

        last_visited = datetime.now().isoformat().split('.', 1)[
            0].replace('T', ' ')
        item = NykkaparserItem()
        item['product_id'] = product_id
        item['catalog_name'] = product_name
        item['catalog_id'] = product_id
        item['source'] = 'nykaa'
        item['scraped_date'] = last_visited
        item['product_name'] = product_name
        item['image_url'] = main_image
        item['category_hierarchy'] = catagory_hierarchys
        item['product_price'] = product_price
        item['arrival_date'] = 'N/A'
        item['shipping_charges'] = 99
        item['is_sold_out'] = is_sold_out
        item['discount'] = discount
        item['mrp'] = mrp if mrp else product_price
        item['page_url'] = 'N/A'
        item['product_url'] = product_url
        item['number_of_ratings'] = number_of_ratings
        item['avg_rating'] = avg_rating
        item['position'] = position
        item['others'] = {'other_images': images,
                          'review_count': review_count, 'sold_by': sold_by}
        yield item