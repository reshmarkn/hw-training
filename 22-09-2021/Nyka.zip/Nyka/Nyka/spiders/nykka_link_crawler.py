import scrapy
from scrapy.http import Request
import re
import json
import requests
import random
import logging
from scrapy.exceptions import CloseSpider
from Nyka.items import NykkalinkcrawlerItem
from Nyka.proxy import parse_proxy
from Nyka.settings import *




headers = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    "accept-encoding": "gzip, deflate",
    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
    "upgrade-insecure-requests": "1",
    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36"
    # "user-agent": random.choice(USER_AGENT_LIST)
}
BASE_URL = 'https://www.nykaa.com'

# handle_httpstatus_list = [500, 200, 403]

class NykkaUrlCrawlerSpider(scrapy.Spider):
    name = 'nykka_link_crawler'

    def start_requests(self):
        main_urls = [
            "https://www.nykaa.com/personal-care/bath-and-shower/c/35?ptype=lst&id=35&root=nav_2&dir=desc&order=popularity",
            "https://www.nykaa.com/makeup/face/c/13?ptype=lst&id=13&root=nav_2&dir=desc&order=popularity"]
        for main_url in main_urls:
            position = 0
            next_url = main_url
            category_url = "https://www.nykaa.com/app-api/index.php/products/getBreadCrumb?id=" + \
                ("".join(re.findall(r'/c/\d+', main_url)).replace("/c/", ""))
            try:
                category_response = requests.get(category_url, headers=headers)
            except:
                category_response = {}
            category_response = category_response.json()
            catagory_hierarchys = {}
            length = 1
            for item in category_response.get('response'):
                catagory_hierarchys.update(
                    {'l' + str(length): item.get('key')})
                if length == 4:
                    break
                length += 1

            meta = {"main_url": main_url,
                    'position': position, 'next_url': next_url, "catagory_hierarchys": catagory_hierarchys}
            yield Request(main_url, headers=headers, callback=self.parse, dont_filter=True, meta=meta)

    def parse(self, response):
        if response.status == 200:
            main_url = response.meta.get('main_url')
            position = response.meta.get('position')
            next_url = response.meta.get('next_url')
            catagory_hierarchys = response.meta.get('catagory_hierarchys')
            links_xpath = '//div[@class="product-list-box card desktop-cart"]/a/@href'
            links = response.xpath(links_xpath).extract()
            if links:
                for link in links:
                    position = position + 1
                    item = NykkalinkcrawlerItem()
                    item['child_url'] = BASE_URL + link
                    item['main_url'] = main_url
                    item['position'] = position
                    item['catagory_hierarchys'] = catagory_hierarchys
                    item['page_url'] = response.url
                    yield item
                next_page_link_xpath = '//link[@rel="next"]/@href'
                next_page_link = response.xpath(
                    next_page_link_xpath).extract_first("")
                if next_page_link:
                    next_page_link = next_page_link
                    meta = {"main_url": main_url, 'position': position,
                            'next_url': next_page_link, "catagory_hierarchys": catagory_hierarchys}
                    yield Request(next_page_link, headers=headers, callback=self.parse, dont_filter=True, meta=meta)
                    # try:
                    #     yield Request(next_url, headers=headers, callback=self.parse, dont_filter=True, meta=meta)
                    # except:
                    #     try:
                    #         yield Request(next_url, headers=headers, callback=self.parse, dont_filter=True, meta=meta)
                    #     except:
                    #         logging.warning(response.url)

        else:
            next_url = response.meta.get('next_url')
            meta = {"main_url": response.meta.get('main_url'),
                    'position': response.meta.get('position'), 'next_url': response.meta.get('next_url'), "catagory_hierarchys": response.meta.get('catagory_hierarchys')}
            try:
                yield Request(next_url, headers=headers, callback=self.parse, dont_filter=True, meta=meta)
            except:
                try:
                    yield Request(next_url, headers=headers, callback=self.parse, dont_filter=True, meta=meta)
                except:
                    logging.warning(response.url)

        
              
