import scrapy

from scrapy.http import Request

import re

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.101 Safari/537.36'
    }



class WayfairSpider(scrapy.Spider):

    name = 'wayfair_link'
    start_urls = ['http://api.ipify.org/?format=json']

    def start_requests(self):
        urls = ['https://www.wayfair.com/furniture/cat/furniture-c45974.html']
        for url in urls:
            response = self.parse_requests(url)
            self.parse_category(response, url)

    def parse_category(self, response, url):
        if response:
            sel = Selector(text=str(response.content, encoding='utf-8'))
            sub_cat = sel.xpath('//nav[@class="CategoryLandingPageNavigation-navWrap"]//a/@href').extract()
            if sub_cat:
                for sub_link in sub_cat:
                    if 'http' in sub_link:
                        res = self.parse_requests(sub_link)
                        self.parse_product_page(res, sub_link)
                    else:
                        res = self.parse_requests(sub_link)
                        self.parse_category(res, sub_link)
        else:
            res = self.parse_requests(url)
            self.parse_category(res, url)

    def parse_product_page(self, response, url):
        if response:
            sel = Selector(text=str(response.content, encoding='utf-8'))
            next_page = sel.xpath('//a[@aria-label="Next"]/@href').extract()
            next_page_link = ''.join(next_page)
            psource = re.findall('[\{"sku":.*"units":".*?\]', str(response.text))
        
    #         purl = re.findall('"url":"(.*?)"', str(psource))
    #         for p in purl:
    #             prourl = p.replace('\\\\\\\\', '').replace('\\\\', '')
    #             part = prourl.split('-')[-1].replace('.html', '')
    #             url_item = WayfairLink()
    #             url_item['url'] = prourl
    #             url_item['part_number'] = part
    #             print(url_item)
    #             # yield url_item

    #         if next_page:
    #             res = self.parse_requests(next_page_link)
    #             self.parse_product_page(res, next_page_link)
    #     else:
    #         res = self.parse_requests(url)
    #         self.parse_product_page(res, url)

    def parse_requests(url):
        request_count = 0
        while True:
            final_response = ''
            if request_count <= 15:
                try:
                    logging.warning(url)
                    request_count = request_count + 1
                    final_response = requests.get(
                        url=url, headers=HEADERS, timeout=10)
                    sleep(2)
                    if final_response and final_response.status_code == 200:
                        break
                except Exception as e:
                    print(e)
                    pass
            else:
                final_response = ''
                break
        return final_response


