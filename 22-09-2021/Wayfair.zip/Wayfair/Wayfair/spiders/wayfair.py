import scrapy

from scrapy.http import Request

import json

from datetime import datetime

import re

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.101 Safari/537.36'
    }

class WayfairSpider(scrapy.Spider):
    name = 'wayfair'

    def start_requests(self):
        urls=['https://www.wayfair.com/appliances/pdp/samsung-36-side-by-side-274-cu-ft-energy-star-refrigerator-smsg1223.html']
        for url in urls:
            yield Request(url,headers=headers, callback=self.parse)

    def parse(self, response):
        JSON_SCRIPT = response.xpath("//script[@type='application/ld+json']/text()").extract()
        json_data = json.loads(JSON_SCRIPT[0])
        # print(json_data)

        date_crawled = (datetime.now()).strftime("%Y-%m-%dT%H:%M:%S")
        product_url = response.url
        product_name = json_data.get('name','')
        price = json_data.get('offers',{}).get('price','')
        Brand_Name = json_data.get('brand','')
        description = json_data.get('description','')
        VENDOR_XPATH = response.xpath('//meta[@property="og:upc"]/@content').extract_first()
        Vendor_Seller_Part_Number = VENDOR_XPATH.strip() if VENDOR_XPATH else ""
        BREAD_CRUM_XPATH = response.xpath('//ol[@class="Breadcrumbs-list"]/li/a/text()').extract()
        availability = json_data.get('offers',{}).get('availability','')
        availability1 = availability.split('/')[-1]
        if availability1.lower() ==  "instock" :
            is_sold_out = False
        else:
            is_sold_out = True

        add_to_cart = response.xpath('//button[@id="btn-add-to-cart"]/span[@class="Button-content"]/text()').extract()
        if add_to_cart:
            cart = "".join(add_to_cart)
        else:
            cart = ''
            if instock == "InStock" and cart == "Add to Cart":
                Availability = 'available'
            else:
                Availability = 'not available'

        sku = json_data.get('sku','')
        part_no = response.xpath("//span[has-class('Breadcrumbs-item')]/text()").re_first(r'Part #:\s*(.*)')

        selectedOptions = re.findall('"selectedOptions":"(.*?)"', str(response.body))
        print(selectedOptions)

        options = ''.join(selectedOptions)
        print(options)

        manufacturer_name = ''.join(re.findall('"brand":"(.*?)"', str(response.body)))
        manufacturer_name = manufacturer_name.strip() if manufacturer_name else ""

        Brand_Name = ''.join(re.findall('"brand":"(.*?)"', str(response.body)))
        Brand_Name = Brand_Name.strip() if Brand_Name else ""
       
        Manufacturer_Part_Number = re.findall('"partNumberToShow":"(.*?)"', str(response.body))[0]
        Manufacturer_Part_Number = Manufacturer_Part_Number.strip() if Manufacturer_Part_Number else ""


        
