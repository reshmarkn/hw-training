# -*- coding: utf-8 -*-
import scrapy


# class WbmasonItem(scrapy.Item):
#     company_name = scrapy.Field()
#     manufacturer_name = scrapy.Field()
#     brand_name = scrapy.Field()
#     manufacturer_part_number = scrapy.Field()
#     vendor_seller_part_number = scrapy.Field()
#     item_name = scrapy.Field()
#     full_product_description = scrapy.Field()
#     price = scrapy.Field()
#     country_of_origin = scrapy.Field()
#     unit_of_issue = scrapy.Field()
#     qty_per_uoi = scrapy.Field()
#     upc = scrapy.Field()
#     model_number = scrapy.Field()
#     product_category = scrapy.Field()
#     url = scrapy.Field()
#     availability = scrapy.Field()
#     date = scrapy.Field()

import scrapy


class WbmasonItem(scrapy.Item):
    def __setitem__(self, key, value):
        self._values[key] = value
        self.fields[key] = {}


# class BettymillsNewLink(scrapy.Item):
#     def __setitem__(self, key, value):
#         self._values[key] = value
#         self.fields[key] = {}
