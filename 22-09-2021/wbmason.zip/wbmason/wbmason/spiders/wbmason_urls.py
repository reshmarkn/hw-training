# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from wbmason.items import *
from wbmason.settings import *
from wbmason.proxy import parse_proxy
from datetime import datetime
from pymongo import MongoClient

db = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017').daria_mathew_wbmason
db.urls.create_index('url', unique=True)

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


class WbmasonSpider(Spider):
    name = 'wbmason_urls'
    start_urls = ['https://www.wbmason.com/RegZipCode.aspx']

    def parse(self, response):
        compressedviewstate = response.xpath(
            '//input[@id="__COMPRESSEDVIEWSTATE"]/@value').extract_first('')
        eventvalidation = response.xpath(
            '//input[@id="__EVENTVALIDATION"]/@value').extract_first('')
        formdata = {'__EVENTTARGET': 'ctl00$ContentPlaceholder1$submitLinkButton',
                    '__EVENTARGUMENT': '',
                    '__COMPRESSEDVIEWSTATE': compressedviewstate,
                    '__VIEWSTATE': '',
                    '__EVENTVALIDATION': eventvalidation,
                    'ctl00$CartDropdown$SaveWorkFlowCart': '',
                    'ctl00$typeAheadCategoryId': '',
                    'ctl00$isTypeAhead': '',
                    'ctl00$txtGlobalSearch': '',
                    'ctl00$TabSetNavigation$listId': '',
                    'ctl00$TabSetNavigation$listOrder': '',
                    'ctl00$TabSetNavigation$listContractCode': '',
                    'ctl00$ContentPlaceholder1$txtZip': '02301',
                    'ctl00$ContentPlaceholder1$rblRegOptions': 'Option3',
                    'ctl00$XPos': '',
                    'ctl00$YPos': '', }
        url = 'https://www.wbmason.com/RegZipCode.aspx'
        yield FormRequest(url=url, callback=self.parse_category, formdata=formdata)

    def parse_category(self, response):
        # =================================================
        # fetch category urls from site first and then crawl
        # ==================================================
        f = open('wbmason_urls.txt')
        for url in f.readlines():
            url = url.strip()
            yield Request(url=url, callback=self.parse_products)

    def parse_products(self, response):
        PRODUCTS_XPATH = '//a[contains(@id, "_imgLnkItemDesc")]/@href'
        category = response.xpath(
            '//img[@class="remove-cat"]/following-sibling::span/text()').extract_first('')
        products = response.xpath(PRODUCTS_XPATH).extract()
        for url in products:
            url = url.strip()
            url = url+'--'+category
            meta = {'url': url}
            print(meta)
            try:
                db.urls.insert(dict(meta))
            except:
                pass

        next_page = response.xpath(
            '//a[@id="ctl00_ContentPlaceholder1_ProductList_SearchOptionsHeader_lnkNextPage"]/@href').extract_first('')
        if next_page:
            next_page = response.urljoin(next_page)
            yield Request(url=next_page, callback=self.parse_products)
