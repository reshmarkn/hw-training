# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from wbmason.items import *
from wbmason.settings import *
from wbmason.proxy import parse_proxy
from datetime import datetime
# from scrapy.shell import inspect_response


handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


class WbmasonSpider(Spider):
    name = 'wbmason'
    start_urls = ['https://www.wbmason.com/RegZipCode.aspx']

    def parse(self, response):
        compressedviewstate = response.xpath(
            '//input[@id="__COMPRESSEDVIEWSTATE"]/@value').extract_first('')
        eventvalidation = response.xpath(
            '//input[@id="__EVENTVALIDATION"]/@value').extract_first('')
        formdata = {'__EVENTTARGET': 'ctl00$ContentPlaceholder1$submitLinkButton',
                    '__EVENTARGUMENT': '',
                    '__COMPRESSEDVIEWSTATE': compressedviewstate,
                    '__VIEWSTATE': '',
                    '__EVENTVALIDATION': eventvalidation,
                    'ctl00$CartDropdown$SaveWorkFlowCart': '',
                    'ctl00$typeAheadCategoryId': '',
                    'ctl00$isTypeAhead': '',
                    'ctl00$txtGlobalSearch': '',
                    'ctl00$TabSetNavigation$listId': '',
                    'ctl00$TabSetNavigation$listOrder': '',
                    'ctl00$TabSetNavigation$listContractCode': '',
                    'ctl00$ContentPlaceholder1$txtZip': '02301',
                    'ctl00$ContentPlaceholder1$rblRegOptions': 'Option3',
                    'ctl00$XPos': '',
                    'ctl00$YPos': '', }
        url = 'https://www.wbmason.com/RegZipCode.aspx'
        yield FormRequest(url=url, callback=self.parse_category, formdata=formdata)

    def parse_category(self, response):
        # f = open('urls.txt')
        # for url in f.readlines():
        #     url = url.strip()
        #     yield Request(url=url, callback=self.parse_products)
# -------------------------            
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        channel = connection.channel()
        while True:
            channel.basic_qos(prefetch_count=1)
            method, properties, url = channel.basic_get(queue=QUEUE_NAME)
            if not url.strip():
                break
            channel.basic_ack(delivery_tag=method.delivery_tag)
            url = str(url.strip(), encoding='utf-8')
            if url.strip():
                link = url
                # link = url.split('--')[0]
                # category = url.split('--')[1]
                # meta = {'category':category}
                yield Request(url=link.strip(), callback=self.parse_products_data, errback=lambda x: self.errback_httpbin(x, url.strip()))
        connection.close()
# ---------------------------------        
    # def parse_products(self, response):
    #     PRODUCTS_XPATH = '//a[contains(@id, "_imgLnkItemDesc")]/@href'
    #     # category = response.xpath(
    #         # '//img[@class="remove-cat"]/following-sibling::span/text()').extract_first('')
    #     products = response.xpath(PRODUCTS_XPATH).extract()
    #     for url in products:
    #         url = url.strip()
    #         # meta = {'category': category}
    #         yield Request(url=url, callback=self.parse_products_data)
    #     next_page = response.xpath(
    #         '//a[@id="ctl00_ContentPlaceholder1_ProductList_SearchOptionsHeader_lnkNextPage"]/@href').extract_first('')
    #     if next_page:
    #         next_page = response.urljoin(next_page)
    #         yield Request(url=next_page, callback=self.parse_products)
# ----------------------------
    def parse_products_data(self, response):
        # inspect_response(response, self)
        MANUFACTURER_NAME_XPATH = '//div[@class="product-info"]/img/@alt'
        ITEM_NAME_XPATH = '//h3[@class="item-name"]/text()'
        FULL_PRODUCT_DESCRIPTION_XPATH = '//ul[@class="item-points"]//li/text()'
        PRICE_XPATH = '//span[@id="ctl00_ContentPlaceholder1_ucProductDetail_fvProductDetail_lblSellPrice"]/text()'
        COUNTRY_OF_ORIGIN_XPATH = '//img[@id="ctl00_ContentPlaceholder1_ucProductDetail_fvProductDetail_rptItemIndicators_ctl11_IndicatorIcon"]/@title'
        UNIT_OF_ISSUE_XPATH = '//span[@id="ctl00_ContentPlaceholder1_ucProductDetail_fvProductDetail_lblUOM"]/text()'
        MANUFACTURER_PART_NUMBER_XPATH = '//span[@id="ctl00_ContentPlaceholder1_ucProductDetail_fvProductDetail_lblItemNumber"]/text()'
        VENDOR_NUM_SKU_XPATH = '//script[contains(text(), "digitalData")]/text()'
        AVAILABILITY_XPATH = '//input[@name="ctl00$ContentPlaceholder1$ucProductDetail$fvProductDetail$btnAddToCart"]/@value'
        CATEGORY_XPATH = '//a[@id="ctl00_ContentPlaceholder1_lnkBackToResults"]/text()'

        company_name = 'Wbmason'
        item_name = response.xpath(ITEM_NAME_XPATH).extract()
        manufacturer_name = response.xpath(
            MANUFACTURER_NAME_XPATH).extract_first('')
        brand_name = manufacturer_name
        manufacturer_part_number = response.xpath(
            MANUFACTURER_PART_NUMBER_XPATH).extract_first('')
        full_product_description = response.xpath(
            FULL_PRODUCT_DESCRIPTION_XPATH).extract()
        price = response.xpath(PRICE_XPATH).extract_first('')
        country_of_origin = response.xpath(
            COUNTRY_OF_ORIGIN_XPATH).extract_first('')
        unit_of_issue = response.xpath(UNIT_OF_ISSUE_XPATH).extract_first('')
        qty_per_uoi = ''
        upc = ''
        model_number = ''
        product_category = response.xpath(CATEGORY_XPATH).extract_first('')

        # product_category = response.meta['category']

        url = response.request.url
        vendor_seller_part_number = response.xpath(
            VENDOR_NUM_SKU_XPATH).extract_first('')
        availability_ = response.xpath(AVAILABILITY_XPATH).extract_first('')

        item_name = ' '.join(' '.join(item_name).split()
                             ).strip() if item_name else ''
        full_product_description = ' '.join(' '.join(
            full_product_description).split()).strip() if full_product_description else ''
        price = price.replace('$', '')
        country_of_origin = country_of_origin.replace('Made In The ', '')
        vendor_seller_part_number = re.findall(
            r'"productSKU":"(.*?)",', vendor_seller_part_number)[0]
        if availability_ == 'Add To Cart':
            availability = 'Available'
        else:
            availability = 'Not Available'
        date = datetime.now().isoformat().split('.', 1)[0]
        product_category = product_category.split('more ')[1]


        item_data = WbmasonItem()
        item_data['URL'] = url
        item_data['Item Name'] = item_name
        item_data['Price'] = price
        item_data['Product Category'] = product_category
        item_data['Full Product Description'] = full_product_description
        item_data['Company Name'] = company_name
        item_data['Manufacturer Name'] = manufacturer_name
        item_data['Vendor/Seller Part Number'] = vendor_seller_part_number
        item_data['Date Crawled'] = date
        item_data['Model Number'] = model_number
        item_data['Manufacturer Part Number'] = manufacturer_part_number
        item_data['Country of Origin'] = country_of_origin
        item_data['Unit of Issue (UOI)'] = unit_of_issue
        item_data['QTY Per UOI'] = qty_per_uoi
        item_data['UPC'] = upc
        item_data['Brand Name'] = brand_name
        item_data['Availability'] = availability
        if item_name:
            yield item_data
    def errback_httpbin(self, failure, url):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=600))
        channel = connection.channel()
        channel.queue_declare(queue=QUEUE_NAME, durable=True)
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=url)
        connection.close()