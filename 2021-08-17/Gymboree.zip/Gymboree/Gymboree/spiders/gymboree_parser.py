import scrapy

from scrapy.http import Request

import json

from scrapy.exceptions import CloseSpider

from Gymboree.items import GymboreeParserItem

import logging

import pika

logger = logging.getLogger('pika')
logger.propagate = False



headers = {
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "accept-encoding": "gzip, deflate, br",
        "accept-language": "en-US,en;q=0.9",
        "upgrade-insecure-requests": "1",
        "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36"
        }

class GymboreeParserSpider(scrapy.Spider):
    name = 'gymboree_parser'

    def start_requests(self):
        
        # links = ['https://www.gymboree.com/us/p/Girls-Long-Sleeve-Embroidered-Floral-Fleece-Ruffle-Zip-Up-Hoodie---Western-Skies-3023068-2152',
        #         'https://www.gymboree.com/us/p/Girls-Long-Sleeve-Embroidered-Horseshoe-Knit-Dress---Western-Skies-3022996-32SZ',
        #         'https://www.gymboree.com/us/p/Girls-Knit-Ruffle-Leggings-3017447-072',
        #         'https://www.gymboree.com/us/p/Zip-front-with-ruffle-trim-3029693-BQ']

        # for url in links:
        #     yield Request(url, headers=headers) 

        credentials = pika.PlainCredentials('guest','guest')
        connection = pika.BlockingConnection(pika.ConnectionParameters( host='localhost', socket_timeout=300))
        channel = connection.channel()
        while True:
            channel.basic_qos(prefetch_count=1)
            method, properties, url = channel.basic_get(queue='gymboree')
            if not url.strip():
                break
            channel.basic_ack(delivery_tag=method.delivery_tag)
            url = str(url.strip(), encoding='utf-8')
            if url.strip():
                link = url
                # link = url.split('--')[0]
                # category = url.split('--')[1]
                # meta = {'category':category}
                yield Request(url=link.strip(), callback=self.parse, headers=headers)
            break
            
        connection.close()

        

    def parse(self, response):
        
        #XPATH
        product_name = response.xpath("//div[@class='title-wrapper']/h1/text()").extract_first()
        product_reviews = response.xpath("//div[@class='custom-ranking-container']/span[2]/text()").extract_first()  
        product_quantity = response.xpath('//select[@id="quantity"]/option/text()').extract()
        product_description = response.xpath("//div[@itemprop='description']/div/ul/li/text()").extract()  
        product_image = response.xpath('//head/meta[@property="og:image"]/@content').extract_first()

        data = response.xpath('//script[@id="__NEXT_DATA__"]/text()').extract()
        json_data = json.loads(data[0]) 

        product_price = json_data.get('props', {}).get('initialState', {}).get('ProductDetail', {}).get('currentProduct', {}).get('offerPrice', '')
        product_afterpay = json_data.get('props',{}).get('initialState',{}).get('session',{}).get('siteDetails',{}).get('AFTERPAY_MIN_ORDER_AMOUNT','')
        data_list = json_data.get('props', {}).get('initialState', {}).get('ProductDetail', {}).get('currentProduct', {}).get('colorFitsSizesMap', [])
        fits_list = data_list[0].get('fits', [])
        variants={}
        for col in data_list:
            colors_name =col.get('color', {}).get('name', '')
            for dis in data_list:
                discount = dis.get('miscInfo',{}).get('badge2','')
                if fits_list:
                    size = []
                    for f in fits_list:
                        sizes = f.get('sizes', [])
                        for s in sizes:
                            s_name = s.get('sizeName')
                            size.append(s_name) if s_name else ''
                            variants.update({'colour': colors_name })
                            variants.update({'size': size})

        
        item = GymboreeParserItem()

        item['pdp_url'] = response.url
        item['product_name'] = product_name
        item['product_price'] = product_price
        item['image_url'] = product_image
        item['product_discount'] = discount
        item['product_reviews'] = product_reviews
        item['product_quantity'] = product_quantity
        item['product_description'] = product_description
        item['product_afterpay'] = product_afterpay
        item['varients'] = variants
        
        yield item 
     
    