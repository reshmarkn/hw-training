# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class ZapposparserItem(scrapy.Item):
    # define the fields for your item here like:
    _id = scrapy.Field()
    PRODUCT_BRAND = scrapy.Field()
    PRODUCT_NAME = scrapy.Field()
    PRODUCT_PRICE = scrapy.Field()
    PRODUCT_DISCOUNT = scrapy.Field()
    PRODUCT_MSRP = scrapy.Field()
    AVAILABLE_COLOURS = scrapy.Field()
    PRODUCT_IMAGE = scrapy.Field()
    PRODUCT_DESCRIPTION = scrapy.Field()
    PRODUCT_REVIEWS=scrapy.Field()

class ZapposlinkcrawlerItem(scrapy.Item):
    _id = scrapy.Field()
    PRODUCT_URL = scrapy.Field()


