import scrapy

from scrapy.http import Request

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.101 Safari/537.36'
    }



class LimeroadSpider(scrapy.Spider):
    
    name = 'limeroad_link_crawler'
    base_urls = 'https://www.limeroad.com'
    
    def start_requests(self):

        start_urls = 'https://www.limeroad.com/clothing/ethnic-wear/sets?src_id=navdeskEthnicSets__002'
        yield Request(start_urls, callback=self.parse, headers = headers)
    
    def parse(self, response):
       
        product_links = response.xpath("//a[@data-pgn='Prod VIP']/@href").extract() 
        # count = 0
        for link in product_links:
            product_url = self.base_urls+link
            # count= count+1

            item = {}
            item['product_url'] = product_url
            yield item

        next_page = response.xpath("//div[@class='paginationPageNext']/a/@href").extract_first()
        if next_page:
            next_page_url = next_page
            yield Request(next_page_url, headers=headers, callback=self.parse)

 
    
   

