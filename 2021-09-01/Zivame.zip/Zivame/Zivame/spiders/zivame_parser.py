import scrapy

from scrapy.http import Request

from datetime import date

import json

import demjson

import re

from Zivame.settings import *

import random

from Zivame.proxy import parse_proxy

today = str(date.today())


# USER_AGENT_LIST = ['Mozilla/5.0 (Windows NT 6.1; WOW64; rv:41.0) Gecko/20100101 Firefox/41.0',
#                    'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36',
#                    'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/537.36',
#                    'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36',
#                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11) AppleWebKit/601.1.56 (KHTML, like Gecko) Version/9.0 Safari/601.1.56',
#                    'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/537.36',
#                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_1) AppleWebKit/601.2.7 (KHTML, like Gecko) Version/9.0.1 Safari/601.2.7',
#                    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/44.0.2403.89 Chrome/44.0.2403.89 Safari/537.36',
#                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36',
#                    'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)']

headers = {
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "accept-encoding": "gzip, deflate, br",
        "accept-language": "en-US,en;q=0.9",
        "upgrade-insecure-requests": "1",
        "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36"
        }


class ZivameParserSpider(scrapy.Spider):
    
    name = 'zivame_parser'


    def start_requests(self):

        PROXY_LIST = requests.get("http://68.183.58.145/torproxies", headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
        PROXY = random.choice(PROXY_LIST)
        proxies = {"http": "http://%s" % PROXY, "https": "https://%s" % PROXY}

        links = ['https://www.zivame.com/maybelline-new-york-color-sensational-creamy-matte-lipstick-640-red-liberation-3-9-g.html?trksrc=category&trkid=Beauty&trkorder=best-sellers']
        for url in links:
            yield Request(url, headers = headers,proxies=proxies)
    
    def parse(self, response):
        
        #XPATH

        SCRIPT_XPATH = "//script[contains(text(), 'window.__product')]/text()"
        IMAGE_XPATH = '//head/meta[@property="og:image"]/@content'
    
        script = response.xpath(SCRIPT_XPATH).extract_first()
        script = script.replace('window.__product=','')
        script = script.replace('window.__product=','').replace('!','') 
        json_data =  demjson.decode(script)
 
        product_url = response.url
        product_name = json_data.get('summary').get('name')
        product_id = json_data.get('summary', {}).get('productId', '')
        average_rating = json_data.get('summary', {}).get('rating', '')
        number_of_ratings = json_data.get('summary', {}).get('reviewCount', '')
        
        product_mrp = json_data.get('summary', {}).get('price', '')
        product_price = json_data.get('summary', {}).get('specialPrice', '')
        
        if product_price == 0:
            product_price = product_mrp
        else:
            product_price = product_price

        product_discount = json_data.get('summary', {}).get('discountPercent','')
        availability = json_data.get('summary', {}).get('stockStatus', '')

        image_url = response.xpath(IMAGE_XPATH).extract_first()
        image_url = 'https:'+image_url


        item = {}
        
        item['product_id'] = product_id
        item['source'] = 'https://www.zivame.com'
        item['scraped_date'] = today
        item['product_name'] = product_name
        item['image_url'] = image_url
        item['category_hierarchy'] = ''
        item['product_price'] = product_price
        item['arrival_date'] = ''
        item['shipping_charges'] = ''
        item['is_sold_out'] = is_sold_out
        item['discount'] = product_discount
        item['mrp'] =  product_mrp
        item['product_url'] = product_url
        item['number_of_ratings'] = number_of_ratings
        item['avg_rating '] = average_rating
        item['position'] = ''
        item['country_code'] = 'IN'
        
        yield item
  
