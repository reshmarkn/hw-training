# -*- coding: utf-8 -*-
import scrapy
import json
from exprealty.items import *
from w3lib.html import remove_tags
from exprealty.settings import *
import re


class ExprealtySpider(scrapy.Spider):
    name = 'exprealty'
    start_urls = ['https://experts.expcloud.com/']
    allowed_domains = ['experts.expcloud.com']
    api_headers = {'accept': 'application/json, text/plain, */*',
                   'accept-encoding': 'gzip, deflate, br',
                   'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', }

    def start_requests(self):
        locations = {
            "Alabama": "AL",
            "Alaska": "AK",
            "Alberta": "AB",
            "Arizona": "AZ",
            "Arkansas": "AR",
            "British Columbia": "BC",
            "California": "CA",
            "Colorado": "CO",
            "Connecticut": "CT",
            "Delaware": "DE",
            "Florida": "FL",
            "Georgia": "GA",
            "Hawaii": "HI",
            "Idaho": "ID",
            "Illinois": "IL",
            "Indiana": "IN",
            "Iowa": "IA",
            "Kansas": "KS",
            "Kentucky": "KY",
            "Louisiana": "LA",
            "Maine": "ME",
            "Manitoba": "MB",
            "Maryland": "MD",
            "Massachusetts": "MA",
            "Michigan": "MI",
            "Minnesota": "MN",
            "Mississippi": "MS",
            "Missouri": "MO",
            "Montana": "MT",
            "Nebraska": "NE",
            "Nevada": "NV",
            "New Brunswick": "NB",
            "New Hampshire": "NH",
            "New Jersey": "NJ",
            "New Mexico": "NM",
            "New York": "NY",
            "Newfoundland": "NF",
            "North Carolina": "NC",
            "North Dakota": "ND",
            "Northwest Territories": "NT",
            "Nova Scotia": "NS",
            "Ohio": "OH",
            "Oklahoma": "OK",
            "Ontario": "ON",
            "Oregon": "OR",
            "Pennsylvania": "PA",
            "Prince Edward Island": "PE",
            "Quebec": "QC",
            "Rhode Island": "RI",
            "Saskatchewan": "SK",
            "South Carolina": "SC",
            "South Dakota": "SD",
            "Tennessee": "TN",
            "Texas": "TX",
            "Utah": "UT",
            "Vermont": "VT",
            "Virginia": "VA",
            "Washington D.C.": "DC",
            "Washington": "WA",
            "West Virginia": "WV",
            "Wisconsin": "WI",
            "Wyoming": "WY",
            "Yukon": "YT",
        }

        for location, _id in locations.items():
            loc_url = 'https://experts.expcloud.com/api4/std?searchterms=' + \
                _id + '&size=6000&from=0'
            meta = {'location': location}
            yield scrapy.Request(url=loc_url, callback=self.parse, headers=self.api_headers, meta=meta, dont_filter=True)

    def parse(self, response):

        # scrapy.shell.inspect_response(response, self)
        json_data = json.loads(response.body_as_unicode())
        if json_data.get('hits'):
            # print(json_data['hits'].get('total'))
            if json_data['hits'].get('hits'):
                agents_data = json_data['hits']['hits']
                for data in agents_data:
                    data = data.get('_source')
                    if data:
                        city = ''
                        state = ''
                        zipcode = ''
                        agent_phone_numbers = [data.get('primaryPhone', '')] if data.get(
                            'primaryPhone', '') else ''
                        agent_loc = data.get('agentPrimaryLocation')
                        if agent_loc:
                            city = agent_loc[0].get('city', '')
                            state = agent_loc[0].get('state', '')
                            zipcode_ = agent_loc[0].get('zipcode', '')
                            if re.findall(r'\d{4,}', zipcode_):
                                zipcode = ', '.join(
                                    re.findall(r'\d{4,}', zipcode_))
                                country = 'United States'
                            elif re.findall(r'\w\d\w\s?-?\d\w\d', zipcode_):
                                zipcode = zipcode_.upper()
                                country = 'Canada'
                            else:
                                for loc in data.get('activeLocations'):
                                    if loc.get('stateName') == state:
                                        country = loc.get('countryName')
                                    elif loc.get('city') == city:
                                        country = loc.get('countryName')
                                    else:
                                        country = ''
                                zipcode = ''
                        address = ''
                        description = remove_tags(
                            data.get('bio', '')).strip() if data.get('bio', '') else ''
                        if description == "":
                            description = data.get('AgentMarketingCenter')
                            if description:
                                for i in description:
                                    description = i.get('Bio', '')
                                    description = remove_tags(description)
                                    description = description.replace(
                                        '*', '').strip()
                                # print(description)
                            else:
                                description = ''

                        email = data.get('primaryEmail', '')
                        first_name = data.get('firstName', '')
                        image_url = 'https://experts.expcloud.com/agentphoto/' + \
                            data.get(
                                'agentPhoto', '') + '.png' if not data.get('agentPhoto', '') == '0' else ''
                        languages = []
                        last_name = data.get('lastName', '')
                        middle_name = ''
                        office_name = 'eXp Realty'
                        office_phone_numbers = []
                        url = data.get('directlink', '')
                        if 'htt' in url:
                            profile_url = url
                        else:
                            profile_url = (
                                'https://experts.expcloud.com/' + data.get('directlink', '')).strip('/')

                        title = data.get('title', '').strip()
                        website = ''
                        data2 = data.get('AgentMarketingCenter')
                        if data2:
                            for i in data2:
                                website = i.get('Website', '')
                                linkedin_url = i.get('LinkedIn_URL', '')
                                facebook_url = i.get('Facebook_URL', '')
                                twitter_url = i.get('Twitter', '')

                        # if not social.get("linkedin_url"):
                        #     social.pop("linkedin_url")
                        # if not social.get("facebook_url"):
                        #     social.pop("facebook_url")
                        # if not social.get("twitter_url"):
                        #     social.pop("twitter_url")

                            if facebook_url or twitter_url or linkedin_url:
                                social = {'facebook_url': facebook_url,
                                          'twitter_url': twitter_url,
                                          'linkedin_url': linkedin_url
                                          }
                            else:
                                social = {}

                        if first_name:
                            items = ExprealtyItem(
                                address=address,
                                agent_phone_numbers=agent_phone_numbers,
                                city=city,
                                country=country,
                                description=description,
                                email=email,
                                first_name=first_name,
                                image_url=image_url,
                                languages=languages,
                                last_name=last_name,
                                middle_name=middle_name,
                                office_name=office_name,
                                office_phone_numbers=office_phone_numbers,
                                profile_url=profile_url,
                                social=social,
                                state=state,
                                website=website,
                                zipcode=zipcode,
                                title=title,
                            )
                            yield items
