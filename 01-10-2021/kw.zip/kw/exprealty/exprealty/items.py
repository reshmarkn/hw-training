# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class ExprealtyItem(scrapy.Item):
    address = scrapy.Field()
    agent_phone_numbers = scrapy.Field()
    city = scrapy.Field()
    country = scrapy.Field()
    description = scrapy.Field()
    email = scrapy.Field()
    first_name = scrapy.Field()
    image_url = scrapy.Field()
    languages = scrapy.Field()
    last_name = scrapy.Field()
    middle_name = scrapy.Field()
    office_name = scrapy.Field()
    office_phone_numbers = scrapy.Field()
    profile_url = scrapy.Field()
    social = scrapy.Field()
    state = scrapy.Field()
    website = scrapy.Field()
    zipcode = scrapy.Field()
    title = scrapy.Field()
