# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json

from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from longandfoster_realestate.items import *
from longandfoster_realestate.settings import *
from longandfoster_realestate.proxy import parse_proxy
from pymongo import MongoClient

headers = {
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36',
    'X-NewRelic-ID': 'VQEEVl5XDRAHV1VXAwYDUA==',
    'X-Requested-With': 'XMLHttpRequest'}


class Longandfoster_RealestateUrlSpider(Spider):
    name = 'longandfoster_realestate_crawler'
    # start_urls = [
    #     'https://www.longandfoster.com/include/ajax/api.aspx?op=SearchAgents&firstname=&lastname=&page=1&pagesize=50']
    allowed_domains = []
    db = MongoClient(
        'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017').automation_test_kw

    def start_requests(self):
        for var in range(0, 192):
            link = 'https://www.longandfoster.com/include/ajax/api.aspx?op=SearchAgents&firstname=&lastname=&page=' + \
                str(var)+'&pagesize=50'
            yield Request(url=link.strip(), callback=self.parse, headers=headers)

    def parse(self, response):
        response_data = json.loads(response.body_as_unicode())
        result = response_data.get('Entity', '')
        if result:
            datas = json.loads(result)
            if datas:
                for data in datas:
                    Id_ = data.get('PersonID', '')
                    profile_url = 'https://www.longandfoster.com/AgentSearch/AgentInfo.aspx?PersonID=' + \
                        str(Id_)
                    urls = {'url': profile_url}
                    self.db['longandfoster_us_url1'].insert(dict(urls))

                    # f = open('urlsdec.txt', 'a')
                    # f.write(profile_url + '\n')
                    # f.close()
