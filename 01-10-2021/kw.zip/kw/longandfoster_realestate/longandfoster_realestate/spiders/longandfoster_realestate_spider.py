# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from longandfoster_realestate.items import *
from longandfoster_realestate.settings import *
from longandfoster_realestate.proxy import parse_proxy

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

headers = {
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36',
    'X-NewRelic-ID': 'VQEEVl5XDRAHV1VXAwYDUA==',
    'X-Requested-With': 'XMLHttpRequest'}


class Longandfoster_RealestateSpider(Spider):
    name = 'longandfoster_realestate'

    def start_requests(self):
        for var in range(0, 192):
            link = 'https://www.longandfoster.com/include/ajax/api.aspx?op=SearchAgents&firstname=&lastname=&page=' + \
                str(var) + '&pagesize=50'
            yield Request(url=link.strip(), callback=self.parse, headers=headers)

    # # Queue implementation
    #     # Fetching URL from queue until queue is empty
    # credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
    # connection = pika.BlockingConnection(pika.ConnectionParameters(
    #     credentials=credentials, host=QUEUE_IP, socket_timeout=300))
    # channel = connection.channel()
    # while True:
    #     channel.basic_qos(prefetch_count=1)
    #     method, properties, url = channel.basic_get(queue=QUEUE_NAME)
    #     if not url.strip():
    #         break
    #     channel.basic_ack(delivery_tag=method.delivery_tag)
    #     url = str(url.strip(), encoding='utf-8')
    #     if url.strip():
    #         yield Request(url=url.strip(), callback=self.parse, headers=headers, errback=lambda x: self.errback_httpbin(x, url.strip()))
    # connection.close()

    def parse(self, response):
        response_data = json.loads(response.body_as_unicode())
        result = response_data.get('Entity', '')

        facebook_url = ''
        twitter_url = ''
        linkedin_url = ''
        instagram_url = ''
        pinterest_url = ''
        googleplus_url = ''
        youtube_url = ''
        first_name = ''
        middle_name = ''
        last_name = ''
        social = {}
        address = ''
        city = ''
        state = ''
        zipcode = ''
        country = ''
        office_name = ''
        office_phone = ''
        agent_phone = ''
        email = ''
        image_url = ''
        website = ''

        if result:
            datas = json.loads(result)
            if datas:
                for data in datas:

                    name = data.get('DisplayName', '')
                    Id_ = data.get('PersonID', '')
                    address = data.get('StreetAddress1', '')
                    city = data.get('CityDisplayName', '')
                    state = data.get('StateCode', '')
                    zipcode = data.get('Zip', '')
                    country = data.get('CountryName', '')
                    office_name = data.get('OfficeName', '')
                    office_phone = data.get('Phone', '')
                    agent_phone = data.get('Cell', '')
                    email = data.get('Email', '')
                    image_url = data.get('PortraitUrl', '')
                    website = data.get('PrimaryWebsiteURL', '')
                    facebook_url = data.get('FacebookURL', '')
                    twitter_url = data.get('TwitterURL', '')
                    linkedin_url = data.get('LinkedInURL', '')
                    instagram_url = data.get('InstagramURL', '')
                    pinterest_url = data.get('PinterestURL', '')
                    googleplus_url = data.get('GoogleURL', '')
                    youtube_url = data.get('YoutubeURL', '')
                    tumblr_url = data.get('TumblrURL', '')
                    myspace_url = data.get('MySpaceURL', '')
                    oth_url = data.get('OtherURL', '')
                    languages = data.get('Languages', [])

                    agent_name = name.replace('-', '').split()
                    if '&' in agent_name:
                        first_name = name
                    else:
                        if len(agent_name) == 1:
                            first_name = agent_name[0].strip()
                            middle_name = ''
                            last_name = ''
                        if len(agent_name) == 2:
                            first_name = agent_name[0].strip()
                            middle_name = ''
                            last_name = agent_name[1].strip()
                        if len(agent_name) == 3:
                            first_name = agent_name[0].strip()
                            middle_name = agent_name[1].strip()
                            last_name = agent_name[2].strip()
                        if len(agent_name) >= 4:
                            first_name = name
                            middle_name = ''
                            last_name = ''

                    languages = [lang.strip()
                                 for lang in languages.split(',') if languages]
                    if image_url:
                        if '/AgentNoPhotoAvailable' in image_url:
                            image_url = ''

                    website = response.urljoin(website)
                    agent_phone_numbers = [agent_phone]
                    if agent_phone_numbers == [None]:
                        agent_phone_numbers = []
                    office_phone_numbers = [office_phone]
                    if office_phone_numbers == [None]:
                        office_phone_numbers = []

                    if facebook_url:
                        if 'facebook' in facebook_url:
                            facebook_url = response.urljoin(
                                facebook_url.strip())
                        else:
                            facebook_url = ''
                    if twitter_url:
                        if 'twitter' in twitter_url:
                            twitter_url = response.urljoin(twitter_url.strip())
                        else:
                            twitter_url = ''
                    if linkedin_url:
                        if 'linkedin' in linkedin_url:
                            linkedin_url = response.urljoin(
                                linkedin_url.strip())
                        else:
                            linkedin_url = ''
                    if pinterest_url:
                        if 'pinterest' in pinterest_url:
                            pinterest_url = response.urljoin(
                                pinterest_url.strip())
                        else:
                            pinterest_url = ''
                    if googleplus_url:
                        if 'google' in googleplus_url:
                            googleplus_url = response.urljoin(
                                googleplus_url.strip())
                        else:
                            googleplus_url = ''
                    if youtube_url:
                        if 'youtube' in youtube_url:
                            youtube_url = response.urljoin(youtube_url.strip())
                        else:
                            youtube_url = ''
                    if instagram_url:
                        if 'instagram' in instagram_url:
                            instagram_url = response.urljoin(
                                instagram_url.strip())
                        else:
                            instagram_url = ''

                    other_urls_ = []

                    if pinterest_url:
                        other_urls_.append(pinterest_url)
                    if googleplus_url:
                        other_urls_.append(googleplus_url)
                    if youtube_url:
                        other_urls_.append(youtube_url)
                    if instagram_url:
                        other_urls_.append(instagram_url)

                    other_urls = []
                    for url in other_urls_:
                        if url:
                            other_urls.append(url)
                        else:
                            other_urls = []

                    if facebook_url or twitter_url or linkedin_url or other_urls:
                        social = {'facebook_url': facebook_url,
                                  'twitter_url': twitter_url,
                                  'linkedin_url': linkedin_url,
                                  'other_urls': other_urls,
                                  }
                    else:
                        social = {}

                    profile_url = 'https://www.longandfoster.com/AgentSearch/AgentInfo.aspx?PersonID=' + \
                        str(Id_)

                    meta = {
                        'office_name': office_name,
                        'address': address,
                        'city': city,
                        'state': state,
                        'zipcode': zipcode,
                        'profile_url': profile_url,
                        'languages': languages,
                        'first_name': first_name,
                        'middle_name': middle_name,
                        'last_name': last_name,
                        'website': website,
                        'email': email,
                        'image_url': image_url,
                        'agent_phone_numbers': agent_phone_numbers,
                        'office_phone_numbers': office_phone_numbers,
                        'social': social,
                        'country': country,
                    }
                    yield Request(url=profile_url, headers=headers, callback=self.parse_profile, meta=meta)

    def parse_profile(self, response):
        office_name = response.meta['office_name']
        address = response.meta['address']
        city = response.meta['city']
        state = response.meta['state']
        zipcode = response.meta['zipcode']
        profile_url = response.meta['profile_url']
        languages = response.meta['languages']
        first_name = response.meta['first_name']
        middle_name = response.meta['middle_name']
        last_name = response.meta['last_name']
        website = response.meta['website']
        email = response.meta['email']
        image_url = response.meta['image_url']
        agent_phone_numbers = response.meta['agent_phone_numbers']
        office_phone_numbers = response.meta['office_phone_numbers']
        social = response.meta['social']
        country = response.meta['country']

        DESCRIPTION_XPATH = '//div[@class="lf_agent-profile__biography lf_component"]/p//text()|//div[@id="agent-biography"]/text()|//div[@id="agent-biography"]/span/text()|//div[@id="agent-biography"]/p[@class="MsoNormal"]//span/text() | //div[@id="agent-biography"]//p/text() | //div[@id="agent-biography"]//li/text() | //div[@id="agent-biography"]//text() | //div[@id="agent-biography"]/p[@class="MsoNormal"]//text() | //div[@id="agent-biography"]//span/text() | //div[@id="agent-biography"]//p//span//text()'
        description = response.xpath(DESCRIPTION_XPATH).extract()
        description = ' '.join(''.join(description).split())
        title = ''

        if first_name:
            item = Longandfoster_RealestateItem(
                title=title,
                office_name=office_name,
                address=address,
                city=city,
                state=state,
                zipcode=zipcode,
                profile_url=profile_url,
                languages=languages,
                description=description,
                first_name=first_name,
                middle_name=middle_name,
                last_name=last_name,
                website=website,
                email=email,
                image_url=image_url,
                agent_phone_numbers=agent_phone_numbers,
                office_phone_numbers=office_phone_numbers,
                social=social,
                country=country,
            )
            yield item

    # Errorback to put failed urls back in queue
    # def errback_httpbin(self, failure, url):
    #     credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
    #     connection = pika.BlockingConnection(pika.ConnectionParameters(
    #         credentials=credentials, host=QUEUE_IP, socket_timeout=600))
    #     channel = connection.channel()
    #     channel.queue_declare(queue=QUEUE_NAME, durable=True)
    #     channel.basic_publish(
    #         exchange='', routing_key=QUEUE_NAME, body=url)
    #     connection.close()
