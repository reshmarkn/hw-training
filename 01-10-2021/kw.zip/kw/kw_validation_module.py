from pymongo import MongoClient
import ast

MONGODB_DB = 'kw_Jan_2021'
COLLECTION_LIST = ['home_realestate', 'woodsbros_v1','robertsbrothers','longandfoster_data_v1','bhgre','royallepage_data','century21global','guarantee_v1','iowarealty_data',
                    'global_remax_data_v1','sutton_data','realliving_realestate_v2','longrealty_v2','edinarealty_data','harrynorman_new','rubina_realestate','coldwellbankerinternational','ewm_data',
                    'century21_us','rector_hayden','realtysouth','berkshirehathawayhs','firstweber','compass_data_v1','semonin_realtors_new','coldwellbanker_us','houlihanlawrence_data_new','wrrealtors_v1',
                    'remax_us','exprealty_new','intero_realestate_data','alliebeth_v3','ebby_items_v1','kentwood_items_v2','reecenichols_data','huff_realty_data'
                   ]
for i in COLLECTION_LIST:
# MONGODB_COLLECTION_AGENT = 'remax_us'
    client = MongoClient(
        'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')
    db = client[MONGODB_DB]

    # fields = ['ad_type', 'agent_name', 'amenities', 'bathrooms', 'bedrooms', 'broker', 'broker_display_name', 'category', 'category_url', 'completion_status', 'currency', 'date', 'ded_license_number', 'description', 'details', 'dtcm_licence', 'furnished', 'id', 'iteration_number',
    #           'latitude', 'listing_id', 'locality', 'location', 'longitude', 'number_of_photos', 'object_id', 'package_type', 'phone_number', 'price', 'price_per', 'reference_number', 'rera_length', 'rera_permit_number', 'rera_registration_number', 'scraped_ts', 'title', 'url', 'user_id', 'verified']


    fields = ['first_name', 'middle_name', 'last_name', 'office_name', 'title', 'description', 'languages', 'image_url', 'address', 'city', 'state', 'country', 'zipcode', 'office_phone_numbers', 'agent_phone_numbers', 'email', 'website', 'social', 'profile_url']

    count = db[i].find().count()
    print(i, ":", count,'\n')
    for field in fields:
        query = '{"' + field + '":{"$exists": True, "$ne":""}}'
        query = ast.literal_eval(query)
        my_col = db[i].find(query)
        count = my_col.count()
        print(field, ":", count)
