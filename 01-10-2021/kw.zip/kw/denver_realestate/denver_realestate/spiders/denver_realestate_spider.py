# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging

from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from denver_realestate.items import *
from denver_realestate.settings import *
from denver_realestate.proxy import parse_proxy
from datetime import datetime
from pymongo import MongoClient


handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False
headers = {
    'Accept': 'image/webp,image/apng,image/*,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}


class Denver_RealestateSpider(Spider):
    name = 'denver_realestate_parser'
    # db = MongoClient('mongodb://localhost:27017')[dbname]
    db = MongoClient(
        'mongodb://datahut:cGFzc21lMTIz@64.225.9.179:27017')[MONGO_DB]
    allowed_domains = ['www.denverrealestate.com']

    def start_requests(self):
        for item in self.db[MONGO_COLLECTION_URL].find(no_cursor_timeout=True):
            url = item.get('url')
            link = url.strip()
            yield Request(url=link, callback=self.parse, headers=headers)
        # f = open('urlfeb.txt')
        # urls = f.readlines()
        # for url in urls:
        #     yield Request(url=url.strip(), callback=self.parse, headers=headers)

    def parse(self, response):
        # Grab XPATH
        NAME_XPATH = '//h1/text()'
        TITLE_XPATH = '//h2/text()'
        OFFICE_NAME_XPATH = '//h3/text()'
        AGENT_PHONE_XPATH = '//tr/td[contains(text(), "Cell")]/following-sibling::td/text()|//tr/td[contains(text(), "Direct")]/following-sibling::td/text()'
        OFFICE_PHONE_XPATH = '//tr/td[contains(text(), "Office")]/following-sibling::td/text()'
        WEBSITE_XPATH = '//a[contains(@title, "Visit My Website")]/@href | //a[contains(@title, "Visit Our Website")]/@href'
        IMAGE_XPATH = '//img[contains(@class, "img")]/@src'
        LANGUAGES_XPATH = '//div/h4[contains(text(), "Languages")]/following-sibling::ul//li/text()'
        LOCATION_XPATH = '//p[@class="margin-bottom-5"]//text()'
        DESCRIPTION_XPATH = '//div[@class="cms-page"]//text()'
        FACEBOOK_XPATH = '//ul[contains(@class, "social-links")]/li/a[@title="Facebook"]/@href |//ul[contains(@class, "social-links")]/li/a[@title="Facebook Fan Page"]/@href '
        LINKEDIN_XPATH = '//ul[contains(@class, "social-links")]/li/a[@title="LinkedIn"]/@href'
        TWITTER_XPATH = '//ul[contains(@class, "social-links")]/li/a[@title="Twitter"]/@href'
        PINTEREST_XPATH = '//ul[contains(@class, "social-links")]/li/a[@title="Pinterest"]/@href'
        INSTAGRAM_XPATH = '//ul[contains(@class, "social-links")]/li/a[@title="Instagram"]/@href'
        YOUTUBE_XPATH = '//ul[contains(@class, "social-links")]/li/a[@title="YouTube (User)"]/@href'
        GOOGLEPLUS_XPATH = '//ul[contains(@class, "social-links")]/li/a[@title="GooglePlus (User)"]/@href'

        # Extract values using above XPATHs
        name = response.xpath(NAME_XPATH).extract_first('').strip()
        title = response.xpath(TITLE_XPATH).extract_first('').strip()
        office_name = response.xpath(
            OFFICE_NAME_XPATH).extract_first('').strip()
        agent_phone = response.xpath(AGENT_PHONE_XPATH).extract()
        office_phone = response.xpath(OFFICE_PHONE_XPATH).extract()
        website = response.xpath(WEBSITE_XPATH).extract_first('').strip()
        image_url = response.xpath(IMAGE_XPATH).extract_first('').strip()
        language = response.xpath(LANGUAGES_XPATH).extract()
        location = response.xpath(LOCATION_XPATH).extract()
        description = response.xpath(DESCRIPTION_XPATH).extract()
        facebook_url = response.xpath(FACEBOOK_XPATH).extract_first('').strip()
        linkedin_url = response.xpath(LINKEDIN_XPATH).extract_first('').strip()
        twitter_url = response.xpath(TWITTER_XPATH).extract_first('').strip()
        instagram_url = response.xpath(
            INSTAGRAM_XPATH).extract_first('').strip()
        pinterest_url = response.xpath(
            PINTEREST_XPATH).extract_first('').strip()
        youtube_url = response.xpath(YOUTUBE_XPATH).extract_first('').strip()
        googleplus_url = response.xpath(
            GOOGLEPLUS_XPATH).extract_first('').strip()

        # Clea Data
        first_name = ''
        middle_name = ''
        last_name = ''
        city = ''
        state = ''
        zipcode = ''

        agent_name = name.replace('-', '').split()
        if '&' in agent_name:
            first_name = name
        else:
            if len(agent_name) == 1:
                first_name = agent_name[0].strip()
                middle_name = ''
                last_name = ''
            if len(agent_name) == 2:
                first_name = agent_name[0].strip()
                middle_name = ''
                last_name = agent_name[1].strip()
            if len(agent_name) == 3:
                first_name = agent_name[0].strip()
                middle_name = agent_name[1].strip()
                last_name = agent_name[2].strip()
            if len(agent_name) >= 4:
                first_name = name
                middle_name = ''
                last_name = ''

        agent_phone_numbers = []
        office_phone_numbers = []
        if agent_phone:
            for number in agent_phone:
                number = number.strip()
                agent_phone_numbers.append(number)
        if office_phone:
            for num in office_phone:
                num = num.strip()
                office_phone_numbers.append(num)
        if agent_phone == [] and office_phone == []:
            office_phone = response.xpath(
                '//table[@class="phone-table"]/tr/td/text()').extract()
            for num_ in office_phone:
                num_ = num_.strip()
                print(num_)
                num_ = re.findall('.\d+.*\d+.*\d+', num_)
                print(num_)
                office_phone_numbers.append(num_)

        languages = []
        for lang in language:
            lang_ = lang.replace('\u2022\xa0\xa0\xa0', '').strip()
            # lang_ = lang.encode('ascii','ignore').strip()
            languages.append(lang_)

        description = ' '.join(''.join(description).split())
        address = location[0].strip() if location else ''
        postal = location[1].strip().split(',') if location else ''
        if postal:
            city = postal[0].strip()
            loc = postal[1].strip().split(' ')
            state = loc[0].strip()
            zipcode = loc[1].strip()

        if 'facebook.com' in facebook_url:
            facebook_url = facebook_url.strip()
        else:
            facebook_url = ''
        if 'twitter.com' in twitter_url:
            twitter_url = twitter_url.strip()
        else:
            twitter_url = ''
        if 'linkedin.com' in linkedin_url:
            linkedin_url = linkedin_url.strip()
        else:
            linkedin_url = ''
        if 'pinterest.com' in pinterest_url:
            pinterest_url = pinterest_url.strip()
        else:
            pinterest_url = ''
        if 'google.com' in googleplus_url:
            googleplus_url = googleplus_url.strip()
        else:
            googleplus_url = ''
        if 'youtube.com' in youtube_url:
            youtube_url = youtube_url.strip()
        else:
            youtube_url = ''
        if 'instagram.com' in instagram_url:
            instagram_url = instagram_url.strip()
        else:
            instagram_url = ''

        other_urls_ = []

        if pinterest_url:
            other_urls_.append(pinterest_url)
        if googleplus_url:
            other_urls_.append(googleplus_url)
        if youtube_url:
            other_urls_.append(youtube_url)
        if instagram_url:
            other_urls_.append(instagram_url)

        other_urls = []
        for url in other_urls_:
            if url:
                other_urls.append(url)
            else:
                other_urls = []

        if facebook_url or twitter_url or linkedin_url or other_urls:
            social = {'facebook_url': facebook_url,
                      'twitter_url': twitter_url,
                      'linkedin_url': linkedin_url,
                      'other_urls': other_urls,
                      }
        else:
            social = {}

        profile_url = response.request.url

        # yield item
        if first_name:
            item = Denver_RealestateItem(
                title=title,
                office_name=office_name,
                address=address,
                city=city,
                state=state,
                zipcode=zipcode,
                profile_url=profile_url,
                languages=languages,
                description=description,
                first_name=first_name,
                middle_name=middle_name,
                last_name=last_name,
                website=website,
                email='',
                image_url=image_url,
                agent_phone_numbers=agent_phone_numbers,
                office_phone_numbers=office_phone_numbers,
                social=social,
                country='United States',
            )
            yield item
