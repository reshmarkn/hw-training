# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import gzip
from scrapy import signals
from xml.dom import minidom
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from denver_realestate.items import *
from denver_realestate.settings import *
import subprocess
from scrapy import cmdline
from pymongo import MongoClient
from databasenotifier import automation_script
from denver_realestate.proxy import parse_proxy



class Denver_RealestateSpider(Spider):
    name = 'denver_realestate_crawler'
    start_urls = ['http://www.denverrealestate.com/agents.xml']
    allowed_domains = ['www.denverrealestate.com']

    def spider_ended(self,):
        cmdline.execute("python script.py".split())
        # subprocess.call("python script.py ", shell=True)

    def parse(self, response):
        xmldoc = minidom.parseString(response.body)
        LOCS = xmldoc.getElementsByTagName('loc')
        LOCS.pop(0)
        for loc in LOCS:
            p_url = loc.childNodes[0].data
            p_url = response.urljoin(p_url)
            # meta = {'url': p_url}
            # db.denver_realestate_urls.insert(dict(meta))
            item = DenverRealestateUrlItem()
            item['url'] = p_url
            yield item
        automation_script.Automation_Spider(MONGO_DB, MONGO_COLLECTION_URL)

    @classmethod
    def from_crawler(cls, crawler, *args, **kwargs):
        spider = super(Denver_RealestateSpider, cls).from_crawler(
            crawler, *args, **kwargs)
        crawler.signals.connect(spider.spider_opened, signals.spider_opened)
        crawler.signals.connect(spider.spider_closed, signals.spider_closed)
        return spider

    def spider_opened(self, spider):
        print('Opening {} spider'.format(spider.name))
    def spider_closed(self, spider):
        print('%%%%%%%%%%%%%%%%%%%%%%%%%%')
        self.spider_ended()
        # cmdline.execute("scrapy crawl denver_realestate_parser".split())
        # subprocess.call('')
        print('Closing {} spider'.format(spider.name))