import subprocess
from scrapy import cmdline
from denver_realestate.settings import *
print('gdddddddddddhg')
cmdline.execute("scrapy crawl denver_realestate_parser".split())
# subprocess.call("scrapy crawl denver_realestate_parser",shell=Tr)
#subprocess.call(
#     "(cd /root/dc_projects/kw/denver_realestate && /usr/local/bin/scrapy crawl denver_realestate_parser)", shell=True)
