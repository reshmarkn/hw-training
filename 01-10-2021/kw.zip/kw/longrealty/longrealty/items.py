# -*- coding: utf-8 -*-
import scrapy


class LongrealtyItem(scrapy.Item):
    # name = scrapy.Field()
    # last_updated = scrapy.Field()
    first_name = scrapy.Field()
    last_name = scrapy.Field()
    middle_name = scrapy.Field()
    title = scrapy.Field()
    image_url = scrapy.Field()
    agent_phone_numbers = scrapy.Field()
    email = scrapy.Field()
    office_name = scrapy.Field()
    address = scrapy.Field()
    city = scrapy.Field()
    state = scrapy.Field()
    zipcode = scrapy.Field()
    website = scrapy.Field()
    description = scrapy.Field()
    languages = scrapy.Field()
    country = scrapy.Field()
    profile_url = scrapy.Field()
    office_phone_numbers = scrapy.Field()
    social = scrapy.Field()

