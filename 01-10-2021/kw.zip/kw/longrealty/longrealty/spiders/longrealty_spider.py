# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from longrealty.items import *
from longrealty.settings import *
from longrealty.proxy import parse_proxy
from scrapy.shell import inspect_response
import requests
from pymongo import MongoClient
handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.119 Safari/537.36'}

headers_ = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
    "Accept-Encoding": "gzip, deflate, br",
    "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8,ml;q=0.7",
    "Cache-Control": "max-age=0",
    "Connection": "keep-alive",
    "Host": "www.longrealty.com",
    "Upgrade-Insecure-Requests": "1",
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36"
}
client = MongoClient('mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
try:
    client.admin.command(
        "shardcollection", MONGO_DB + '.' + MONGO_COLLECTION, key={'profile_url': 1}, unique=True)
except:
    pass

db = client[MONGO_DB]

class LongrealtySpider(Spider):
    name = 'longrealty'
    # start_urls = ['https://www.longrealty.com/agents.php?p=1']
    # allowed_domains = []

    def start_requests(self):
        for var in range(1, 6):
            start_url = 'https://www.longrealty.com/roster/Offices/'+str(var)
        # start_url = 'https://www.longrealty.com/roster/Offices/'
            response = requests.get(url=start_url, headers=headers_)
            sel = Selector(text=response.text)
            try:
                self.parse1(sel)
            except:
                pass
        # yield Request(start_url, headers=headers, callback=self.parse1, dont_filter=True)

    def parse1(self, response):

        office_list_url = response.xpath(
            '//article[@class="rng-agent-roster-agent-card js-sort-item"]/a/@href').extract()

        #office_list_url = ['/Roster/Offices/aben/']
        base_url = 'https://www.longrealty.com'
        for office in office_list_url:
            if 'Roster/' in office:
                office_url = base_url + office+'/'
                print(office_url)
                for var in range(1, 10):
                    url_ = office_url+str(var)
                    response = requests.get(url=url_, headers=headers_)
                    sel = Selector(text=response.text)
                    agents_sel = sel.xpath(
                        '//article[@class="rng-agent-roster-agent-card js-sort-item"]')
                    if agents_sel:
                        try:
                            self.parse2(sel)
                        except:
                            pass
                    else:
                        break

    def parse2(self, response):
        #print(response.url, '/////////////')
        office_number = ''
        office_name = ''
        agent_phone_numbers = ''
        agents_sel = response.xpath(
            '//article[@class="rng-agent-roster-agent-card js-sort-item"]')

        # agent_url_list = response.xpath(
        #     '//article/ul[3]/li[1]/a/@href | //article/ul[2]/li[1]/a/@href').extract()

        office_name_1 = response.xpath(
            '//article[@class="rng-agent-roster-agent-card js-sort-item"]/p/strong/text()').extract()

        for office in office_name_1:
            if office:
                office_name = office
            else:
                office_name = ''

            # print(office_name)
        # office_phone_numbers = response.xpath(
        #     '//section[@class="rng-agent-roster-agent-cards js-sort-container"]/article[@class="rng-agent-roster-agent-card js-sort-item"]/ul[1]/li[1]/a[1]/text()').extract()

        phone_company = response.xpath(
            '//section[@class="site-roster-customroster1"]//div[@id="rosterResults"]/article/ul//i[@class="rni-company"]/ancestor::a[1]/text()').extract_first('').strip()
        office_number = phone_company.strip()
        office_number = [office_number] if office_number else []
        # if office_phone_numbers:

        #     for office_phone_numbers in office_phone_numbers:

        #         office_number = office_phone_numbers

        # else:
        #     office_number = ''

        for sel in agents_sel:
            url = sel.xpath(
                'ul//i[@class="rni-website"]/ancestor::a[1]/@href').extract_first('')
            if url:
                response = requests.get(url=url, headers=headers)
                meta = {'office_name': office_name,
                        'office_number': office_number, 'profile_url': url}
                sel = Selector(text=response.text)
                self.parse(sel, meta)

            # yield Request(url, headers=headers, meta={'office_name': office_name, 'office_number': office_number}, callback=self.parse)
        # agent_phone_numbers = response.xpath(
        #     '//section[@class="rng-agent-roster-agent-cards js-sort-container"]/article[@class="rng-agent-roster-agent-card js-sort-item"]/ul[1]/li[2]/a[1]/text()').extract()
        # if agent_phone_numbers:
        #     for agent_phone_numbers in agent_phone_numbers:
        #         agent_phone_numbers = ''.join(agent_phone_numbers).strip()
        # else:
        #     agent_phone_numbers

        # for agent_url in agent_url_list:
        #     if 'tel:(' in agent_url:
        #         ''
        # else:
        # yield Request(agent_url, headers=headers, meta={'office_name': office_name, 'office_number': office_number}, callback=self.parse)

        # print(response)

        # agents = response.xpath(
        #     '//h1[@class="agent-card__name"]/a/@href').extract()
        # print(agents)
        # for agent in agents:
        #     print(agent)
        #     # yield Request(url=agent, callback=self.parse_data)

        # next_page_ = response.xpath('//a[@id="next"]/@href').extract()
        # next_page_ = ''.join(next_page_).strip()
        # next_page = response.urljoin(next_page_)
        # if next_page:
        # yield Request(url=next_page, callback=self.parse2)
        # -======================================================================
        # f = open('urldec.txt')
        # urls = f.readlines()
        # for url in urls:
        #     yield Request(url=url.strip(), callback=self.parse, headers=headers)

    def parse(self, response, meta):
        # def parse_data(self, response):
        # inspect_response(response, self)

        office_name = meta.get('office_name')
        office_number = meta.get('office_number')
        profile_url = meta.get('profile_url')
        # agent_phone_number = response.meta.get('agent_phone_numbers')
        # print(agent_phone_numbers)
        agent_phone_numbers = []
        office_phone_numbers = []
        middle_name = ''
        first_name = ''
        last_name = ''
        other_urls = []
        social = {}
        image_url = ''
        zipcode_ = ''
        name = response.xpath(
            '//ul[@class="no-bullet footer-account-info"]/li[@class="site-footer-name"]/text()').extract()
        if name:

            name = ''.join(name).strip()
            name_split = name.split(' ')
            if len(name_split) == 2:
                first_name = name_split[0]
                last_name = name_split[1]
            if len(name_split) == 3:
                first_name = name_split[0]
                middle_name = name_split[1]
                last_name = name_split[2]
            if len(name_split) >= 4:
                first_name = name
                middle_name = ''
                last_name = ''

            title_ = response.xpath(
                '//ul[@class="no-bullet footer-account-info"]/li[2]/text()').extract()
            title_ = ''.join(title_).strip()
            title = title_.split('-')[0].strip()

            image = response.xpath(
                '//div[@class="site-header-mobile-account"]/img/@src').extract()
            image = ''.join(image)

            if 'gif' not in image:

                image_url = image
            # agent_phone_numbers.append(agent_phone_number)
            # office_phone_numbers.append(office_number)

            agent_phone_numbers = response.xpath(
                '//ul[@class="no-bullet footer-account-info"]/li[4]/text()').extract_first()
            if agent_phone_numbers:
                if 'Cell:' in agent_phone_numbers:
                    agent_phone_numbers = agent_phone_numbers.split(
                        'Cell:')
                    agent_phone_numbers = agent_phone_numbers[1]
                elif 'Direct:' in agent_phone_numbers:
                    agent_phone_numbers = agent_phone_numbers.split(
                        'Direct:') if agent_phone_numbers else ''
                    agent_phone_numbers = agent_phone_numbers[1] if agent_phone_numbers else ''
                elif 'Mobile Phone:' in agent_phone_numbers:
                    agent_phone_numbers = agent_phone_numbers.split(
                        'Mobile Phone:') if agent_phone_numbers else ''
                    agent_phone_numbers = agent_phone_numbers[1] if agent_phone_numbers else ''
            else:
                agent_phone_numbers = []

            # office_phone_number = response.xpath(
            #     '//ul[@class="no-bullet footer-address"]/li[5]/text()').extract()
            # if office_phone_number:
            #     office_phone_number = office_phone_number[0].split(
            #         'Office Phone:')
            #     office_phone_numbers = office_phone_number[1]
            # else:
            #     office_phone_numbers = ''

            # email = response.xpath(
            #     '//ul[@class="site-header-mobile-account-info"]/li[5]/a/@href').extract()
            # email = ''.join(email).strip()
            # email = email.replace('mailto:', '')
            email = response.xpath(
                '//div[@class="site-column quarter"]/ul//li/a[contains(text(),"Email")]/text()').extract()
            email = ''.join(email).replace('Email:', '').strip()

            # office_name = response.xpath(
            #     '//li[@class="office"]/a/text()').extract()
            # office_name = ''.join(office_name).strip()

            address = response.xpath(
                '//ul[@class="no-bullet footer-address"]/li/text()').extract()[-2]
            address = ''.join(address).strip()

            # city_state = response.xpath(
            #     '//ul[@class="no-bullet footer-address"]/li[4]/text()').extract_first()

            # city_state = ''.join(city_state)
            # city = city_state.split(', ') if city_state else ''
            # CITY = city[0] if city else ''
            # zipcode_ = city[1].split(' ') if zipcode_ else ''
            # zip_code = zipcode_[1] if zipcode_ else ''
            # state = zipcode_[0] if zipcode_ else ''

            city_state = response.xpath(
                '//ul[@class="no-bullet footer-address"]/li/text()').extract()[-1]
            city_state = ''.join(city_state)
            city = city_state.split(', ') if city_state else ''
            CITY = city[0] if city else ''
            zipcode_ = city[1].split(' ')
            if zipcode_:
                zipcode_ = zipcode_
            else:
                zipcode_ = ''
            zip_code = zipcode_[1]
            state = zipcode_[0]

            # zipcode = ''.join(zipcode)

            # website = response.xpath(
            #     '//a[@class="uk-button uk-button-primary '
            #     'agent-detail-cta"][1]/@href').extract()
            # website = ''.join(website).strip()

            # description = response.xpath(
            #     '//p[@class="uk-article-lead agent-description"]/text()').extract()
            # description = ' '.join(''.join(description).split())

            social = {}

            instagram_url = response.xpath(
                '//li[@class="social-instagram"]/a/@href').extract_first()
            facebook_url = response.xpath(
                '//li[@class="social-facebook"]/a/@href').extract_first()
            youtube_url = response.xpath(
                '//li[@class="social-youtube"]/a/@href').extract_first()
            other_url = response.xpath(
                '//li[@class="social-misc"]/a/@href').extract_first()
            twitter_url = response.xpath(
                '//li[@class="social-twitter"]/a/@href').extract_first()
            blog_url = response.xpath(
                '//li[@class="social-blog"]/a/@href').extract_first()
            # social_ = response.xpath(
            #     '//nav[@class="social-media__agent-detail"]/a/@href').extract()
            if instagram_url:
                social.update({'instagram_url': instagram_url})

            if facebook_url:
                social.update({'facebook_url': facebook_url})
            if youtube_url:
                social.update({'youtube_url': youtube_url})
            if twitter_url:
                social.update({'twitter_url': twitter_url})
            if blog_url:
                social.update({'blog_url': blog_url})
            if other_url:
                social.update({'other_url': other_url})

            if first_name:
                item = LongrealtyItem(
                    first_name=first_name,
                    last_name=last_name,
                    middle_name=middle_name,
                    title=title,
                    image_url=image_url,
                    agent_phone_numbers=[agent_phone_numbers],
                    office_phone_numbers=office_number,
                    email=email,
                    office_name=office_name,
                    address=address,
                    city=CITY,
                    state=state,
                    zipcode=zip_code,
                    website=profile_url,
                    description='',
                    languages=[],
                    country='United States',
                    social=social,
                    profile_url=profile_url,
                )
                # yield item
                print(item)
                try:
                    db[MONGO_COLLECTION].insert(dict(item))
                except:
                    pass
    """
    # Errorback to put failed urls back in queue
    def errback_httpbin(self, failure, url):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=600))
        channel = connection.channel()
        channel.queue_declare(queue=QUEUE_NAME, durable=True)
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=url)
        connection.close()
    """
