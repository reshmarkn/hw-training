# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from longrealty.items import *
from longrealty.settings import *
from longrealty.proxy import parse_proxy

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.119 Safari/537.36'}


class LongrealtyUrlSpider(Spider):
    name = 'longrealty_crawler'
    start_urls = ['https://www.longrealty.com/agents.php?p=1']
    allowed_domains = []

    def parse(self, response):
        agents = response.xpath(
            '//article[@class="rng-agent-roster-agent-card js-sort-item"]/a/@href').extract()
        base_url = 'https://www.longrealty.com/'
        for agent in agents:
            agent_url = base_url + agent
            # print(agent_url)
            yield Request(url=agent_url, callback=self.parseAgent)

    def parseAgent(self, response):
        agent_urls = response.xpath(
            '//article/ul[3]/li[1]/a/@href | //article/ul[2]/li[1]/a/@href').extract()

        for url in agent_urls:
            if 'tel:(' in url:
                ''
            else:
                f = open('urldec.txt', 'a')
                f.write(url + '\n')
                f.close()

        # next_page_ = response.xpath('//a[@id="next"]/@href').extract()
        # next_page_ = ''.join(next_page_).strip()
        # next_page = response.urljoin(next_page_)
        # if next_page:
        #     yield Request(url=next_page, callback=self.parse)
