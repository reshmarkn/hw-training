# -*- coding: utf-8 -*-
import scrapy


class IowarealtyItem(scrapy.Item):
    # name = scrapy.Field()
    # last_updated = scrapy.Field()
    first_name = scrapy.Field()
    middle_name = scrapy.Field()
    last_name = scrapy.Field()
    office_name = scrapy.Field()
    title = scrapy.Field()
    languages = scrapy.Field()
    website = scrapy.Field()
    image_url = scrapy.Field()
    agent_phone_numbers = scrapy.Field()
    office_phone_numbers = scrapy.Field()
    email = scrapy.Field()
    address = scrapy.Field()
    city = scrapy.Field()
    state = scrapy.Field()
    zipcode = scrapy.Field()
    country = scrapy.Field()
    description = scrapy.Field()
    social = scrapy.Field()
    profile_url = scrapy.Field()
