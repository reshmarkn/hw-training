# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from iowarealty.items import *
from iowarealty.settings import *
from iowarealty.proxy import parse_proxy


handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

headers = {
    "Accept": "application/json, text/javascript, */*; q=0.01",
    "Accept-Encoding": "gzip, deflate, br",
    "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36",
}


class LongrealtyUrlSpider(Spider):
    name = 'lowarealty_crawler'
    start_urls = ['https://www.iowarealty.com/real-estate-agents']
    allowed_domains = []

    def parse(self, response):
        agents = response.xpath(
            '//a[@class="mdl-color-text--primary"]//@href').extract()
        for agent in agents:
            f = open('urlsjan.txt', 'a')
            f.write(agent + '\n')
            f.close()
        for page in range(1, 66):
            next_ = 'https://www.iowarealty.com/real-estate-agents/sort-sn/' + \
                str(page)
            yield Request(url=next_, callback=self.parse)

        # next_page = response.xpath('//li[@class="mobile"]/a//@href').extract()
        # # next_page_ = ''.join(next_page_).strip()
        # # next_page = response.urljoin(next_page_)
        # if next_page:
        #     yield Request(url=next_page, callback=self.parse)
