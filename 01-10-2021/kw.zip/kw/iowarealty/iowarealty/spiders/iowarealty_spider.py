# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
import random
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from iowarealty.items import *
from iowarealty.settings import *
from iowarealty.proxy import parse_proxy

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


# headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
#            'Accept-Encoding': 'gzip, deflate',
#            "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8,ml;q=0.7",
#            # "Connection": "keep-alive",
#            # "Host": "amyabram.iowarealty.com",
#            'Upgrade-Insecure-Requests': '1',
#            'User-Agent': random.choice(USER_AGENT_LIST)}

headers = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "Accept-Encoding": "gzip, deflate",
    "Accept-Language": "en-US,en;q=0.9,ml;q=0.8",
    "Connection": "keep-alive",
    # "Host": "www.iowarealty.com",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Upgrade-Insecure-Requests": "1",
    "User-Agent": random.choice(USER_AGENT_LIST)
}


class IowarealtySpider(Spider):
    name = 'iowarealty_spider'
    # start_urls = ['https://www.iowarealty.com/real-estate-agents']
    allowed_domains = []
    handle_httpstatus_list = [504]

    def start_requests(self):
        url = 'https://www.iowarealty.com/real-estate-agents/sort-sn/'
        yield Request(url, headers=headers, callback=self.parse1, meta={'page': 1}, dont_filter=True,)

    def parse1(self, response):
        page = response.meta['page']
        # agents = response.xpath(
        #     '//a[@class="mdl-color-text--primary"]//@href').extract()
        agents = response.xpath(
            '//a[@data-label="My Website"]//@href').extract()

        if agents:
            for agents in agents:
                url = response.urljoin(agents)
                yield Request(url, headers=headers, callback=self.parse, dont_filter=True)
            page = page + 1
            nxt_url = 'https://www.iowarealty.com/real-estate-agents/sort-sn/' + \
                str(page)
            yield Request(nxt_url, headers=headers, callback=self.parse1, meta={'page': page}, dont_filter=True,)

    def parse(self, response):

        first_name = ''
        middle_name = ''
        last_name = ''
        office_name = ''
        state = ''
        other_urls = []
        languages = []
        agent_phone_numbers = []
        office_phone_numbers = []
        website = ''
        facebook_url = ''
        twitter_url = ''
        linkedin_url = ''
        social = {}
        email = ''
        img = ''
        image_url = ''
        img_ = ''
        name = response.xpath(
            '//div[@class="agent-temp_name"]/h1//text() | //h1[@class="agent-name"]/text() | //h2[@class="team-name"]/text()').extract()

        name = ''.join(name).strip()
        name_split = name.split(' ')
        # if len(name_split) == 2:
        #     first_name = name_split[0]
        #     last_name = name_split[1]
        if len(name_split) == 1:
            first_name = name_split[0].strip()
            middle_name = ''
            last_name = ''
        if len(name_split) == 2:
            first_name = name_split[0].strip()
            middle_name = ''
            last_name = name_split[1].strip()
        if len(name_split) == 3:
            first_name = name_split[0].strip()
            middle_name = name_split[1].strip()
            last_name = name_split[2].strip()
        if len(name_split) >= 4:
            first_name = name
            middle_name = ''
            last_name = ''

        img = ''
        img = response.xpath(
            '//div[@class="agent-photo"]/@style').extract_first('')
        image = img.strip("'background-image: url(').strip(');")

        if image:
            image_url = response.urljoin(image)

        title_ = response.xpath(
            '//span[@class="title"]//text()|//span[@class="designation"]//text()|//font[@class="agent_title"]//text()').extract_first('')
        title = ''.join(title_).strip()
        office_name = response.xpath(
            '//ul[@class="primary"]/li//text()').extract_first('')

        if office_name == 'Ohl Iowa Realty Real Estate & Insurance, Inc.':
            address_ = response.xpath(
                '//div[@class="mdl-grid mdl-cell mdl-cell--12-col"]/div/span//text()|//ul[@class="primary"]/li/text()').extract()
            addres = ' '.join(' '.join(address_).split()
                              ).strip() if address_ else ''
            address = addres.replace(office_name, '').strip()
            zipcode = ''
            state_zip = ''
            state = ''

            city = address.split(',', 1)[0]
            state_zip = address.split(',', 1)[1].strip() if address else ''
            state = state_zip.split(' ')[0] if state_zip else ''
            zipcode = state_zip.split(' ')[1] if state_zip else ''
        else:

            address_ = response.xpath(
                '//div[@class="mdl-grid mdl-cell mdl-cell--12-col"]/div/span//text()|//ul[@class="primary"]/li/text()').extract()
            addres = ' '.join(' '.join(address_).split()
                              ).strip() if address_ else ''
            addr_ = response.xpath(
                '//ul[@class="primary ag_info"]/li[2]/@data-value').extract_first('').replace('<br>', '')
            address = addres.replace(addr_, '').strip()

            zipcode = ''
            state_zip = ''
            state = ''

            city = address.split(',', 1)[0]
            state_zip = address.split(',', 1)[1].strip() if address else ''
            state = state_zip.split(' ')[0] if state_zip else ''
            zipcode = state_zip.split(' ')[1] if state_zip else ''

        office_phone_numbers = []
        office_phone = response.xpath(
            '//span[contains(text(),"office:")]//text() | //div/a[contains(text(),"Phone:")]//text()').extract_first()
        office_phone = office_phone.replace('Phone:\xa0', '').replace(
            'office:\xa0', '') if office_phone else ''
        # office_phone_number = re.findall('\d+', office_phone_)
        if office_phone:
            office_phone_numbers.append(office_phone)
        agent_phone_numbers = []
        agent_phone = response.xpath(
            '//span[contains(text(),"mobile:")]//text() | //div/a[contains(text(),"Mobile:")]//text()').extract_first()
        agent_phone = agent_phone.replace('Mobile:\xa0', '').replace(
            'Mobile:\xa0', '') if agent_phone else ''
        if agent_phone:
            agent_phone_numbers.append(agent_phone)
        email = response.xpath(
            '//div[@class="agent-template-links"]/a[@class="emailMe"]/text()').extract_first('')
        if email:
            email = ''.join(email).strip()
        else:
            email = ''
        #     email2 = response.xpath(
        #         '//script[@type="application/ld+json"][2]/text()').extract_first('')
        #     email_json = json.loads(email2)
        #     email = email_json.get('contactPoint', '').get('email', '')

        # office_phone_number = response.xpath(
        #     '//div/a[contains(text(),"Phone:")]//text()').extract_first('')
        # office_phone_number = str(office_phone_number.strip(
        #     'Phone:').encode('ascii', 'ignore'), encoding='utf-8')
        # if office_phone_number:
        #     office_phone_numbers.append(office_phone_number)

        # agent_phone_numbers = []
        # agent_phone_number = response.xpath(
        #     '//div/a[contains(text(),"Mobile:")]//text()').extract_first('')
        # agent_phone_number = str(agent_phone_number.strip(
        #     'Mobile:').encode('ascii', 'ignore'), encoding='utf-8')
        # if agent_phone_number:
        #     agent_phone_numbers.append(agent_phone_number)

        description_1 = response.xpath(
            '//div[@class="mdl-cell mdl-cell--12-col"]/p/text()').extract()
        description_2 = response.xpath(
            '//div[@class="mdl-cell mdl-cell--12-col"]/ul//text()').extract()
        description_3 = response.xpath(
            '//div[@class="mdl-cell mdl-cell--12-col"]/p/span/text()').extract()
        description = ''

        if description_1:
            description = ' '.join(''.join(description_1).split())
        if description_2:
            description = ' '.join(''.join(description_2).split())
        if description_3:
            description = ' '.join(''.join(description_3).split())
        social = {}
        social_ = response.xpath(
            '//div[@class="footer-icon-div header_social"]/a/@href').extract()
        for soc in social_:
            if 'facebook' in soc:
                facebook_url = soc
                social.update({'facebook_url': facebook_url})
            elif 'twitter' in soc:
                twitter_url = soc
                social.update({'twitter_url': twitter_url})
            elif 'linkedin' in soc:
                linkedin_url = soc
                social.update({'linkedin_url': linkedin_url})
            elif soc != '#':  # or soc != 'https://.':
                other_urls.append(soc)
                social.update({'other_urls': other_urls})

        if first_name:
            item = IowarealtyItem(
                first_name=first_name,
                middle_name=middle_name,
                last_name=last_name,
                office_name=office_name,
                title=title,
                languages=languages,
                website=website,
                image_url=image_url,
                agent_phone_numbers=agent_phone_numbers,
                office_phone_numbers=office_phone_numbers,
                email=email,
                address=address,
                city=city,
                state=state,
                zipcode=zipcode,
                country='United States',
                description=description,
                social=social,
                profile_url=response.url,
            )
            yield item
