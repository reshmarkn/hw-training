from pymongo import MongoClient
import pika
import json
from time import sleep
import datetime

import re
Hosts = ['134.209.174.206', '159.89.47.171', '157.230.178.209', '45.55.53.35', '134.122.120.61']

for i in Hosts:
    print(Hosts.index(i), "  ", i)


QUEUE_HOST = Hosts[int(input("Choose Host:"))]
# QUEUE_HOST = '159.89.47.171'  # load balancer

QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'
QUEUE_NAME = input("QUEUE NAME:")


DB_NAME = input('Enter DB Name:')

# client = MongoClient()
client = MongoClient('mongodb://datahut:cGFzc21lMTIz@64.225.9.179:27017')
db = client[DB_NAME]


COLLECTION_NAME = input('Enter Collection Name:')
while(not COLLECTION_NAME):
    colist = db.list_collection_names()
    for j in colist:

        print(colist.index(j) + 1, j, ":",
              str(db[j].estimated_document_count()))

    COLLECTION_NAME = input('Enter Collection Name:')

print('COLLECTION NAME:' + COLLECTION_NAME)

doc = dict(db[COLLECTION_NAME].find_one())
cols = ''

for key in doc:
    cols = cols + key + ','
print(cols)

FIELD = input('Enter FIELD:')
if not FIELD:

    doc = db[COLLECTION_NAME].find_one()
    FIELD = input('Enter FIELD:')

FIELD = FIELD.split(',')
FIELD = [x.strip() for x in FIELD if x.strip()]

print("FIELD:", FIELD)
searchString = {'_id': 0}
for field in FIELD:
    searchString[field] = 1

limit = input("Enter Limit:")

if limit:
    result = db[COLLECTION_NAME].find({}, searchString).limit(int(limit))
else:
    result = db[COLLECTION_NAME].find({}, searchString)

credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
connection = pika.BlockingConnection(pika.ConnectionParameters(
    credentials=credentials, host=QUEUE_HOST, socket_timeout=3000))
channel = connection.channel()


channel.queue_declare(queue=QUEUE_NAME, durable=True)
count = str(result.count(True))
# print("QUEUE_IP="+QUEUE_HOST+"\n"+"QUEUE_NAME= "+QUEUE_NAME)
# print(QUEUE_HOST+":15672/")
# print("QUEUE Username:"+QUEUE_USER)
# print("QUEUE Password:"+QUEUE_PASS)
# print(DB_NAME+"["+COLLECTION_NAME+"]")
# print("Element Count="+count)
message = "QUEUE_IP=" + QUEUE_HOST + "\n" + "QUEUE_NAME= " + QUEUE_NAME + "\n" + QUEUE_HOST + ":15672/" + "\nQUEUE Username:" + \
    QUEUE_USER + "\nQUEUE Password:" + QUEUE_PASS + "\n" + DB_NAME + \
    "[" + COLLECTION_NAME + "]" + "\nElement Count=" + count
print(message)

for data in result:

    document = dict(data)
    if len(FIELD) == 1:
        try:
            document = document[FIELD[0]]
        except:
            document = ''
        if document:
            channel.basic_publish(
                exchange='', routing_key=QUEUE_NAME, body=document)
        sleep(0.0001)

    else:
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=json.dumps(document))
        sleep(0.0001)
connection.close()
