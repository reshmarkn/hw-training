# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from semonin_realtors.items import *
from semonin_realtors.settings import *
from semonin_realtors.proxy import parse_proxy
from pymongo import MongoClient
handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}
client = MongoClient('mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
try:
    client.admin.command(
        "shardcollection", MONGO_DB + '.' + MONGO_COLLECTION, key={'profile_url': 1},unique=True)
except:
    pass

db = client[MONGO_DB]


class Semonin_RealtorsSpider(Spider):
    name = 'semonin_realtors'
    # start_urls = [
    #     'https://www.semonin.com/Roster/Offices/elizabethtown', - 4
    #     # 'https://www.semonin.com/Roster/Offices/Louisville',
    #     # 'https://www.semonin.com/Roster/Offices/southernindiana'
    # ]

    def start_requests(self):
        for var in range(1, 47):
            # url = 'https://www.semonin.com/Roster/Offices/elizabethtown/' + str(var)
            # url = 'https://www.semonin.com/Roster/Offices/southernindiana/' + str(var)
            url = 'https://www.semonin.com/Roster/Offices/Louisville/' + str(var)
            yield Request(url=url, callback=self.parse, headers=headers, dont_filter=True)

    def parse(self, response):
        agents_sel = response.xpath(
            '//article[@class="rng-agent-roster-agent-card js-sort-item"]')
        for sel in agents_sel:
            name = sel.xpath(
                'h1[@class="rn-agent-roster-name js-sort-name"]/text()').extract_first('').strip()
            url = sel.xpath('ul//i[@class="rni-website"]/ancestor::a[1]/@href').extract_first('')
            title = sel.xpath(
                'h1[@class="rn-agent-roster-name js-sort-name"]/span[@class="account-title"]/text()').extract_first('').strip()
            agent_phone = sel.xpath(
                'ul[1]/li/a/i[contains(@class,"rni-profile")]/following-sibling::text()').extract()
            office_phone = sel.xpath(
                'ul[1]/li/a/i[contains(@class,"rni-company")]/following-sibling::text()').extract()
            meta = {
                'name': name,
                'title': title,
                'agent_phone': agent_phone,
                'office_phone': office_phone}
            # if 'tel:' not in url:
            #     url2 = sel.xpath('ul[2]/li/a/@href').extract_first('')
            #     if 'https' in url2:
            #         yield Request(url=url2, callback=self.parse_profile,headers=headers, meta=meta, dont_filter=True)
            # else:
            #     if 'https:' in url:
            yield Request(url=url, callback=self.parse_profile, headers=headers, meta=meta, dont_filter=True)

    def parse_profile(self, response):
        name = response.meta['name']
        title = response.meta['title']
        agent_phone = response.meta['agent_phone']
        office_phone = response.meta['office_phone']
        profile_url = response.url

        ADDRESS_XPATH = '//ul[@class="no-bullet footer-address"]/li[3]/text()'
        OFFICE_NAME_XPATH = '//li[@class="office"]/a/text()'
        POSTAL_XPATH = '//ul[@class="no-bullet footer-address"]/li[4]/text()'
        ADDRESS_DETAILS = '//ul[@class="rn-site-footer-main-links"]/li[4]/text()'
        SOCIAL_XPATH = '//ul[@class="no-bullet footer-social"]/li/a/@href'
        IMAGE_XPATH1 = '//img[@class="agent-image"]/@src|//div[@class="site-home-page-content-agent-details"]/img/@src'
        IMAGE_XPATH2 = '//div[@class="site-home-page-content-agent-image"]/@style'
        DESCRIPTION_XPATH = '//div[@class="site-column two-thirds"]//text()'

        first_name = ''
        middle_name = ''
        last_name = ''

        agent_name = name.split()
        if '&' in agent_name:
            first_name = name
        else:
            if len(agent_name) == 1:
                first_name = agent_name[0].strip()
                middle_name = ''
                last_name = ''
            if len(agent_name) == 2:
                first_name = agent_name[0].strip()
                middle_name = ''
                last_name = agent_name[1].strip()
            if len(agent_name) == 3:
                first_name = agent_name[0].strip()
                middle_name = agent_name[1].strip()
                last_name = agent_name[2].strip()
            if len(agent_name) >= 4:
                first_name = name
                middle_name = ''
                last_name = ''

        agent_phone_numbers = []
        office_phone_numbers = []
        for number in agent_phone:
            number = number.strip()
            agent_phone_numbers.append(number)
        for num in office_phone:
            num = num.strip()
            office_phone_numbers.append(num)

        if not office_phone_numbers:
            of_phn = response.xpath('//ul[@class="no-bullet footer-address"]/li//text()').extract()
            for ph in of_phn:
                if 'Office Phone:' in ph:
                    office_ph = ph.replace('Office Phone:', '').strip()
                    office_phone_numbers.append(office_ph)
        if not agent_phone_numbers:
            agn_phn = response.xpath('//ul[@class="no-bullet footer-account-info"]/li//text()').extract()
            for ag in agn_phn:
                if 'Cell:' in ag or 'Mobile Phone:' in ag:
                    agent_ph = ag.replace('Cell:', '').replace('Mobile Phone:', '').strip()
                    agent_phone_numbers.append(agent_ph)
        country = 'United States'
        social = {}
        email = ''
        website = response.url

        office_name = response.xpath(
            OFFICE_NAME_XPATH).extract_first('').strip()

        languages = []
        zipcode = ''
        city = ''
        state = ''
        address = response.xpath(ADDRESS_XPATH).extract_first('').strip()
        if address:
            postal = response.xpath(POSTAL_XPATH).extract_first('').split(',')
            if len(postal) == 3:
                city = postal[0].strip()
                state = postal[1].strip()
                zipcode = postal[2].strip()

            if len(postal) == 2:
                city = postal[0].strip()
                postalcode = postal[1].strip().split(' ')
                if postalcode:
                    state = postalcode[0].strip()
                    zipcode = postalcode[1].strip()

        if address == '':
            address_details = response.xpath(
                ADDRESS_DETAILS).extract_first('').strip()
            if address_details:
                postal = address_details.split(',')
                if len(postal) == 3:
                    address = postal[0]
                    city = postal[1].strip()
                    loc = postal[2].split()
                    state = loc[0].strip()
                    zipcode = loc[1].strip()
                if len(postal) == 2:
                    city = postal[0].strip()
                    postalcode = postal[1].strip().split(' ')
                    if postalcode:
                        state = postalcode[0].strip()
                        zipcode = postalcode[1].strip()

        facebook_url = ''
        linkedin_url = ''
        twitter_url = ''
        social = {}
        other_urls_ = []
        socio_url = response.xpath(SOCIAL_XPATH).extract()
        if socio_url:
            for media in socio_url:
                if 'facebook' in media and 'www.facebook.com/SemoninRealtors' not in media:
                    facebook_url = response.urljoin(media)
                elif 'linkedin' in media:
                    linkedin_url = response.urljoin(media)
                elif 'twitter' in media and 'twitter.com/Semonin' not in media:
                    twitter_url = response.urljoin(media)
                elif 'pinterest' in media and 'www.pinterest.com/semoninrealtors' not in media:
                    other_urls_.append(response.urljoin(media))
                elif 'googleplus' in media and 'plus.google.com/+SemoninRealtors/about' not in media:
                    other_urls_.append(response.urljoin(media))
                elif 'youtube' in media and 'www.youtube.com/user/SemoninRealtors' not in media:
                    other_urls_.append(response.urljoin(media))
                elif 'instagram' in media and 'www.instagram.com/semonin.realtors' not in media:
                    other_urls_.append(response.urljoin(media))
                else:
                    pass

            other_urls = []
            other_urls_ = []
            for url in other_urls_:
                if url:
                    other_urls.append(url)
                else:
                    other_urls = []

            if facebook_url or twitter_url or linkedin_url or other_urls:
                social = {'facebook_url': facebook_url,
                          'twitter_url': twitter_url,
                          'linkedin_url': linkedin_url,
                          'other_urls': other_urls,
                          }
            else:
                social = {}

        image_url1 = response.xpath(IMAGE_XPATH1).extract_first('').strip()
        image_url2 = response.xpath(IMAGE_XPATH2).extract_first('').strip()

        if image_url2:
            image_url2 = re.findall("https.*\w", image_url2)
            image_url2 = ''.join(image_url2)
        if image_url1:
            image_url = image_url1
        else:
            image_url = image_url2

        if 'no-agent-photo' in image_url:
            image_url = ''

        description = response.xpath(DESCRIPTION_XPATH).extract()
        description = ' '.join(''.join(description).split())

        # yield item
        if first_name:
            item = Semonin_RealtorsItem(
                title=title,
                office_name=office_name,
                address=address,
                city=city,
                state=state,
                zipcode=zipcode,
                profile_url=profile_url,
                languages=languages,
                description=description,
                first_name=first_name,
                middle_name=middle_name,
                last_name=last_name,
                website=website,
                email=email,
                image_url=image_url,
                agent_phone_numbers=agent_phone_numbers,
                office_phone_numbers=office_phone_numbers,
                social=social,
                country=country,
            )
            yield item


            # try:
            #     db[MONGO_COLLECTION].insert(dict(item))
            # except:
            #     pass
"""
    # Errorback to put failed urls back in queue
    def errback_httpbin(self, failure, url):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=600))
        channel = connection.channel()
        channel.queue_declare(queue=QUEUE_NAME, durable=True)
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=url)
        connection.close()
    """
