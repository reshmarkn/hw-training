# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from semonin_realtors.items import *
from semonin_realtors.settings import *
from semonin_realtors.proxy import parse_proxy

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}


class Semonin_RealtorsSpider(Spider):
    name = 'semonin_realtorsurl'
    start_urls = [
        'https://www.semonin.com/Roster/Offices/elizabethtown',
        'https://www.semonin.com/Roster/Offices/Louisville',
        'https://www.semonin.com/Roster/Offices/southernindiana'
    ]

    def parse(self, response):
        agents_sel = response.xpath(
            '//article[@class="rng-agent-roster-agent-card js-sort-item"]')
        for sel in agents_sel:
            name = sel.xpath(
                'h1[@class="rn-agent-roster-name js-sort-name"]/text()').extract_first('').strip()
            url = sel.xpath('ul[2]/li/a/@href').extract_first('')
            # # print(url)
            # for agent in url:
            f = open('urlsfeb.txt', 'a')
            f.write(url + '\n')
            f.close()
