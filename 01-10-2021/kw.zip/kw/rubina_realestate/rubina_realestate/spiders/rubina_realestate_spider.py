# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from rubina_realestate.items import *
from rubina_realestate.settings import *
from rubina_realestate.proxy import parse_proxy

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

headers = {
    ':authority': 'www.rubinarealestate.com',
    ':method': 'GET',
    ':path': '/en/our-team/',
    ':scheme': 'https',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'referer': 'https://www.rubinarealestate.com/en/',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}


class Rubina_RealestateSpider(Spider):
    name = 'rubina_realestate'
    start_urls = ['https://www.rubinarealestate.com/en/our-team/']
    allowed_domains = []

    def parse(self, response):
        AGENTS_DETAIL_XPATH = '//div[@class="post-teaser clearfix"]/div//div[@class="wpcasa-staff-member"]/div'
        agents_details = response.xpath(AGENTS_DETAIL_XPATH)
        for agent in agents_details:
            IMAGE_XPATH = 'img/@src'
            NAME_XPATH = 'div[@class ="wpcasa-staff-member-overlay"]//div[@class="wpcasa-staff-member-title"]/text()'
            TITLE_XPATH = 'div[@class ="wpcasa-staff-member-overlay"]//div[@class="wpcasa-staff-member-position"]/text()'
            LANGUAGES_XPATH = 'div[@class ="wpcasa-staff-member-overlay"]//div[@class="wpcasa-staff-member-languages"]/text()'
            SOCIAL_XPATH = 'div[@class ="wpcasa-staff-member-overlay"]//div[@class="wpcasa-staff-member-links"]/a/@href'

            image_url = agent.xpath(IMAGE_XPATH).extract_first('').strip()
            name = agent.xpath(NAME_XPATH).extract_first('').strip()
            title = agent.xpath(TITLE_XPATH).extract_first('').strip()
            language = agent.xpath(
                LANGUAGES_XPATH).extract_first('').split(',')
            social = agent.xpath(SOCIAL_XPATH).extract()

            first_name = ''
            middle_name = ''
            last_name = ''

            agent_name = name.replace('-', '').split()
            if '&' in agent_name:
                first_name = name
            else:
                if len(agent_name) == 1:
                    first_name = agent_name[0].strip()
                    middle_name = ''
                    last_name = ''
                if len(agent_name) == 2:
                    first_name = agent_name[0].strip()
                    middle_name = ''
                    last_name = agent_name[1].strip()
                if len(agent_name) == 3:
                    first_name = agent_name[0].strip()
                    middle_name = agent_name[1].strip()
                    last_name = agent_name[2].strip()
                if len(agent_name) >= 4:
                    first_name = name
                    middle_name = ''
                    last_name = ''

            office_phone = '+49[0] 3041717040'
            languages = []
            for lang in language:
                lang_ = lang.strip()
                languages.append(lang_)

            other_urls = []
            facebook_url = ''
            youtube_url = ''
            twitter_url = ''
            linkedin_url = ''
            if social:
                for url_ in social:
                    url_ = url_.strip()
                    if 'facebook.com' in url_.lower():
                        facebook_url = url_
                    elif 'youtube.com' in url_.lower():
                        youtube_url = url_
                    elif 'twitter.com' in url_.lower():
                        twitter_url = url_
                    elif 'linkedin.com' in url_.lower():
                        linkedin_url = url_
                    else:
                        other_urls.append(url_)
                social = {
                    'facebook_url': facebook_url,
                    'twitter_url': twitter_url,
                    'linkedin_url': linkedin_url,
                    'other_urls': other_urls,
                }
            else:
                social = {}

            if first_name:
                item = Rubina_RealestateItem(
                    title=title,
                    office_name='Rubina Real Estate GmbH',
                    address='Charlottenstraße 18',
                    city='Mitte',
                    state='Berlin',
                    zipcode='10117',
                    profile_url='',
                    languages=languages,
                    description='',
                    first_name=first_name,
                    middle_name=middle_name,
                    last_name=last_name,
                    website='',
                    email='',
                    image_url=image_url,
                    agent_phone_numbers='',
                    office_phone_numbers=office_phone,
                    social=social,
                    country='Germany',
                )
                yield item
