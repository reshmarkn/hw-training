# # -*- coding: utf-8 -*-
# import scrapy
# import re
# import pika
# import json
# import logging
# # from dateutil import parser
# from scrapy.spiders import Spider
# from scrapy.selector import Selector
# from scrapy.http import Request, FormRequest
# from intero_realestate.items import *
# from intero_realestate.settings import *
# from intero_realestate.proxy import parse_proxy
# from scrapy.shell import inspect_response


# handler = logging.FileHandler('spider_error.log')
# handler.setLevel('ERROR')
# logging.root.addHandler(handler)
# logger = logging.getLogger('pika')
# logger.propagate = False

# headers = {
#     'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
#     'Accept-Encoding': 'gzip, deflate',
#     'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
#     'Upgrade-Insecure-Requests': '1',
#     'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}


# class Intero_RealestateSpider(Spider):
#     name = 'intero_realestate_parser'
#     start_urls = ['http://www.interorealestate.com/offices']
#     allowed_domains = ['www.interorealestate.com']

#     def parse(self, response):
#         OFFICE_URLS_XPATH = response.xpath(
#             '//div[@id="offices_index"]/div[@id="office_row_1"]/div|//div[@id="offices_index"]/div[@id="office_row_2"]/div')
#         for office_url in OFFICE_URLS_XPATH:
#             url = office_url.xpath('a/@href').extract_first('').strip()
#             url = response.urljoin(url)
#             yield Request(url=url, headers=headers, callback=self.parse_office)

#     def parse_office(self, response):
#         OFFICE_NAME_XPATH = '//h2/text()'
#         LOCATION_XPATH = '//p[@class="sub-office-address"]/text()'
#         office_name = response.xpath(
#             OFFICE_NAME_XPATH).extract_first('').strip()
#         location = response.xpath(LOCATION_XPATH).extract()
#         location = ' '.join(','.join(location).split())
#         # print('aaaaaaaaaaaaaaaaaaaaaaaaaaa', location)

#         AGENT_URL_XPATH = '//div[@id="agent-cards"]/div/div[@class="agent-cell-container white-background"]/div/a/@href'
#         agent_url = response.xpath(AGENT_URL_XPATH).extract()
#         for url in agent_url:
#             meta = {
#                 'office_name': office_name,
#                 'location': location
#             }
#             profile_url = response.urljoin(url)
#             yield Request(url=profile_url, meta=meta, headers=headers, callback=self.parse_profile)

#     def parse_profile(self, response):
#         # inspect_response(response, self)
#         office_name = response.meta['office_name']
#         location = response.meta['location']
# # -----------------------------------------------------------
#     # def start_requests(self):
#     #     f = open('urlsmay.txt')
#     #     urls = f.readlines()
#     #     for url in urls:
#     #         yield Request(url=url.strip(), callback=self.parse, headers=headers)

#     # def parse(self, response):
#     #     office_name = ''
#     #     location = ''
# # ------------------------------------------------------------
#         # Grab XPATH
#         NAME_XPATH = '//h2/text()'
#         TITLE_XPATH = '//p[@class="sub-office-address"]/text()'
#         # LOCATION_XPATH = '//span[contains(text(), "LOCATION | ")]/following-sibling::a/text()'
#         OFFICE_PHONE_XPATH = '//span[contains(text(), "OFFICE |")]/following-sibling::a/text()'
#         AGENT_PHONE_XPATH = '//span[contains(text(), "PHONE |")]/following-sibling::a/text()'
#         EMAIL_XPATH = '//span[contains(text(), "EMAIL |")]/following-sibling::a/text()'
#         LANGUAGES_XPATH = '//span[contains(text(), "LANGUAGES |")]/following-sibling::text()'
#         WEBSITE_XPATH = '//a[contains(text(), "Visit Website")]/@href'
#         DESCRIPTION_XPATH = '//div[contains(@class, "agent-description")]//text()'
#         IMAGE_XPATH = '//div[@class="office-image"]/@style'
#         FACEBOOK_XPATH = '//div[@class="social-container"]/div[@class="agent-social-icons social"]/a[@class="fb"]/@href'
#         LINKEDIN_XPATH = '//div[@class="social-container"]/div[@class="agent-social-icons social"]/a[@class="li"]/@href'
#         TWITTER_XPATH = '//div[@class="social-container"]/div[@class="agent-social-icons social"]/a[@class="tw"]/@href'
#         PINTEREST_XPATH = '//div[@class="social-container"]/div[@class="agent-social-icons social"]/a[@class="pi"]/@href'
#         INSTAGRAM_XPATH = '//div[@class="social-container"]/div[@class="agent-social-icons social"]/a[@class="ig"]/@href'
#         YOUTUBE_XPATH = '//div[@class="social-container"]/div[@class="agent-social-icons social"]/a[@class=""]/@href'
#         GOOGLEPLUS_XPATH = '//div[@class="social-container"]/div[@class="agent-social-icons social"]/a[@class="yt"]/@href'
#         YELP_XPATH = '//div[@class="social-container"]/div[@class="agent-social-icons social"]/a[@class="yp"]/@href'

#         # Extract values using above XPATHs
#         name = response.xpath(NAME_XPATH).extract_first('').strip()
#         titles = response.xpath(TITLE_XPATH).extract_first('').strip()
#         # location = response.xpath(LOCATION_XPATH).extract_first('').strip()
#         office_phone = response.xpath(
#             OFFICE_PHONE_XPATH).extract_first('').strip()
#         agent_phone = response.xpath(
#             AGENT_PHONE_XPATH).extract_first('').strip()
#         email = response.xpath(EMAIL_XPATH).extract_first('').strip()
#         languages = response.xpath(LANGUAGES_XPATH).extract_first('').strip()
#         website = response.xpath(WEBSITE_XPATH).extract_first('').strip()
#         description = response.xpath(DESCRIPTION_XPATH).extract()
#         image = response.xpath(IMAGE_XPATH).extract_first('').strip()
#         facebook_url = response.xpath(FACEBOOK_XPATH).extract_first('').strip()
#         linkedin_url = response.xpath(LINKEDIN_XPATH).extract_first('').strip()
#         twitter_url = response.xpath(TWITTER_XPATH).extract_first('').strip()
#         instagram_url = response.xpath(
#             INSTAGRAM_XPATH).extract_first('').strip()
#         pinterest_url = response.xpath(
#             PINTEREST_XPATH).extract_first('').strip()
#         youtube_url = response.xpath(YOUTUBE_XPATH).extract_first('').strip()
#         googleplus_url = response.xpath(
#             GOOGLEPLUS_XPATH).extract_first('').strip()
#         yelp_url = response.xpath(
#             YELP_XPATH).extract_first('').strip()

#         # Clea Data
#         social = {}
#         first_name = ''
#         middle_name = ''
#         last_name = ''
#         agent_title = ''
#         country = 'United States'

#         agent_name = name.split()
#         if '&' in agent_name:
#             first_name = name
#         else:
#             if len(agent_name) == 1:
#                 first_name = agent_name[0].strip()
#                 middle_name = ''
#                 last_name = ''
#             if len(agent_name) == 2:
#                 first_name = agent_name[0].strip()
#                 middle_name = ''
#                 last_name = agent_name[1].strip()
#             if len(agent_name) == 3:
#                 first_name = agent_name[0].strip()
#                 middle_name = agent_name[1].strip()
#                 last_name = agent_name[2].strip()
#             if len(agent_name) >= 4:
#                 first_name = name
#                 middle_name = ''
#                 last_name = ''

#         # if len(titles) == 1:
#         #     agent_title = titles[0].strip()
#         # if len(titles) == 2:
#         #     agent_title = []
#         #     for i in titles:
#         #         title = i.strip()
#         #         agent_title.append(title)

#         languages = [lang.strip()
#                      for lang in languages.split(',') if languages]
#         description = ' '.join(
#             ''.join(description).replace('Read More', '').split())

#         image_url1 = re.findall('https.*?[jJ][pP][gG]', image)
#         if image_url1:
#             image_url1 = image_url1[0]
#         image_url2 = re.findall('https.*?[pP][nN][gG]', image)
#         if image_url2:
#             image_url2 = image_url2[0]
#         if image_url1:
#             image_url = image_url1
#         elif image_url2:
#             image_url = image_url2
#         else:
#             image_url = ''
#         if '/agent_placeholder' in image_url:
#             image_url = ''

#         if 'facebook' in facebook_url:
#             facebook_url = facebook_url.strip()
#         else:
#             facebook_url = ''
#         if 'twitter' in twitter_url:
#             twitter_url = twitter_url.strip()
#         else:
#             twitter_url = ''
#         if 'linkedin' in linkedin_url:
#             linkedin_url = linkedin_url.strip()
#         else:
#             linkedin_url = ''
#         if 'pinterest' in pinterest_url:
#             pinterest_url = pinterest_url.strip()
#         else:
#             pinterest_url = ''
#         if 'google' in googleplus_url:
#             googleplus_url = googleplus_url.strip()
#         else:
#             googleplus_url = ''
#         if 'youtube' in youtube_url:
#             youtube_url = youtube_url.strip()
#         else:
#             youtube_url = ''
#         if 'instagram' in instagram_url:
#             instagram_url = instagram_url.strip()
#         else:
#             instagram_url = ''
#         if 'yelp' in yelp_url:
#             yelp_url = yelp_url.strip()
#         else:
#             yelp_url = ''

#         other_urls_ = []

#         if pinterest_url:
#             other_urls_.append(pinterest_url)
#         if googleplus_url:
#             other_urls_.append(googleplus_url)
#         if youtube_url:
#             other_urls_.append(youtube_url)
#         if instagram_url:
#             other_urls_.append(instagram_url)
#         if yelp_url:
#             other_urls_.append(yelp_url)

#         other_urls = []
#         for url in other_urls_:
#             if url:
#                 other_urls.append(url)
#             else:
#                 other_urls = []

#         if facebook_url or twitter_url or linkedin_url or other_urls:
#             social = {'facebook_url': facebook_url,
#                       'twitter_url': twitter_url,
#                       'linkedin_url': linkedin_url,
#                       'other_urls': other_urls,
#                       }
#         else:
#             social = {}

#         profile_url = response.request.url

#         agent_phone_numbers = [agent_phone]
#         if agent_phone_numbers == ['']:
#             agent_phone_numbers = []
#         office_phone_numbers = [office_phone]
#         if office_phone_numbers == ['']:
#             office_phone_numbers = []

#         location = location.split(',')
#         if len(location) == 3:
#             address = location[0].strip() if location else ''
#             city = location[1].strip() if location else ''
#             postal = location[2].strip() if location else ''
#             if postal:
#                 state = postal.split(' ')[0].strip() if postal else ''
#                 zipcode = postal.split(' ')[1].strip() if postal else ''
#         elif len(location) == 4:
#             address1 = location[0].strip() if location else ''
#             address2 = location[1].strip() if location else ''
#             address = address1 + ',' + ' ' + address2
#             city = location[2].strip() if location else ''
#             postal = location[3].strip() if location else ''
#             if postal:
#                 state = postal.split(' ')[0].strip() if postal else ''
#                 zipcode = postal.split(' ')[1].strip() if postal else ''
#         else:
#             address = ''
#             city = ''
#             state = ''
#             zipcode = ''

#         if office_name == 'Yuba City':
#             address = '868 Richland Rd'
#             city = 'Yuba City'
#             state = ''
#             zipcode = '95991'

#         # yield item
#         if first_name:
#             item = Intero_RealestateItem(
#                 title=titles,
#                 office_name=office_name,
#                 address=address,
#                 city=city,
#                 state=state,
#                 zipcode=zipcode,
#                 profile_url=profile_url,
#                 languages=languages,
#                 description=description,
#                 first_name=first_name,
#                 middle_name=middle_name,
#                 last_name=last_name,
#                 website=website,
#                 email=email,
#                 image_url=image_url,
#                 agent_phone_numbers=agent_phone_numbers,
#                 office_phone_numbers=office_phone_numbers,
#                 social=social,
#                 country=country,
#             )
#             yield item
