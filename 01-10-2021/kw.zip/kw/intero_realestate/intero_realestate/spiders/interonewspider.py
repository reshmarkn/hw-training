import scrapy
import re
import pika
import json
import logging
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from intero_realestate.items import *
from intero_realestate.settings import *
from intero_realestate.proxy import parse_proxy
from scrapy.shell import inspect_response

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

headers = {

    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'Host': 'svc.moxiworks.com',
    'Pragma': 'no-cache',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36'

}


class Intero_RealestateSpider(Spider):
    name = 'intero_realestate_new'
    start_urls = [
        'https://svc.moxiworks.com/service/v1/profile/offices/search?company_uuid=3220480']
    # allowed_domains = ['www.interorealestate.com']

    def parse(self, response):
        json_data = json.loads(response.body_as_unicode())
        source = json_data.get('data').get('result_list')
        # print(s)
        for ite in source:
            user = ite.get('uuid')
            url = 'https://svc.moxiworks.com/service/profile/v2_insecure/offices/' + \
                str(user)+'/agents'

            # url = 'https://svc.moxiworks.com/service/profile/v2_insecure/offices/' + \
            #     str(user)+'/agents'
            # print(url)
            yield Request(url=url, headers=headers, callback=self.parse_profile, dont_filter=True)

    def parse_profile(self, response):

        # print('3333333333333333333333333333333333333333333333333333333')
        profile_data = json.loads(response.body_as_unicode())
        agentss = profile_data.get('data').get('result_list')

        for pro in agentss:
            name = pro.get('display_name', '')
            title = pro.get('title')
            if title == None:
                title = ''
            first_name = pro.get('firstname', '')
            last_name = pro.get('lastname')
            middle_name = pro.get('middlename', '')
            email = pro.get('email', '')
            agent_phone_numbers = pro.get('mainphone')
            if agent_phone_numbers == None:
                # agent_phone_numbers = ''
                agent_phone_numbers = pro.get('cellphone', '')
            office_phone_numbers = pro.get('office').get('phone')
            office_name = pro.get('office').get('name')
            address = pro.get('office').get('location').get('address')
            city = pro.get('office').get('location').get('city')
            # country = pro.get('office').get('location').get('county')
            state = pro.get('office').get('location').get('state')
            zipcode = pro.get('office').get('location').get('zip')
            profile_url = 'https://www.intero.com/directory/agents/' + \
                pro.get('url_slug', '')
            social = pro.get('social_urls', '')
            if social == None:
                social = ''
            languages = ''
            lang = []
            langu = pro.get('languages')
            for f in langu:
                languages = f.get('languagename')
                lang.append(languages)
            img = pro.get('image')
            for im in img:
                image_url = im.get('raw_url')
            meta = {'item': {'first_name': first_name,
                             'middle_name': middle_name,
                             'last_name': last_name,
                             'office_name': office_name,
                             'title': title,
                             'languages': lang,
                             'image_url': image_url,
                             'address': address,
                             'city': city,
                             'state': state,
                             'zipcode': zipcode,
                             'email': email,
                             'website': '',
                             'office_phone_numbers': office_phone_numbers,
                             'agent_phone_numbers': agent_phone_numbers,
                             'social': social,
                             'profile_url': profile_url, }}

            user_id = pro.get('user_id')

            description_url = 'https://svc.moxiworks.com/service/v1/profile/' + \
                str(user_id)
            yield Request(url=description_url, headers=headers, callback=self.parse_description, meta=meta, dont_filter=True)

    def parse_description(self, response):
        item = Intero_RealestateItem()
        item.update(response.meta.get('item'))
        profile_data = json.loads(response.body_as_unicode())
        agentss = profile_data.get('data').get('result_list')
        description = ''
        for pro1 in agentss:
            desc = pro1.get('contentblocks')
            if desc:
                description = desc[0].get('body')
            cleanr = re.compile('<.*?>')
            cleantext = re.sub(cleanr, '', description)
        item['description'] = ''.join(cleantext).strip()
        item['country'] = 'United States'
        yield item
