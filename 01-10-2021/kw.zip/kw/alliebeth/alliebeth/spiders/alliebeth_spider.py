# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from alliebeth.items import *
from alliebeth.settings import *
from alliebeth.proxy import parse_proxy

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Connection': 'keep-alive',
    'Host': 'www.alliebeth.com',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36', }


class AlliebethSpider(Spider):
    name = 'alliebeth'
    start_urls = ['http://www.alliebeth.com/associates/int']
    allowed_domains = []

    def parse(self, response):
        links = response.xpath('//a[@class="url"]/@href').extract()
        for link in links:
            url = response.urljoin(link)
            yield Request(url=url, callback=self.parse_profile)

        next_ = response.xpath('//link[@rel="next"]/@href').extract()
        if next_:
            next_page = 'https:' + next_[0]
            yield Request(url=next_page, callback=self.parse)

    def parse_profile(self, response):
        first_name = ''
        last_name = ''
        middle_name = ''
        languages = []
        office_phone_numbers = []
        agent_phone_numbers = []
        email = ''
        websites = ''
        social = {}
        zipcode = ''

        name = response.xpath('//h1[@itemprop="name"]/text()').extract()
        title = response.xpath('//h2[@itemprop="jobTitle"]/text()').extract()
        image = response.xpath(
            '//div[@class="u-ar__content"]//img/@src').extract_first()
        if 'nophoto' not in image:
            image_url = image
        office_name = response.xpath(
            '//h3[@class="contact-card__office-title"]//text()').extract()
        agent_phone_numbers = response.xpath(
            '//a[@class="o-phone-number  tel  phone_block  icon-text  js-phone-link  phone-num-1"]/text()').extract()
        address = response.xpath(
            '//div[@class="street-address"]/text()').extract()
        city = response.xpath(
            '//span[@itemprop="addressLocality"]/text()').extract_first()
        state = response.xpath(
            '//span[@itemprop="addressRegion"]/text()').extract_first()
        zipcode = response.xpath(
            '//span[@itemprop="postalCode"]/text()').extract_first()
        country = response.xpath(
            '//span[@itemprop="addressCountry"]/text()').extract_first()
        description = response.xpath(
            '//div[@itemprop="description"]/p//text() | //div[@itemprop="description"]//text()').extract()

        name_ = ''.join(name)
        if ',' in name_:
            nam_ = name_.split(',')[0]
            nam = nam_.split(' ')
        else:
            nam = name_.split(' ')

        if len(nam) == 2:
            first_name = nam[0]
            last_name = nam[1]
            middle_name = ''
        elif len(nam) == 3:
            first_name = nam[0]
            middle_name = nam[1]
            last_name = nam[2]
        elif len(nam) >= 4:
            first_name = name_
            middle_name = ''
            last_name = ''

        office_name = ''.join(office_name).strip()
        title = ''.join(title).strip()
        description = ''.join(description).strip()
        address = ''.join(address).strip()

        item = AlliebethItem(
            first_name=first_name,
            middle_name=middle_name,
            last_name=last_name,
            office_name=office_name,
            title=title,
            description=description,
            languages=languages,
            image_url=image_url,
            address=address,
            city=city,
            state=state,
            country=country,
            zipcode=zipcode,
            office_phone_numbers=office_phone_numbers,
            agent_phone_numbers=agent_phone_numbers,
            email=email,
            website=websites,
            social=social,
            profile_url=response.url,
        )
        logging.warning(item)
        try:
            yield item
        except:
            pass
