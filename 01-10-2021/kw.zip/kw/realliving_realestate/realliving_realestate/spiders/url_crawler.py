import scrapy
import re
import pika
import json
import logging
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from realliving_realestate.items import *
from realliving_realestate.settings import *
from realliving_realestate.proxy import parse_proxy

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.119 Safari/537.36'}


class Realliving_RealestateUrlSpider(Spider):
    name = 'realliving_realestate_crawler'

    def start_requests(self):
        for page in range(1, 62):
            url = 'https://www.realliving.com/AgentSearch/Results.aspx?SearchType=agent&FirstName=&LastName=&OfficeName=&Address=&City=&State=&Country=-32768&Zip=&Languages=&Titles=&Specialties=&Accreditations=&Areas=&rpp=50&page=' + \
                str(page) + '&SortOrder='
            yield Request(url=url, callback=self.parse)

    def parse(self, response):
        agent_url = response.xpath(
            '//h3/a/@href').extract()
        for i in agent_url:
            f = open('urlsjan.txt', 'a')
            f.write(i + '\n')
            f.close()
