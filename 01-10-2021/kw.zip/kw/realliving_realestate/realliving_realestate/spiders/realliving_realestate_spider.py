# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from realliving_realestate.items import *
from realliving_realestate.settings import *
from realliving_realestate.proxy import parse_proxy
from scrapy.shell import inspect_response


handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.119 Safari/537.36'}


class Realliving_RealestateSpider(Spider):
    name = 'realliving_realestate'
    start_urls = ['https://www.realliving.com/AgentSearch/Results.aspx?'
                  'SearchType=agent&FirstName=&LastName=&OfficeName=&'
                  'Address=&City=&State=&Country=-32768&Zip=&Languages='
                  '&Titles=&Specialties=&Accreditations=&Areas=&rpp=50&'
                  'page=1&SortOrder=']

    """
    # Queue implementation
    def start_requests(self):
        # Fetching URL from queue until queue is empty
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        channel = connection.channel()
        while True:
            channel.basic_qos(prefetch_count=1)
            method, properties, url = channel.basic_get(queue=QUEUE_NAME)
            if not url.strip():
                break
            channel.basic_ack(delivery_tag=method.delivery_tag)
            url = str(url.strip(), encoding='utf-8')
            if url.strip():
                yield Request(url=url.strip(), callback=self.parse, '
                'headers=self.headers, errback=lambda x: '
                'self.errback_httpbin(x, url.strip()))
        connection.close()
    """

    def parse(self, response):
        name = ''
        agent_phone = ''
        city = ''
        state = ''
        zipcode = ''
        office_phone_numbers = []
        office_phone_numbers = []

        agent_sel = response.xpath(
            '//div[@class="ao_search_results_container"]//div[starts-with'
            '(@class, "rui-row")]/div[not(contains(@class, '
            '"ao_page_controls_area"))]')
        for sel in agent_sel:
            url = sel.xpath(
                'div[@class="ao-info-container"]/div/div/h3/a/@href').extract_first('').strip()
            name = sel.xpath(
                'div[@class="ao-info-container"]/div/div/h3/a/text()').extract_first('').strip()
            image_url = sel.xpath(
                'div[@class="ao-photo-container"]/a/img/@src').extract_first('').strip()
            agent_phone_numbers = sel.xpath(
                'div[@class="ao-info-container"]/div/div/div[@id="ao-phone"]//text()').extract()
            office_phone_numbers = sel.xpath(
                'div[@class="ao-info-container"]/div/div/div[@id="ao-cell"]//text()').extract()
            website = sel.xpath(
                'div[@class="ao-info-container"]/div/span[@class="view-website-container"]/a[contains(text(), "Visit Website")]/@href').extract_first('')
            address = sel.xpath(
                'div[@class="ao-info-container"]/div/div/div[@class="ao-address"]/span/text()').extract_first('').strip()
            office_name = sel.xpath(
                'div[@class="ao-info-container"]/div/div[@class="ao-info-c2"]/div[@class="ao-office"]/a/span/text()').extract_first('').strip()
            social_ = sel.xpath(
                'div[@class="ao-info-container"]/div/div[@class="ao-info-c3"]/div[@class="ao-social"]/a/@href').extract()
            location = sel.xpath(
                'div[@class="ao-info-container"]/div/div/div[@class="ao-address"]/text()').extract()
            location = ' '.join(''.join(location).split())
            if location:
                city = location.split(',')[0].strip()
                postal = location.split(',')[1].strip()
                if postal:
                    zipcode = postal.split()[-1].strip()
                    state = postal.replace(zipcode, '').strip()

            agent_phone_numbers = [''.join(agent_phone_numbers).strip()]
            office_phone_numbers = [''.join(office_phone_numbers).strip()]

            meta = {
                'name': name,
                'image_url': image_url,
                'agent_phone_numbers': agent_phone_numbers,
                'office_phone_numbers': office_phone_numbers,
                'website': website,
                'address': address,
                'office_name': office_name,
                'city': city,
                'zipcode': zipcode,
                'state': state,
                'social_': social_,
            }
            yield Request(url=url, headers=headers, callback=self.parse_profile, meta=meta, dont_filter=True)

        for page in range(1, 64):
            next_ = 'https://www.realliving.com/AgentSearch/Results.aspx?SearchType=agent&FirstName=&LastName=&OfficeName=&Address=&City=&State=&Country=-32768&Zip=&Languages=&Titles=&Specialties=&Accreditations=&Areas=&rpp=50&page=' + \
                str(page) + '&SortOrder='
            yield Request(url=next_, callback=self.parse)

    def parse_profile(self, response):
        # inspect_response(response, self)

        name = response.meta['name']
        image_url = response.meta['image_url']
        agent_phone_numbers = response.meta['agent_phone_numbers']
        office_phone_numbers = response.meta['office_phone_numbers']
        website = response.meta['website']
        address = response.meta['address']
        office_name = response.meta['office_name']
        city = response.meta['city']
        zipcode = response.meta['zipcode']
        state = response.meta['state']
        social_ = response.meta['social_']
        other_urls = []
        title = ''
        middle_name = ''
        languages = []
        description = ''
        social = {}

        description = response.xpath(
            '//div[@class="general-content"]/p/text() | //div[@class="bio-text"]//text()').extract()
        description = ''.join(description).replace('\r\n', '').strip()

        title = response.xpath('//td[@id="headertitle"]/h2/text()').extract()
        title = ''.join(title).strip()

        email1 = response.xpath(
            '//a[starts-with(@href, "mailto")]/text()').extract_first('')
        email2 = response.xpath(
            '//div[@class="row container-inner text-center"]//a//text()').extract_first()

        if email1:
            email = email1
        elif email2:
            email2 = ''.join(email2).split()[0]
            email = email2
        else:
            email = ''

        agent_name = name.replace('-', '').split()
        if '&' in agent_name:
            first_name = name
        else:
            if len(agent_name) == 1:
                first_name = agent_name[0].strip()
                middle_name = ''
                last_name = ''
            if len(agent_name) == 2:
                first_name = agent_name[0].strip()
                middle_name = ''
                last_name = agent_name[1].strip()
            if len(agent_name) == 3:
                first_name = agent_name[0].strip()
                middle_name = agent_name[1].strip()
                last_name = agent_name[2].strip()
            if len(agent_name) >= 4:
                first_name = name
                middle_name = ''
                last_name = ''

        for url in social_:
            if 'facebook' in url:
                facebook_url = url
                social.update({'facebook_url': facebook_url})
            elif 'twitter' in url:
                twitter_url = url
                social.update({'twitter_url': twitter_url})
            elif 'linkedin' in url:
                linkedin_url = url
                social.update({'linkedin_url': linkedin_url})
            else:
                other_urls.append(url)
                social.update({'other_urls': other_urls})

        if first_name:
            item = Realliving_RealestateItem(
                title=title,
                office_name=office_name,
                address=address,
                city=city,
                state=state,
                zipcode=zipcode,
                profile_url=response.url,
                languages=languages,
                description=description,
                first_name=first_name,
                middle_name=middle_name,
                last_name=last_name,
                website=website,
                email=email,
                image_url=image_url,
                agent_phone_numbers=agent_phone_numbers,
                office_phone_numbers=[],
                social=social,
                country='United States',
            )
            yield item

    """
    # Errorback to put failed urls back in queue
    def errback_httpbin(self, failure, url):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=600))
        channel = connection.channel()
        channel.queue_declare(queue=QUEUE_NAME, durable=True)
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=url)
        connection.close()
    """
