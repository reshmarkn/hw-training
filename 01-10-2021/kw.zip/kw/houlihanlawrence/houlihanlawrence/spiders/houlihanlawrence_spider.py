# -*- coding: utf-8 -*-
import scrapy
import ast
import re
from scrapy.http import Request, FormRequest
from houlihanlawrence.items import *
from houlihanlawrence.proxy import *
from houlihanlawrence.settings import *
from string import ascii_lowercase


class HoulihanlawrenceSpiderSpider(scrapy.Spider):
    name = 'houlihanlawrence_spider'
    start_urls = ['http://www.houlihanlawrence.com/agents_offices/']
    #allowed_domains = ['http://www.houlihanlawrence.com']

    def parse(self, response):
        #searchwords = list(string.lowercase)
        for alpha in ascii_lowercase:
            headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
                       'Accept-Encoding': 'gzip, deflate',
                       'Accept-Language': 'en-GB,en-US;q=0.8,en;q=0.6',
                       'Upgrade-Insecure-Requests': '1',
                       'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.91 Safari/537.36'}

            form_data = {'houlihan_keywords': alpha,
                         'Search': 'search'}

            yield FormRequest(url=response.url, method='POST', formdata=form_data, callback=self.parse_people, dont_filter=True)

    def parse_people(self, response):
        offices = []
        office_data = re.findall(
            "office_points.push\((\{(?:.|\n)*?\})\);", response.body_as_unicode())
        for data in office_data:
            office = ' '.join(data.split())
            office = ast.literal_eval(office)
            offices.append(office)

        people = response.xpath('//a[@class="green"]/@href').extract()
        for profile in people:
            meta = {'offices': offices}
            yield Request(url=response.urljoin(profile), callback=self.parse_agent_link, meta=meta, dont_filter=True)

    def parse_agent_link(self, response):
        offices = response.meta['offices']
        agent_link = response.xpath(
            '//a[@class="green upper"]//@href').extract()
        for link in agent_link:
            meta = {'offices': offices}
            yield Request(url=response.urljoin(link), callback=self.parse_data, meta=meta)

    def parse_data(self, response):
        offices = response.meta['offices']
        first_name = ''
        middle_name = ''
        last_name = ''
        languages = []
        website = ''
        address = ''
        city = ''
        state = ''
        zipcode = ''
        social = {}

        NAME_XPATH = '//strong[@class="upper"]/text()'
        TITLE_XPATH = '//p[@class="black font-13"]/em/text()'
        DESCRIPTION_XPATH = '//div[@class="col-sm-9 col-md-7 col-lg-6 col-lg-offset-2"]//div//text()'
        IMAGE_XPATH = '//img[@class="replace-image"]/@src'
        OFFICE_NAME_XPATH = '//ul[@class="list-unstyled font-13 black margin-0 social-links"]/li[1]/text()'
        OFFICE_PHONE_XPATH = '//ul[@class="list-unstyled font-13 black margin-0 social-links"]/li[contains(text(),"Office:")]/text()'
        AGENT_PHONE_XPATH = '//ul[@class="list-unstyled font-13 black margin-0 social-links"]/li[contains(text(),"Mobile:")]/text()'
        EMAIL_XPATH = '//a[@class="green fancybox"]/text()'
        LANGUAGES_XPATH = '//p/strong[contains(text(), "Additional Languages Spoken")]/following-sibling::text()'
        LIVESIN_XPATH = '//p/strong[contains(text(), "Lives In")]/following-sibling::text()'
        FACEBOOK_XPATH = '//a[@title="Visit my Facebook page"]/@href'
        LINKEDIN_XPATH = '//a[@title="Visit my LinkedIn page"]/@href'
        TWITTER_XPATH = '//a[@title="Visit my Twitter page"]/@href'
        PINTEREST_XPATH = '//a[@title="Visit my Pinterest page"]/@href'
        INSTAGRAM_XPATH = '//a[@title="Visit my Instagram page"]/@href'
        YOUTUBE_XPATH = '//a[@title="Visit my YouTube (User) page"]/@href'
        GOOGLEPLUS_XPATH = '//a[@title="Visit my Googleplus page"]/@href'
        YELP_XPATH = '//a[@title="Visit my Yelp page"]/@href'

        name = response.xpath(NAME_XPATH).extract_first('').strip()
        title = response.xpath(TITLE_XPATH).extract_first('').strip()
        description = response.xpath(DESCRIPTION_XPATH).extract()
        image = response.xpath(IMAGE_XPATH).extract_first('').strip()
        office_name = response.xpath(
            OFFICE_NAME_XPATH).extract_first('').strip()
        office_phone = response.xpath(OFFICE_PHONE_XPATH).extract()
        agent_phone = response.xpath(AGENT_PHONE_XPATH).extract()
        email = response.xpath(EMAIL_XPATH).extract_first('').strip()
        languages = response.xpath(LANGUAGES_XPATH).extract_first('').strip()
        livesin = response.xpath(LIVESIN_XPATH).extract_first(
            '').strip().split(',')
        facebook_url = response.xpath(FACEBOOK_XPATH).extract_first('').strip()
        linkedin_url = response.xpath(LINKEDIN_XPATH).extract_first('').strip()
        twitter_url = response.xpath(TWITTER_XPATH).extract_first('').strip()
        instagram_url = response.xpath(
            INSTAGRAM_XPATH).extract_first('').strip()
        pinterest_url = response.xpath(
            PINTEREST_XPATH).extract_first('').strip()
        youtube_url = response.xpath(YOUTUBE_XPATH).extract_first('').strip()
        googleplus_url = response.xpath(
            GOOGLEPLUS_XPATH).extract_first('').strip()
        yelp_url = response.xpath(
            YELP_XPATH).extract_first('').strip()
        profile_url = response.url

        agent_name = name.split()
        if '&' in agent_name:
            first_name = name
        else:
            if len(agent_name) == 1:
                first_name = agent_name[0].strip()
                middle_name = ''
                last_name = ''
            if len(agent_name) == 2:
                first_name = agent_name[0].strip()
                middle_name = ''
                last_name = agent_name[1].strip()
            if len(agent_name) == 3:
                first_name = agent_name[0].strip()
                middle_name = agent_name[1].strip()
                last_name = agent_name[2].strip()
            if len(agent_name) >= 4:
                first_name = name
                middle_name = ''
                last_name = ''

        languages = [lang.strip()
                     for lang in languages.split(',') if languages]

        if len(livesin) == 1:
            city = ''.join(livesin)
        if len(livesin) == 2:
            city = livesin[0].strip()
            state = livesin[1].strip()

        description = ' '.join(''.join(description).split())

        # image_url = image.replace('maxwidth/192','maxwidth/384')
        agent_phone_numbers = []
        office_phone_numbers = []
        for number in agent_phone:
            number = number.replace('Mobile: ', '').strip()
            agent_phone_numbers.append(number)
        for num in office_phone:
            num = num.replace('Office: ', '').strip()
            office_phone_numbers.append(num)

        image_url = response.urljoin(image) if image else ''
        if 'images/agent-placeholder' in image_url:
            image_url = ''

        if 'facebook' in facebook_url:
            facebook_url = facebook_url.strip()
        else:
            facebook_url = ''
        if 'twitter' in twitter_url:
            twitter_url = twitter_url.strip()
        else:
            twitter_url = ''
        if 'linkedin' in linkedin_url:
            linkedin_url = linkedin_url.strip()
        else:
            linkedin_url = ''
        if 'pinterest' in pinterest_url:
            pinterest_url = pinterest_url.strip()
        else:
            pinterest_url = ''
        if 'google' in googleplus_url:
            googleplus_url = googleplus_url.strip()
        else:
            googleplus_url = ''
        if 'youtube' in youtube_url:
            youtube_url = youtube_url.strip()
        else:
            youtube_url = ''
        if 'instagram' in instagram_url:
            instagram_url = instagram_url.strip()
        else:
            instagram_url = ''
        if 'yelp' in yelp_url:
            yelp = yelp.strip()
        else:
            yelp = ''

        other_urls_ = []

        if pinterest_url:
            other_urls_.append(pinterest_url)
        if googleplus_url:
            other_urls_.append(googleplus_url)
        if youtube_url:
            other_urls_.append(youtube_url)
        if instagram_url:
            other_urls_.append(instagram_url)
        if yelp_url:
            other_urls_.append(yelp_url)

        other_urls = []
        for url in other_urls_:
            if url:
                other_urls.append(url)
            else:
                other_urls = []

        if facebook_url or twitter_url or linkedin_url or other_urls:
            social = {'facebook_url': facebook_url,
                      'twitter_url': twitter_url,
                      'linkedin_url': linkedin_url,
                      'other_urls': other_urls,
                      }
        else:
            social = {}

        if office_name:
            for i in offices:
                if i.get('title') in office_name.replace(' Office', ''):
                    address1 = i.get('street_address')
                    address2 = i.get('street_address_2')
                    if address2:
                        address = address1 + ',' + address2
                    else:
                        address = address1
                    city = i.get('city')
                    state = i.get('state').strip()
                    zipcode = i.get('zip').strip()

        if first_name:
            item = HoulihanlawrenceItem(
                title=title,
                office_name=office_name,
                address=address,
                city=city,
                state=state,
                zipcode=zipcode,
                profile_url=profile_url,
                languages=languages,
                description=description,
                first_name=first_name,
                middle_name=middle_name,
                last_name=last_name,
                website=website,
                email=email,
                image_url=image_url,
                agent_phone_numbers=agent_phone_numbers,
                office_phone_numbers=office_phone_numbers,
                social=social,
                country='United States',
            )
            # print(item)
            yield item
