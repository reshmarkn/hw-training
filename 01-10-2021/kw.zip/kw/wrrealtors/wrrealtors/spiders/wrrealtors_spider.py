# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from wrrealtors.items import *
from wrrealtors.settings import *
from wrrealtors.proxy import parse_proxy

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

h = {"Accept":"*/*",   
        "Accept-Encoding":"gzip, deflate",   
        "Accept-Language":"en-GB,en-US;q=0.9,en;q=0.8",   
        "Host":"www.wrrealtors.com",   
        "Referer":"https://www.wrrealtors.com/roster/agents",   
        "Sec-Fetch-Mode":"cors",   
        "Sec-Fetch-Site":"same-origin",   
        "User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36", 
        "X-Requested-With":"XMLHttpRequest"}                                                                                      


class WrrealtorsSpider(Spider):
    name = 'wrrealtors'

    def start_requests(self):
        for var in range(1, 4):
            url = 'https://www.wrrealtors.com/CMS/CmsRoster/RosterSection?layoutID=956&pageSize=10&pageNumber='+str(var)+'&sortBy=firstname'
            yield Request(url=url, callback=self.parse, headers=h)
    def parse(self, response):
        # AGENTS_LINK_XPATH = '//a[@class="button hollow"]/@href'
        # agents_link = response.xpath(AGENTS_LINK_XPATH).extract()
        # for link in agents_link:
        #     url = response.urljoin(link)
        #     yield scrapy.Request(url=url, callback=self.parse_data)
        agent_list = response.xpath('//article[@class="rng-agent-roster-agent-card js-sort-item"]')
        for agent in agent_list:
            url = agent.xpath('a[@class="button hollow"]/@href').extract_first('').strip()
            if url:
                url = response.urljoin(url)
                yield scrapy.Request(url=url, callback=self.parse_data)
            else:
                name = agent.xpath('h1[@class="rn-agent-roster-name js-sort-name"]/text()').extract_first('').strip()
                title = agent.xpath('h1/span[@class="account-title"]/text()').extract_first('').strip()
                agent_phone_numbers = agent.xpath('ul/li/a/i[@class="rni-profile"]/following-sibling::text()').extract()
                website = agent.xpath('ul/li/a[contains(text(),"Website")]/@href').extract_first('').strip()
                image = agent.xpath('img/@src').extract_first('').strip()
                agent_phone_numbers = [z.strip() for z in agent_phone_numbers if z.strip()]

                first_name = ''
                middle_name = ''
                last_name = ''
                agent_name = name.replace('-', '').split()
                if '&' in agent_name:
                    first_name = name
                else:
                    if len(agent_name) == 1:
                        first_name = agent_name[0].strip()
                        middle_name = ''
                        last_name = ''
                    if len(agent_name) == 2:
                        first_name = agent_name[0].strip()
                        middle_name = ''
                        last_name = agent_name[1].strip()
                    if len(agent_name) == 3:
                        first_name = agent_name[0].strip()
                        middle_name = agent_name[1].strip()
                        last_name = agent_name[2].strip()
                    if len(agent_name) >= 4:
                        first_name = name
                        middle_name = ''
                        last_name = ''

                office_name = 'Wakefield Reutlinger Realtors'
                address = '6511 Glenridge Park Place'
                state = 'Louisville'
                city = 'KY'
                zipcode = '40222'
                office_phone = '(502) 425-0225'
                office_phone_numbers = [office_phone]
                country = 'United States'
                languages = []
                social = {}
                if first_name:
                    item = WrrealtorsItem(
                        title=title,
                        office_name=office_name,
                        address=address,
                        city=city,
                        state=state,
                        zipcode=zipcode,
                        profile_url='',
                        languages=languages,
                        description='',
                        first_name=first_name,
                        middle_name=middle_name,
                        last_name=last_name,
                        website=website,
                        email='',
                        image_url=image,
                        agent_phone_numbers=agent_phone_numbers,
                        office_phone_numbers=office_phone_numbers,
                        social=social,
                        country=country,
                    )
                    yield item

    def parse_data(self, response):

        NAME_XPATH = '//p[@class="rng-agent-profile-contact-name"]/text()'
        TITLE_XPATH = '//span[@class="rng-agent-profile-contact-title"]/text()'
        IMAGE_XPATH = '//article[@class="rng-agent-profile-main"]/img/@src'
        AGENT_PHONE_XPATH = '//li[@class="rng-agent-profile-contact-phone"]/a/text()'
        EMAIL_XPATH = '//div/strong[contains(text(), "Email:")]/following-sibling::span/a/@data-email'
        WEBSITE_XPATH = '//li[@class="rng-agent-profile-contact-website"]/a/@href'
        DESCRIPTION_XPATH = '//div[@id="body-text-1-preview-5500"]//text()'
        LINKEDIN_XPATH = '//ul[@class="rng-agent-profile-contact"]/li[@class="social-linkedin"]/a/@href'
        FACEBOOK_XPATH = '//ul[@class="rng-agent-profile-contact"]/li[@class="social-facebook"]/a/@href'
        # TWITTER_XPATH = '//a[@class="social-profile social-profile--twitter"]/@href'
        INSTAGRAM_XPATH = '//ul[@class="rng-agent-profile-contact"]/li[@class="social-instagram"]/a/@href'
        # PINTEREST_XPATH = '//a[@class="social-profile social-profile--pinterest"]/@href'

        name = response.xpath(NAME_XPATH).extract_first('').strip()
        title = response.xpath(TITLE_XPATH).extract_first('').strip()
        image_url = response.xpath(IMAGE_XPATH).extract_first('').strip()
        agent_phone_numbers = response.xpath(AGENT_PHONE_XPATH).extract()
        email = response.xpath(EMAIL_XPATH).extract_first('').strip()
        website = response.xpath(WEBSITE_XPATH).extract_first('').strip()
        description = response.xpath(DESCRIPTION_XPATH).extract()
        facebook_url = response.xpath(FACEBOOK_XPATH).extract_first('').strip()
        linkedin_url = response.xpath(LINKEDIN_XPATH).extract_first('').strip()
        # twitter_url = response.xpath(TWITTER_XPATH).extract_first('').strip()
        instagram_url = response.xpath(
            INSTAGRAM_XPATH).extract_first('').strip()
        # pinterest_url = response.xpath(
        #     PINTEREST_XPATH).extract_first('').strip()

        first_name = ''
        middle_name = ''
        last_name = ''
        agent_name = name.replace('-', '').split()
        if '&' in agent_name:
            first_name = name
        else:
            if len(agent_name) == 1:
                first_name = agent_name[0].strip()
                middle_name = ''
                last_name = ''
            if len(agent_name) == 2:
                first_name = agent_name[0].strip()
                middle_name = ''
                last_name = agent_name[1].strip()
            if len(agent_name) == 3:
                first_name = agent_name[0].strip()
                middle_name = agent_name[1].strip()
                last_name = agent_name[2].strip()
            if len(agent_name) >= 4:
                first_name = name
                middle_name = ''
                last_name = ''
        agent_phone_numbers = [z.strip() for z in agent_phone_numbers if z.strip()]
        description = ' '.join(''.join(description).split())

        office_name = 'Wakefield Reutlinger Realtors'
        address = '6511 Glenridge Park Place'
        state = 'Louisville'
        city = 'KY'
        zipcode = '40222'
        office_phone = '(502) 425-0225'
        office_phone_numbers = [office_phone]
        country = 'United States'
        languages = []
        social = {}
        profile_url = response.url

        if 'facebook.com' in facebook_url:
            facebook_url = facebook_url.strip()
        else:
            facebook_url = ''
        # if 'twitter.com' in twitter_url:
        #     twitter_url = twitter_url.strip()
        # else:
        #     twitter_url = ''
        if 'linkedin.com' in linkedin_url:
            linkedin_url = linkedin_url.strip()
        else:
            linkedin_url = ''
        # if 'pinterest.com' in pinterest_url:
        #     pinterest_url = pinterest_url.strip()
        # else:
        #     pinterest_url = ''
        if 'instagram.com' in instagram_url:
            instagram_url = instagram_url.strip()
        else:
            instagram_url = ''

        other_urls_ = []

        # if pinterest_url:
        #     other_urls_.append(pinterest_url)
        if instagram_url:
            other_urls_.append(instagram_url)

        other_urls = []
        for url in other_urls_:
            if url:
                other_urls.append(url)
            else:
                other_urls = []

        if facebook_url or linkedin_url or other_urls:
            social = {'facebook_url': facebook_url,
                      # 'twitter_url': twitter_url,
                      'linkedin_url': linkedin_url,
                      'other_urls': other_urls,
                      }
        else:
            social = {}

        if 'nophoto_mid' in image_url:
            image_url = ''

        # yield item
        if first_name:
            item = WrrealtorsItem(
                title=title,
                office_name=office_name,
                address=address,
                city=city,
                state=state,
                zipcode=zipcode,
                profile_url=profile_url,
                languages=languages,
                description=description,
                first_name=first_name,
                middle_name=middle_name,
                last_name=last_name,
                website=website,
                email=email,
                image_url=image_url,
                agent_phone_numbers=agent_phone_numbers,
                office_phone_numbers=office_phone_numbers,
                social=social,
                country=country,
            )
            yield item
            # print(item)
