import scrapy
import string
from scrapy.http import Request, FormRequest
from royallepage.items import RoyallepageItem
from royallepage.settings import *
import re
import gzip
import json
from scrapy.selector import Selector


class royallepage(scrapy.Spider):
    name = 'royallepage'
    allowed_domains = ['royallepage.ca']
    start_urls = ['https://www.royallepage.ca/']
    headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
        'accept-encoding': 'gzip, deflate, br',
        'accept-language': 'en-US,en;q=0.9',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36'
    }

    def parse(self, response):
        LOCATION_URLS = response.xpath(
            '//p[contains(text(), "Browse agents")]/a/@href').extract()
        for url in LOCATION_URLS:
            yield Request(response.urljoin(url), callback=self.parse_loc, headers=self.headers)

    def parse_loc(self, response):
        OFC_URLS = response.xpath(
            '//h1/following-sibling::div/ul/li/a/@href').extract()
        # https://www.royallepage.ca/en/search/get-list/agent/289/2/
        for url in OFC_URLS:
            url = 'https://www.royallepage.ca/en/search/get-list/agent/' + \
                url.strip('/').split('/')[-1]
            yield Request(url, callback=self.parse_ofc, headers=self.headers)

    def parse_ofc(self, response):
        body = json.loads(response.body_as_unicode().strip(
            ');').strip('(')).get('html', '')
        sel = Selector(text=body)
        PROFILE_URLS = sel.xpath(
            '//div[@class="agent-info"]/a/@href').extract()
        for url in PROFILE_URLS:
            yield Request(response.urljoin(url), callback=self.parse_profile, headers=self.headers)
        NEXT_PAGE = sel.xpath('//a[span/text()="next"]/@href').extract_first()
        if NEXT_PAGE:
            yield Request(response.urljoin(NEXT_PAGE), callback=self.parse_ofc, headers=self.headers)

    def parse_profile(self, response):
        TITLE_XPATH = '//span[@class="media__sub-title"]/text()'
        CITY_STATE_XPATH = '//span[@itemprop="addressLocality"]/text()'
        ADDRESS_XPATH = '//span[@itemprop="streetAddress"]/text()'
        LANGUAGES_XPATH = '//div[h2/text()="Spoken Languages"]/p/text()'
        # DESCRIPTION_XPATH_1 = '//div[h2/text()="Professional Experience"]/p/text()|//h2/following-sibling::p/text()'
        DESCRIPTION_XPATH_1 = '//div[@class="col-sm-5-8"]/div/div/p//text()'
        # DESCRIPTION_XPATH_2 = '//div[contains(comment(), "h2>Profile</h2") and count(p)=1 and not(h2)]/p/text()'
        # DESCRIPTION_XPATH_2 = '//div[@class="designation u-margin-bottom"]/following-sibling::div/div/p/text()'
        DESCRIPTION_XPATH_2 = '//div[@class="col-sm-5-8"]/div/div/div/p//text()'
        NAME_XPATH = '//h1[@itemprop="name"]/text()'
        OFC_XPATH = '//span[@class="agent-info__brokerage"]//text()'
        WEBSITES_XPATH = '//a[text()="Agent\'s Website"]/@href'
        EMAIL_XPATH = '//span[@id="btnContactAgentAlt" and @itemprop="email"]//text()'
        ZIPCODE_XPATH = '//span[@itemprop="postalCode"]/text()'
        IMG_XPATH = '//img[@itemprop="image" and not(contains(@src, "_noimage_"))]/@src'
        AGENT_PHONE_XPATH = '//p[span/text()="Mobile"]/a/text()'
        OFC_PHONE_XPATH = '//p[span/text()="Office"]/a/text()'
        FACEBOOK_XPATH = '//li[starts-with(@class, "facebook")]/a/@href'
        LINKEDIN_XPATH = '//li[starts-with(@class, "linkedin")]/a/@href'
        TWITTER_XPATH = '//li[starts-with(@class, "twitter")]/a/@href'
        OTHER_URLS_XPATH = '//ul[starts-with(@class, "social-list")]/div/li[not(contains(@class, "twitter")) and not(contains(@class, "linkedin")) and not(contains(@class, "facebook"))]/a/@href'

        title = response.xpath(TITLE_XPATH).extract_first('').strip()
        city_state = response.xpath(CITY_STATE_XPATH).extract_first('').strip()
        address = response.xpath(ADDRESS_XPATH).extract_first('').strip()
        languages = response.xpath(LANGUAGES_XPATH).extract_first('').strip()
        description_1 = response.xpath(DESCRIPTION_XPATH_1).extract()
        description_2 = response.xpath(DESCRIPTION_XPATH_2).extract()
        name = response.xpath(NAME_XPATH).extract_first('').strip()
        office_name = response.xpath(OFC_XPATH).extract()
        websites = response.xpath(WEBSITES_XPATH).extract_first('').strip()
        email = response.xpath(EMAIL_XPATH).extract()
        zipcode = response.xpath(ZIPCODE_XPATH).extract_first('').strip()
        image_url = response.xpath(IMG_XPATH).extract_first('').strip()
        agent_phone_numbers = response.xpath(AGENT_PHONE_XPATH).extract()
        office_phone_numbers = response.xpath(OFC_PHONE_XPATH).extract()
        facebook_url = response.xpath(FACEBOOK_XPATH).extract_first('').strip()
        linkedin_url = response.xpath(LINKEDIN_XPATH).extract_first('').strip()
        twitter_url = response.xpath(TWITTER_XPATH).extract_first('').strip()
        other_urls = response.xpath(OTHER_URLS_XPATH).extract()
        city = ''
        state = ''
        if re.findall(r',\s*[A-Z]{2}', city_state):
            state = re.findall(r',\s*([A-Z]{2})', city_state)[0].strip()
            city = re.sub(r',\s*[A-Z]{2}', '', city_state).strip()
        # address = ', '.join([addr.strip() for addr in address])
        description_1 = ' '.join(' '.join(description_1).split())
        description_2 = ' '.join(' '.join(description_2).split())
        description = description_1 if description_1 else description_2
        office_name = ' '.join(' '.join(office_name).split())
        email = ''.join(email).strip()
        first_name = ''
        middle_name = ''
        last_name = ''
        if len(name.split()) >= 3:
            first_name = name.split(' ', 2)[0].strip()
            middle_name = name.split(' ', 2)[1].strip()
            last_name = name.split(' ', 2)[2].strip()
        elif len(name.split()) == 2:
            first_name = name.split()[0].strip()
            last_name = name.split()[1].strip()
        else:
            first_name = name.strip()
        if linkedin_url.count('://') == 2:
            linkedin_url = 'https://' + linkedin_url.rsplit('://', 1)[-1]
        social = {}
        if linkedin_url:
            social.update({"linkedin_url": linkedin_url})
        if facebook_url:
            social.update({"facebook_url": facebook_url})
        if twitter_url:
            social.update({"twitter_url": twitter_url})
        if other_urls:
            social.update({"other_urls": other_urls})
        languages = [lang.strip()
                     for lang in languages.split(',') if languages]
        # social = {
        #     "linkedin_url": linkedin_url,
        #     "facebook_url": facebook_url,
        #     "twitter_url": other_urls,
        #     "other_urls": other_urls
        # }
        if image_url.startswith('//'):
            image_url = 'https:' + image_url

        item = RoyallepageItem(
            address=address,
            agent_phone_numbers=agent_phone_numbers,
            city=city,
            country='Canada',
            description=description,
            email=email,
            first_name=first_name,
            image_url=image_url,
            languages=languages,
            last_name=last_name,
            middle_name=middle_name,
            office_name=office_name,
            office_phone_numbers=office_phone_numbers,
            profile_url=response.url,
            social=social,
            state=state,
            website=websites,
            zipcode=zipcode,
            title=title,
        )
        yield item
