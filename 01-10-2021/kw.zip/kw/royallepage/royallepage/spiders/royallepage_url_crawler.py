import scrapy
import string
from scrapy.http import Request, FormRequest
from royallepage.items import RoyallepageItem
# import StringIO
import gzip
import json
from scrapy.selector import Selector
headers = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
           'accept-encoding': 'gzip, deflate, br',
           'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
           'upgrade-insecure-requests': '1',
           'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36', }


class Remax(scrapy.Spider):
    name = 'royallepage_url_crawler'
    allowed_domains = ['royallepage.ca']
    start_urls = ['https://www.royallepage.ca/']
    headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
        'accept-encoding': 'gzip, deflate, br',
        'accept-language': 'en-US,en;q=0.9',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36'
    }

    def parse(self, response):
        LOCATION_URLS = response.xpath(
            '//p[contains(text(), "Browse agents")]/a/@href').extract()
        for url in LOCATION_URLS:
            yield Request(response.urljoin(url), callback=self.parse_loc, headers=self.headers)

    def parse_loc(self, response):
        OFC_URLS = response.xpath(
            '//h1/following-sibling::div/ul/li/a/@href').extract()
        # https://www.royallepage.ca/en/search/get-list/agent/289/2/
        for url in OFC_URLS:
            url = 'https://www.royallepage.ca/en/search/get-list/agent/' + \
                url.strip('/').split('/')[-1]
            yield Request(url, callback=self.parse_ofc, headers=self.headers)

    def parse_ofc(self, response):
        body = json.loads(response.body_as_unicode().strip(
            ');').strip('(')).get('html', '')
        sel = Selector(text=body)
        PROFILE_URLS = sel.xpath(
            '//div[@class="agent-info"]/a/@href').extract()
        for url in PROFILE_URLS:
            with open('urls_may1.txt', 'a') as f:
                f.write(response.urljoin(url) + '\n')
            # yield Request(response.urljoin(url), callback=self.parse_profile,
            # headers=headers)
        NEXT_PAGE = sel.xpath('//a[span/text()="next"]/@href').extract_first()
        if NEXT_PAGE:
            yield Request(response.urljoin(NEXT_PAGE), callback=self.parse_ofc, headers=self.headers)

    def parse_profile(self, response):
        pass
