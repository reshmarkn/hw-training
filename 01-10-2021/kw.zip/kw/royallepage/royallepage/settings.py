# -*- coding: utf-8 -*-
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
now = datetime.now()
day = int(now.strftime("%d"))
if day > 20:
    db_month = now + relativedelta(months=+1)
else:
    db_month = now
new_format = "%Y_%m"
db_date = db_month.strftime(new_format)
dbname = 'kw_monthly_' + db_date
# Scrapy settings for royallepage project
#
# For simplicity, this file contains only settings considered important or
# commonly used. You can find more settings consulting the documentation:
#
#     https://doc.scrapy.org/en/latest/topics/settings.html
#     https://doc.scrapy.org/en/latest/topics/downloader-middleware.html
#     https://doc.scrapy.org/en/latest/topics/spider-middleware.html

BOT_NAME = 'royallepage'
DUP_KEY = ''

SPIDER_MODULES = ['royallepage.spiders']
NEWSPIDER_MODULE = 'royallepage.spiders'

AUTHOR_EMAIL = 'praviraj@datahut.co'
# Crawl responsibly by identifying yourself (and your website) on the
# user-agent
USER_AGENT = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'

EXTENSIONS = {
    #     'general_validator.GeneralValidator': 100,
    # 'sc_mongo.ScrapyMongoExtension': 400,
}

# Configure MONGODB
# MONGO_URI = 'mongodb://localhost:27017'  # local
MONGO_URI = 'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false'  # shard
MONGO_DB = dbname
MONGO_COLLECTION = 'royallepage_com_data'


# Enable or disable downloader middlewares
# DOWNLOADER_MIDDLEWARES = {
#     'royallepage.middlewares.RandomUserAgentMiddleware': 100,
#     'royallepage.middlewares.ProxyMiddleware': 110,
#     'scrapy.contrib.downloadermiddleware.httpproxy.HttpProxyMiddleware': 130,
#     'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,

# }

# Configure item pipelines
ITEM_PIPELINES = {
    'royallepage.pipelines.RoyallepagePipeline': 300,
}
