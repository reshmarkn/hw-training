import logging
import random
import requests
import json
from coldwellbankerinternational.settings import *

logger = logging.getLogger(__name__)


def parse_proxy():
    # PROXY_LIST = [
    #         # '5.79.73.131:13200',
    #         '157.230.189.5:5566',

    #      # '195.154.161.89:11789',
    #     # '62.210.169.109:5759',


    #     # '62.210.169.109:5760',
    #     # '62.210.169.109:5761',
    #     # '62.210.169.109:5762',
    #     # '62.210.169.109:5763',
    #     # '62.210.169.109:5764',
    #     # '62.210.169.109:5765',
    #     # '62.210.169.109:5766',
    #     # '62.210.169.109:5767',
    #     # '62.210.169.109:5768',
    #     # '62.210.169.109:5769',
    #     # '62.210.169.109:5770',
    #     # '62.210.169.109:5771',
    #     # '62.210.169.109:5772',
    #     # '62.210.169.109:5773',
    #     # '62.210.169.109:5774',
    #     # '62.210.169.109:5775',
    #     # '62.210.169.109:5776',
    #     # '62.210.169.109:5777',
    #     # '62.210.169.109:5778',
    #     # '62.210.169.109:5779',
    #     # '62.210.169.109:5780',
    #     # '62.210.169.109:5781',
    #     # '62.210.169.109:5782',
    #     # '62.210.169.109:5783'
    # ]


# PROXY_LIST = requests.get('http://68.183.58.145/microleaves',
#                           headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
    PROXY = random.choice(PROXY_LIST)
    proxy_url = "http://%s" % PROXY
    proxies = {"http": "http://%s" % PROXY,
               "https": "http://%s" % PROXY}
    logger.debug("Proxy added")
    return {'proxies': proxies, 'proxy_url': proxy_url}
