# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
from scrapy.spiders import Spider
import pika
import json
import logging
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from realtysouth_new.items import *
from realtysouth_new.settings import *
from realtysouth_new.proxy import parse_proxy

headers1 = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}


class Realtysouth_NewUrlSpider(Spider):
    name = 'realtysouth_new_crawler'
    # start_urls = ['']
    allowed_domains = []

    def start_requests(self):
        for var in range(1, 19):
            url = 'https://www.realtysouth.com/AgentSearch/Results.aspx?SearchType=agent&FirstName=&LastName=&OfficeName=&Address=&City=&State=&Country=-32768&Zip=&Languages=&Titles=&Specialties=&Accreditations=&Areas=&rpp=50&page=' + \
                str(var) + '&SortOrder='
            yield Request(url, headers=headers1, callback=self.parse)

    def parse(self, response):
        agent_links = response.xpath(
            '//a[@class="ao_results_icon_text A detail-page"]/@href').extract()
        for link in agent_links:
            # url = link
            item = Realtysouth_url(
                url=link)
            # print(item)
            yield item
