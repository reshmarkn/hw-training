import scrapy
import re
import pika
import json
import logging
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from realtysouth_new.items import *
from realtysouth_new.settings import *
from realtysouth_new.proxy import parse_proxy

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


headers = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
    "Accept-Encoding": "gzip, deflate, br",
    "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8,ml;q=0.7",
    "Connection": "keep-alive",
    "Host": "www.realtysouth.com",
    "Upgrade-Insecure-Requests": "1",
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36"
}


class Realtysouth_NewSpider(Spider):
    name = 'realtysouth_new_parser_updated'

    def start_requests(self):
        urls = ["https://www.realtysouth.com/roster/agents/1",
                "https://www.realtysouth.com/roster/agents/2",
                "https://www.realtysouth.com/roster/agents/3",
                "https://www.realtysouth.com/roster/agents/4",
                "https://www.realtysouth.com/roster/agents/5",
                "https://www.realtysouth.com/roster/agents/6",
                "https://www.realtysouth.com/roster/agents/7",
                "https://www.realtysouth.com/roster/agents/8",
                "https://www.realtysouth.com/roster/agents/9",
                "https://www.realtysouth.com/roster/agents/10",
                "https://www.realtysouth.com/roster/agents/11",
                "https://www.realtysouth.com/roster/agents/12",
                "https://www.realtysouth.com/roster/agents/13",
                "https://www.realtysouth.com/roster/agents/14",
                "https://www.realtysouth.com/roster/agents/15",
                "https://www.realtysouth.com/roster/agents/16",
                "https://www.realtysouth.com/roster/agents/17",
                "https://www.realtysouth.com/roster/agents/18",
                "https://www.realtysouth.com/roster/agents/19",
                "https://www.realtysouth.com/roster/agents/20",
                "https://www.realtysouth.com/roster/agents/21",
                "https://www.realtysouth.com/roster/agents/22",
                "https://www.realtysouth.com/roster/agents/23",
                "https://www.realtysouth.com/roster/agents/24",
                "https://www.realtysouth.com/roster/agents/25",
                "https://www.realtysouth.com/roster/agents/26",
                "https://www.realtysouth.com/roster/agents/27",
                "https://www.realtysouth.com/roster/agents/28",
                "https://www.realtysouth.com/roster/agents/29",
                "https://www.realtysouth.com/roster/agents/30",
                "https://www.realtysouth.com/roster/agents/31",
                "https://www.realtysouth.com/roster/agents/32",
                "https://www.realtysouth.com/roster/agents/33",
                "https://www.realtysouth.com/roster/agents/34",
                "https://www.realtysouth.com/roster/agents/35",
                "https://www.realtysouth.com/roster/agents/36",
                "https://www.realtysouth.com/roster/agents/37",
                "https://www.realtysouth.com/roster/agents/38",
                "https://www.realtysouth.com/roster/agents/39",
                "https://www.realtysouth.com/roster/agents/40",
                "https://www.realtysouth.com/roster/agents/41",
                "https://www.realtysouth.com/roster/agents/42",
                "https://www.realtysouth.com/roster/agents/43",
                "https://www.realtysouth.com/roster/agents/44",
                "https://www.realtysouth.com/roster/agents/45",
                "https://www.realtysouth.com/roster/agents/46",
                "https://www.realtysouth.com/roster/agents/47",
                "https://www.realtysouth.com/roster/agents/48",
                "https://www.realtysouth.com/roster/agents/49",
                "https://www.realtysouth.com/roster/agents/50",
                "https://www.realtysouth.com/roster/agents/51",
                "https://www.realtysouth.com/roster/agents/52",
                "https://www.realtysouth.com/roster/agents/53",
                "https://www.realtysouth.com/roster/agents/54",
                "https://www.realtysouth.com/roster/agents/55",
                "https://www.realtysouth.com/roster/agents/56",
                "https://www.realtysouth.com/roster/agents/57",
                "https://www.realtysouth.com/roster/agents/58",
                "https://www.realtysouth.com/roster/agents/59",
                "https://www.realtysouth.com/roster/agents/60",
                "https://www.realtysouth.com/roster/agents/61",
                "https://www.realtysouth.com/roster/agents/62",
                "https://www.realtysouth.com/roster/agents/63",
                "https://www.realtysouth.com/roster/agents/64",
                "https://www.realtysouth.com/roster/agents/65",
                "https://www.realtysouth.com/roster/agents/66",
                "https://www.realtysouth.com/roster/agents/67",
                "https://www.realtysouth.com/roster/agents/68",
                "https://www.realtysouth.com/roster/agents/69",
                "https://www.realtysouth.com/roster/agents/70",
                "https://www.realtysouth.com/roster/agents/71",
                "https://www.realtysouth.com/roster/agents/72",
                "https://www.realtysouth.com/roster/agents/73",
                "https://www.realtysouth.com/roster/agents/74",
                "https://www.realtysouth.com/roster/agents/75",
                "https://www.realtysouth.com/roster/agents/76",
                "https://www.realtysouth.com/roster/agents/77",
                "https://www.realtysouth.com/roster/agents/78",
                "https://www.realtysouth.com/roster/agents/79",
                "https://www.realtysouth.com/roster/agents/80",
                "https://www.realtysouth.com/roster/agents/81",
                "https://www.realtysouth.com/roster/agents/82",
                "https://www.realtysouth.com/roster/agents/83",
                "https://www.realtysouth.com/roster/agents/84",
                "https://www.realtysouth.com/roster/agents/85",
                "https://www.realtysouth.com/roster/agents/86",
                "https://www.realtysouth.com/roster/agents/87",
                "https://www.realtysouth.com/roster/agents/88",
                "https://www.realtysouth.com/roster/agents/89",
                "https://www.realtysouth.com/roster/agents/90", ]

        for url in urls:

            yield Request(url, headers=headers, callback=self.parse)

    def parse(self, response):

        agent_loop = response.xpath(
            '//section[@class="site-roster-customroster1"]//div[@id="rosterResults"]/article')

        for a in agent_loop:
            agent_link = a.xpath(
                'a[contains(text(),"More about")]/@href').extract_first()
            if agent_link:
                profile_link = "https://www.realtysouth.com"+agent_link
                profile_link = profile_link
            else:
                profile_link = response.url

            name = a.xpath('h1/text()').extract_first('').strip()
            first_name = ''
            middle_name = ''
            last_name = ''
            agent_name = name.split()
            if len(agent_name) == 1:
                first_name = agent_name[0].strip() if agent_name[0] else ''
                middle_name = ''
                last_name = ''
            if len(agent_name) == 2:
                first_name = agent_name[0].strip() if agent_name[0] else ''
                middle_name = ''
                last_name = agent_name[1].strip() if agent_name[1] else ''
            if len(agent_name) == 3:
                first_name = agent_name[0].strip() if agent_name[0] else ''
                middle_name = agent_name[1].strip() if agent_name[1] else ''
                last_name = agent_name[2].strip() if agent_name[2] else ''
            if len(agent_name) >= 4:
                first_name = name
                middle_name = ''
                last_name = ''

            office_name = a.xpath('p/strong/text()').extract_first('').strip()
            address = a.xpath('p//text()').extract()
            address = [v.strip() for v in address if v.strip() != '']
            address_full = [s.strip()
                            for s in address if s.strip() != '\ufeff']
            #print(address, '///////////////////')
            if len(address_full) == 6:
                address_name = address_full[2].strip()
            else:
                #del address_full[4:6]
                address_name = address_full[1].strip()
            city = a.xpath(
                'p//span[@class="js-sort-city"]/text()').extract_first().strip()
            sub = a.xpath(
                'p//span[@class="js-sort-city"]/following-sibling::text()').extract_first().strip()
            state = sub.replace('|', '').strip().split(' ')[0].strip()
            zipcode = sub.replace('|', '').strip().split(' ')[1].strip()
            title = a.xpath(
                'h1/span[@class="account-title"]/text()').extract_first('').strip()
            image_url = a.xpath('img/@src').extract_first('').strip()
            phone_company = a.xpath(
                'ul//i[@class="rni-company"]/ancestor::a[1]/text()').extract_first('').strip()
            phone_company = phone_company.strip()
            agent_office_numbers = [phone_company] if phone_company else []
            phone_profile = a.xpath(
                'ul//i[@class="rni-profile"]/ancestor::a[1]/text()').extract()
            number = [v.strip() for v in phone_profile if v.strip() != '']
            profile_number = number[0].strip() if number else []
            agent_phone_numbers = [profile_number] if profile_number else []
            email = a.xpath(
                'ul//i[@class="rni-mail"]/ancestor::a[1]/@href').extract_first('').strip()
            email = email.strip() if email else ''
            website = a.xpath(
                'ul//i[@class="rni-website"]/ancestor::a[1]/@href').extract_first('').strip()
            website = website.strip() if website else ''
            social_urls = a.xpath(
                'ul/li[@class="rng-agent-profile-contact-social"]/a/@href').extract()
            other_urls = []
            facebook_url = ''
            twitter_url = ''
            linkedin_url = ''
            social = {}
            if social_urls:
                for url_ in social_urls:
                    url_ = url_.strip()
                    if 'http' in url_:
                        if 'facebook.com' in url_.lower():
                            facebook_url = url_
                        elif 'twitter.com' in url_.lower():
                            twitter_url = url_
                        elif 'linkedin.com' in url_.lower():
                            linkedin_url = url_
                        else:
                            other_urls.append(url_)

                social = {
                    'facebook_url': facebook_url,
                    'twitter_url': twitter_url,
                    'linkedin_url': linkedin_url,
                    'other_urls': other_urls if other_urls else [],
                }
            else:
                social = {}

            item = Realtysouth_NewItemUpdated(
                first_name=first_name,
                middle_name=middle_name,
                last_name=last_name,
                office_name=office_name,
                title=title,
                description='',
                languages=[],
                image_url=image_url,
                address=address_name,
                city=city,
                state=state,
                country='United States',
                zipcode=zipcode,
                email=email,
                website=website,
                office_phone_numbers=agent_office_numbers,
                agent_phone_numbers=agent_phone_numbers,
                social=social,
                profile_url=profile_link,
            )
            yield item
