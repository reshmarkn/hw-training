# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from realtysouth_new.items import *
from realtysouth_new.settings import *
from realtysouth_new.proxy import parse_proxy

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

headers1 = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}


headers2 = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.119 Safari/537.36'}


class Realtysouth_NewSpider(Spider):
    name = 'realtysouth_new_parser'
    # start_urls = ['']
    # allowed_domains = ['realtysouth.com']
 # ==========================================================

    def start_requests(self):
        for var in range(1, 19):
            url = 'https://www.realtysouth.com/AgentSearch/Results.aspx?SearchType=agent&FirstName=&LastName=&OfficeName=&Address=&City=&State=&Country=-32768&Zip=&Languages=&Titles=&Specialties=&Accreditations=&Areas=&rpp=50&page=' + \
                str(var) + '&SortOrder='
            yield Request(url, headers=headers1, callback=self.parse)

    def parse(self, response):

        agent_links = response.xpath(
            '//a[@class="ao_results_icon_text A detail-page"]/@href').extract()
        for link in agent_links:
            url = response.urljoin(link)
            yield Request(url, headers=headers2, callback=self.parse_profile)
    # == == == == == == == == == == == == == == == == == == == == == == == == == == == == == == == == == == == == == == == == =

    # def start_requests(self):
    #     f = open('miss.txt')
    #     URLS = f.readlines()
    #     for url in URLS:
    #         yield Request(url=url, callback=self.parse_profile)

    def parse_profile(self, response):
        NAME_XPATH = '//p[@class="agent-name"]/text()|//span[@id="lblAgentName"]/text()'
        OFFICE_NAME_XPATH = '//p[@class="agent- office-name"]/text()|//a[@id="hlPrimaryOfficeName"]/text()'
        ADDRESS_XPATH = '//p[@class="agent-address"]/text()|//div[@class="ai_primary_office_address"]/text()'
        LOCATION_XPATH = '//div[@class="container"]/div/div/div/div[@id="agentContact"]/p[@class="agent-address"]/text()|//div[@class="container"]/div/div/div[@id="agentContact"]/p[@class="agent-address"]/text()|//div[@class="row"]/div/div/div/div[@id="agentContact"]/p[@class="agent-address"]/text()|//div[@class="ai_primary_office_address"]/text()|//div[@class="row"]/div/div/div[@id="agentContact"]/p[@class="agent-address"]/text()'
        AGENT_PHONE_XPATH = '//p[@class="agent-office-phone"]/text()'
        IMAGE_XPATH = '//img[@id="agentPhotoImg"]/@src|//a[@id="hlAgentPhoto"]/img/@src'
        DESCRIPTION_XPATH = '//p[@class="professional-profile"]/text()|//div[@class="welcome-message show-grid"]/p/text()|//div[@class="professional-profile"]/p/text()'
        # TITLE_XPATH = '//span[@class="AgentDesignationViewport"]/text()'

        name = response.xpath(NAME_XPATH).extract_first('').strip()
        office_name = response.xpath(
            OFFICE_NAME_XPATH).extract_first('').strip()
        address = response.xpath(ADDRESS_XPATH).extract_first('').strip()
        location = response.xpath(LOCATION_XPATH).extract()
        agent_phone = response.xpath(
            AGENT_PHONE_XPATH).extract_first('').strip()
        image_url = response.xpath(IMAGE_XPATH).extract_first('').strip()
        description = response.xpath(DESCRIPTION_XPATH).extract()

        # title = response.xpath(TITLE_XPATH).extract()
        first_name = ''
        middle_name = ''
        last_name = ''
        agent_name = name.split()
        if len(agent_name) == 1:
            first_name = agent_name[0].strip() if agent_name[0] else ''
            middle_name = ''
            last_name = ''
        if len(agent_name) == 2:
            first_name = agent_name[0].strip() if agent_name[0] else ''
            middle_name = ''
            last_name = agent_name[1].strip() if agent_name[1] else ''
        if len(agent_name) == 3:
            first_name = agent_name[0].strip() if agent_name[0] else ''
            middle_name = agent_name[1].strip() if agent_name[1] else ''
            last_name = agent_name[2].strip() if agent_name[2] else ''
        if len(agent_name) >= 4:
            first_name = name
            middle_name = ''
            last_name = ''
        try:
            office_name = office_name.replace('Office: ', '')
            location = ' '.join(''.join(location).split()
                                ).replace(address, '').strip()
            location = location.split(',')
            city = location[0].strip()
            postal = location[1].strip()
            if postal:
                state = postal.split(' ')[0].strip()
                zipcode = postal.split(' ')[1].strip()
        except:
            office_name = ''
            location = ''
            city = ''
            state = ''
            zipcode = ''

        agent_phone_numbers = [agent_phone] if agent_phone else []
        office_phone_numbers = []
        description = ' '.join(''.join(description).split())

        social_urls = response.xpath(
            '//div[@class="container"]/div/div/div/div[@id="agentContact"]/ul[@class="list-unstyled agent-social-media"]//li/a/@href|//div[@class="container"]/div/div/div[@id="agentContact"]/ul[@class="list-unstyled agent-social-media"]//li/a/@href|//div[@class="row"]/div/div/div/div[@id="agentContact"]/ul[@class="list-unstyled agent-social-media"]//li/a/@href|//div[@class="row"]/div/div/div[@id="agentContact"]/ul[@class="list-unstyled agent-social-media"]//li/a/@href').extract()
        other_urls = []
        facebook_url = ''
        twitter_url = ''
        linkedin_url = ''
        social = {}
        if social_urls:
            for url_ in social_urls:
                url_ = url_.strip()
                if 'http' in url_:
                    if 'facebook.com' in url_.lower():
                        facebook_url = url_
                    elif 'twitter.com' in url_.lower():
                        twitter_url = url_
                    elif 'linkedin.com' in url_.lower():
                        linkedin_url = url_
                    else:
                        other_urls.append(url_)

            social = {
                'facebook_url': facebook_url,
                'twitter_url': twitter_url,
                'linkedin_url': linkedin_url,
                'other_urls': other_urls if other_urls else [],
            }
        else:
            social = {}

        # yield item
        item = Realtysouth_NewItem(
            first_name=first_name,
            middle_name=middle_name,
            last_name=last_name,
            office_name=office_name,
            title='',
            description=description,
            languages=[],
            image_url=image_url,
            address=address,
            city=city,
            state=state,
            country='United States',
            zipcode=zipcode,
            email='',
            website='',
            office_phone_numbers=office_phone_numbers,
            agent_phone_numbers=agent_phone_numbers,
            social=social,
            profile_url=response.url,
        )
        yield item
