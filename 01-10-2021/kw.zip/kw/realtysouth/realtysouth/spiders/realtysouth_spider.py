# -*- coding: utf-8 -*-
import scrapy
from realtysouth.items import RealtysouthItem
from realtysouth.settings import *

class RealtysouthSpider(scrapy.Spider):
	name = 'realtysouth_spider'
	#allowed_domains = ['realtysouth.com']
	temp = []
	for x in range(1,18):
		next_page = 'http://www.realtysouth.com/AgentSearch/Results.aspx?page=' + str(x)
		temp.append(next_page)
	start_urls = temp

	def parse(self, response):
		links = response.xpath('//div[@class="ao-info-container"]')
		for link in links:
			# profile_url = link.xpath('div[@class="ao-info-r1 rui-inner-row"]/div[@class="ao-info-c1"]/h3/a/@href').extract_first()
			profile_url = 'https://nikimiller.realtysouth.com/'
			address = link.xpath('div[@class="ao-info-r1 rui-inner-row"]/div[@class="ao-info-c1"]/div[@class="ao-address"]//text()').extract()
			office_site = link.xpath('div[@class="ao-info-r1 rui-inner-row"]/div[@class="ao-info-c2"]/div[@class="ao-office"]/a/@href').extract_first()
			website = link.xpath('div[@class="ao-info-r3 rui-inner-row"]/span[@class="view-website-container"]/a/@href').extract_first()
			websites = []
			if office_site :
				websites.append(office_site)
			if website:
				websites.append(website)

			meta = {'websites':websites,
					#'profile_url' : profile_url,
					'address' : address,
					}
			yield scrapy.Request(url=profile_url,callback=self.parse_info,meta = meta)

	def parse_info(self, response):
		meta = response.meta

		languages = []
		fax = []
		emails = []
		title = ''
		image_url = response.xpath('//div[@id="agent-photo"]/span/img/@src').extract_first()
		name = response.xpath('//div[@id="agent-contact"]/b/text()').extract_first()
		company_name = response.xpath('//div[@id="agent-contact"]/span[1]/text()').extract_first()
		phone_numbers_ = response.xpath('//div[@id="agent-contact"]/span[2]/text()').extract_first()
		description = response.xpath('//td[@id="agent-content"]/table//p/text()|//table[@width="100%"]//p/text()').extract()
		facebook_url = response.xpath('//a[@class="soc-ic-facebook"]/@href').extract_first('')
		twitter_url = response.xpath('//a[@class="soc-ic-twitter"]/@href').extract_first('')
		linkedin_url = response.xpath('//a[@class="soc-ic-linkedin"]/@href').extract_first('')
		youtube_url = response.xpath('//a[@class="soc-ic-youtube"]/@href').extract_first('')
		pinterest_url = response.xpath('//a[@class="soc-ic-pinterest"]/@href').extract_first('')
		other_urls = []
		if youtube_url:
			other_urls.append(youtube_url)
		if pinterest_url:
			other_urls.append(pinterest_url)

		other_urls = other_urls if other_urls else []

		websites = meta.get('websites')
		profile_url = response.url
		address = meta.get('address')
		address = [x.strip() for x in address]
		address = ''.join(address)
		phone_numbers = []
		if phone_numbers_:
			phone_numbers.append(phone_numbers_)
			
		company_name = ''.join(company_name).strip() if company_name else ''
		description = ''.join(description).strip() if description else ''
		
		social = {'facebook_url' : facebook_url,
					'twitter_url' : twitter_url,
					'linkedin_url' : linkedin_url,
					'other_urls' : other_urls}

		item = RealtysouthItem(
			languages=languages,
			fax=fax,
			emails=emails,
			title=title,
			image_url=image_url,
			name=name,
			company_name=company_name,
			phone_numbers=phone_numbers,
			description=description,
			websites=websites,
			address=address,
			social=social,
			profile_url=profile_url
			)
		yield item