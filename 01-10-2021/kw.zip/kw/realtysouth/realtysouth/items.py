# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class RealtysouthItem(scrapy.Item):
	
	languages = scrapy.Field()
	fax = scrapy.Field()
	emails = scrapy.Field()
	title = scrapy.Field()
	image_url = scrapy.Field()
	name = scrapy.Field()
	company_name = scrapy.Field()
	phone_numbers = scrapy.Field()
	description = scrapy.Field()
	websites = scrapy.Field()
	address = scrapy.Field()
	social = scrapy.Field()
	profile_url = scrapy.Field()