# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
import requests
# from date.util import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from glorianilson.items import *
from glorianilson.settings import *
from glorianilson.proxy import parse_proxy

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.119 Safari/537.36'}


header = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.119 Safari/537.36'}


class GlorianilsonSpider(Spider):
    name = 'glorianilson_parser'
    start_urls = ['https://www.glorianilson.com/real-estate-agents/']
    allowed_domains = []

    def parse(self, response):
        alphabet_links = response.xpath(
            '//a[@class="link-agent-alphabet"]/@href').extract()
        for link in alphabet_links:
            alphabet_url = response.urljoin(link)
            yield Request(url=alphabet_url.strip(), callback=self.parse_urls, headers=headers)

    def parse_urls(self, response):

        agent_details = response.xpath('//table[@id="agent-dir"]/tbody//tr')
        for data in agent_details:
            office = []
            agent_link = data.xpath(
                'td/p/a[contains(text(), "Visit Web Site")]/@href').extract_first('')
            name = data.xpath(
                'td/strong[@class="agentname"]/text()|td/a/strong[@class="agentname"]/text()').extract_first('').strip()
            title = data.xpath(
                'td/strong[@class="agentname"]/following-sibling::text()|td[@id="list_name"]/a/following-sibling::text()').extract_first('').strip()
            office_names = data.xpath(
                'td/strong[@class="agentname"]/following-sibling::a/text()|td[@id="list_name"]/a/following-sibling::a/text()').extract()
            # office_name = data.xpath(
            # 'td/strong[@class="agentname"]/following-sibling::a/text()|td[@id="list_name"]/a/following-sibling::a/text()').extract_first('').strip()
            for i in office_names:
                if 'office' in i.lower():
                    office.append(i)

            office_url = data.xpath(
                'td/strong[@class="agentname"]/following-sibling::a/@href|td[@id="list_name"]/a/following-sibling::a/@href').extract_first('').strip()
            email = data.xpath(
                'td/a[@class="link-agent-mailto"]/text()').extract_first('').strip()
            phone_numbers = data.xpath(
                'td/a[@class="link-agent-mailto"]/following-sibling::text()').extract()

            if len(office_names) == 1:
                office_name = ''.join(office_names)

            try:
                office_name = office[0]
            except:
                office_name = ''

            agent = name.split(',')
            name = agent[1].strip() + ' ' + agent[0].strip()
            agent_name = name.replace('-', ' ').split()
            first_name = ''
            middle_name = ''
            last_name = ''
            if '&' in agent_name:
                first_name = name
            else:
                if len(agent_name) == 1:
                    first_name = agent_name[0]
                    middle_name = ''
                    last_name = ''
                if len(agent_name) == 2:
                    first_name = agent_name[0]
                    middle_name = ''
                    last_name = agent_name[1]
                if len(agent_name) == 3:
                    first_name = agent_name[0]
                    middle_name = agent_name[1]
                    last_name = agent_name[2]
                if len(agent_name) >= 4:
                    first_name = name
                    middle_name = ''
                    last_name = ''

            agent_phone = ''
            office_phone = ''
            agent_phone_numbers = []
            office_phone_numbers = []
            for number in phone_numbers:
                phone = number.strip()
                if '(Office)' in phone:
                    office_phone = phone.replace('(Office)', '')
                    office_phone_numbers = [office_phone.strip()]
                elif '(Cell)' in phone:
                    agent_phone = phone.replace('(Cell)', '')
                    agent_phone_numbers = [agent_phone.strip()]
                else:
                    pass

            address = ''
            city = ''
            state = ''
            zipcode = ''
            if office_url:
                res = requests.get(url=office_url, headers=header)
                sel = Selector(text=res.content)
                address = sel.xpath(
                    '//span[@itemprop="streetAddress"]/text()').extract_first('').strip()
                city = sel.xpath(
                    '//span[@itemprop="addressLocality"]/text()').extract_first('').strip()
                state = sel.xpath(
                    '//span[@itemprop="addressRegion"]/text()').extract_first('').strip()
                zipcode = sel.xpath(
                    '//span[@itemprop="postalCode"]/text()').extract_first('').strip()

            if agent_link:
                meta = {
                    'title': title,
                    'office_name': office_name,
                    'email': email,
                    'agent_phone_numbers': agent_phone_numbers,
                    'office_phone_numbers': office_phone_numbers,
                    'address': address,
                    'city': city,
                    'state': state,
                    'zipcode': zipcode,
                }
                yield Request(url=agent_link, headers=headers, callback=self.parse_profile, meta=meta)
            else:
                if first_name:
                    item = GlorianilsonItem(
                        title=title,
                        office_name=office_name,
                        address=address,
                        city=city,
                        state=state,
                        zipcode=zipcode,
                        profile_url='',
                        languages=[],
                        description='',
                        first_name=first_name,
                        middle_name=middle_name,
                        last_name=last_name,
                        website='',
                        email=email,
                        image_url='',
                        agent_phone_numbers=agent_phone_numbers,
                        office_phone_numbers=office_phone_numbers,
                        social={},
                        country='United States',
                    )
                    yield item

    def parse_profile(self, response):
        title = response.meta['title']
        office_name = response.meta['office_name']
        email = response.meta['email']
        agent_phone_numbers = response.meta['agent_phone_numbers']
        office_phone_numbers = response.meta['office_phone_numbers']
        address = response.meta['address']
        city = response.meta['city']
        state = response.meta['state']
        zipcode = response.meta['zipcode']

        name = response.xpath('//h1/text()').extract_first('').strip()
        agent_name = name.replace('-', ' ').split()
        first_name = ''
        middle_name = ''
        last_name = ''
        if '&' in agent_name:
            first_name = name
        else:
            if len(agent_name) == 1:
                first_name = agent_name[0]
                middle_name = ''
                last_name = ''
            if len(agent_name) == 2:
                first_name = agent_name[0]
                middle_name = ''
                last_name = agent_name[1]
            if len(agent_name) == 3:
                first_name = agent_name[0]
                middle_name = agent_name[1]
                last_name = agent_name[2]
            if len(agent_name) >= 4:
                first_name = name
                middle_name = ''
                last_name = ''

        image_url = ''
        image_urls = response.xpath(
            '//img[@class="img-responsive"]/@src').extract()
        for url in image_urls:
            if 'idxzoom.com/People' in url:
                image_url = url.strip()

        description = response.xpath(
            '//div[@id="tabs-1"]//text()|//h3/following-sibling::p//text()').extract()
        description = ' '.join(''.join(description).split())
        social = {}
        if first_name:
            item = GlorianilsonItem(
                title=title,
                office_name=office_name,
                address=address,
                city=city,
                state=state,
                zipcode=zipcode,
                profile_url=response.url,
                languages=[],
                description=description,
                first_name=first_name,
                middle_name=middle_name,
                last_name=last_name,
                website='',
                email=email,
                image_url=image_url,
                agent_phone_numbers=agent_phone_numbers,
                office_phone_numbers=office_phone_numbers,
                social={},
                country='United States',
            )
            yield item
