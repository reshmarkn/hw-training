# -*- coding: utf-8 -*-
import re
import pika
import json
import scrapy
import logging

from kentwood.items import *
from kentwood.settings import *
from datetime import datetime
from pymongo import MongoClient
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from kentwood.proxy import parse_proxy


handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

headers = {
    'Accept': 'image/webp,image/apng,image/*,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}


class kentwoodSpider(Spider):
    name = 'kentwood_parser'
    # db = MongoClient('mongodb://localhost:27017')[dbname]
    db = MongoClient(
        'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')[MONGO_DB]

    def start_requests(self):
        for item in self.db[MONGO_COLLECTION_URL].find(no_cursor_timeout=True):
            url = item.get('url')
            link = url.strip()
            yield Request(url=link, callback=self.parse, headers=headers, meta=item)

    def parse(self, response):
        if response.status == 200:
            # Grab XPATH
            office_name = response.meta.get('office_name', '')
            NAME_XPATH = '//p[@class="rng-agent-profile-contact-name"]/text()'
            TITLE_XPATH = '//span[@class="rng-agent-profile-contact-title"]/text()'
            ADDRESS_XPATH = '//li[@class="rng-agent-profile-contact-address"]/strong/text()'
            LOCATION_XPATH = '//li[@class="rng-agent-profile-contact-address"]//text()'
            IMAGE_XPATH = '//img[@class="rng-agent-profile-photo"]/@src'
            DESCRIPTION_XPATH = '//div[@id="body-text-1-preview-5500"]//text() | //div[@id="widget-text-1-preview-5503"]//text() | //h1[@id]//text()'
            SOCIAL_XPATH = '//li[@class="rng-agent-profile-contact-social"]/ul[@class="rng-agent-profile-contact"]/li/a/@href'
            OFFICE_PHONE_XPATH = '//li[@class="rng-agent-profile-contact-phone"]/a/i[@class="rni-company"]/following-sibling::text()'
            AGENT_PHONE_XPATH = '//li[@class="rng-agent-profile-contact-phone"]/a/i[@class="rni-profile"]/following-sibling::text()'
            WEBSITE_XPATH = '//li[@class="rng-agent-profile-contact-website"]/a[contains(text(), "My Website")]/@href'

            # response.xpath('//li[@class="rng-agent-profile-contact-phone"]/a/text()').extract()  
            
            # Extract values using above XPATHs
            name = response.xpath(NAME_XPATH).extract_first('').strip()
            title = response.xpath(TITLE_XPATH).extract_first('').strip()
            agent_phone = response.xpath(AGENT_PHONE_XPATH).extract()
            office_phone = response.xpath(OFFICE_PHONE_XPATH).extract()
            website = response.xpath(WEBSITE_XPATH).extract_first('').strip()
            image_url = response.xpath(IMAGE_XPATH).extract_first('').strip()
            location = response.xpath(LOCATION_XPATH).extract()
            description = response.xpath(DESCRIPTION_XPATH).extract()
            address = response.xpath(ADDRESS_XPATH).extract()
            social = response.xpath(SOCIAL_XPATH).extract()

            # Clea Data
            first_name = ''
            middle_name = ''
            last_name = ''
            city = ''
            state = ''
            zipcode = ''

            agent_name = name.replace('-', '').split()
            if '&' in agent_name:
                first_name = name
            else:
                if len(agent_name) == 1:
                    first_name = agent_name[0].strip()
                    middle_name = ''
                    last_name = ''
                if len(agent_name) == 2:
                    first_name = agent_name[0].strip()
                    middle_name = ''
                    last_name = agent_name[1].strip()
                if len(agent_name) == 3:
                    first_name = agent_name[0].strip()
                    middle_name = agent_name[1].strip()
                    last_name = agent_name[2].strip()
                if len(agent_name) >= 4:
                    first_name = name
                    middle_name = ''
                    last_name = ''

            agent_phone_numbers = []
            office_phone_numbers = []
            if agent_phone:
                for number in agent_phone:
                    number = number.strip()
                    agent_phone_numbers.append(number)
            if office_phone:
                for num in office_phone:
                    num = num.strip()
                    office_phone_numbers.append(num)

            languages = []
            languages = response.xpath('//p[@class="rng-agent-profile-languages"]/text()').extract()
            description = ' '.join(''.join(description).split())
            address = address[0].strip() if address else ''
            location = ''.join(location).strip()
            if location:
                try:
                    city = re.findall('(.*)[A-Z]{2}.\d{5}',
                                      location)[0].split() if location else ''
                except:
                    city = re.findall('(.*)[A-Z]{2}.\d{4}',
                                      location)[0].split() if location else ''

                city = ' '.join(city) if city else ''

                city = city.strip() if city else ''
                if ',' in city:
                    city = city.replace(',', '')
                state = re.findall(
                    '([A-Z]{2}).\d{5}', location)if location else ''
                state = state[0].strip() if state else ''
                zipcode = re.findall(
                    '[A-Z]{2}(.\d{5})', location)if location else ''
                zipcode = zipcode[0].strip() if zipcode else ''
                if not state:
                    state = re.findall(
                        '([A-Z]{2}).\d{4}', location)if location else ''
                    state = state[0].strip() if state else ''
                if not zipcode:
                    zipcode = re.findall(
                        '[A-Z]{2}(.\d{4})', location)if location else ''
                    zipcode = zipcode[0].strip() if zipcode else ''
            social_urls = {}
            other_urls = []
            for link in social:
                if 'facebook' in link:
                    facebook_url = link
                    social_urls.update({'facebook_url': facebook_url})
                elif 'twitter' in link:
                    twitter_url = link
                    social_urls.update({'twitter_url': twitter_url})
                elif 'linkedin' in link:
                    linkedin_url = link
                    social_urls.update({'linkedin_url': linkedin_url})
                else:
                    other_urls.append(link)
                    social_urls.update({'other_urls': other_urls})

            profile_url = response.request.url

            # yield item
            if first_name:
                item = KentwoodItem()
                item['title'] = title
                item['office_name'] = office_name
                item['address'] = address
                item['city'] = city
                item['state'] = state
                item['zipcode'] = zipcode
                item['profile_url'] = profile_url
                item['languages'] = languages
                item['description'] = description
                item['first_name'] = first_name
                item['middle_name'] = middle_name
                item['last_name'] = last_name
                item['website'] = website
                item['email'] = ''
                item['image_url'] = image_url
                item['agent_phone_numbers'] = agent_phone_numbers
                item['office_phone_numbers'] = office_phone_numbers
                item['social'] = social_urls
                item['country'] = 'United States'

                yield item


# {"office_phone_numbers":[],"state":"CO","first_name":"Ed","city":"Denver","email":"","title":"Broker Associate","website":"https://emcwilliams.kentwood.com","country":"United States","address":"4949 South Niagara St 400","middle_name":"","profile_url":"https://www.kentwood.com/bio/emcwilliams","description":"Ed started his career in real estate after graduating from the Denver public school system and the University of Colorado. A natural in meeting and interacting with people, Ed was attracted to real estate for the independence it offered and the ability to work with many different kinds of people helping them realize their dreams. He joined Kentwood and has continued to grow and serve Colorado families as the company has grown over the last 40 years.Ed and his wife Marilyn, an attorney with local firm Moye White, bought their first house in Montclair in 1978 and have been there ever since.When he’s not selling homes, you can find Ed sipping a local brew at My Brother's Bar, walking Denver’s city trails, or hiding out in the mountains hiking and fishing with his family. He feels fortunate to have climbed half of Colorado’s 14ers, skied to many huts in the 10th mountain system, and trekked on five continents.Ed is most grateful for his incredible family and good health. He and Marilyn have been married almost 50 years and boast three beautiful daughters and five wonderful grandchildren.","languages":[],"agent_phone_numbers":["(303) 902-1558"],"zipcode":"80237","office_name":"Kentwood DTC","image_url":"https://content.mediastg.net/dynamic/RealEstate/company/624/account/539905/539905_08222021161815.jpg","last_name":"McWilliams","social":{}}