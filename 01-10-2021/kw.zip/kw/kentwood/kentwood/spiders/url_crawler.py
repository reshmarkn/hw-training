# -*- coding: utf-8 -*-
import io
import gzip
import scrapy

from io import StringIO
from kentwood.items import *
from xml.dom import minidom
from kentwood.settings import *
from scrapy.spiders import Spider
from scrapy.selector import Selector
from kentwood.proxy import parse_proxy
from scrapy.http import Request, FormRequest
# from databasenotifier import automation_script
h = {"Accept":"*/*",  
"Accept-Encoding":"gzip, deflate",  
"Accept-Language":"en-GB,en-US;q=0.9,en;q=0.8",  
"Host":"www.kentwood.com",  
"Referer":"https://www.kentwood.com/roster/agents",  
"Sec-Fetch-Mode":"cors",  
"Sec-Fetch-Site":"same-origin",  
"User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36",  
"X-Requested-With":"XMLHttpRequest"}  

class kentwoodSpider(Spider):
    name = 'kentwood_crawler'
    def start_requests(self):
        for var in range(1, 21):
            # url = 'https://www.reecenichols.com/CMS/CmsRoster/RosterSection?layoutID=944&pageSize=10&pageNumber='+str(var)+'&sortBy=firstname-asc'
            # response = req.get(url=url,headers=headers,proxies=proxies)
            # sleep(5)
            # self.parse(response,url)
            url = 'https://www.kentwood.com/CMS/CmsRoster/RosterSection?layoutID=956&pageSize=10&pageNumber='+str(var)+'&sortBy=firstname'
            yield Request(url=url, callback=self.parse, headers=h)

    def parse(self, response):
        LINK_XPATH = 'a[@class="button hollow"]/@href'
        AGENT_LIST = '//article[@class="rng-agent-roster-agent-card js-sort-item"]'
        OFFICE_NAME_XPATH = 'hr/following-sibling::p/strong/text()'

        agent_list = response.xpath(AGENT_LIST)
        for agent in agent_list:
            link = agent.xpath(LINK_XPATH).extract_first('')
            office_name = agent.xpath(OFFICE_NAME_XPATH).extract_first('')
            p_url = response.urljoin(link)
            item = KentwoodUrlItem()
            item['url'] = p_url
            item['office_name'] = office_name
            yield item
        # automation_script.Automation_Spider(MONGO_DB, MONGO_COLLECTION_URL)
