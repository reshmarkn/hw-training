# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from harrynorman.items import *
from harrynorman.settings import *
from harrynorman.proxy import parse_proxy
from scrapy.shell import inspect_response


handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

headers = {

    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
}


class HarrynormanSpider(Spider):
    name = 'harrynorman'
    start_urls = ['https://www.harrynorman.com/agents']
    # start_urls = ['https://www.harrynorman.com/agents/46262-Lauren-Sinclair',
    # 'https://www.harrynorman.com/agents/20109-The-Barocas-Feldman-Team']
    allowed_domains = []

    def parse(self, response):
        agents = response.xpath('//a[@class="agent-link"]/@href').extract()
        for agent in agents:
            agent = response.urljoin(agent)
            yield Request(url=agent, headers=headers, callback=self.parse_data)

        next_page = response.xpath(
            '//li[@class="page-item next"]/a/@href').extract()
        if next_page:
            url = ''.join(next_page).strip()
            url = response.urljoin(url)
            # url = ''.join(next_page).strip()
            yield Request(url=url, headers=headers, callback=self.parse)

    def parse_data(self, response):
        # inspect_response(response, self)

        middle_name = ''
        state = ''
        other_urls = []
        facebook_url = ''
        twitter_url = ''
        linkedin_url = ''
        social = {}
        first_name = ''
        address = ''
        zipcode = ''
        city = ''

        name = response.xpath(
            '//h1[@class="body-title"]/text()').extract_first()
        name_split = name.split(' ')
        if len(name_split) == 2:
            first_name = name_split[0]
            last_name = name_split[1]
        else:
            if len(name_split) == 1:
                first_name = name_split[0].strip()
                middle_name = ''
                last_name = ''
            # if len(agent_name) == 2:
            #     first_name = agent_name[0].strip()
            #     middle_name = ''
            #     last_name = agent_name[1].strip()
            if len(name_split) == 3:
                first_name = name_split[0].strip()
                middle_name = name_split[1].strip()
                last_name = name_split[2].strip()
            if len(name_split) >= 4:
                first_name = name
                middle_name = ''
                last_name = ''
        office_name = response.xpath(
            '//span[@class="agent-office-name"]/text()').extract()
        office_name = ''.join(office_name).strip()

        title = response.xpath(
            '//div[@class="col-sm-10 text-center agent-information"]'
            '/div[1]/h3/text()').extract()
        title = ''.join(title).strip()

        agent_phone_numbers = response.xpath(
            '//span[contains(text(), "PHONE:")]/following-sibling'
            '::a/text()').extract()
        office_phone_numbers = response.xpath(
            '//span[contains(text(), "OFFICE:")]/following-sibling'
            '::a/text()').extract()

        email = response.xpath('//a[@class="agent_email"]/text()').extract()
        email = ''.join(email).strip()

        website = response.xpath(
            '//a[contains(text(), "MY WEBSITE")]/@href').extract()
        website = ''.join(website).strip()

        image = response.xpath('//img[@class="agent-photo"]/@src').extract()
        image_url = ''.join(image).strip()
        if '.png' in image_url:
            image_url = ''
        addrress_full = response.xpath(
            '//div[@class="agent-summary col-sm-8"]/text()').extract()
        try:
            address_ = []
            for line in addrress_full:
                line = line.strip()
                address_.append(line)

            address_1 = []
            for add in address_:
                if add != '':
                    address_1.append(add)

            address = address_1[0]
            if len(address_1) == 2:
                city_state_zip = address_1[1]
                city = city_state_zip.split(',', 1)[0]
                state_zip = city_state_zip.split(',', 1)[1]
                state_zip = ''.join(state_zip).strip()
                state_zip_ = state_zip.split(' ')
                state = state_zip_[0]
                zipcode = state_zip_[1]
            elif len(address_1) == 3:
                city_state_zip = address_1[2]
                city = city_state_zip.split(',', 1)[0]
                state_zip = city_state_zip.split(',', 1)[1]
                state_zip = ''.join(state_zip).strip()
                state_zip_ = state_zip.split(' ')
                state = state_zip_[0]
                zipcode = state_zip_[1]
        except:
            pass

        description = response.xpath(
            '//p[@class="MsoNormal"]//text()').extract()
        description = ''.join(description).strip()

        languages = response.xpath(
            '//div[@class="language-list col-sm-6"]/ul//text()').extract()

        social_ = response.xpath('//div[@class="social"]/a/@href').extract()
        if social_:
            for url in social_:
                if url != 'https://www.facebook.com/HarryNormanRealtors/':
                    if 'linkedin' in url:
                        linkedin_url = url
                    elif 'facebook' in url:
                        facebook_url = url
                    elif 'twitter' in url:
                        twitter_url = url
                    else:
                        other_urls.append(url)
            social = {
                'facebook_url': facebook_url,
                'twitter_url': twitter_url,
                'linkedin_url': linkedin_url,
                'other_urls': other_urls if other_urls else [],
            }
        else:
            social = {}

        # yield item
        if first_name:
            item = HarrynormanItem(
                first_name=first_name,
                middle_name=middle_name,
                last_name=last_name,
                office_name=office_name,
                title=title,
                description=description,
                languages=languages,
                image_url=image_url,
                agent_phone_numbers=agent_phone_numbers,
                office_phone_numbers=office_phone_numbers,
                email=email,
                website=website,
                address=address,
                city=city,
                state=state,
                zipcode=zipcode,
                country='United States',
                social=social,
                profile_url=response.url,
            )
            yield item

    """
    # Errorback to put failed urls back in queue
    def errback_httpbin(self, failure, url):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=600))
        channel = connection.channel()
        channel.queue_declare(queue=QUEUE_NAME, durable=True)
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=url)
        connection.close()
    """
