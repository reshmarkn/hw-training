# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
import requests
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from huff_realty.items import *
from huff_realty.settings import *
from huff_realty.proxy import parse_proxy

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

headers = {}


class Huff_RealtySpider(Spider):
    name = 'huff_realty1'
    start_urls = [
        'https://www.huff.com/index.asp?p=agentResults.asp&search=%%']
    # allowed_domains = []

    # def start_requests(self):
    #     url = 'https://www.huff.com/index.asp?p=agentResults.asp&search=%%'
    #     yield Request(url=url, callback=self.parse_profile, headers=headers)

    def parse(self, response):
        # print('1111111111111111111', response)
        zipcode = ''
        city = ''
        state = ''
        city_state_zip_ = ''
        address = ''
        state_zip_ = ''
        agents_sel = response.xpath(
            '//div[@class="rn-agent-roster"]/article[@class="rn-agent-card"]')

        for sel in agents_sel:

            profile_url = sel.xpath(
                'div//div[@class="rn-agent-icon-website"]/a/@href').extract()
            profile_url = profile_url[0].strip() if profile_url else ''
            name = sel.xpath(
                'div/div[@class="rn-agent-contact"]/span[@class="rn-agent-name"]/text()').extract_first('').strip()
            title = sel.xpath(
                'div[@class="rn-agent-info"]//div[@class="rn-agent-title"]/span/text()').extract_first('').strip()
            agent_phone = sel.xpath(
                'div/div/div/span[contains(text(), "Main")]/following-sibling::span/text()').extract()
            office_phone = sel.xpath(
                'div/div/div/span[contains(text(), "Office")]/following-sibling::span/text()').extract()
            office_name = sel.xpath(
                'div/div/div/div/span[@class="rn-agent-contact-office-name"]/text()').extract_first('').strip()
            image_url = sel.xpath(
                'div[@class="rn-agent-info"]//div[@class="rn-agent-photo-languages"]/img/@src').extract_first('').strip()
            address = sel.xpath(
                'div[@class="rn-agent-info"]//span[@class="rn-agent-contact-office-address-street"]/text()').extract_first('').strip()
            city_state_zip_ = sel.xpath(
                'div[@class="rn-agent-info"]//span[@class="rn-agent-contact-office-city-state-zip"]/text()').extract_first()
            first_name = ''
            middle_name = ''
            last_name = ''
            if name:
                agent_name = name.split()
                if '&' in agent_name:
                    first_name = name
                else:
                    if len(agent_name) == 1:
                        first_name = agent_name[0].strip()
                        middle_name = ''
                        last_name = ''
                    if len(agent_name) == 2:
                        first_name = agent_name[0].strip()
                        middle_name = ''
                        last_name = agent_name[1].strip()
                    if len(agent_name) == 3:
                        first_name = agent_name[0].strip()
                        middle_name = agent_name[1].strip()
                        last_name = agent_name[2].strip()
                    if len(agent_name) >= 4:
                        first_name = name
                        middle_name = ''
                        last_name = ''
            languages = []
            email = ''
            website = profile_url
            country = 'United States'
            if '/no-agent-photo' in image_url:
                image_url = ''

            agent_phone_numbers = []
            office_phone_numbers = []
            for number in agent_phone:
                number = number.strip()
                agent_phone_numbers.append(number)
            for num in office_phone:
                num = num.strip()
                office_phone_numbers.append(num)

            city = city_state_zip_.split(',')[0] if city_state_zip_ else ''
            state_zip_ = city_state_zip_.split(
                ',')[1].strip() if city_state_zip_ else ''
            state_zip_1 = state_zip_.split(' ') if state_zip_ else ''
            state_zip_2 = state_zip_1[0].split('\xa0') if state_zip_1 else ''
            state = state_zip_2[0].strip() if state_zip_2 else ''
            zipcode = state_zip_2[1].strip() if state_zip_2 else ''
            meta = {
                'title': title,
                'office_name': office_name,
                'first_name': first_name,
                'middle_name': middle_name,
                'last_name': last_name,
                'languages': languages,
                'email': email,
                'website': website,
                'country': country,
                'image_url': image_url,
                'agent_phone_numbers': agent_phone_numbers,
                'office_phone_numbers': office_phone_numbers,
                'address': address,
                'city': city,
                'state': state,
                'zipcode': zipcode}
            if profile_url:
                if 'a href=' not in profile_url:
                    yield Request(url=profile_url, callback=self.parse_profile, meta=meta)
            else:

                item = Huff_RealtyItem(
                    title=title,
                    office_name=office_name,
                    address=address,
                    city=city,
                    state=state,
                    zipcode=zipcode,
                    languages=languages,
                    first_name=first_name,
                    middle_name=middle_name,
                    last_name=last_name,
                    website='',
                    email=email,
                    image_url=image_url,
                    agent_phone_numbers=agent_phone_numbers,
                    office_phone_numbers=office_phone_numbers,
                    country=country
                )
                yield item

    def parse_profile(self, response):
        title = response.meta.get('title', '')
        office_name = response.meta.get('office_name')
        first_name = response.meta.get('first_name')
        middle_name = response.meta.get('middle_name')
        last_name = response.meta.get('last_name')
        image_url = response.meta.get('image_url')
        email = response.meta.get('email')
        website = response.meta.get('website')
        country = response.meta.get('country')
        languages = response.meta.get('languages')
        agent_phone_numbers = response.meta.get('agent_phone_numbers')
        office_phone_numbers = response.meta.get('office_phone_numbers')
        address = response.meta.get('address')
        city = response.meta.get('city')
        state = response.meta.get('state')
        zipcode = response.meta.get('zipcode')
        profile_url = response.url
        description = response.xpath(
            '//section[@class="rn-home-agent-info"]/p//text()|//div[@class="site-home-page-content-text"]/p//text()|//div[@id="divSavedContent"]/p//text()|//div[@class="site-home-page-content-text"]/p//text()').extract()
        description = ' '.join(''.join(description).split())
        facebook_url = response.xpath(
            '//a[@title="Like me"]/@href|//li[@class="social-facebook"]/a/@href').extract_first('')
        linkedin_url = response.xpath(
            '//a[@title="Link with me"]/@href|//li[@class="social-linkedin"]/a/@href').extract_first('')
        twitter_url = response.xpath(
            '//a[@title="Follow me"]/@href|//li[@class="social-twitter"]/a/@href').extract_first('')
        instagram_url = response.xpath(
            '//a[@title="See my Instagram"]/@href|//li[@class="social-instagram"]/a/@href').extract_first('')
        pinterest_url = response.xpath(
            '//a[@title="See my Pinterest"]/@href|//li[@class="social-misc"]/a/@href').extract_first('')
        youtube_url = response.xpath(
            '//a[@title="See my Youtube"]/@href|//li[@class="social-youtube"]/a/@href').extract_first('')
        googleplus_url = response.xpath(
            '//a[@title="See my GooglePlus"]/@href|//li[@class="social-google-plus"]/a/@href').extract_first('')

        if 'www.facebook' in facebook_url:
            facebook_url = facebook_url.strip()
        else:
            facebook_url = ''
        if 'twitter' in twitter_url:
            twitter_url = twitter_url.strip()
        else:
            twitter_url = ''
        if 'www.linkedin' in linkedin_url:
            linkedin_url = linkedin_url.strip()
        else:
            linkedin_url = ''
        if 'www.pinterest' in pinterest_url:
            pinterest_url = pinterest_url.strip()
        else:
            pinterest_url = ''
        if 'google' in googleplus_url:
            googleplus_url = googleplus_url.strip()
        else:
            googleplus_url = ''
        if 'www.youtube' in youtube_url:
            youtube_url = youtube_url.strip()
        else:
            youtube_url = ''
        if 'www.instagram' in instagram_url:
            instagram_url = instagram_url.strip()
        else:
            instagram_url = ''

        other_urls_ = []

        if pinterest_url:
            other_urls_.append(pinterest_url)
        if googleplus_url:
            other_urls_.append(googleplus_url)
        if youtube_url:
            other_urls_.append(youtube_url)
        if instagram_url:
            other_urls_.append(instagram_url)

        other_urls = []
        for url in other_urls_:
            if url:
                other_urls.append(url)
            else:
                other_urls = []

        if facebook_url or twitter_url or linkedin_url or other_urls:
            social = {'facebook_url': facebook_url,
                      'twitter_url': twitter_url,
                      'linkedin_url': linkedin_url,
                      'other_urls': other_urls,
                      }
        else:
            social = {}

        item = Huff_RealtyItem(
            title=title,
            office_name=office_name,
            address=address,
            city=city,
            state=state,
            zipcode=zipcode,
            profile_url=profile_url,
            languages=languages,
            description=description,
            first_name=first_name,
            middle_name=middle_name,
            last_name=last_name,
            website=website,
            email=email,
            image_url=image_url,
            agent_phone_numbers=agent_phone_numbers,
            office_phone_numbers=office_phone_numbers,
            social=social,
            country=country,
        )
        yield item
