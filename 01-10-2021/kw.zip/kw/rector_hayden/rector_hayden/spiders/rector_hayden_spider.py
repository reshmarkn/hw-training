# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
import re
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from rector_hayden.items import *
from rector_hayden.settings import *
from rector_hayden.proxy import parse_proxy

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}


class Rector_HaydenSpider(Spider):
    name = 'rector_hayden'

    def start_requests(self):

        start_urls = 'http://www.rhr.com/rhnr/index.asp?p=agentResults.asp&search=%%'
        allowed_domains = []
        yield Request(url=start_urls, headers=headers, callback=self.parse, dont_filter=True)

    """
    # Queue implementation
    def start_requests(self):
        # Fetching URL from queue until queue is empty
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        channel = connection.channel()
        while True:
            channel.basic_qos(prefetch_count=1)
            method, properties, url = channel.basic_get(queue=QUEUE_NAME)
            if not url.strip():
                break
            channel.basic_ack(delivery_tag=method.delivery_tag)
            url = str(url.strip(), encoding='utf-8')
            if url.strip():
                yield Request(url=url.strip(), callback=self.parse, headers=self.headers, errback=lambda x: self.errback_httpbin(x, url.strip()))
        connection.close()
    """

    def parse(self, response):
        agents_sel = response.xpath('//article[@class="rn-agent-card"]')
        for sel in agents_sel:
            profile_url = sel.xpath(
                'div//div[@class="rn-agent-icon-website"]/a/@href').extract()
            name = sel.xpath(
                'div/div[@class="rn-agent-contact"]/span[@class="rn-agent-name"]/text()').extract_first('').strip()
            title = sel.xpath(
                'div/div/div[@class="rn-agent-title"]/span/text()').extract_first('').strip()
            agent_phone = sel.xpath(
                'div/div/div/span[contains(text(), "Main")]/following-sibling::span/text()').extract()
            office_phone = sel.xpath(
                'div/div/div/span[contains(text(), "Office")]/following-sibling::span/text()').extract()
            office_name = sel.xpath(
                'div/div/div/div/span[@class="rn-agent-contact-office-name"]/text()').extract_first('').strip()
            office_address = sel.xpath(
                '//div[@class="rn-agent-contact-office-content"]/span[@class="rn-agent-contact-office-address-street"]/text()').extract_first('')
            office_city_state = sel.xpath(
                '//div[@class="rn-agent-contact-office-content"]/span[@class="rn-agent-contact-office-city-state-zip"]/text()').extract()
            # img_url = sel.xpath(
            #     '//div[@class="rn-agent-info"]/div[@class="rn-agent-photo-languages"]/img/@src').extract()

            meta = {
                'name': name,
                'title': title,
                'agent_phone': agent_phone,
                'office_phone': office_phone,
                'office_name': office_name,
                'office_address': office_address,
                'office_city_state': office_city_state,
                # 'img_url': img_url
            }

            for link in profile_url:
                yield Request(url=link, callback=self.parse_profile, headers=headers, meta=meta, dont_filter=True)

    def parse_profile(self, response):
        name = response.meta['name']
        title = response.meta['title']
        agent_phone = response.meta['agent_phone']
        office_phone = response.meta['office_phone']
        office_name = response.meta['office_name']
        # office_address = response.meta['office_address']
        office_city_state = response.meta['office_city_state']
        # image_urls = response.meta['img_url']
        profile_url = response.url

        first_name = ''
        middle_name = ''
        last_name = ''

        agent_name = name.split()
        if '&' in agent_name:
            first_name = name
        else:
            if len(agent_name) == 1:
                first_name = agent_name[0].strip()
                middle_name = ''
                last_name = ''
            if len(agent_name) == 2:
                first_name = agent_name[0].strip()
                middle_name = ''
                last_name = agent_name[1].strip()
            if len(agent_name) == 3:
                first_name = agent_name[0].strip()
                middle_name = agent_name[1].strip()
                last_name = agent_name[2].strip()
            if len(agent_name) >= 4:
                first_name = name
                middle_name = ''
                last_name = ''

        agent_phone_numbers = []
        office_phone_numbers = []
        for number in agent_phone:
            number = number.strip()
            agent_phone_numbers.append(number)
        for num in office_phone:
            num = num.strip()
            office_phone_numbers.append(num)
        country = 'United States'
        social = {}
        image_url = ''

        # for image_url in image_urls:
        #     image_url = image_url
        # image_url = response.xpath(
        #     '//img[@class="agent-image"]/@src|//div[@class="site-home-page-content-agent-details"]/img/@src').extract_first('').strip()

        email = ''
        website = response.url
        description = response.xpath(
            '//section[@class="rn-home-agent-info"]/p//text()|//div[@class="site-home-page-content-text"]/p//text()|//div[@id="divSavedContent"]/p//text()|//div[@class="site-home-page-content-text"]/p//text()').extract()
        description = ' '.join(''.join(description).split())
        image_url = response.xpath(
            '//div[@class="site-home-page-content-agent-details"]/img/@src').extract_first()
        if image_url == None:
            image_url = ''
        if not image_url:
            image_url = response.xpath(
                '//style[contains(text(), "--hero")]/text()').extract_first().strip()
            image_url = re.findall(
                '--hero.*?url.*?;', image_url)[0].replace('--hero: url("', '').replace('");', '')

        languages = []
        zipcode = ''
        city = ''
        state = ''
        # address = office_address
        # for city in office_city_state:
        #     city = city.split(',')[0]
        # for state in office_city_state:
        #     state = state.split(',')[1]
        #     state = state.split()[0]
        # for zipcode in office_city_state:
        #     zipcode = zipcode.split(',')[1]
        #     zipcode = zipcode.split()[1]

        address = response.xpath(
            '//ul[@class="no-bullet footer-address"]/li[3]/text()').extract_first('').strip()
        if address:
            postal = response.xpath(
                '//ul[@class="no-bullet footer-address"]/li[4]/text()').extract_first('').split(',')
            if len(postal) == 3:
                city = postal[0].strip()
                state = postal[1].strip()
                zipcode = postal[2].strip()
            if len(postal) == 2:
                city = postal[0].strip()
                postalcode = postal[1].strip().split(' ')
                if postalcode:
                    state = postalcode[0].strip()
                    zipcode = postalcode[1].strip()
        if address == '':
            address_details = response.xpath(
                '//ul[@class="rn-site-footer-main-links"]/li[4]/text()').extract_first('').strip()
            if address_details:
                postal = address_details.split(',')
                if len(postal) == 3:
                    address = postal[0]
                    city = postal[1].strip()
                    loc = postal[2].split()
                    state = loc[0].strip()
                    zipcode = loc[1].strip()
                if len(postal) == 2:
                    city = postal[0].strip()
                    postalcode = postal[1].strip().split(' ')
                    if postalcode:
                        state = postalcode[0].strip()
                        zipcode = postalcode[1].strip()

        facebook_url = response.xpath(
            '//a[@title="Like me"]/@href|//li[@class="social-facebook"]/a/@href').extract_first('')
        facebook_url = response.urljoin(facebook_url)
        linkedin_url = response.xpath(
            '//a[@title="Link with me"]/@href|//li[@class="social-linkedin"]/a/@href').extract_first('')
        linkedin_url = response.urljoin(linkedin_url)
        twitter_url = response.xpath(
            '//a[@title="Follow me"]/@href|//li[@class="social-twitter"]/a/@href').extract_first('')
        twitter_url = response.urljoin(twitter_url)
        instagram_url = response.xpath(
            '//a[@title="See my Instagram"]/@href|//li[@class="social-instagram"]/a/@href').extract_first('')
        instagram_url = response.urljoin(instagram_url)
        pinterest_url = response.xpath(
            '//a[@title="See my Pinterest"]/@href|//li[@class="social-misc"]/a/@href').extract_first('')
        pinterest_url = response.urljoin(pinterest_url)
        youtube_url = response.xpath(
            '//a[@title="See my Youtube"]/@href|//li[@class="social-youtube"]/a/@href').extract_first('')
        youtube_url = response.urljoin(youtube_url)
        googleplus_url = response.xpath(
            '//a[@title="See my GooglePlus"]/@href|//li[@class="social-google-plus"]/a/@href').extract_first('')
        googleplus_url = response.urljoin(googleplus_url)

        if 'www.facebook' in facebook_url:
            facebook_url = facebook_url.strip()
        else:
            facebook_url = ''
        if 'twitter.com' in twitter_url:
            twitter_url = twitter_url.strip()
        else:
            twitter_url = ''
        if 'www.linkedin' in linkedin_url:
            linkedin_url = linkedin_url.strip()
        else:
            linkedin_url = ''
        if 'www.pinterest' in pinterest_url:
            pinterest_url = pinterest_url.strip()
        else:
            pinterest_url = ''
        if 'google.com' in googleplus_url:
            googleplus_url = googleplus_url.strip()
        else:
            googleplus_url = ''
        if 'www.youtube' in youtube_url:
            youtube_url = youtube_url.strip()
        else:
            youtube_url = ''
        if 'www.instagram' in instagram_url:
            instagram_url = instagram_url.strip()
        else:
            instagram_url = ''

        other_urls_ = []

        if pinterest_url:
            other_urls_.append(pinterest_url)
        if googleplus_url:
            other_urls_.append(googleplus_url)
        if youtube_url:
            other_urls_.append(youtube_url)
        if instagram_url:
            other_urls_.append(instagram_url)

        other_urls = []
        for url in other_urls_:
            if url:
                other_urls.append(url)
            else:
                other_urls = []

        if facebook_url or twitter_url or linkedin_url or other_urls:
            social = {'facebook_url': facebook_url,
                      'twitter_url': twitter_url,
                      'linkedin_url': linkedin_url,
                      'other_urls': other_urls,
                      }
        else:
            social = {}

        if first_name:
            item = Rector_HaydenItem(
                title=title,
                office_name=office_name,
                address=address,
                city=city,
                state=state,
                zipcode=zipcode,
                profile_url=profile_url,
                languages=languages,
                description=description,
                first_name=first_name,
                middle_name=middle_name,
                last_name=last_name,
                website=website,
                email=email,
                image_url=image_url,
                agent_phone_numbers=agent_phone_numbers,
                office_phone_numbers=office_phone_numbers,
                social=social,
                country=country,
            )
            yield item

    """
    # Errorback to put failed urls back in queue
    def errback_httpbin(self, failure, url):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=600))
        channel = connection.channel()
        channel.queue_declare(queue=QUEUE_NAME, durable=True)
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=url)
        connection.close()
    """
