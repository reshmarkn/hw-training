# -*- coding: utf-8 -*-
import scrapy
import logging
from scrapy.http import Request
from championrealty_agent.items import *
from championrealty_agent.settings import *


class championrealtyAgentSpider(scrapy.Spider):
	name = 'championrealty_agent'
	allowed_domains = ["championrealty.com"]
	start_urls = ['http://www.championrealty.com/agents.php?refine=true&search_aname=%25%25',
				  ]  # Browse all
	BASE_URL = 'http://www.championrealty.com'
	HEADERS = {'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
				'Accept-Encoding':'gzip, deflate, br',
				'Accept-Language':'en-GB,en-US;q=0.9,en;q=0.8',
				'Upgrade-Insecure-Requests':'1',
				'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.82 Safari/537.36',}


	def parse(self, response):
		agents_urls = response.xpath('//article[@class="agent-col"]//a[@class="btn"]/@href').extract()

		for agent in agents_urls:
			if agent.startswith('//'):
				agent = 'http:' + agent
			elif agent.startswith('/'):
				agent = self.BASE_URL + agent
			agent = agent.strip()
			if agent.startswith('http'):
				yield Request(url=agent, callback=self.parse_profile, headers=self.HEADERS)

	def parse_profile(self, response):
		name = response.xpath('//h1/text()').extract()
		title = response.xpath('//h1/small/text()').extract()
		image_url = response.xpath('//div[@class="photo"]//img/@data-src').extract()
		biography = response.xpath('//div[@class="details"]/p[@class="description"]/text()').extract()
		company_name =  response.xpath('//li[@class="keyval office"]/span/a/text()').extract()
		address = response.xpath('//li[@class="keyval location"]/span//text()').extract()
		phone_numbers = response.xpath('//li[contains(@class,"keyval")][contains(@class,"phone")]/span//text()').extract()
		emails = response.xpath('//li[@class="keyval email"]/span//text()').extract()
		websites = response.xpath('//li[@class="keyval website"]/span//text()').extract()
		fax = response.xpath('//li[contains(@class,"keyval")][contains(@class,"fax")]/span//text()').extract()

		name = name[0].strip() if name else ''
		title = title[0].strip() if title else ''
		image_url = image_url[0].strip() if image_url else ''
		if image_url.startswith('//'):
			image_url = 'http:' + image_url
		elif image_url.startswith('/'):
			image_url = self.BASE_URL + image_url
		image_url = image_url.strip()  if image_url.startswith('http') else ''
		biography = [x.strip() for x in biography] if biography else []
		biography = [x.strip() for x in biography if x] if biography else []
		biography = ' '.join(biography).strip() if biography else ''
		company_name = company_name[0].strip() if company_name else ''
		address = address[0].strip() if address else ''

		items =  ChampionrealtyItem(
					profile_url= response.url,
					image_url = image_url,
					name = name,
					description  = biography,
					address = address,
					phone_numbers=phone_numbers,
					emails = emails,
					social = {},
					websites = websites,
					languages = [],
					fax = fax,
					company_name = company_name,
					title = title,
			)
		if name:
			yield items