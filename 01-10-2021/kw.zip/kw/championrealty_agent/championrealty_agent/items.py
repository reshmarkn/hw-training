# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class ChampionrealtyItem(scrapy.Item):
    # define the fields for your item here like:
    name = scrapy.Field()
    image_url = scrapy.Field()
    title = scrapy.Field()
    company_name = scrapy.Field()
    description = scrapy.Field()
    languages = scrapy.Field()
    address = scrapy.Field()
    phone_numbers = scrapy.Field()
    social = scrapy.Field()
    websites = scrapy.Field()
    emails = scrapy.Field()
    fax = scrapy.Field()
    profile_url = scrapy.Field()
