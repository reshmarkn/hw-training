# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html
from pymongo import MongoClient
from scrapy.exceptions import DropItem
from championrealty_agent.items import *

MONGODB_DB = 'kw'
MONGODB_COLLECTION_AGENT = 'championrealty_agent'


class ChampionrealtyPipeline(object):
    def __init__(self, *args, **kwargs):
        self.client = MongoClient()
        self.db = MongoClient('mongodb://datahut:cGFzc21lMTIz@138.197.119.22:27045').kw
        self.db[MONGODB_COLLECTION_AGENT].create_index('profile_url', unique=True)

    def process_item(self, item, spider):
        if isinstance(item, ChampionrealtyItem):
            try:
                self.db[MONGODB_COLLECTION_AGENT].insert(dict(item))
            except:
                raise DropItem("Dropping duplicate item")

        return item