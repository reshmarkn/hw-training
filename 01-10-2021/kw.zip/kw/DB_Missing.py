from pymongo import MongoClient
import pika
import json
from time import sleep
import datetime

# client = MongoClient('mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')
client = MongoClient('mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
DB_NAME = input('Enter 1st DB Name:')

db = client[DB_NAME]
# colist = db.list_collection_names()
# for j in colist:

#     print(colist.index(j)+1, j, ":", str(db[j].estimated_document_count()))

COLLECTION_NAME_1 = input('Enter First Collection Name:')

while(not COLLECTION_NAME_1):

    print(db.list_collection_names())
    COLLECTION_NAME_1 = input('Enter first Collection Name:')


doc = dict(db[COLLECTION_NAME_1].find_one())
for key in doc:
    print(key, ":", doc[key])
FIELD_1 = input('Enter FIELD:')
FIELD_1 = FIELD_1.split(',')
FIELD_1 = [x.strip() for x in FIELD_1 if x.strip()]
searchString1 = {'_id': 0}
for field in FIELD_1:
    searchString1[field] = 1
result = db[COLLECTION_NAME_1].find({}, searchString1)
f1l = []
for data in result:

    document = dict(data)
    if len(FIELD_1) == 1:
        document = document[FIELD_1[0]]
    f1l.append(document)
f1l = [x.strip() for x in f1l if x.strip()]

print(COLLECTION_NAME_1, ":", len(f1l))
print('Unique Items:', len(set(f1l)))

DB_NAME = input('Enter 2nd DB Name:')

db = client[DB_NAME]
# colist = db.list_collection_names()
# for j in colist:

#     print(colist.index(j)+1, j, ":", str(db[j].estimated_document_count()))


COLLECTION_NAME_2 = input('Enter Second Collection Name:')

while(not COLLECTION_NAME_2):

    print(db.list_collection_names())
    COLLECTION_NAME_2 = input('Enter Second Collection Name:')


doc = dict(db[COLLECTION_NAME_2].find_one())
for key in doc:
    print(key, ":", doc[key])
FIELD_2 = input('Enter FIELD:')
FIELD_2 = FIELD_2.split(',')
FIELD_2 = [x.strip() for x in FIELD_2 if x.strip()]
searchString2 = {'_id': 0}
for field in FIELD_2:
    searchString2[field] = 1
result = db[COLLECTION_NAME_2].find({}, searchString2)
f2l = []
for data in result:

    document = dict(data)
    if len(FIELD_2) == 1:
        document = document[FIELD_2[0]]
    f2l.append(document)
f2l = [x.strip() for x in f2l if x.strip()]
print(COLLECTION_NAME_2, ":", len(f2l))
print('Unique Items:', len(set(f2l)))

missing = set(f1l) - set(f2l)

print("-----Length-----")

print(DB_NAME + "[" + COLLECTION_NAME_1 + "]:", len(f1l))
print('Unique Items:', len(set(f1l)))

print(DB_NAME + "[" + COLLECTION_NAME_2 + "]:", len(f2l))

print('Unique Items:', len(set(f2l)))
print("Missing:", len(missing))

missing = [x.strip() for x in missing if x.strip()]

f3name = input("Enter Output File Name:")
while(not f3name):
    f3name = input("Enter Output File Name:")

f3 = open(f3name, "a")


for i in missing:
    if i not in f2l:
        f3.write(i + '\n')

print(f3name, ":", len(missing))
f3.close()
