# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from woodsbros.items import *
from woodsbros.settings import *
# from woodsbros.proxy import parse_proxy

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

h = {"Accept":"*/*",   
        "Accept-Encoding":"gzip, deflate",   
        "Accept-Language":"en-GB,en-US;q=0.9,en;q=0.8",   
        "Host":"www.woodsbros.com",   
        "Referer":"https://www.woodsbros.com/roster/Agents",   
        "Sec-Fetch-Mode":"cors",   
        "Sec-Fetch-Site":"same-origin",   
        "User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36", 
        "X-Requested-With":"XMLHttpRequest"}   

class WoodsbrosSpiderSpider(scrapy.Spider):
    name = 'woodsbros_spider'
    def start_requests(self):
        for var in range(1, 19):
            url = 'https://www.woodsbros.com/CMS/CmsRoster/RosterSection?layoutID=956&pageSize=10&pageNumber='+str(var)+'&sortBy=random'
            yield Request(url=url, callback=self.parse, headers=h)

    def parse(self, response):
        links = response.xpath(
            '//article[@class="rng-agent-roster-agent-card js-sort-item"]')

        # links = response.xpath(
        #     '//div[@class="rn-agent-roster"]/article[@class="rn-agent-card"]')
        for link in links:
            image = link.xpath('img/@src').extract()
            name = link.xpath(
                'h1[@class="rn-agent-roster-name js-sort-name"]/text()').extract()
            title = link.xpath(
                'h1[@class="rn-agent-roster-name js-sort-name"]/span/text()').extract()
            office_phone_numbers = link.xpath(
                'ul/li[1]/a/text()').extract_first('')
            agent_phone_numbers = link.xpath('ul/li[2]/a/text() ').extract()[1]
            office_name = link.xpath('p/strong/text()').extract()
            website = link.xpath('ul[2]/li[1]/a/@href').extract_first('')
            social_ = link.xpath(
                'ul[1]/li[@class="rng-agent-profile-contact-social"]/a/@href').extract()

            # image = link.xpath(
            #     'div[@class="rn-agent-info"]/div[@class="rn-agent-photo-languages"]/img/@src').extract()
            # name = link.xpath(
            #     'div[@class="rn-agent-info"]/div[@class="rn-agent-contact"]/span[@class="rn-agent-name"]/text()').extract()
            # title = link.xpath(
            #     'div[@class="rn-agent-info"]/div[@class="rn-agent-contact"]/div[@class="rn-agent-title"]/span/text()').extract()
            # agent_phone_numbers = link.xpath(
            #     'div[@class="rn-agent-info"]/div[@class="rn-agent-contact"]/div[@class="rn-agent-contact-main-phone"]/span[@class="rn-agent-contact-main-phone-number"]/text()').extract()
            # office_phone_numbers = link.xpath(
            #     'div[@class="rn-agent-info"]/div[@class="rn-agent-contact"]/div[@class="rn-agent-contact-office-phone"]/span[@class="rn-agent-contact-office-phone-number"]/text()').extract()
            # office_name = link.xpath(
            #     'div[@class="rn-agent-info"]/div[@class="rn-agent-contact"]/div[@class="rn-agent-contact-office"]/div[@class="rn-agent-contact-office-content"]/span[@class="rn-agent-contact-office-name"]/text()').extract()
            # address = link.xpath(
            #     'div[@class="rn-agent-info"]/div[@class="rn-agent-contact"]/div[@class="rn-agent-contact-office"]/div[@class="rn-agent-contact-office-content"]/span[@class="rn-agent-contact-office-address-street"]/text()').extract()
            # city_state_zip = link.xpath(
            #     'div[@class="rn-agent-info"]/div[@class="rn-agent-contact"]/div[@class="rn-agent-contact-office"]/div[@class="rn-agent-contact-office-content"]/span[@class="rn-agent-contact-office-city-state-zip"]/text()').extract()
            # website = link.xpath(
            #     'div[@class="rn-agent-buttons"]//div[@class="rn-agent-icon-website"]/a/@href').extract()

            name = ''.join(name).strip().replace('\xa0', ' ')
            name_list = name.split(' ')
            if len(name_list) > 3:
                first_name = name.strip()
                middle_name = ''
                last_name = ''
            elif len(name_list) == 3:
                first_name = name_list[0].strip()
                middle_name = name_list[1].strip()
                last_name = name_list[2].strip()
            elif len(name_list) == 2:
                first_name = name_list[0].strip()
                middle_name = ''
                last_name = name_list[1].strip()
            elif len(name_list) == 1:
                first_name = name_list[0].strip()
                middle_name = ''
                last_name = ''
            else:
                first_name = ''
                middle_name = ''
                last_name = ''

            title = ''.join(title).strip()
            image = ''.join(image).strip()
            if 'no-agent-photo' in image:
                image_url = ''
            else:
                image_url = image
            office_name = ''.join(office_name).strip()
            # address = ''.join(address).strip()
            # city_state_zip = ''.join(
            #     city_state_zip).strip().replace('\xa0', ' ')
            # if ',' in city_state_zip:
            #     city = city_state_zip.split(',')[0]
            #     state_zip = city_state_zip.split(',')[1].strip()
            #     state = state_zip.split(' ')[0]
            #     zipcode = state_zip.split(' ')[1]
            website = ''.join(website).strip()
            social = {}
            other_urls = []
            for soc in social_:
                if 'facebook' in soc:
                    facebook_url = soc
                    social.update({'facebook_url': facebook_url})
                elif 'twitter' in soc:
                    twitter_url = soc
                    social.update({'twitter_url': twitter_url})
                elif 'linkedin' in soc:
                    linkedin_url = soc
                    social.update({'linkedin_url': linkedin_url})
                else:
                    other_urls.append(soc)
                    social.update({'other_urls': other_urls})

            profile_url = website

            if first_name:
                if website:
                    meta = {
                        'first_name': first_name,
                        'middle_name': middle_name,
                        'last_name': last_name,
                        'title': title,
                        'image_url': image_url,
                        'agent_phone_number': agent_phone_numbers,
                        'office_phone_numbers': office_phone_numbers,
                        'office_name': office_name,
                        'website': website,
                        'profile_url': profile_url,
                        'social': social
                    }
                    yield Request(url=website, callback=self.parse_website, meta=meta,dont_filter=True)
    def parse_website(self, response):
        agent_number = ''
        address = ''
        city = ''
        state = ''
        zipcode = ''

        first_name = response.meta['first_name']
        middle_name = response.meta['middle_name']
        last_name = response.meta['last_name']
        title = response.meta['title']
        #agent_phone_numbers = response.meta['agent_phone_number']
        office_phone_numbers = response.meta['office_phone_numbers']
        image_url = response.meta['image_url']
        office_name = response.meta['office_name']
        # address = response.meta['address']
        # city = response.meta['city']
        # state = response.meta['state']
        # zipcode = response.meta['zipcode']
        website = response.meta['website']
        profile_url = response.meta['profile_url']
        social = response.meta['social']

        description = response.xpath(
            '//div[@class="site-column two-thirds"]//p/text() | //div[@class="site-home-page-about-text"]/p/text() | //div[@class="site-home-page-content-text"]/p/text() ').extract()
        description = ''.join(description).strip()
        try:
            address = response.xpath(
                '//ul[@class="no-bullet footer-address"]/li/text()').extract()[-3]
        except:
            address =''
        address = ''.join(address).strip()
        try:

            city_state_zip = response.xpath(
                '//ul[@class="no-bullet footer-address"]/li/text()').extract()[-2]
            if city_state_zip:
                city = city_state_zip.split(',')[0]
                state_zip = city_state_zip.split(',')[1]
                state = state_zip.split()[0]
                zipcode = state_zip.split()[1]
        except:
            city =''
            state =''
            zipcode =''
        
        agent_phone_number = response.xpath(
            '//ul[@class="no-bullet footer-account-info"]/li[contains(text(),"Cell:")]/text() | //ul[@class="no-bullet footer-account-info"]/li[3]/text()').extract_first('')
        if 'Cell' in agent_phone_number:
            agent_number = agent_phone_number.replace('Cell:', '')

        if ':' in agent_phone_number:
            agent_number = agent_phone_number.split(':')[1]

        # social_ = response.xpath(
        #     '//ul[@class="no-bullet footer-social"]//a/@href').extract()
        # social = {}
        # other_urls = []
        # for soc in social_:
        #     if 'facebook' in soc:
        #         facebook_url = soc
        #         social.update({'facebook_url': facebook_url})
        #     elif 'twitter' in soc:
        #         twitter_url = soc
        #         social.update({'twitter_url': twitter_url})
        #     elif 'linkedin' in soc:
        #         linkedin_url = soc
        #         social.update({'linkedin_url': linkedin_url})
        #     else:
        #         other_urls.append(soc)
        #         social.update({'other_urls': other_urls})

        item = WoodsbrosItem(
            first_name=first_name,
            middle_name=middle_name,
            last_name=last_name,
            title=title,
            image_url=image_url,
            agent_phone_numbers=agent_number,
            office_phone_numbers=office_phone_numbers,
            office_name=office_name,
            address=address,
            email='',
            website=website,
            city=city,
            state=state,
            zipcode=zipcode,
            description=description,
            languages=[],
            country='United States',
            social=social,
            profile_url=profile_url,
        )
        print(item)
        yield item


# {"office_phone_numbers":[],"state":"CO","first_name":"Ed","city":"Denver","email":"","title":"Broker Associate","website":"https://emcwilliams.kentwood.com","country":"United States","address":"4949 South Niagara St 400","middle_name":"","profile_url":"https://www.kentwood.com/bio/emcwilliams","description":"Ed started his career in real estate after graduating from the Denver public school system and the University of Colorado. A natural in meeting and interacting with people, Ed was attracted to real estate for the independence it offered and the ability to work with many different kinds of people helping them realize their dreams. He joined Kentwood and has continued to grow and serve Colorado families as the company has grown over the last 40 years.Ed and his wife Marilyn, an attorney with local firm Moye White, bought their first house in Montclair in 1978 and have been there ever since.When he’s not selling homes, you can find Ed sipping a local brew at My Brother's Bar, walking Denver’s city trails, or hiding out in the mountains hiking and fishing with his family. He feels fortunate to have climbed half of Colorado’s 14ers, skied to many huts in the 10th mountain system, and trekked on five continents.Ed is most grateful for his incredible family and good health. He and Marilyn have been married almost 50 years and boast three beautiful daughters and five wonderful grandchildren.","languages":[],"agent_phone_numbers":["(303) 902-1558"],"zipcode":"80237","office_name":"Kentwood DTC","image_url":"https://content.mediastg.net/dynamic/RealEstate/company/624/account/539905/539905_08222021161815.jpg","last_name":"McWilliams","social":{}}