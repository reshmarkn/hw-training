
import scrapy
import time
import requests
import re
import json
from pymongo import MongoClient
from berkshirehathawayhs.settings import *
from scrapy.http import Request, FormRequest
from berkshirehathawayhs.tor_proxy import parse_proxy
from scrapy import signals
import subprocess
# from databasenotifier import automation_script


MONGODB_DB = 'kw_Oct_2020'
MONGODB_COLLECTION = 'bhhs_urls'


client = MongoClient('mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')
try:
    client.admin.command(
        "shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION, key={'url': 1})
except:
    pass

db = client[MONGODB_DB]

headers = {
    'authority': 'www.bhhs.com',
    'method': 'GET',
    # 'path': '/bin/bhhs/officeSearchServlet?PageSize=10&Sort=1&Page=1',
    'scheme': 'https',
    'accept': 'application/json, text/javascript, */*; q=0.01',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'pragma': 'no-cache',
    'referer': 'https://www.bhhs.com/office-results-list',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
}


class BerSpiderSpider(scrapy.Spider):
    name = "bhhs_url_v2"
    handle_httpstatus_list = [503, 403]

    # def spider_ended(self):
    #     automation_script.Automation_Spider(MONGODB_DB, MONGODB_COLLECTION)
    #     # subprocess.call("python q_insert.py ", shell=True)

    def start_requests(self):
        pagesize = 10
        state = ["AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "DC", "FL", "GA", "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO",
                 "MT", "NE", "NV", "NH", "NJ", "NM", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY", "PR", "NY", "BE"]
        for i in state:
            url = 'https://www.bhhs.com/bin/bhhs/agentSearchServlet?sortType=6&resultSize=' + str(pagesize) + '&page=1&state=' + str(i)
            meta = {'state': i, 'page': 1}
            yield Request(url.strip(), headers=headers, callback=self.parse, meta=meta)

    def parse(self, response):

        page = response.meta.get('page')
        state = response.meta.get('state')
        json_data = json.loads(response.body_as_unicode())
        if json_data:
            if json_data.get('@odata.count'):
                total_count = json_data.get('@odata.count')
                print(total_count)
                context = json_data.get('@odata.context', 1)
                context = int(context)
            if json_data.get('value'):
                for data in json_data.get('value'):
                    agent_url = data.get('BhhsWebsiteUrl')
                    meta = {'url': agent_url}
                    if agent_url:
                        f = open('bhhs_url.txt', 'a')
                        f.write(agent_url + '\n')
                        f.close()
            #             db[MONGODB_COLLECTION].insert(dict(meta))
            page = page + 1
            if page <= int(context):
                next_url = 'https://www.bhhs.com/bin/bhhs/agentSearchServlet?sortType=6&resultSize=10&page=' + str(page) + '&state=' + str(state)
                metadata = {'state': state, 'page': page}
                yield Request(next_url, headers=headers, callback=self.parse, meta=metadata)
