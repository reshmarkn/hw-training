# -*- coding: utf-8 -*-
import scrapy
from berkshirehathawayhs.settings import *
from berkshirehathawayhs.tor_proxy import parse_proxy

from string import ascii_lowercase
from scrapy.selector import Selector
from xml.dom import minidom
import requests
from scrapy.shell import inspect_response
from berkshirehathawayhs.items import *
import time
from scrapy.http import Request, FormRequest
import re
from scrapy import signals
# from databasenotifier import automation_script
from pymongo import MongoClient
import pika
import logging

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False
# ua = UserAgent()
h = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
    "accept-encoding": "gzip, deflate, br",
    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
    "upgrade-insecure-requests": "1",
    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36"
}


client = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')

try:
    client.admin.command("enablesharding", MONGODB_DB)
except:
    pass
try:
    client.admin.command(
        "shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION, key={'profile_url': 1}, unique=True)
except:
    pass
db = client[MONGODB_DB]


class BerkshirehathawayhssSpiderSpider(scrapy.Spider):
    name = "berkshirehathawayhs_parser"

    def spider_ended(self):
        automation_script.Automation_Spider(MONGODB_DB, MONGODB_COLLECTION)

    def start_requests(responsef):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        while True:
            try:
                channel = connection.channel()
            except:
                connection = pika.BlockingConnection(pika.ConnectionParameters(
                    credentials=credentials, host=QUEUE_IP, socket_timeout=300))
                channel = connection.channel()

            channel.basic_qos(prefetch_count=1)
            method, properties, url = channel.basic_get(queue=QUEUE_NAME)
            if not url:
                break
            url = str(url.strip(), encoding='utf-8')
            channel.basic_ack(delivery_tag=method.delivery_tag)

            if url.strip():
                link = str(url)

                try:
                    proxy = parse_proxy()
                    proxies = proxy['proxies']
                    link = str(link)
                    r = requests.get(link, headers=h, proxies=proxies)
                except:
                    try:

                        proxy = parse_proxy()
                        proxies = proxy['proxies']
                        r = requests.get(link, headers=h, proxies=proxies)
                    except:
                        r = ''
                        pass
                if r and r.status_code == 200:
                    responsef.parse_profile(r, link)
                else:
                    try:

                        proxy = parse_proxy()
                        proxies = proxy['proxies']
                        r = requests.get(link, headers=h, proxies=proxies)
                    except:
                        try:

                            proxy = parse_proxy()
                            proxies = proxy['proxies']
                            r = requests.get(link, headers=h, proxies=proxies)
                        except:
                            pass
                    if r and r.status_code == 200:
                        responsef.parse_profile(r, link)
                    else:
                        item = {'link': link}
            # else:
            #     break

        connection.close()

    def parse_profile(self, response, link):
        # print('SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSss')

        # inspect_response(response, self)
        description = ''
        res = Selector(text=response.content)
        agent_name = res.xpath('//h1//text()').extract()
        agent_name = ''.join(agent_name).strip()
        if not agent_name:
            pass
        else:
            country = 'United States'

            NAME_XPATH = '//h1[@class="cmp-agent__name"]//text()'
            ADDRESS_XPATH = '//div[@class="cmp-agent__office"]//text()'
            IMAGE_XPATH = '//meta[@property="og:image"]/@content'
            EMAIL_XPATH = '//a[@class="cmp-agent-details__mail text-lowercase"]/text()'
            PHONE_NUMBER = '//ul[@class="cmp-agent-details__list cmp-agent-details__phones order-2 order-lg-1"]/li[2]//text()'
            MOBILE_NUMBER = '//ul[@class="cmp-agent-details__list cmp-agent-details__phones order-2 order-lg-1"]/li[1]//text()'
            TITLE_XPATH = '//h6[@class="cmp-agent__title"]/text()'
            SOCIAL_XPATH = '//ul[@class="cmp-agent__social "]/li/a/@href'
            LANGUAGES_XPATH = '//div[@class="cmp-agent__language"]//li//text() | //ul[@id="languages"]//li//text()'
            LOCATION_XPATH = '//div[@class="cmp-agent__office"]//text()'
            CONTACT_XPATH = '//ul[@class="cmp-agent-details__list cmp-agent-details__phones order-2 order-lg-1"]//text()'

            name = res.xpath(NAME_XPATH).extract()
            mobile_number = res.xpath(MOBILE_NUMBER).extract()
            phone_number = res.xpath(PHONE_NUMBER).extract()
            image = res.xpath(IMAGE_XPATH).extract()
            location = res.xpath(LOCATION_XPATH).extract()
            languages = res.xpath(LANGUAGES_XPATH).extract()
            social_urls = res.xpath(SOCIAL_XPATH).extract()
            email = res.xpath(EMAIL_XPATH).extract_first('').strip()
            title = res.xpath(TITLE_XPATH).extract_first('').strip()

            # name = name[0].strip() if name else ''
            name = ''.join(name).strip() if name else ''
            name = name.split()
            first_name = ''
            middle_name = ''
            last_name = ''
            if len(name) == 1:
                first_name = name[0].strip() if name[0] else ''
                middle_name = ''
                last_name = ''
            if len(name) == 2:
                first_name = name[0].strip() if name[0] else ''
                middle_name = ''
                last_name = name[1].strip() if name[1] else ''
            if len(name) == 3:
                first_name = name[0].strip() if name[0] else ''
                middle_name = name[1].strip() if name[1] else ''
                last_name = name[2].strip() if name[2] else ''
            if len(name) >= 4:
                first_name = ' '.join(name)
                middle_name = ''
                last_name = ''

            facebook_url = ''
            twitter_url = ''
            linkedin_url = ''
            other_urls = []
            social = {}
            website = ''
            website_url = ''
            if social_urls:
                for url_ in social_urls:
                    url_ = url_.strip()
                    if 'http' in url_:
                        if 'facebook.com' in url_.lower():
                            facebook_url = url_
                        elif 'twitter.com' in url_.lower():
                            twitter_url = url_
                        elif 'linkedin.com' in url_.lower():
                            linkedin_url = url_
                        else:
                            other_urls.append(url_)

                social = {
                    'facebook_url': facebook_url,
                    'twitter_url': twitter_url,
                    'linkedin_url': linkedin_url,
                    'other_urls': other_urls if other_urls else '',
                }
            else:
                social = {}

            image = image[0].strip() if image else ''
            if 'no_user_image' in image:
                image = ''
            elif 'AgentNoPhotoAvailable' in image:
                image = ''
            else:
                image = image

            office_name = "".join(location).split('\n')[2].strip()
            languages_ = []
            for lan in languages:
                languages = lan.strip()
                languages_.append(languages)
            mobile_number1 = []
            phone_number1 = []
            if phone_number:
                if phone_number[0] == 'office':
                    phone_number1.append(phone_number[1])
            if mobile_number:
                if mobile_number[0] == 'mobile':
                    mobile_number1.append(mobile_number[1])
            address = "".join(location).split('\n')[3].strip()
            location = location[0].strip() if location else ''
            if location:
                try:
                    city = re.findall('(.*)[A-Z]{2}.\d{5}',
                                      location)[0].split() if location else ''
                except:
                    city = re.findall('(.*)[A-Z]{2}.\d{4}',
                                      location)[0].split() if location else ''

                city = ' '.join(city) if city else ''

                city = city.strip() if city else ''
                if ',' in city:
                    city = city.replace(',', '')
                state = re.findall(
                    '([A-Z]{2}).\d{5}', location)if location else ''
                state = state[0].strip() if state else ''
                zipcode = re.findall(
                    '[A-Z]{2}(.\d{5})', location)if location else ''
                zipcode = zipcode[0].strip() if zipcode else ''
                if not state:
                    state = re.findall(
                        '([A-Z]{2}).\d{4}', location)if location else ''
                    state = state[0].strip() if state else ''
                if not zipcode:
                    zipcode = re.findall(
                        '[A-Z]{2}(.\d{4})', location)if location else ''
                    zipcode = zipcode[0].strip() if zipcode else ''

            # if location:
            #     city = re.findall('(.*)[A-Z]{2}.\d{4}',location)
            #     city = ''.join(city) if city else ''
            #     if ',' in city:
            #         city = city.replace(',', '')
            #         city = city.strip()
            #     state = re.findall('([A-Z]{2}).\d{4}', location)if location else ''
            #     state = state[0].strip() if state else ''
            #     zipcode = re.findall('[A-Z]{2}(.\d{4})', location)if location else ''
            #     zipcode = zipcode[0].strip() if zipcode else ''

            items = BerkshirehathawayhsItem(
                # profile_url=response.url,
                profile_url=response.request.url,
                first_name=first_name,
                middle_name=middle_name,
                last_name=last_name,
                image_url=image,
                office_name=office_name,
                address=address,
                description='',
                languages=languages_,
                city=city,
                zipcode=zipcode,
                state=state,
                social=social,
                agent_phone_numbers=mobile_number1,
                office_phone_numbers=phone_number1,
                website=website_url,
                email=email,
                title=title,
                country=country
            )
            if first_name:
                logging.warning(items)
                try:
                    db[MONGODB_COLLECTION].insert(dict(items))
                except:
                    pass
    def errback_httpbin(self, publication_url):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=600))
        channel = connection.channel()
        channel.queue_declare(queue=QUEUE_NAME, durable=True)
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=publication_url)
        connection.close()

    @classmethod
    def from_crawler(cls, crawler, *args, **kwargs):
        spider = super(BerkshirehathawayhssSpiderSpider, cls).from_crawler(
            crawler, *args, **kwargs)
        crawler.signals.connect(spider.spider_opened, signals.spider_opened)
        crawler.signals.connect(spider.spider_closed, signals.spider_closed)
        return spider

    def spider_opened(self, spider):

        print('Opening {} spider'.format(spider.name))

    def spider_closed(self, spider):
        self.spider_ended()
        print('Closing {} spider'.format(spider.name))
