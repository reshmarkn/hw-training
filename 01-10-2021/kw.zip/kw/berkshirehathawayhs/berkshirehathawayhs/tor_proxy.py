from requests.auth import HTTPProxyAuth
from berkshirehathawayhs.settings import *
import random
import base64
import random
import logging
import requests

logger = logging.getLogger(__name__)
# from scrapy.conf import settings

# from scrapy import log


def parse_proxy():

    # PROXY_LIST = [
    #         # "5.79.66.2:13200"
    #         '68.183.58.145:5566',
    #     '157.230.189.5:5566'
    # ]

    PROXY = random.choice(PROXY_LIST)
    proxy_url = "http://%s" % PROXY
    proxies = {"http": "http://%s" % PROXY,
                       "https": "http://%s" % PROXY}
    logger.debug("Proxy added")
    return {'proxies': proxies, 'proxy_url': proxy_url}

    # proxies = {"http": "http://5.79.66.2:13200",
    #            "https": "https://5.79.66.2:13200"}
    # proxies = {"http": "http://68.183.58.145:5566",
    #            "https": "https://157.230.189.5:5566"}

    # # log.msg("Proxy added")
    # return {'proxies': proxies}
    # user_agent = random.choice(settings.get('USER_AGENT_LIST'))
    # # headers = {'Accept-Encoding': 'gzip', 'User-Agent': user_agent,
    # #            'Accept': 'application/json, text/javascript, */*; q=0.01', 'X-Requested-With': 'XMLHttpRequest'}
    # # headers = {
    # headers = {
    #     'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    #     'accept-encoding': 'gzip, deflate',
    #     'method': 'GET',
    #     'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    #     'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
    #     'upgrade-insecure-requests': '1',
    # }
    # return {'headers': headers, 'proxies': proxies}
