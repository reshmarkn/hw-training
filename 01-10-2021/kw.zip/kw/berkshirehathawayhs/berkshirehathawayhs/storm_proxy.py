# from scrapy.conf import settings
# from scrapy import log
from berkshirehathawayhs.settings import *
import random


def parse_proxy():

    # proxies = {"http": "http://138.197.105.52:5566",
    #            "https": "https://138.197.105.12:5566"}
    proxies = {"http": "http://5.79.66.2:13200",
               "https": "http://5.79.66.2:13200"}
    # log.msg("Proxy added")
    return {'proxies': proxies}
    user_agent = random.choice(settings.get('USER_AGENT_LIST'))
    headers = {'Accept-Encoding': 'gzip', 'User-Agent': user_agent,
               'Accept': 'application/json, text/javascript, */*; q=0.01', 'X-Requested-With': 'XMLHttpRequest'}
    return {'headers': headers, 'proxies': proxies}
