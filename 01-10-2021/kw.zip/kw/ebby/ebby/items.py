# -*- coding: utf-8 -*-
import scrapy


class EbbyItem(scrapy.Item):
    first_name = scrapy.Field()
    middle_name = scrapy.Field()
    last_name = scrapy.Field()
    image_url = scrapy.Field()
    title = scrapy.Field()
    office_name = scrapy.Field()
    description = scrapy.Field()
    languages = scrapy.Field()
    address = scrapy.Field()
    city = scrapy.Field()
    zipcode = scrapy.Field()
    state = scrapy.Field()
    country = scrapy.Field()
    agent_phone_numbers = scrapy.Field()
    office_phone_numbers = scrapy.Field()
    social = scrapy.Field()
    website = scrapy.Field()
    email = scrapy.Field()
    profile_url = scrapy.Field()

class EbbyUrlItem(scrapy.Item):
    url = scrapy.Field()