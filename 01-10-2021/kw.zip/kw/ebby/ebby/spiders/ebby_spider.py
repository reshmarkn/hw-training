# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
# from databasenotifier import automation_script
from ebby.items import *
from ebby.settings import *
from ebby.proxy import parse_proxy
from pymongo import MongoClient

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}

client = MongoClient('mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
try:
    client.admin.command(
        "shardcollection", MONGO_DB + '.' + MONGO_COLLECTION, key={'profile_url': 1})
except:
    pass

db = client[MONGO_DB]


class EbbySpider(Spider):
    # db = MongoClient('mongodb://localhost:27017')[dbname]
    name = 'ebby'

    def start_requests(self):
        for item in db[MONGO_COLLECTION_URL].find(no_cursor_timeout=True):
            url = item.get('url')
            link = url.strip()
            yield Request(url=link, callback=self.parse, headers=headers)
        # automation_script.Automation_Spider(MONGO_DB, MONGO_COLLECTION)

    def parse(self, response):
        city = ''
        state = ''
        zipcode = ''
        address = ''
        email = ''
        location = ''

        NAME_XPATH = '//h1/text()'
        DESCRIPTION_XPATH = '//section[@class="rng-bio-account-content-description"]//div[@id="body-text-1-preview-7321"]//text()'
        TITLE_XPATH = '//section[@class="rng-bio-account-content-office"]/div/span/text()'
        IMAGE_XPATH = '//div[@class="rng-bio-account-slider"]/img/@src'
        DETALS_XPATH = '//section[@class="rng-bio-account-details"]/ul/li'
        LOCATION_XPATH = '//section[@class="rng-bio-account-content-office"]/div/text()'
        WEBSITE_XPATH = '//a[@title="Visit My Website"]/@href'
        OFFICE_NAME_XPATH = '//section[@class="rng-bio-account-content-office"]/div/strong/text()'
        # Extract values using above XPATHs
        name = response.xpath(NAME_XPATH).extract_first('')
        office_name = response.xpath(
            OFFICE_NAME_XPATH).extract_first('').strip()
        description = response.xpath(DESCRIPTION_XPATH).extract()
        image_url = response.xpath(IMAGE_XPATH).extract_first('')
        title = response.xpath(TITLE_XPATH).extract_first('').strip()
        location = response.xpath(LOCATION_XPATH).extract()
        website = response.xpath(WEBSITE_XPATH).extract_first('').strip()
        details = response.xpath(DETALS_XPATH)

        name_list = name.split(' ')
        if len(name_list) > 3:
            first_name = name.strip()
            middle_name = ''
            last_name = ''
        elif len(name_list) == 3:
            first_name = name_list[0].strip()
            middle_name = name_list[1].strip()
            last_name = name_list[2].strip()
        elif len(name_list) == 2:
            first_name = name_list[0].strip()
            middle_name = ''
            last_name = name_list[1].strip()
        elif len(name_list) == 1:
            first_name = name_list[0].strip()
            middle_name = ''
            last_name = ''
        else:
            first_name = ''
            middle_name = ''
            last_name = ''

        office_phone_numbers = []
        agent_phone_numbers = []

        for det in details:
            key = det.xpath('strong/text()').extract_first('').strip()
            if 'Office' in key:
                office_phone = det.xpath('a/text()').extract_first('').strip()
                office_phone_numbers.append(office_phone)
            if 'Primary' in key:
                agent_phone = det.xpath('a/text()').extract_first('').strip()
                agent_phone_numbers.append(agent_phone)
            if 'Email' in key:
                email = det.xpath('a/text()').extract_first('').strip()

        description = [x.strip() for x in description if x.strip()]
        description = ' '.join(description)
        title = title.split(',')[0] if title else ''

        office_name = office_name.split('|')[1] if office_name else ''

        languages = []
        location = ''.join(location).strip()
        # if '.' in location:
        #     address = location.split('.')[0].strip()
        #     city = location.split('.')[1].strip()
        #     postal = location.split('.')[1].split()
        #     if postal:
        #         state = postal[-2].strip()
        #         zipcode = postal[-1].strip()
        #         city = city.replace(str(state),'').replace(str(zipcode),'')
        # if ',' in location:
        #     address = location.split(',')[0].strip()
        #     city = location.split(',')[1].strip()
        #     postal = location.split(',')[1].split()
        #     if postal:
        #         state = postal[-2].strip()
        #         zipcode = postal[-1].strip()
        #         city = city.replace(str(state),'').replace(str(zipcode),'')
        # if '#' in location:
        #     address = location.split('#')[0].strip()
        #     city = location.split('#')[1].strip()
        #     postal = location.split('#')[1].split()
        #     if postal:
        #         state = postal[-2].strip()
        #         zipcode = postal[-1].strip()
        #         city = city.replace(str(state),'').replace(str(zipcode),'')
        if location:
            try:
                city = re.findall('(.*)[A-Z]{2}.\d{5}',
                                  location)[0].split() if location else ''
            except:
                city = re.findall('(.*)[A-Z]{2}.\d{4}',
                                  location)[0].split() if location else ''

            city = ' '.join(city) if city else ''

            city = city.strip() if city else ''
            if ',' in city:
                city = city.replace(',', '')
            state = re.findall(
                '([A-Z]{2}).\d{5}', location)if location else ''
            state = state[0].strip() if state else ''
            zipcode = re.findall(
                '[A-Z]{2}(.\d{5})', location)if location else ''
            zipcode = zipcode[0].strip() if zipcode else ''
            if not state:
                state = re.findall(
                    '([A-Z]{2}).\d{4}', location)if location else ''
                state = state[0].strip() if state else ''
            if not zipcode:
                zipcode = re.findall(
                    '[A-Z]{2}(.\d{4})', location)if location else ''
                zipcode = zipcode[0].strip() if zipcode else ''

        facebook_url = response.xpath(
            '//ul[@class="rng-agent-bio-content-contact-social"]/li[@class="social-facebook"]/a/@href').extract_first('').strip()
        twitter_url = response.xpath(
            '//ul[@class="rng-agent-bio-content-contact-social"]/li[@class="social-twitter"]/a/@href').extract_first('').strip()
        linkedin_url = response.xpath(
            '//ul[@class="rng-agent-bio-content-contact-social"]/li[@class="social-misc"]/a/@href').extract_first('').strip()
        pinterest_url = response.xpath(
            '//ul[@class="rng-agent-bio-content-contact-social"]/li[@class="social-misc"]/a/@href').extract_first('').strip()
        googleplus_url = response.xpath(
            '//ul[@class="rng-agent-bio-content-contact-social"]/li[@class="social-misc"]/a/@href').extract_first('').strip()
        instagram_url = response.xpath(
            '//ul[@class="rng-agent-bio-content-contact-social"]/li[@class="social-misc"]/a/@href').extract_first('').strip()

        if 'www.facebook.com' in facebook_url:
            facebook_url = facebook_url.strip()
        else:
            facebook_url = ''
        if 'twitter.com' in twitter_url:
            twitter_url = twitter_url.strip()
        else:
            twitter_url = ''
        if 'www.linkedin.com' in linkedin_url:
            linkedin_url = linkedin_url.strip()
        else:
            linkedin_url = ''
        if 'www.pinterest.com' in pinterest_url:
            pinterest_url = pinterest_url.strip()
        else:
            pinterest_url = ''
        if 'google.com' in googleplus_url:
            googleplus_url = googleplus_url.strip()
        else:
            googleplus_url = ''
        if 'www.instagram.com' in instagram_url:
            instagram_url = instagram_url.strip()
        else:
            instagram_url = ''

        other_urls_ = []

        if pinterest_url:
            other_urls_.append(pinterest_url)
        if googleplus_url:
            other_urls_.append(googleplus_url)
        if instagram_url:
            other_urls_.append(instagram_url)

        other_urls = []
        for url in other_urls_:
            if url:
                other_urls.append(url)
            else:
                other_urls = []

        if facebook_url or twitter_url or linkedin_url or other_urls:
            social = {'facebook_url': facebook_url,
                      'twitter_url': twitter_url,
                      'linkedin_url': linkedin_url,
                      'other_urls': other_urls,
                      }
        else:
            social = {}

        if first_name:
            item = EbbyItem(
                first_name=first_name,
                middle_name=middle_name,
                last_name=last_name,
                image_url=image_url,
                title=title,
                office_name=office_name,
                description=description,
                languages=languages,
                address=location,
                city=city,
                zipcode=zipcode,
                country='United States',
                state=state,
                agent_phone_numbers=agent_phone_numbers,
                office_phone_numbers=office_phone_numbers,
                social=social,
                website=website,
                email=email,
                profile_url=response.url,
            )
            # yield item
            try:
                db[MONGO_COLLECTION].insert(dict(item))
            except:
                pass
            print(item)
