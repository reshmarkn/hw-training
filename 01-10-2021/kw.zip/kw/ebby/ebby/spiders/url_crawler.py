import scrapy
import re
import pika
import json
import subprocess
import string
import gzip
from io import StringIO
import io
from scrapy import signals
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from xml.dom import minidom
from slacker import Slacker
from pymongo import MongoClient
from ebby.proxy import parse_proxy
from datetime import datetime
from ebby.settings import *
# from databasenotifier import automation_script
from ebby.items import *
import gzip
headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}


client = MongoClient('mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
try:
    client.admin.command(
        "shardcollection", MONGO_DB + '.' + MONGO_COLLECTION_URL, key={'_id': 1})
except:
    pass

db = client[MONGO_DB]


class EbbyUrlSpider(scrapy.Spider):
    name = 'ebby_crawler'
    allowed_domains = ['ebby.com']

    # def spider_ended(self,):
    #     # cmdline.execute("python script.py".split())
    #     subprocess.call("python script.py ", shell=True)

    def start_requests(self):
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}
        url = 'https://www.ebby.com/sitemapbio.xml.gz'
        yield Request(url=url, callback=self.parse, headers=headers)

    def parse(self, response):
        compressedFile = io.BytesIO()
        compressedFile.write(response.body)
        compressedFile.seek(0)
        decompressedFile = gzip.GzipFile(fileobj=compressedFile, mode='rb')
        sitemap_data = decompressedFile.read()
        xmldoc = minidom.parseString(sitemap_data)
        LOCS = xmldoc.getElementsByTagName('loc')
        for loc in LOCS:
            p_url = loc.childNodes[0].data
            urls = {'url': p_url}
            db[MONGO_COLLECTION_URL].insert(dict(urls))
            # item = EbbyUrlItem()
            # item['url'] = p_url
            # yield item

        # automation_script.Automation_Spider(MONGO_DB, MONGO_COLLECTION_URL)

    # @classmethod
    # def from_crawler(cls, crawler, *args, **kwargs):
    #     spider = super(EbbyUrlSpider, cls).from_crawler(
    #         crawler, *args, **kwargs)
    #     crawler.signals.connect(spider.spider_opened, signals.spider_opened)
    #     crawler.signals.connect(spider.spider_closed, signals.spider_closed)
    #     return spider

    # def spider_opened(self, spider):
    #     print('Opening {} spider'.format(spider.name))

    # def spider_closed(self, spider):
    #     # self.spider_ended()
    #     cmdline.execute("scrapy crawl ebby".split())
    #     # subprocess.call('')
    #     print('Closing {} spider'.format(spider.name))
