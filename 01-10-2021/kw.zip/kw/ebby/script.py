import subprocess
from scrapy import cmdline
from ebby.settings import *
cmdline.execute("scrapy crawl ebby".split())
