# -*- coding: utf-8 -*-
import pymongo
from scrapy.exceptions import DropItem
from robertsbrothers.items import *
from robertsbrothers.settings import *
# from databasenotifier import automation_script
from pymongo import MongoClient


class RobertsbrothersPipeline(object):

    def __init__(self, settings):
        self.mongo_uri = settings.get('MONGO_URI')
        self.mongo_db = settings.get('MONGO_DB')
        self.mongo_collection = settings.get('MONGO_COLLECTION')
        self.dup_key = settings.get('DUP_KEY', '')

    @classmethod
    def from_crawler(cls, crawler):
        return cls(
            settings=crawler.settings
        )

    def open_spider(self, spider):
        # self.client = pymongo.MongoClient(self.mongo_uri)
        # self.db = self.client[self.mongo_db]
        # if self.dup_key:
        #     self.db[self.mongo_collection].create_index(
        #         self.dup_key, unique=True)
        # self.client = pymongo.MongoClient(self.mongo_uri)
        self.client = MongoClient(self.mongo_uri)
        try:
            self.client.admin.command("enablesharding", self.mongo_db)
        except:
            pass
        try:
            self.client.admin.command(
                "shardcollection", self.mongo_db + '.' + self.mongo_collection, key={'_id': 1})
        except:
            pass
        self.db = self.client[self.mongo_db]

    def process_item(self, item, spider):
        if isinstance(item, RobertsbrothersItem):
            try:
                self.db[self.mongo_collection].insert(dict(item))
            except:
                raise DropItem("Dropping duplicate item")
        return item

    def close_spider(self, spider):
        # automation_script.Automation_Spider(
        #     self.mongo_db, self.mongo_collection)
        self.client.close()
