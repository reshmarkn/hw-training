# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from robertsbrothers.items import *
from robertsbrothers.settings import *
from robertsbrothers.proxy import parse_proxy
from xml.dom import minidom

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


class RobertsbrothersSpider(Spider):
    name = 'robertsbrothers_spider'
    allowed_domains = []

    def start_requests(self):
        urls = ['https://www.robertsbrothers.com/sitemap_agent_1.xml',
                'https://www.robertsbrothers.com/sitemap_agent_2.xml',
                'https://www.robertsbrothers.com/sitemap_agent_3.xml']
        # start_url = 'https://www.robertsbrothers.com/sitemap_agent_1.xml'
        for start_url in urls:
            yield Request(url=start_url, callback=self.parse)

    def parse(self, response):

        xmldoc = minidom.parseString(response.text)
        LOCS = xmldoc.getElementsByTagName('loc')
        LOCS.pop(0)
        for loc in LOCS:
            p_url = loc.childNodes[0].data

            yield Request(url=p_url, callback=self.parse_data)

    def parse_data(self, response):

        NAME_XPATH = '//h1[@class="mdl-color-text--accent mdl-cell mdl-cell--12-col notranslate"]/text()'
        TITLE_XPATH = '//span[@class="agent-designation basic-info"]/@data-value'
        EMAIL_XPATH = '//a[@aria-label="Email"]/b/text()'
        MOBILE_XPATH = '//a[@aria-label="mobilephone"]/b/text()'
        PHONE_XPATH = '//a[@aria-label="phone"]/b/text()'
        WEBSITE_XPATH = '//a[@aria-label="Websiteurl"]/@href'
        DESCRIPTION_XPATH = '//div[@class="mdl-cell mdl-cell--12-col"]/p/text() | //div[@class="mdl-cell mdl-cell--12-col"]//span[@style]/text() '
        IMAGE_XPATH = '//img[@class="Agent-detail_photo"]/@src'
        OFFICE_NAME = '//span[@class="bold"]/text()'
        ADDRESS = '//i[@class="b"]/text()'

        name = response.xpath(NAME_XPATH).extract_first('').strip()
        title = response.xpath(TITLE_XPATH).extract()
        email = response.xpath(EMAIL_XPATH).extract()
        agent_phone_numbers = response.xpath(MOBILE_XPATH).extract()
        office_phone_numbers = response.xpath(PHONE_XPATH).extract()
        website_link = response.xpath(WEBSITE_XPATH).extract()
        description = response.xpath(DESCRIPTION_XPATH).extract()
        image = response.xpath(IMAGE_XPATH).extract()
        office_name = response.xpath(OFFICE_NAME).extract()
        full_address = response.xpath(ADDRESS).extract()

        title = ''.join(title).strip() if title else ''
        email = email[0].strip() if email else ''
        agent_phone_numbers = agent_phone_numbers[0].strip(
        ) if agent_phone_numbers else ''
        office_phone_numbers = office_phone_numbers[0].strip(
        ) if office_phone_numbers else ''
        website = website_link[0].strip() if website_link else ''
        description = ''.join(description).replace('/n', '').replace('\n','').strip()
        image_url = image[0].strip() if image else ''
        office_name = office_name[0].strip() if office_name else ''
        address = full_address[0].strip() if full_address else ''
        city = full_address[1]
        state = full_address[2]
        zipcode = full_address[-1]
        languages = []
        social = {}

        first_name = ''
        middle_name = ''
        last_name = ''

        agent_name = name.split()
        if '&' in agent_name:
            first_name = name
        else:
            if len(agent_name) == 1:
                first_name = agent_name[0].strip()
                middle_name = ''
                last_name = ''
            if len(agent_name) == 2:
                first_name = agent_name[0].strip()
                middle_name = ''
                last_name = agent_name[1].strip()
            if len(agent_name) == 3:
                first_name = agent_name[0].strip()
                middle_name = agent_name[1].strip()
                last_name = agent_name[2].strip()
            if len(agent_name) >= 4:
                first_name = name
                middle_name = ''
                last_name = ''

        if first_name:
            item = RobertsbrothersItem(
                title=title,
                office_name=office_name,
                address=address,
                city=city,
                state=state,
                zipcode=zipcode,
                profile_url=response.url,
                languages=languages,
                description=description,
                first_name=first_name,
                middle_name=middle_name,
                last_name=last_name,
                website=website,
                email=email,
                image_url=image_url,
                agent_phone_numbers=agent_phone_numbers,
                office_phone_numbers=office_phone_numbers,
                social=social,
                country='United States',
            )
            yield item
            # print(item)
