# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from robertsbrothers.items import *
from robertsbrothers.settings import *
from robertsbrothers.proxy import parse_proxy

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

headers1 = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}

headers2 = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}


class RobertsbrothersSpider(Spider):
    name = 'robertsbrothers'
    start_urls = ['http://www.robertsbrothers.com/our-realestate-agents']
    allowed_domains = []

    def parse(self, response):
        agents_sel = response.xpath(
            '//div[@class="Agent_details"]/div[@class="toolbar"]')
        for agents in agents_sel:
            profile_url = agents.xpath(
                'ul[@class="button-group"]/li/a[@class="btn"]/@href').extract_first('').strip()
            email = agents.xpath(
                'ul/li//a[@data-reveal-id="ContactMeModal"]/@title').extract_first('').strip()
            website = agents.xpath(
                'ul[@class="button-group"]/li/a[@class="btn"]/@title').extract_first('').strip()
            profile_url = response.urljoin(profile_url)
            meta = {
                'email': email,
                'website': website
            }
            yield Request(url=profile_url, callback=self.parse_next, meta=meta, headers=headers1)

    def parse_next(self, response):
        profile_url = response.url
        email = response.meta['email']
        website = response.meta['website']

        NAME_XPATH = '//span[@class="Agent_name"]/a/span/text()'
        DESCRIPTION_XPATH = '//div[@class="wbcontent"]//text()'
        IMAGE_XPATH = '//div[@class="agent-part-box"]/a/img/@src'
        NEXT_PAGE_XPATH = '//div[@class="toolbar"]/ul/li[2]/a/@href'
        name = response.xpath(NAME_XPATH).extract_first('').strip()
        description = response.xpath(DESCRIPTION_XPATH).extract()
        image_url = response.xpath(IMAGE_XPATH).extract_first('').strip()
        next_page = response.xpath(NEXT_PAGE_XPATH).extract_first('').strip()

        first_name = ''
        middle_name = ''
        last_name = ''

        agent_name = name.split()
        if '&' in agent_name:
            first_name = name
        else:
            if len(agent_name) == 1:
                first_name = agent_name[0].strip()
                middle_name = ''
                last_name = ''
            if len(agent_name) == 2:
                first_name = agent_name[0].strip()
                middle_name = ''
                last_name = agent_name[1].strip()
            if len(agent_name) == 3:
                first_name = agent_name[0].strip()
                middle_name = agent_name[1].strip()
                last_name = agent_name[2].strip()
            if len(agent_name) >= 4:
                first_name = name
                middle_name = ''
                last_name = ''

        description = ' '.join(''.join(description).split())
        image_url = response.urljoin(image_url)

        facebook_url = ''
        linkedin_url = ''
        twitter_url = ''

        social = {}
        other_urls_ = []
        socio_url = response.xpath(
            '//div[@class="small-12 medium-4 large-3 column text-center"]/a/@href').extract()
        if socio_url:
            for media in socio_url:
                if 'facebook' in media and 'facebook.com/RobertsBrothersRealtors' not in media:
                    facebook_url = response.urljoin(media)
                elif 'linkedin' in media:
                    linkedin_url = response.urljoin(media)
                elif 'twitter' in media and 'twitter.com/RobertsBrothers' not in media:
                    twitter_url = response.urljoin(media)
                elif 'pinterest' in media and 'www.pinterest.com/rbrealtors0381/' not in media:
                    other_urls_.append(response.urljoin(media))
                elif 'googleplus' in media and 'plus.google.com/+RobertsbrothersAL/about' not in media:
                    other_urls_.append(response.urljoin(media))
                elif 'youtube' in media and 'www.youtube.com/user/RobertsBrothersHomes' not in media:
                    other_urls_.append(response.urljoin(media))
                elif 'instagram' in media and 'instagram.com/robertsbrothers' not in media:
                    other_urls_.append(response.urljoin(media))
                else:
                    pass

            other_urls = []
            other_urls_ = []
            for url in other_urls_:
                if url:
                    other_urls.append(url)
                else:
                    other_urls = []

            if facebook_url or twitter_url or linkedin_url or other_urls:
                social = {'facebook_url': facebook_url,
                          'twitter_url': twitter_url,
                          'linkedin_url': linkedin_url,
                          'other_urls': other_urls,
                          }
            else:
                social = {}

            address_list = response.xpath(
                '//div[@class="small-12 column office-location nopadding"]//div')
            office_address = []
            for add in address_list:
                de = {}
                office = add.xpath(
                    'ul/li[1]/strong/text()').extract_first('').strip()
                address = add.xpath(
                    'ul/li[2]/text()').extract_first('').strip()
                location = add.xpath(
                    'ul/li[3]/text()').extract_first('').strip()
                office_phone = add.xpath(
                    'ul/li[4]/text()').extract_first('').strip()
                de.update({'office': office})
                de.update({'address': address})
                de.update({'location': location})
                de.update({'office_phone': office_phone})
                office_address.append(de)

        if next_page:
            next_pageurl = response.urljoin(next_page)
            meta = {
                'profile_url': profile_url,
                'email': email,
                'description': description,
                'image_url': image_url,
                'first_name': first_name,
                'middle_name': middle_name,
                'last_name': last_name,
                'website': website,
                'social': social,
                'office_address': office_address
            }
            yield Request(url=next_pageurl, callback=self.parse_final, meta=meta, headers=headers2)

    def parse_final(self, response):
        profile_url = response.meta['profile_url']
        email = response.meta['email']
        description = response.meta['description']
        image_url = response.meta['image_url']
        first_name = response.meta['first_name']
        middle_name = response.meta['middle_name']
        last_name = response.meta['last_name']
        website = response.meta['website']
        languages = []
        social = response.meta['social']
        office_address = response.meta['office_address']

        AGENT_PHONE_XPATH = '//span/label[contains(text(), "Cell")]/following-sibling::text()'
        OFFICE_PHONE_XPATH = '//span/label[contains(text(), "Office")]/following-sibling::text()'
        OFFICE_NAME_XPATH = '//span[@class="Agent_office"]/text()'
        TITLE_XPATH = '//span[@class="Agent_title"]/text()'

        agent_phone = response.xpath(
            AGENT_PHONE_XPATH).extract_first('').strip()
        office_phone = response.xpath(
            OFFICE_PHONE_XPATH).extract_first('').strip()
        office_name = response.xpath(
            OFFICE_NAME_XPATH).extract_first('').strip()
        title = response.xpath(TITLE_XPATH).extract_first('').strip()

        agent_phone_numbers = [agent_phone]if agent_phone else []
        office_phone_numbers = [office_phone]if office_phone else []

        if office_name:
            for i in office_address:
                if i.get('office') in office_name:
                    address = i.get('address')
                    location = i.get('location')
                    city = location.split(', ')[0].strip()
                    postal = location.split(', ')[1]
                    if postal:
                        state = postal.split(' ')[0].strip()
                        zipcode = postal.split(' ')[1].strip()

        # yield item
        if first_name:
            item = RobertsbrothersItem(
                title=title,
                office_name=office_name,
                address=address,
                city=city,
                state=state,
                zipcode=zipcode,
                profile_url=profile_url,
                languages=languages,
                description=description,
                first_name=first_name,
                middle_name=middle_name,
                last_name=last_name,
                website=website,
                email=email,
                image_url=image_url,
                agent_phone_numbers=agent_phone_numbers,
                office_phone_numbers=office_phone_numbers,
                social=social,
                country='United States',
            )
            yield item
