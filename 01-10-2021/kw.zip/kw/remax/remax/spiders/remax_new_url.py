# import scrapy
# import json
# import re
# import requests
# import string
# from scrapy.http import Request, FormRequest
# from remax.items import RemaxItem
# from xml.dom import minidom
# from remax.proxy import parse_proxy
# import gzip
# from pymongo import MongoClient
# from scrapy.shell import inspect_response
# import csv

# headers = {
#     'Accept': 'application/json',
#     'Accept-Encoding': 'gzip, deflate, br',
#     'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8,ml;q=0.7',
#     'Content-Type': 'application/json;charset=UTF-8',
#     'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36'
# }

# db = MongoClient(
#     'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')[MONGO_DB]
# db[MONGO_COLLECTION_URL].create_index('url', unique=True)


# class Remax(scrapy.Spider):
#     name = 'remax_new'
#     allowed_domains = ['remax.com']

#     def start_requests(self):
#         req_response = ''
#         specialties = ['Auctions', 'Business Opportunities', 'Buyer Brokerage', 'Condominiums', 'Development Land', 'Farm Land', 'Farm/Ranch', 'First Time Buyers', 'Foreclosure Property', 'Historic Property', 'Horse Property', 'Hospitality', 'Industrial', 'International', 'Investments', 'Lake/Beach Property',
#                        'Land', 'Luxury Homes', 'Military', 'Multi-Family', 'New Construction', 'vineyards', 'Vineyards', 'Vacation and Resorts', 'Time Share', 'Short Sales', 'Senior Communities', 'Retail', 'Residential Acreages', 'Rentals', 'Relocation', 'RE/MAX Other', 'Property Management', 'Power of Sale', 'Office', ]
#         # specialties = ['Auctions', 'Business Opportunities', 'Farm/Ranch', 'First Time Buyers', 'Historic Property', 'Horse Property', 'Hospitality', 'Industrial', 'International', 'Land',
#         #                'Military', 'Multi-Family', 'vineyards', 'Vineyards', 'Vacation and Resorts', 'Time Share', 'Senior Communities', 'Retail', 'Rentals', 'RE/MAX Other', 'Property Management', 'Power of Sale', 'Office']
#         # specialties = ['Rentals']
#         # 'Condominiums', 'Development Land', 'Farm Land', 'Investments', 'Lake/Beach Property',
#         # 'New Construction', 'Luxury Homes', 'Relocation', 'Residential Acreages', 'Short Sales', 'Foreclosure Property']
#         # languages = ['Afrikaans', 'Albanian', 'Amharic', 'Arabic', 'Aramaic', 'Armenian', 'Assyrian', 'Bengali', 'Bosnian', 'Bulgarian', 'Burmese', 'Cambodian', 'Canadian French', 'Cantonese', 'Catalan', 'Chaldean', 'Cherokee', 'Creole ', 'Croatian', 'Czech', 'Danish', 'Dutch', 'English', 'Estonian', 'Farsi', 'Filipino', 'Finnish', 'Flemish', 'French', 'Gaelic', 'Georgian', 'German', 'Greek', 'Gujarati', 'Hakha Chin', 'Hebrew', 'Hindi', 'Hmong', 'Icelandic', 'Indian', 'Indonesian', 'Italian', 'Japanese',
#         #              'Kannada', 'Korean', 'Latvian', 'Lithuanian', 'Macedonian', 'Malayalam', 'Mandarin', 'Marathi', 'Mongolian', 'Nepali', 'None Listed', 'Norwegian', 'Oriya', 'Pashto', 'Persian', 'Polish', 'Portuguese', 'Punjabi', 'Romanian', 'Russian', 'Serbian', 'Shanghainese', 'Shingala', 'Sindhi', 'Sign Language', 'Sinhalese', 'Slovak', 'Slovenian', 'Spanish', 'Swahili', 'Swedish', 'Tagalog', 'Taiwanese', 'Tamil', 'Telugu', 'Thai', 'Tigrinya', 'Turkish', 'Ukrainian', 'Urdu', 'Vietnamese', 'Welsh', 'Yiddish', 'Yoruba', ]

#         for i in specialties:
#             page = 0
#             payload = {'offset': 0, 'count': 100, 'include': ['agents'], 'filters': {'primaryOfficeCountryCode': 'USA', 'officeMembershipRolesPrimary.relationshipType': 'Employment', 'officeMembershipRolesPrimary.relationshipCode': {'or': [
#                 'OWNER', 'MANAGER', 'ASSOCIATE']}, 'officeMembershipRolesPrimary.activeFlag': 'Y', 'primaryOfficeClass': {'not': ['CRPOFF']}, 'status': 'ACTIVE', 'specialties.subSpecialtyDescr': [str(i)]}, 'custom': {'filters': {}}, 'aggregations': ['languages.languageDescr', 'specialties.subSpecialtyDescr']}

#             url = 'https://public-api-gateway-prod.kube.remax.booj.io/personnel/agent/list'
#             meta = {'specialties': i, 'page': page}
#             yield Request(url=url, headers=headers, body=json.dumps(payload), dont_filter=True, meta=meta, callback=self.parse_url)

#     def parse_url(self, response):
#         meta_ = response.meta
#         url = 'https://public-api-gateway-prod.kube.remax.booj.io/personnel/agent/list'
#         specialties = meta_.get('specialties')
#         page = meta_.get('page')
#         if response.status == 200:
#             json_ = json.loads(response.body_as_unicode())
#             if json_.get('data'):
#                 if json_.get('data').get('agents'):
#                     if json_.get('data').get('agents').get('total'):
#                         total_count = json_.get('data').get(
#                             'agents').get('total')

#                         if total_count < 10000:

#                             if json_.get('data').get('agents').get('results'):
#                                 data = json_.get('data').get(
#                                     'agents').get('results')
#                                 for agent in data:
#                                     # print('666666666666666666666666')
#                                     id_ = agent.get('masterCustomerId', '')
#                                     sample_url = 'https://public-api-gateway-prod.kube.remax.booj.io/personnel/agents/' + \
#                                         str(id_)
#                                     print(sample_url)
#                                     # yield Request(url=sample_url, callback=self.parse_profile, headers=headers, dont_filter=True)
#                                     url_ = {'url': sample_url}
#                                     db.remax_us_url_v1.insert(dict(url_))

#                                 page = page + 100
#                                 payload = {'offset': page, 'count': 100, 'include': ['agents'], 'filters': {'primaryOfficeCountryCode': 'USA', 'officeMembershipRolesPrimary.relationshipType': 'Employment', 'officeMembershipRolesPrimary.relationshipCode': {'or': [
#                                     'OWNER', 'MANAGER', 'ASSOCIATE']}, 'officeMembershipRolesPrimary.activeFlag': 'Y', 'primaryOfficeClass': {'not': ['CRPOFF']}, 'status': 'ACTIVE', 'specialties.subSpecialtyDescr': [str(specialties)]}, 'custom': {'filters': {}}, 'aggregations': ['languages.languageDescr', 'specialties.subSpecialtyDescr']}

#                                 meta_.update(
#                                     {'page': page, 'payload_1': payload, 'total_count': total_count})
#                                 yield Request(url=url, callback=self.parse_url2, headers=headers, dont_filter=True, body=json.dumps(payload), meta=meta_)

#                         else:

#                             with open('uscities.csv', newline='') as csvfile:
#                                 page = 0
#                                 reader = (
#                                     i for i in csv.DictReader(csvfile))
#                                 for row in reader:
#                                     city = row.get('city_ascii')
#                                     state_id = row.get('state_id')
#                                     payload = {'offset': page, 'count': 100, 'include': ['agents'], 'filters': {'primaryOfficeCountryCode': 'USA', 'officeMembershipRolesPrimary.relationshipType': 'Employment', 'officeMembershipRolesPrimary.relationshipCode': {'or': ['OWNER', 'MANAGER', 'ASSOCIATE']}, 'officeMembershipRolesPrimary.activeFlag': 'Y', 'primaryOfficeClass': {
#                                         'not': ['CRPOFF']}, 'status': 'ACTIVE', 'specialties.subSpecialtyDescr': [str(specialties)]}, 'custom': {'filters': {'serviceAreaOrLocation': {'city': str(city), 'state': str(state_id)}}}, 'aggregations': ['languages.languageDescr', 'specialties.subSpecialtyDescr']}

#                                     meta_p = {
#                                         'payload_1': payload, 'page': page, 'total_count': total_count, 'specialties': specialties}
#                                     yield Request(url=url, callback=self.parse_url2, headers=headers, dont_filter=True, body=json.dumps(payload), meta=meta_p)

#     def parse_url2(self, response):

#         url = 'https://public-api-gateway-prod.kube.remax.booj.io/personnel/agent/list'
#         meta_data = response.meta
#         page = meta_data.get('page')
#         payload = meta_data.get('payload_1')

#         specialties = meta_data.get('specialties')
#         total_count = meta_data.get('total_count')
#         if response.status == 200:
#             # if total_count > page:
#             json_ = json.loads(response.body_as_unicode())
#             if json_.get('data'):
#                 if json_.get('data').get('agents'):

#                     if json_.get('data').get('agents').get('results'):
#                         data = json_.get('data').get(
#                             'agents').get('results')
#                         for agent in data:
#                             id_ = agent.get('masterCustomerId', '')
#                             sample_url = 'https://public-api-gateway-prod.kube.remax.booj.io/personnel/agents/' + \
#                                 str(id_)
#                             # yield Request(url=sample_url, callback=self.parse_profile, headers=headers, dont_filter=True)

#                             url_ = {'url': sample_url}
#                             db.remax_us_url_v1.insert(dict(url_))
#                         page = page + 100
#                         payload.update({'offset': page})
#                         print(payload, '667777777777777777777')
#                         meta_data.update(
#                             {'page': page, 'offset': page})
#                         yield Request(url=url, callback=self.parse_url2, headers=headers, dont_filter=True, body=json.dumps(payload), meta=meta_data)

#                     else:
#                         print('completed')
#                         pass

#     # def parse_profile(self, response):
#     #     data = json.loads(response.body_as_unicode())
#     #     pro = data.get('data')
#     #     id_ = pro.get('masterCustomerId', '')

#     #     list_ = []
#     #     first_name = pro.get('firstName', '')
#     #     first_name = first_name.replace(' ', '')
#     #     middle_name = pro.get('middleName', '')
#     #     if middle_name == None:
#     #         middle_name = ''
#     #     middle_name = middle_name.replace(' ', '') if middle_name else ''
#     #     last_name = pro.get('lastName', '')
#     #     last_name = last_name.replace(' ', '')
#     #     office = pro.get('officeMembership')[0].get(
#     #         'office') if pro.get('officeMembership') else ''
#     #     state = office.get('state', '')
#     #     if state == None:
#     #         state = ''
#     #     if not state:
#     #         state = pro.get('licenses', '')[0].get(
#     #             'state', '') if pro.get('licenses') else ''
#     #     city = office.get('city', '')
#     #     if not city:
#     #         city = pro.get('officeMembershipRolesPrimary')[0].get(
#     #             'office') if pro.get('officeMembershipRolesPrimary') else ''
#     #         city = city.get(
#     #             'office', '') if city else ''

#     #     city = city.replace(' ', '')
#     #     state = state.replace(' ', '')
#     #     list_.append(first_name) if first_name else ''
#     #     list_.append(middle_name) if middle_name else ''
#     #     list_.append(last_name) if last_name else ''
#     #     list_.append(city) if city else ''
#     #     list_.append(state) if state else ''
#     #     slug = '-'.join(list_)
#     #     p_url = 'https://www.remax.com/real-estate-agents/' + \
#     #         str(slug) + '/' + str(id_)
#     #     data = {'url': response.url, 'profile_url': p_url}
#     #     db.remax_url.insert(dict(data))
