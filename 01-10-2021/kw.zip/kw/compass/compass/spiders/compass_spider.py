# # -*- coding: utf-8 -*-
# import scrapy
# import re
# import pika
# import json
# import logging
# import scrapy
# import string
# from scrapy.spiders import Spider
# from scrapy.selector import Selector
# from scrapy.http import Request, FormRequest
# from compass.items import *
# from compass.settings import *

# headers = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
#            'accept-encoding': 'gzip, deflate, br',
#            'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
#            'upgrade-insecure-requests': '1',
#            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}

# handler = logging.FileHandler('spider_error.log')
# handler.setLevel('ERROR')
# logging.root.addHandler(handler)
# logger = logging.getLogger('pika')
# logger.propagate = False


# class CompassSpider(scrapy.Spider):
#     name = 'comapss_spider'
#     # start_urls = ['https://www.compass.com/agents/sf/james-shinbori/']
#     allowed_domains = ['www.compass.com']

#     def start_requests(self):
#         # Reading from File
#         # -------------------
#         # f = open('compass_miss.txt')
#         # urls = f.readlines()
#         # for url in urls:
#         #     yield Request(url=url.strip(), callback=self.parse, headers=headers)

#         # # Reading from queue
#         # # ------------------
#         credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
#         connection = pika.BlockingConnection(pika.ConnectionParameters(
#             credentials=credentials, host=QUEUE_IP, socket_timeout=300))
#         channel = connection.channel()
#         while True:
#             channel.basic_qos(prefetch_count=1)
#             method, properties, url = channel.basic_get(queue=QUEUE_NAME)
#             if not url.strip():
#                 break
#             channel.basic_ack(delivery_tag=method.delivery_tag)
#             url = str(url.strip(), encoding='utf-8')
#             if url.strip():
#                 yield Request(url=url.strip(), callback=self.parse, headers=headers, errback=lambda x: self.errback_httpbin(x, url.strip()))
#         connection.close()

#     def parse(self, response):
#         # INITIALIZING_DATA
#         # -----------------
#         title = ''
#         address = ''
#         city = ''
#         state = ''
#         zipcode = ''
#         profile_url = ''
#         description = ''
#         first_name = ''
#         middle_name = ''
#         last_name = ''
#         email = ''
#         image_url = ''
#         agent_phone_number2 = ''

#         agent_phone_numbers = []
#         agent_phone_number = ''
#         office_phone_numbers = []
#         office_phone_number = ''
#         office_numbers = ''
#         agent_phone_number1 = ''
#         social = {}
#         # languages = []
#         office_name = ''
#         country = 'United States'
#         websites = ''
#         other_urls = []
#         facebook_url = ''
#         twitter_url = ''
#         linkedin_url = ''
#         email = ''

#     # GRAB_XPATH
#     # ----------
#         NAME_XPATH = 'a[@class="agents1506-profile-link"]/h1/text()|//h1/text()'
#         TITLE_XPATH = '//div[@class="agents1506-profile-cardTitle"]/text()'
#         EMAIL_XPATH = '//div[@class="agents1506-profile-cardEmail"]/a/text()'
#         PHONE_NUMBERS_XPATH = '//div[@class="agents1506-profile-cardPhone"]/a/text()'
#         OFFICE_NUMBER_XPATH = '//a[@class="consumerFooter-office"]/text()'
#         DESCRIPTION_XPATH = '//div[contains(@class, "profile-aboutBlock")]/p/text()'
#         IMAGE_XPATH = '//img[@class="agents1506-profile-cardImage"]/@src'
#         ADDRESS_XPATH = '//div[@class="consumerFooter-pane"]/p[1]//text()'
#         LOCATION_XPATH = '//div[@class="consumerFooter-pane"]/p[2]/text()'
#         OFFICE_NAME_XPATH = '//h4[@class="consumerFooter-header"]/text()'
#         SOCIAL_XPATH = '//div[contains(text(), "Social Media")]/following-sibling::p//a/@href'
#         PHONE_NUMBERS_XPATH = '//div[@class="agents1506-profile-cardPhone"]/a/text()'
#         OFFICE_NUMBER_XPATH = '//a[@class="consumerFooter-office"]/text()'
#         LANGUAGES_XPATH = '//p[contains(text(), "Languages")]/text()'
#         # WEBSITES_XPATH = ''

#     # EXTRACT_XPATH
#     # -------------
#         name = response.xpath(NAME_XPATH).extract_first('').strip()
#         titles = response.xpath(TITLE_XPATH).extract_first('').strip()
#         emails = response.xpath(EMAIL_XPATH).extract_first('').strip()
#         phone_numbers = response.xpath(PHONE_NUMBERS_XPATH).extract()
#         office_numbers = response.xpath(
#             OFFICE_NUMBER_XPATH).extract_first('').strip()
#         description = response.xpath(DESCRIPTION_XPATH).extract()
#         image_url = response.xpath(IMAGE_XPATH).extract_first('')
#         address = response.xpath(ADDRESS_XPATH).extract()
#         location = response.xpath(LOCATION_XPATH).extract()
#         office_name = response.xpath(OFFICE_NAME_XPATH).extract_first('')
#         social_urls = response.xpath(SOCIAL_XPATH).extract()
#         phone_numbers = response.xpath(PHONE_NUMBERS_XPATH).extract()
#         office_numbers = response.xpath(
#             OFFICE_NUMBER_XPATH).extract_first('').strip()
#         languages = response.xpath(LANGUAGES_XPATH).extract_first('').strip()
#         # websites = response.xpath(WEBSITES_XPATH).extract()

#     # Cleaning data
#     # -------------
#         TITLE_XPATH = '//div[@class="agents1506-profile-cardTitle"]/text()'
#         titles = response.xpath(TITLE_XPATH).extract_first('').strip()
#         agent_title = ''
#         title = re.sub(
#             '\w+\s?#?\s?:?\s{0,2}\d{4,}\s?/?\&?\d+', '', titles) if titles else ''
#         if ' | ' in title or ' \ ' in title or ' / ' in title:
#             if ' | ' in title:
#                 agent_title = title.replace(' | ', ',')
#             if ' \ ' in title:
#                 agent_title = title.replace(' \ ', ',')
#             if ' / ' in title:
#                 agent_title = title.replace(' / ', ',')
#         else:
#             agent_title = title
#         agent_title = agent_title.strip().strip(',') if agent_title else ''

#         if agent_title:
#             agent_title = agent_title.split(',')[0].strip()

#     # email cleaning
#     # ---------------
#         if emails:
#             if '| DRE' in emails:
#                 email = emails.split('|')[0].strip()
#             elif '| CalBRE' in emails:
#                 email = emails.split('|')[0].strip()
#             else:
#                 email = emails

#     # name cleaning
#     # --------------
#         name = name.split()
#         if len(name) == 1:
#             first_name = name[0].strip() if name[0] else ''
#             middle_name = ''
#             last_name = ''
#         if len(name) == 2:
#             first_name = name[0].strip() if name[0] else ''
#             middle_name = ''
#             last_name = name[1].strip() if name[1] else ''
#         if len(name) == 3:
#             first_name = name[0].strip() if name[0] else ''
#             middle_name = name[1].strip() if name[1] else ''
#             last_name = name[2].strip() if name[2] else ''
#         if len(name) >= 4:
#             first_name = ' '.join(name)
#             middle_name = ''
#             last_name = ''

#     # phone_numbercleaning
#     # ---------------------
#         if phone_numbers:
#             for number in phone_numbers:
#                 if 'M:' in number:
#                     agent_phone = number.strip()
#                     agent_phone_number1 = agent_phone.replace('M:', '').strip()
#                 if 'O:' in number:
#                     agent_phone = number.strip()
#                     agent_phone_number2 = agent_phone.replace('O:', '').strip()

#         if agent_phone_number1 == []:
#             agent_phone_numbers = [
#                 agent_phone_number2] if agent_phone_number2 else []
#         else:
#             agent_phone_numbers = [
#                 agent_phone_number1] if agent_phone_number1 else []
#         office_phone_numbers = [office_numbers] if office_numbers else []

#     # address and description cleaning
#     # --------------------------------
#         description = ' '.join(
#             ''.join(description).split()) if description else ''
#         if address:
#             address = ' '.join(','.join(address).split())
#             if location:
#                 location = ' '.join(
#                     ''.join(location).split()) if location else ''
#                 loc = location.rsplit(' ', 2) if location else ''
#                 zipcode = loc[2] if loc else ''
#                 state = loc[1] if loc else ''
#                 city = loc[0] if loc else ''
#         else:
#             address_regex = re.findall(
#                 '<footer(?:.|\n)*?</footer>', response.body_as_unicode())
#             if address_regex:
#                 sel = Selector(text=str(address_regex))
#                 address = sel.xpath(ADDRESS_XPATH).extract()
#                 location = sel.xpath(LOCATION_XPATH).extract()
#                 office_name = sel.xpath(OFFICE_NAME_XPATH).extract_first('')
#                 address = ' '.join(','.join(address).split())
#                 if location:
#                     location = ' '.join(
#                         ''.join(location).split()) if location else ''
#                     loc = location.rsplit(' ', 2) if location else ''
#                     zipcode = loc[2].strip('\\n') if loc else ''
#                     state = loc[1].strip('\\n') if loc else ''
#                     city = loc[0].strip('\\n') if loc else ''

#         profile_url = response.url

#     # socialnetworking
#     # ----------------
#         if social_urls:
#             for url_ in social_urls:
#                 url_ = url_.strip()
#                 if 'http' in url_:
#                     if 'facebook.com' in url_.lower():
#                         facebook_url = url_
#                     elif 'twitter.com' in url_.lower():
#                         twitter_url = url_
#                     elif 'linkedin.com' in url_.lower():
#                         linkedin_url = url_
#                     else:
#                         other_urls.append(url_)

#             social = {
#                 'facebook_url': facebook_url,
#                 'twitter_url': twitter_url,
#                 'linkedin_url': linkedin_url,
#                 'other_urls': other_urls if other_urls else '',
#             }
#         else:
#             social = {}
#         if languages:

#             languages = [lang.strip()
#                      for lang in languages.split(',') if languages]

#     # additional conditions
#     # ---------------------
#         office_name = office_name if office_name else ''
#         if office_name == 'Our Region':
#             office_name = ''

#         if agent_phone_numbers == [".."]:
#             agent_phone_numbers = []

#     # YIELDING_DATA
#     # -------------
#         if first_name:
#             item = CompassItem(
#                 title='',
#                 office_name=office_name,
#                 address=address,
#                 city=city,
#                 state=state,
#                 zipcode=zipcode,
#                 profile_url=profile_url,
#                 languages=languages,
#                 description=description,
#                 first_name=first_name,
#                 middle_name=middle_name,
#                 last_name=last_name,
#                 website=websites,
#                 email=email,
#                 image_url=image_url,
#                 agent_phone_numbers=agent_phone_numbers,
#                 office_phone_numbers=office_phone_numbers,
#                 social=social,
#                 country=country,
#             )
#             yield item

#     # # ERRORBACK_HANDLING
#     # # ------------------
#     # def errback_httpbin(self, failure, url):
#     #     credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
#     #     connection = pika.BlockingConnection(pika.ConnectionParameters(
#     #         credentials=credentials, host=QUEUE_IP, socket_timeout=600))
#     #     channel = connection.channel()
#     #     channel.queue_declare(queue=QUEUE_NAME, durable=True)
#     #     channel.basic_publish(
#     #         exchange='', routing_key=QUEUE_NAME, body=url)
#     #     connection.close()
