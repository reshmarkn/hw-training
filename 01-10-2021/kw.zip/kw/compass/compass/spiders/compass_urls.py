# -*- coding: utf-8 -*-
import scrapy
import string
from scrapy.http import Request, FormRequest
from compass.items import *
from xml.dom import minidom
from compass.settings import *
from scrapy import signals
import subprocess
# from databasenotifier import automation_script
import gzip
import re
from pymongo import MongoClient

headers = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
           'accept-encoding': 'gzip, deflate, br',
           'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
           'upgrade-insecure-requests': '1',
           'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}


class CompassSpider(scrapy.Spider):
    name = 'compass_urls'
    start_urls = ['https://www.compass.com/sitemaps/agent-pages/sitemap_1.xml']

    # def spider_ended(self):
    #     automation_script.Automation_Spider(MONGO_DB, MONGO_COLLECTION_URL)
    #     # subprocess.call("python q_insert.py ", shell=True)

    def parse(self, response):
        urls = re.findall('https.*?>', response.body_as_unicode())
        for links in urls:
            link = links.replace('</loc>', '')
            # urls = {'url': link}
            # db.compass_url_test.insert(dict(urls))
            item = CompassUrlItem()
            item['url'] = link
            yield item

    @classmethod
    def from_crawler(cls, crawler, *args, **kwargs):
        spider = super(CompassSpider, cls).from_crawler(
            crawler, *args, **kwargs)
        crawler.signals.connect(spider.spider_opened, signals.spider_opened)
        crawler.signals.connect(spider.spider_closed, signals.spider_closed)
        return spider

    def spider_opened(self, spider):
        print('Opening {} spider'.format(spider.name))

    def spider_closed(self, spider):
        print('%%%%%%%%%%%%%%%%%%%%%%%%%%')
        self.spider_ended()
        print('Closing {} spider'.format(spider.name))
