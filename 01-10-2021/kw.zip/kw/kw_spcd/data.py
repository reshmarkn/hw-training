import re
import csv
import json
import random
import requests
import logging
import comparison
from xpath import *
from log_file import *
from slacker import Slacker
from datetime import datetime
from pymongo import MongoClient
from scrapy.selector import Selector
from sample_genarate import * 
# today = datetime.now().strftime('%Y_%m_%d')

PROXY_LIST = [
    '68.183.58.145:5566',
    '157.230.189.5:5566'
]
PROXY = random.choice(PROXY_LIST)
proxy_url = "http://%s" % PROXY
proxies = {"http": "http://%s" % PROXY,
           "https": "http://%s" % PROXY}

headers = {

    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
}

country = 'United States'
def alliebeth_fun(links):

    print('alliebeth')
    name_ = []
    title_ = []
    image_ = []
    office_name_ = []
    agent_phone_ = []
    address_ = []
    description_ = []
    city_ = []
    state_ = []
    zipcode_ = []
    country_ = []
    message = []
    office_phone = ''
    languages = ''
    email = ''
    website = ''
    social = ''
    domain = 'alliebeth_v1'
    row_data = []
    for link in links:
        link = 'https:' + link
        # res = requests.get(link, headers=headers)
        res = requests.get(link, headers=headers,proxies=proxies)
        sel = Selector(text=res.content)
        if res.status_code == 200:
            name = sel.xpath(alliebeth.NAME_XPATH).extract_first('')
            title = sel.xpath(alliebeth.TITLE_XPATH).extract_first('')
            image = sel.xpath(alliebeth.IMAGE_XPATH).extract_first('')
            office_name = sel.xpath(
                alliebeth.OFFICE_NAME_XPATH).extract_first('')
            agent_phone = sel.xpath(
                alliebeth.AGENT_PHONE_XPATH).extract_first('')
            address = sel.xpath(alliebeth.ADDRESS_XPATH).extract_first('')
            description = ''.join(sel.xpath(
                alliebeth.DESCRIPTION_XPATH).extract())
            city = sel.xpath(alliebeth.CITY_XPATH).extract_first('')
            state = sel.xpath(alliebeth.STATE_XPATH).extract_first('')
            zipcode = sel.xpath(alliebeth.ZIPCODE_XPATH).extract_first('')
            country = sel.xpath(alliebeth.COUNTRY_XPATH).extract_first('')

            name_.append(name) if name else ''
            title_.append(title) if title else ''
            image_.append(image) if image else ''
            office_name_.append(office_name) if office_name else ''
            agent_phone_.append(agent_phone) if agent_phone else ''
            address_.append(address) if address else ''
            description_.append(description) if description else ''
            city_.append(city) if city else ''
            zipcode_.append(zipcode) if zipcode else ''
            state_.append(state) if state else ''
            country_.append(country) if state else ''
            row = [link, name, title, image, office_name, agent_phone, office_phone, address,
                    description, city, zipcode, state, country, languages, email, website, social]
            row_data.append(row)
            comparison.CollectDb(link, name, title, image, office_name, agent_phone, office_phone, address,
                                 description, city, zipcode, state, country, languages, email, website, social, domain)
    Sample_Genaration(domain,row_data)
    if name_ == []:
        msg = 'name field is empty in alliebeth'
        message.append(msg)
    if title_ == []:
        msg = 'title field is empty in alliebeth'
        message.append(msg)
    # if office_name_ == []:
    #     msg = 'office_name field is empty in alliebeth'
    #     message.append(msg)
    if agent_phone_ == []:
        msg = 'agent_phone field is empty in alliebeth'
        message.append(msg)
    if address_ == []:
        msg = 'address field is empty in alliebeth'
        message.append(msg)
    if description == []:
        msg = 'description field is empty in alliebeth '
        message.append(msg)
    if zipcode_ == []:
        msg = 'zipcode empty in alliebeth '
        message.append(msg)
    if state_ == []:
        msg = 'state empty in alliebeth '
        message.append(msg)
    if country_ == []:
        msg = 'country empty in alliebeth '
        message.append(msg)
    slack_note(message,domain)


def harrynorman_fun(links):
    print('harrynorman')
    name_ = []
    title_ = []
    image_ = []
    office_name_ = []
    agent_phone_ = []
    office_phone_ = []
    email_ = []
    address_ = []
    description_ = []
    languages_ = []
    website_ = []
    social_ = []
    message = []
    city = ''
    zipcode = ''
    state = ''
    country = 'United States'
    email = ''
    domain = 'harrynorman'
    row_data = []
    for link in links:
        link = 'https://www.harrynorman.com' + link
        res = requests.get(link, headers=headers,proxies=proxies)
        # res = requests.get(link, headers=headers)
        sel = Selector(text=res.content)

        name = sel.xpath(harrynorman.NAME_XPATH).extract_first('')
        title = sel.xpath(harrynorman.TITLE_XPATH).extract_first('')
        image = sel.xpath(harrynorman.IMAGE_XPATH).extract_first('')
        office_name = sel.xpath(
            harrynorman.OFFICE_NAME_XPATH).extract_first('')
        agent_phone = sel.xpath(
            harrynorman.AGENT_PHONE_XPATH).extract_first('')
        office_phone = sel.xpath(
            harrynorman.OFFICE_PHONE_XPATH).extract_first('')
        email = sel.xpath(harrynorman.EMAIL_XPATH).extract_first()
        address = ''.join(
            sel.xpath(harrynorman.ADDRESS_XPATH).extract()).strip()
        description = ''.join(sel.xpath(
            harrynorman.DESCRIPTION_XPATH).extract())
        languages = sel.xpath(
            harrynorman.LANGUAGES_XPATH).extract_first('')
        website = sel.xpath(harrynorman.WEBSITE_XPATH).extract_first('')
        social = sel.xpath(harrynorman.SOCIAL_XPATH).extract()

        name_.append(name) if name else ''
        title_.append(title) if title else ''
        image_.append(image) if image else ''
        office_name_.append(office_name) if office_name else ''
        agent_phone_.append(agent_phone) if agent_phone else ''
        office_phone_.append(office_phone) if office_phone else ''
        address_.append(address) if address else ''
        description_.append(description) if description else ''
        languages_.append(languages) if languages else ''
        website_.append(website) if website else ''
        social_.extend(social) if social else ''
        # print(description, '???????????')
        row = [link, name, title, image, office_name, agent_phone, office_phone, address,
                description, city, zipcode, state, country, languages, email, website, social]
        row_data.append(row)
        comparison.CollectDb(link, name, title, image, office_name, agent_phone, office_phone, address,
                             description, city, zipcode, state, country, languages, email, website, social, domain)
    Sample_Genaration(domain,row_data)

    if name_ == []:
        msg = 'name field is empty in harrynorman'
        message.append(msg)
    if title_ == []:
        msg = 'title field is empty in harrynorman'
        message.append(msg)
    if office_name_ == []:
        msg = 'office_name field is empty in harrynorman'
        message.append(msg)
    if agent_phone_ == []:
        msg = 'agent_phone field is empty in harrynorman'
        message.append(msg)
    if address_ == []:
        msg = 'address field is empty in harrynorman'
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in harrynorman '
        message.append(msg)
    if languages_ == []:
        msg = 'languages is empty in harrynorman'
        message.append(msg)
    if website_ == []:
        msg = 'website is empty in harrynorman'
        message.append(msg)
    if social_ == []:
        msg = 'social is empty in harrynorman'
        message.append(msg)
    slack_note(message,domain)

def homerealestate_fun(agent_list):
    print('homerealestate')
    email_ = []
    description_ = []
    address_ = []
    social_ = []
    message = []
    links = []
    name_ = []
    title_ = []
    agent_phone_ = []
    office_phone_ = []
    office_name_ = []
    image_url_ = []
    count = 0
    city = ''
    zipcode = ''
    state = ''
    country = 'United States'
    website = ''
    languages = ''
    domain = 'home_realestate'
    row_data = []
    for agent in agent_list:
        profile_url = agent.xpath(
            home_realestate.PROFILE_URL_XPATH).extract_first('')
        name = agent.xpath(home_realestate.NAME_XPATH).extract_first('')
        title = agent.xpath(home_realestate.TITLE_XPATH).extract_first('')
        agent_phone = agent.xpath(
            home_realestate.AGENT_PHONE_XPATH).extract_first('')
        office_phone = agent.xpath(
            home_realestate.OFFICE_PHONE_XPATH).extract_first()
        office_name = agent.xpath(
            home_realestate.OFFICE_NAME_XPATH).extract_first('')
        image_url = agent.xpath(
            home_realestate.IMAGE_XPATH).extract_first('')

        # res = requests.get(profile_url, headers=headers)
        res = requests.get(profile_url, headers=headers,proxies=proxies)
        sel = Selector(text=res.content)
        if res.status_code == 200:
            email = sel.xpath(
                home_realestate.EMAIL_XPATH).extract_first('')
            description = sel.xpath(
                home_realestate.DESCRIPTION_XPATH).extract()
            description = ' '.join(''.join(description).split())
            address = sel.xpath(
                home_realestate.ADDRESS_XPATH).extract_first('')
            address_2 = sel.xpath(
                home_realestate.ADDRESS_XPATH_2).extract_first('')
            facebook_url = sel.xpath(
                home_realestate.FACEBOOK_XPATH).extract_first('')
            linkedin_url = sel.xpath(
                home_realestate.LINKED_IN_XPATH).extract_first('')
            instagram_url = sel.xpath(
                home_realestate.INSTAGRAM_XPATH).extract_first('')
            twitter_url = sel.xpath(
                home_realestate.TWITTER_XPATH).extract_first('')
            youtube_url = sel.xpath(
                home_realestate.YOUTUBE_XPATH).extract_first('')
            address_details = address if address else address_2
            social = []
            social.append(facebook_url) if facebook_url else ''
            social.append(linkedin_url) if linkedin_url else ''
            social.append(instagram_url) if instagram_url else ''
            social.append(twitter_url) if twitter_url else ''
            social.append(youtube_url) if youtube_url else ''

            name_.append(name) if name else ''
            title_.append(title) if title else ''
            agent_phone_.append(agent_phone) if agent_phone else ''
            office_phone_.append(office_phone) if office_phone else ''
            office_name_.append(office_name) if office_name else ''
            image_url_.append(image_url) if image_url else ''
            email_.append(email) if email else ''
            description_.append(description) if description else ''
            address_.append(address_details) if address_details else ''
            social_.extend(social) if social else ''

            count = count + 1
        if count > 24:
            break
        row = [profile_url, name, title, image_url, office_name, agent_phone, office_phone,
                address_details, description, city, zipcode, state, country, languages, email, website, social]
        row_data.append(row)
        comparison.CollectDb(profile_url, name, title, image_url, office_name, agent_phone, office_phone,
                             address_details, description, city, zipcode, state, country, languages, email, website, social, domain)
    Sample_Genaration(domain,row_data)
    if name_ == []:
        msg = 'name fields is empty in home_realestate'
        message.append(msg)
    if office_name_ == []:
        msg = 'office_name is empty in home_realestate '
        message.append(msg)
    if title_ == []:
        msg = 'title fields is empty in homerealestate'
        message.append(msg)
    if agent_phone_ == []:
        msg = 'agent_phone is empty in homerealestate'
        message.append(msg)
    if office_phone_ == []:
        msg = 'office_phone is empty in homerealestate'
        message.append(msg)
    if image_url_ == []:
        msg = 'image_url is empty in homerealestate'
        message.append(msg)
    if email_ == []:
        msg = 'email field is empty in homerealestate'
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in homerealestate'
        message.append(msg)
    if address_ == []:
        msg = 'address field is empty in homerealestate'
        message.append(msg)
    if social_ == []:
        msg = 'social is empty in homerealestate'
        message.append(msg)
    slack_note(message,domain)

def royallepage_fun(links):
    print('royallepage')
    title_ = []
    city_ = []
    address_ = []
    languages_ = []
    description_ = []
    name_ = []
    office_name_ = []
    website_ = []
    email_ = []
    zipcode_ = []
    image_url_ = []
    agent_phone_ = []
    office_phone_ = []
    social_ = []
    message = []
    city = ''
    state = ''
    country = 'United States'
    domain = 'royallepage_data'
    row_data = []    
    for link in links:
        res = requests.get(link, headers=headers,proxies=proxies)
        sel = Selector(text=res.content)
        if res.status_code == 200:
            title = sel.xpath(royallepage.TITLE_XPATH).extract_first('')
            city_state = sel.xpath(
                royallepage.CITY_STATE_XPATH).extract_first('')
            address = sel.xpath(
                royallepage.ADDRESS_XPATH).extract_first('')
            languages = sel.xpath(
                royallepage.LANGUAGES_XPATH).extract_first('')
            description_1 = sel.xpath(
                royallepage.DESCRIPTION_XPATH_1).extract()
            description_2 = sel.xpath(
                royallepage.DESCRIPTION_XPATH_2).extract()
            name = sel.xpath(royallepage.NAME_XPATH).extract_first('')
            office_name = sel.xpath(royallepage.OFC_XPATH).extract()
            websites = sel.xpath(
                royallepage.WEBSITES_XPATH).extract_first('')
            email = sel.xpath(royallepage.EMAIL_XPATH).extract()
            zipcode = sel.xpath(
                royallepage.ZIPCODE_XPATH).extract_first('')
            image_url = sel.xpath(
                royallepage.IMAGE_XPATH).extract_first('')
            agent_phone = sel.xpath(
                royallepage.AGENT_PHONE_XPATH).extract_first('')
            office_phone = sel.xpath(
                royallepage.OFFICE_PHONE_XPATH).extract_first('')
            facebook_url = sel.xpath(
                royallepage.FACEBOOK_XPATH).extract_first('')
            linkedin_url = sel.xpath(
                royallepage.LINKEDIN_XPATH).extract_first('')
            twitter_url = sel.xpath(
                royallepage.TWITTER_XPATH).extract_first('')
            other_urls = sel.xpath(royallepage.OTHER_URLS_XPATH).extract()

            description_1 = ' '.join(' '.join(description_1).split())
            description_2 = ' '.join(' '.join(description_2).split())
            description = description_1 if description_1 else description_2
            office_name = ' '.join(' '.join(office_name).split())
            email = ''.join(email).strip()
            social = []
            social.append(facebook_url) if facebook_url else ''
            social.append(linkedin_url) if linkedin_url else ''
            social.append(other_urls) if other_urls else ''
            title_.append(title) if title else ''
            city_.append(city_state) if city_state else ''
            address_.append(address) if address else ''
            languages_.append(languages) if languages else ''
            description_.append(description) if description else ''
            name_.append(name) if name else ''
            website_.append(websites) if websites else ''
            email_.append(email) if email else ''
            zipcode_.append(zipcode) if zipcode else ''
            image_url_.append(image_url) if image_url else ''
            office_name_.append(office_name) if office_name else ''
            agent_phone_.append(agent_phone) if agent_phone else ''
            office_phone_.append(office_phone) if office_phone else ''
            social_.extend(social) if social else ''
            address = address + city_state
        row = [link, name, title, image_url, office_name, agent_phone, office_phone, address,
                description, city, zipcode, state, country, languages, email, websites, social]
        row_data.append(row)
        comparison.CollectDb(link, name, title, image_url, office_name, agent_phone, office_phone, address,
                             description, city, zipcode, state, country, languages, email, websites, social, domain)
    Sample_Genaration(domain,row_data)
    if title_ == []:
        msg = 'title fields is empty in royallepage'
        message.append(msg)
    if city_ == []:
        msg = 'city state is empty in royallepage'
        message.append(msg)
    if address_ == []:
        msg = 'address field is empty in royallepage'
        message.append(msg)
    if languages_ == []:
        msg = 'languages fields is empty in royallepage'
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in royallepage'
        message.append(msg)
    if name_ == []:
        msg = 'name fields is empty in royallepage'
        message.append(msg)
    if website_ == []:
        msg = 'website fields is empty in royallepage'
        message.append(msg)
    # if email_ == []:
    #     msg = 'email field is empty in royallepage'
    #     message.append(msg)
    if zipcode_ == []:
        msg = 'zipcode fields is empty in royallepage'
        message.append(msg)
    if image_url_ == []:
        msg = 'image_url is empty in royallepage'
        message.append(msg)
    if office_name_ == []:
        msg = 'office_name is empty in royallepage '
        message.append(msg)
    if agent_phone_ == []:
        msg = 'agent_phone is empty in royallepage'
        message.append(msg)
    if office_phone_ == []:
        msg = 'office_phone is empty in royallepage'
        message.append(msg)
    if social_ == []:
        msg = 'social is empty in royallepage'
        message.append(msg)
    slack_note(message,domain)


def guarantee_fun(agent_list):
    print('guarantee')
    name_ = []
    title_ = []
    address_ = []
    description_ = []
    image_url_ = []
    email_ = []
    agent_phone_ = []
    website_ = []
    message = []
    count = 0
    city = ''
    zipcode = ''
    languages = ''
    social = ''
    state = ''
    office_phone = ''
    country = 'United States'
    domain = 'guarantee_v2'
    row_data = []
    for agent in agent_list:
        response1 = requests.get(agent, headers=headers,proxies=proxies)
        sel1 = Selector(text=response1.content)
        office_name = sel1.xpath(
            guarantee.OFFICE_NAME_XPATH).extract_first('')
        profile_url = sel1.xpath(guarantee.PROFILE_URL_XPATH).extract()
        break
    for link in profile_url:
        count = count + 1
        res = requests.get(link, headers=headers,proxies=proxies)
        sel = Selector(text=res.content)
        if res.status_code == 200:
            name = sel.xpath(guarantee.NAME_XPATH).extract_first('')
            title = sel.xpath(guarantee.TITLE_XPATH).extract_first('')
            image = sel.xpath(guarantee.IMAGE_XPATH).extract()
            agent_phone = sel.xpath(
                guarantee.AGENT_PHONE_XPATH).extract_first('')
            email = sel.xpath(guarantee.EMAIL_XPATH).extract_first('')
            website = sel.xpath(guarantee.WEBSITE_XPATH).extract_first('')
            address = ''.join(sel.xpath(guarantee.ADDRESS_XPATH).extract())
            description = sel.xpath(guarantee.DESCRIPTION_XPATH).extract()

            description = ' '.join(''.join(description).split())
            image_url = ''.join(image)
            title_.append(title) if title else ''
            description_.append(description) if description else ''
            name_.append(name) if name else ''
            website_.append(website) if website else ''
            email_.append(email) if email else ''
            address_.append(address) if address else ''
            image_url_.append(image_url)if image_url else ''
            agent_phone_.append(agent_phone) if agent_phone else ''
            if count > 24:
                break

            row = [link, name, title, image_url, office_name, agent_phone,
                    office_phone, address, description, city, zipcode, state, country, languages, email, website, social]
            row_data.append(row)
            comparison.CollectDb(link, name, title, image_url, office_name, agent_phone, office_phone, address,
                                 description, city, zipcode, state, country, languages, email, website, social, domain)
    Sample_Genaration(domain,row_data)
    if title_ == []:
        msg = 'title fields is empty in guarantee'
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in guarantee'
        message.append(msg)
    if name_ == []:
        msg = 'name fields is empty in guarantee'
        message.append(msg)
    if website_ == []:
        msg = 'website fields is empty in guarantee'
        message.append(msg)
    if email_ == []:
        msg = 'email field is empty in guarantee'
        message.append(msg)
    if address_ == []:
        msg = 'address field is empty in guarantee'
        message.append(msg)
    if image_url_ == []:
        msg = 'image_url is empty in guarantee'
        message.append(msg)
    if agent_phone_ == []:
        msg = 'agent_phone is empty in guarantee'
        message.append(msg)
    slack_note(message,domain)



def huff_realty_fun(agent_list):
    print('huff_realty')
    description_ = []
    social_ = []
    message = []
    name_ = []
    title_ = []
    agent_phone_ = []
    office_phone_ = []
    office_name_ = []
    address_ = []
    image_url_ = []
    city_ = []
    count = 0
    city = ''
    zipcode = ''
    state = ''
    country = 'United States'
    languages = ''
    email = ''
    website = ''
    domain = 'huff_realty_data'
    row_data = []
    for agent in agent_list:
        urls = agent.xpath(huff_realty.PROFILE_URL_XPATH).extract_first('')
        name = agent.xpath(huff_realty.NAME_XPATH).extract_first('')
        title = agent.xpath(huff_realty.TITLE_XPATH).extract_first('')
        agent_phone = agent.xpath(
            huff_realty.AGENT_PHONE_XPATH).extract_first('')
        office_phone = agent.xpath(
            huff_realty.OFFICE_PHONE_XPATH).extract_first('')
        office_name = agent.xpath(
            huff_realty.OFFICE_NAME_XPATH).extract_first('')
        image_url = agent.xpath(huff_realty.IMAGE_XPATH).extract_first('')
        address = agent.xpath(huff_realty.ADDRESS_XPATH).extract_first('')
        city_state_zip = agent.xpath(
            huff_realty.CITY_XPATH).extract_first('')
        if 'a href=' not in urls:
            res = requests.get(urls, headers=headers,proxies=proxies)
            sel = Selector(text=res.content)
            url = res.url
        if res.status_code == 200:
            description = sel.xpath(
                huff_realty.DESCRIPTION_XPATH).extract()
            facebook_url = sel.xpath(
                huff_realty.FACEBOOK_XPATH).extract_first('')
            linkedin_url = sel.xpath(
                huff_realty.LINKEDIN_XPATH).extract_first('')
            twitter_url = sel.xpath(
                huff_realty.TWITTER_XPATH).extract_first('')
            instagram_url = sel.xpath(
                huff_realty.INSTAGRAM_XPATH).extract_first('')
            pinterest_url = sel.xpath(
                huff_realty.PINTEREST_XPATH).extract_first('')
            youtube_url = sel.xpath(
                huff_realty.YOUTUBE_XPATH).extract_first('')
            googleplus_url = sel.xpath(
                huff_realty.GOOGLE_PLUS_XPATH).extract_first('')

            description = ' '.join(''.join(description).split())
            social = []
            social.append(facebook_url) if facebook_url else ''
            social.append(linkedin_url) if linkedin_url else ''
            social.append(twitter_url) if twitter_url else ''
            social.append(youtube_url) if youtube_url else ''
            social.append(googleplus_url) if googleplus_url else ''

            count = count + 1
            if count > 24:
                break

        name_.append(name) if name else ''
        title_.append(title) if title else ''
        agent_phone_.append(agent_phone) if agent_phone else ''
        office_phone_.append(office_phone) if office_phone else ''
        office_name_.append(office_name) if office_name else ''
        city_.append(city_state_zip) if city_state_zip else ''
        image_url_.append(image_url) if image_url else ''
        address_.append(address) if address else ''
        description_.append(description) if description else ''
        social_.extend(social)
        address = address + city_state_zip
        row = [url, name, title, image_url, office_name, agent_phone, office_phone,
                address, description, city, zipcode, state, country, languages, email, website, social]
        row_data.append(row)
        comparison.CollectDb(urls, name, title, image_url, office_name, agent_phone, office_phone,
                             address, description, city, zipcode, state, country, languages, email, website, social, domain)
    Sample_Genaration(domain,row_data)
    if title_ == []:
        msg = 'title fields is empty in huff_realty'
        message.append(msg)
    if name_ == []:
        msg = 'name fields is empty in huff_realty'
        message.append(msg)
    if agent_phone_ == []:
        msg = 'agent_phone is empty in huff_realty'
        message.append(msg)
    if office_phone_ == []:
        msg = 'office_phone is empty in huff_realty'
        message.append(msg)
    if office_name_ == []:
        msg = 'office_name is empty in huff_realty'
        message.append(msg)
    if city_ == []:
        msg = 'city state zip is empty in huff_realty'
        message.append(msg)
    if image_url_ == []:
        msg = 'image_url is empty in huff_realty'
        message.append(msg)
    if address_ == []:
        msg = 'address field is empty in huff_realty'
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in huff_realty'
        message.append(msg)
    if social_ == []:
        msg = 'social is empty in huff_realty'
        message.append(msg)
    slack_note(message,domain)



def houlihanlawrence_fun(profile_url, offices):
    print('houlihanlawrence')
    name_ = []
    title_ = []
    description_ = []
    image_url_ = []
    office_name_ = []
    office_phone_ = []
    agent_phone_ = []
    email_ = []
    languages_ = []
    social_ = []
    city_state_ = []
    message = []
    count = 0
    address = ''
    website = ''
    domain = 'Houlihanlawrence'
    row_data = []
    for url in profile_url:
        url = 'https://www.houlihanlawrence.com' + url
        res = requests.get(url, headers=headers,proxies=proxies)
        sel_ = Selector(text=res.content)
        agent_link = sel_.xpath(
            houlihanlawrence.PROFILE_URL_XPATH).extract()
        for link in agent_link:
            response = requests.get(link, headers=headers,proxies=proxies)
            sel = Selector(text=response.content)
            count = count + 1
            name = sel.xpath(
                houlihanlawrence.NAME_XPATH).extract_first('').strip()
            title = sel.xpath(
                houlihanlawrence.TITLE_XPATH).extract_first('').strip()
            description = ''.join(
                sel.xpath(houlihanlawrence.DESCRIPTION_XPATH).extract())
            image = sel.xpath(
                houlihanlawrence.IMAGE_XPATH).extract_first('').strip()
            office_name = sel.xpath(
                houlihanlawrence.OFFICE_NAME_XPATH).extract_first('').strip()
            office_phone = sel.xpath(
                houlihanlawrence.OFFICE_PHONE_XPATH).extract()
            agent_phone = sel.xpath(
                houlihanlawrence.AGENT_PHONE_XPATH).extract()
            email = sel.xpath(
                houlihanlawrence.EMAIL_XPATH).extract_first('').strip()
            languages = sel.xpath(
                houlihanlawrence.LANGUAGES_XPATH).extract_first('').strip()
            livesin = sel.xpath(houlihanlawrence.LIVESIN_XPATH).extract_first(
                '').strip()
            facebook_url = sel.xpath(
                houlihanlawrence.FACEBOOK_XPATH).extract_first('').strip()
            linkedin_url = sel.xpath(
                houlihanlawrence.LINKEDIN_XPATH).extract_first('').strip()
            twitter_url = sel.xpath(
                houlihanlawrence.TWITTER_XPATH).extract_first('').strip()
            instagram_url = sel.xpath(
                houlihanlawrence.INSTAGRAM_XPATH).extract_first('').strip()
            pinterest_url = sel.xpath(
                houlihanlawrence.PINTEREST_XPATH).extract_first('').strip()
            youtube_url = sel.xpath(
                houlihanlawrence.YOUTUBE_XPATH).extract_first('').strip()
            googleplus_url = sel.xpath(
                houlihanlawrence.GOOGLEPLUS_XPATH).extract_first('').strip()
            yelp_url = sel.xpath(
                houlihanlawrence.YELP_XPATH).extract_first('').strip()

            social = []
            social.append(facebook_url) if facebook_url else ''
            social.append(linkedin_url) if linkedin_url else ''
            social.append(twitter_url) if twitter_url else ''
            social.append(instagram_url) if instagram_url else ''
            social.append(pinterest_url) if pinterest_url else ''
            social.append(youtube_url) if youtube_url else ''
            social.append(googleplus_url) if googleplus_url else ''
            social.append(yelp_url) if yelp_url else ''
            name_.append(name) if name else ''
            title_.append(title) if title else ''
            description_.append(description) if description else ''
            image_url_.append(image) if image else ''
            office_name_.append(office_name) if office_name else ''
            office_phone_.append(office_phone) if office_phone else ''
            agent_phone_.append(agent_phone) if agent_phone else ''
            email_.append(email) if email else ''
            languages_.append(languages) if languages else ''
            city_state_.append(livesin) if livesin else ''
            social_.extend(social) if social else ''
            row = [url, name, title, image, office_name, agent_phone, office_phone, description,
                    email, languages, livesin, social]
            row_data.append(row)
            comparison.CollectDb(url, name, title, image, office_name, agent_phone, office_phone,
                 address, description, livesin, livesin, livesin, country, languages, email, website, social, domain)
            if count > 24:
                break
        break
            
    Sample_Genaration(domain,row_data)      
    if name_ == []:
        msg = 'name fields is empty in houlihanlawrence'
        message.append(msg)
    if title_ == []:
        msg = 'title fields id empty in houlihanlawrence'
        message.append(msg)
    if description_ == []:
        msg = 'description is empty in houlihanlawrence'
        message.append(msg)
    if image_url_ == []:
        msg = 'image_url field is empty in houlihanlawrence'
        message.append(msg)
    if office_name_ == []:
        msg = 'office_name fields is empty in houlihanlawrence'
        message.append(msg)
    if office_phone_ == []:
        msg = 'office_phone fields is empty in houlihanlawrence'
        message.append(msg)
    if email_ == []:
        msg = 'email fields is empty in houlihanlawrence'
        message.append(msg)
    if languages_ == []:
        msg = 'languages fields is empty in houlihanlawrence'
        message.append(msg)
    if city_state_ == []:
        msg = 'city_state fields is empty in houlihanlawrence'
        message.append(msg)
    if social_ == []:
        msg = 'social fields is empty in houlihanlawrence'
        message.append(msg)
    slack_note(message,domain)


def robertsbrothers_fun(agent_list):
    print('robertsbrothers')
    name_ = []
    description_ = []
    image_url_ = []
    next_page_ = []
    address_ = []
    agent_phone_ = []
    office_phone_ = []
    office_name_ = []
    title_ = []
    social_ = []
    message = []
    email_ = []
    website_ = []
    count = 0
    city = ''
    state = ''
    zipcode = ''
    country = 'United States'
    languages = ''
    domain = 'robertsbrothers'
    row_data = []
    for agent in agent_list:
        url = agent.xpath(
            robertsbrothers.PROFILE_URL_XPATH).extract_first('')
        email = agent.xpath(robertsbrothers.EMAIL_XPATH).extract_first('')
        website = agent.xpath(
            robertsbrothers.WEBSITE_XPATH).extract_first('')
        res = requests.get(url, headers=headers,proxies=proxies)
        link = res.url
        sel = Selector(text=res.content)
        if res.status_code == 200:
            name = sel.xpath(robertsbrothers.NAME_XPATH).extract_first('')
            description = sel.xpath(
                robertsbrothers.DESCRIPTION_XPATH).extract()
            image_url = sel.xpath(
                robertsbrothers.IMAGE_XPATH).extract_first('')
            image_url = url.replace('http:', 'https:') + image_url
            next_page = sel.xpath(
                robertsbrothers.NEXT_PAGE_XPATH).extract_first('')
            next_page = url + next_page
            description = ' '.join(''.join(description).split())
            address_list = sel.xpath(robertsbrothers.ADDRESS_LIST_XPATH)
            office_address = []
            for add in address_list:
                de = {}
                office = add.xpath(
                    robertsbrothers.OFFICE_XPATH).extract_first('').strip()
                address = add.xpath(
                    robertsbrothers.ADDRESS_XPATH).extract_first('').strip()
                location = add.xpath(
                    robertsbrothers.LOCATION_XPATH).extract_first('').strip()
                office_phone = add.xpath(
                    robertsbrothers.OFFICE_PHN_XPATH).extract_first('').strip()
                de.update({'office': office})
                de.update({'address': address})
                de.update({'location': location})
                de.update({'office_phone': office_phone})
                office_address.append(de)
            res_1 = requests.get(next_page, headers=headers,proxies=proxies)
            sel_1 = Selector(text=res_1.content)
            agent_phone = sel_1.xpath(
                robertsbrothers.AGENT_PHONE_XPATH).extract_first('')
            office_phone = sel_1.xpath(
                robertsbrothers.OFFICE_PHONE_XPATH).extract_first('')
            office_name = sel_1.xpath(
                robertsbrothers.OFFICE_NAME_XPATH).extract_first('')
            title = sel_1.xpath(
                robertsbrothers.TITLE_XPATH).extract_first('')
            social = sel.xpath(robertsbrothers.SOCIAL_XPATH).extract()
            if office_name:
                for i in office_address:
                    if i.get('office') in office_name:
                        address = i.get('address')
                        location = i.get('location')
                        city = location.split(', ')[0].strip()
                        postal = location.split(', ')[1]
                        if postal:
                            state = postal.split(' ')[0].strip()
                            zipcode = postal.split(' ')[1].strip()

            social_.extend(social) if social else ''
            name_.append(name) if name else ''
            description_.append(description) if description else ''
            image_url_.append(image_url) if image_url else ''
            next_page_.append(next_page) if next_page else ''
            address_.append(address) if address else ''
            agent_phone_.append(agent_phone) if agent_phone else ''
            office_phone_.append(office_phone) if office_phone else ''
            office_name_.append(office_name) if office_name else ''
            title_.append(title) if title else ''
            email_.append(email) if email else ''
            website_.append(website) if website else ''
            count = count + 1
            if count > 24:
                break

            row = [link, name, title, image_url, office_name, agent_phone, office_phone, address,
                    description, city, zipcode, state, country, languages, email, website, social]
            row_data.append(row)
            comparison.CollectDb(link, name, title, image_url, office_name, agent_phone, office_phone, address,
                                 description, city, zipcode, state, country, languages, email, website, social, domain)
    Sample_Genaration(domain,row_data)
    if name_ == []:
        msg = 'name fields is empty in robertsbrothers'
        message.append(msg)
    if description_ == []:
        msg = 'description fields is empty in robertsbrothers'
        message.append(msg)
    if image_url_ == []:
        msg = 'image_url fields is empty in robertsbrothers'
        message.append(msg)
    if next_page_ == []:
        msg = 'next page link  is empty in robertsbrothers'
        message.append(msg)
    if address_ == []:
        msg = 'address fields is empty in robertsbrothers'
        message.append(msg)
    if agent_phone_ == []:
        msg = 'agent phone fields is empty in robertsbrothers'
        message.append(msg)
    if office_phone_ == []:
        msg = 'office_phone fields is empty in robertsbrothers'
        message.append(msg)
    if office_name_ == []:
        msg = 'office_name fields is empty in robertsbrothers'
        message.append(msg)
    if title_ == []:
        msg = 'title fields is empty in robertsbrothers'
        message.append(msg)
    if website_ == []:
        msg = 'website fields is empty in robertsbrothers'
        message.append(msg)
    if email_ == []:
        msg = 'email field is empty in robertsbrothers'
        message.append(msg)
    if social_ == []:
        msg = 'social field is empty in robertsbrothers'
        message.append(msg)
    slack_note(message,domain)


def wrrealtors_fun(links):
    print('wrrealtors')
    name_ = []
    title_ = []
    image_url_ = []
    agent_phone_ = []
    email_ = []
    website_ = []
    description_ = []
    social_ = []
    message = []
    office_name = 'Wakefield Reutlinger Realtors'
    address = '6511 Glenridge Park Place'
    state = 'Louisville'
    city = 'KY'
    zipcode = '40222'
    office_phone = '(502) 425-0225'
    country = 'United States'
    languages = ''
    domain = 'wrrealtors'
    row_data = []
    for link in links:
        link = 'https://www.wrrealtors.com' + link
        res = requests.get(link, headers=headers,proxies=proxies)
        sel = Selector(text=res.content)
        name = sel.xpath(wrrealtors.NAME_XPATH).extract_first('')
        title = sel.xpath(
            wrrealtors.TITLE_XPATH).extract_first('').strip()
        image_url = sel.xpath(
            wrrealtors.IMAGE_XPATH).extract_first('').strip()
        agent_phone_numbers = sel.xpath(
            wrrealtors.AGENT_PHONE_XPATH).extract()
        email = sel.xpath(
            wrrealtors.EMAIL_XPATH).extract_first('').strip()
        website = sel.xpath(
            wrrealtors.WEBSITE_XPATH).extract_first('').strip()
        description = ''.join(
            sel.xpath(wrrealtors.DESCRIPTION_XPATH).extract())
        facebook_url = sel.xpath(
            wrrealtors.FACEBOOK_XPATH).extract_first('').strip()
        linkedin_url = sel.xpath(
            wrrealtors.LINKEDIN_XPATH).extract_first('').strip()
        twitter_url = sel.xpath(
            wrrealtors.TWITTER_XPATH).extract_first('').strip()
        instagram_url = sel.xpath(
            wrrealtors.INSTAGRAM_XPATH).extract_first('').strip()
        pinterest_url = sel.xpath(
            wrrealtors.PINTEREST_XPATH).extract_first('').strip()
        social = []
        social.append(facebook_url) if facebook_url else ''
        social.append(linkedin_url) if linkedin_url else ''
        social.append(twitter_url) if twitter_url else ''
        social.append(instagram_url) if instagram_url else ''
        social.append(pinterest_url) if pinterest_url else ''
        name_.append(name) if name else ''
        title_.append(title) if title else ''
        image_url_.append(image_url) if image_url else ''
        agent_phone_.append(
            agent_phone_numbers) if agent_phone_numbers else ''
        email_.append(email) if email else ''
        website_.append(website) if website else ''
        description_.append(description) if description else ''
        social_.extend(social) if social else ''
        row = [link, name, title, image_url, office_name, agent_phone_numbers, office_phone,
                address, description, city, zipcode, state, country, languages, email, website, social]
        row_data.append(row)
        comparison.CollectDb(link, name, title, image_url, office_name, agent_phone_numbers, office_phone,
                             address, description, city, zipcode, state, country, languages, email, website, social, domain)
    Sample_Genaration(domain,row_data)
    if name_ == []:
        msg = 'name fields is empty in wrrealtors'
        message.append(msg)
    if title_ == []:
        msg = 'title fields is empty in wrrealtors'
        message.append(msg)
    if agent_phone_ == []:
        msg = 'agent_phone fields is empty in wrrealtors'
        message.append(msg)
    if image_url_ == []:
        msg = 'image_url fields is empty in wrrealtors'
        message.append(msg)
    if email_ == []:
        msg = 'image_url fields is empty in wrrealtors'
        message.append(msg)
    if website_ == []:
        msg = 'website fields is empty in wrrealtors'
        message.append(msg)
    if description_ == []:
        msg = 'description fields is empty in wrrealtors'
        message.append(msg)
    if social_ == []:
        msg = 'social fields is empty in wrrealtors'
        message.append(msg)
    slack_note(message,domain)


def rubinarealestate_fun(agent_list):
    print('rubinarealestate')
    name_ = []
    title_ = []
    language_ = []
    social_ = []
    image_url_ = []
    message = []
    url = ''
    office_phone = '+49[0] 3041717040'
    office_name = 'Rubina Real Estate GmbH'
    address = 'Charlottenstraße 18'
    city = 'Mitte'
    state = 'Berlin'
    zipcode = '10117'
    agent_phone = ''
    description = ''
    country = 'Germany'
    domain = 'rubina_realestate'
    email = ''
    website = ''
    row_data = []
    for agent in agent_list:
        image_url = agent.xpath(
            rubina_realestate.IMAGE_XPATH).extract_first('')
        name = agent.xpath(rubina_realestate.NAME_XPATH).extract_first('')
        title = agent.xpath(
            rubina_realestate.TITLE_XPATH).extract_first('')
        language = agent.xpath(
            rubina_realestate.LANGUAGES_XPATH).extract()
        social = agent.xpath(rubina_realestate.SOCIAL_XPATH).extract()

        name_.append(name) if name else ''
        title_.append(title) if title else ''
        language_.extend(language) if language else ''
        social_.extend(social) if social else ''
        image_url_.append(image_url) if image_url else ''

        row = [url, name, title, image_url, office_name, agent_phone, office_phone, address,
                description, city, zipcode, state, country, language, email, website, social]
        row_data.append(row)
        comparison.CollectDb(url, name, title, image_url, office_name, agent_phone, office_phone, address,
                             description, city, zipcode, state, country, language, email, website, social, domain)
    Sample_Genaration(domain,row_data)
    if name_ == []:
        msg = 'name fields is empty in rubinarealestate'
        message.append(msg)
    if image_url_ == []:
        msg = 'image_url fields is empty in rubinarealestate'
        message.append(msg)
    if title_ == []:
        msg = 'title fields is empty in rubinarealestate'
        message.append(msg)
    if language_ == []:
        msg = 'languages fields is empty in rubinarealestate'
        message.append(msg)
    if social_ == []:
        msg = 'social fields is empty in rubinarealestate'
        message.append(msg)
    slack_note(message,domain)


def woodbros_fun(agent_list):
    print('woodbros')
    image_url_ = []
    name_ = []
    title_ = []
    agent_phone_ = []
    office_phone_ = []
    office_name_ = []
    address_ = []
    city_state_ = []
    website_ = []
    description_ = []
    social_ = []
    message = []
    count = 0
    languages = ''
    country = 'United States'
    email = ''
    domain = 'woodsbros_d2'
    row_data = []
    for agent in agent_list:
        image_url = ''.join(agent.xpath(woodbros.IMAGE_XPATH).extract())
        name = ''.join(agent.xpath(woodbros.NAME_XPATH).extract())
        title = ''.join(agent.xpath(woodbros.TITLE_XPATH).extract())
        social = agent.xpath(woodbros.SOCIAL_XPATH).extract()
        agent_phone = ''.join(agent.xpath(
            woodbros.AGENT_PHONE_XPATH).extract())
        office_phone = ''.join(agent.xpath(
            woodbros.OFFICE_PHONE_XPATH).extract())
        office_name = ''.join(agent.xpath(
            woodbros.OFFICE_NAME_XPATH).extract())
        website = agent.xpath(woodbros.WEBSITE_XPATH).extract()
        website = ''.join(website).strip()
        res = requests.get(website, headers=headers,proxies=proxies)
        sel = Selector(text=res.content)
        description = ''.join(
            sel.xpath(woodbros.DESCRIPTION_XPATH).extract())
        address = ''.join(sel.xpath(woodbros.ADDRESS_XPATH).extract()[-3])
        city_state_zip = ''.join(agent.xpath(
            woodbros.CITY_STATE_XPATH).extract()[-2])
        count = count + 1
        if count > 24:
            break
        #
        image_url_.append(image_url) if image_url else ''
        name_.append(name) if name else ''
        title_.append(title) if title else ''
        agent_phone_.append(agent_phone) if agent_phone else ''
        office_phone_.append(agent_phone) if office_phone else ''
        office_name_.append(office_name) if office_name else ''
        address_.append(address) if address else ''
        city_state_.append(city_state_zip) if city_state_zip else ''
        website_.append(website) if website else ''
        description_.append(description) if description else ''
        social_.extend(social) if social else ''
        row = [website, name, title, image_url, office_name, agent_phone, office_phone, description, address,
                city_state_zip, city_state_zip, city_state_zip, country, languages, email, website, social]
        row_data.append(row)
        comparison.CollectDb(website, name, title, image_url, office_name, agent_phone, office_phone, description, address,
                             city_state_zip, city_state_zip, city_state_zip, country, languages, email, website, social, domain)
    Sample_Genaration(domain,row_data)
    if image_url_ == []:
        msg = 'image_url fields is empty in woodbros'
        message.append(msg)
    if name_ == []:
        msg = 'name fields is empty in woodbros'
        message.append(msg)
    if title_ == []:
        msg = 'title fields is empty in woodbros'
        message.append(msg)
    if agent_phone_ == []:
        msg = 'agent_phone fields is empty in woodbros'
        message.append(msg)
    if office_phone_ == []:
        msg = 'office_phone fields is empty in woodbros'
        message.append(msg)
    if office_name_ == []:
        msg = 'office_name fields is empty in woodbros'
        message.append(msg)
    if address_ == []:
        msg = 'address fields is empty in woodbros'
        message.append(msg)
    if city_state_ == []:
        msg = 'city_state_zip fields is empty in woodbros'
        message.append(msg)
    if website_ == []:
        msg = 'website fields is empty in woodbros'
        message.append(msg)
    if description_ == []:
        msg = 'description fields is empty in woodbros'
        message.append(msg)
    if social_ == []:
        msg = 'social fields is empty in woodbros'
        message.append(msg)
    slack_note(message,domain)

def reecenichols_fun(agent_list):
    print('reecenichols')
    address_ = []
    city_ = []
    state_ = []
    zipcode_ = []
    office_phone_ = []
    agent_phone_ = []
    name_ = []
    office_name_ = []
    image_url_ = []
    email_ = []
    description_ = []
    social_ = []
    message = []
    title = ''
    languages = ''
    website = ''
    count = 0
    domain = 'reecenichols_data_v4'
    country = 'United States'
    row_data = []
    for agent in agent_list:
        profile_url = agent.xpath(
            reecenichols.PROFILE_URL_XPATH).extract_first('').strip()
        address = agent.xpath(
            reecenichols.ADDRESS_XPATH).extract_first('').strip()
        location = agent.xpath(
            reecenichols.LOCATION_XPATH).extract()
        location = ' '.join(''.join(location).split())
        address = ' '.join(''.join(address).split())
        office_phone = agent.xpath(reecenichols.OFFICE_PHONE_XPATH).extract_first(
            '').replace('Phone:', '').strip()
        agent_phone = agent.xpath(reecenichols.AGENT_PHONE_XPATH).extract_first(
            '').replace('Cell:', '').strip()
        name = agent.xpath(
            reecenichols.NAME_XPATH).extract_first('').strip()
        office_name = agent.xpath(
            reecenichols.OFFICE_NAME_XPATH).extract_first('')
        if not 'http' in profile_url:
            profile_url = 'https://www.reecenichols.com' + profile_url
        res = requests.get(profile_url, headers=headers,proxies=proxies)
        sel = Selector(text=res.content)
        if location:
            city = location.split(', ')[0].strip()
            postal = location.split(', ')[1].strip()
            if postal:
                state = postal.split(' ')[0].strip()
                zipcode = postal.split(' ')[1].strip()

        agent_phone = agent_phone.replace('Phone:', '')
        agent_phone_numbers = [agent_phone] if agent_phone else []
        office_phone_numbers = [office_phone] if office_phone else []
        image_url = sel.xpath(reecenichols.IMAGE_XPATH).extract_first('')
        email = sel.xpath(
            reecenichols.EMAIL_XPATH).extract_first('').strip()
        description = sel.xpath(reecenichols.DESCRIPTION_XPATH).extract()
        description = ' '.join(''.join(description).split())
        facebook_url = sel.xpath(
            reecenichols.FACEBOOK_XPATH).extract_first('').strip()
        linkedin_url = sel.xpath(
            reecenichols.LINKEDIN_XPATH).extract_first('').strip()
        twitter_url = sel.xpath(
            reecenichols.TWITTER_XPATH).extract_first('').strip()
        instagram_url = sel.xpath(
            reecenichols.INSTAGRAM_XPATH).extract_first('').strip()
        pinterest_url = sel.xpath(
            reecenichols.PINTEREST_XPATH).extract_first('').strip()
        youtube_url = sel.xpath(
            reecenichols.YOUTUBE_XPATH).extract_first('').strip()
        googleplus_url = sel.xpath(
            reecenichols.GOOGLEPLUS_XPATH).extract_first('').strip()

        address_.append(address) if address else ''
        city_.append(city) if city else ''
        state_.append(state) if state else ''
        zipcode_.append(zipcode) if zipcode else ''
        office_phone_.append(office_phone_numbers) if office_phone_numbers else ''
        agent_phone_.append(agent_phone_numbers) if agent_phone_numbers else ''
        name_.append(name) if name else ''
        office_name_.append(office_name) if office_name else ''
        image_url_.append(image_url) if image_url else ''
        email_.append(email) if email else ''
        description_.append(description) if description else ''
        social = []
        social.append(facebook_url) if facebook_url else ''
        social.append(linkedin_url) if linkedin_url else ''
        social.append(twitter_url) if twitter_url else ''
        social.append(instagram_url) if instagram_url else ''
        social.append(pinterest_url) if pinterest_url else ''
        social.append(youtube_url) if youtube_url else ''
        social.append(googleplus_url) if googleplus_url else ''
        social_.extend(social) if social else ''
        count = count + 1
        if count > 24:
            break
        row = [profile_url, name, title, image_url, office_name, agent_phone_numbers, office_phone_numbers, address, description, city,
                zipcode, state, country, languages, email, website, social]
        row_data.append(row)
        comparison.CollectDb(profile_url, name, title, image_url, office_name, agent_phone_numbers, office_phone_numbers, address, description, city,
                             zipcode, state, country, languages, email, website, social, domain)
    Sample_Genaration(domain,row_data)
    if address_ == []:
        msg = 'address fields is empty in reecenichols'
        message.append(msg)
    # if city_state_zip_ == []:
    #     msg = 'city state zipcode fields is empty in reecenichols'
    #     message.append(msg)
    if office_phone_ == []:
        msg = 'office_phone fields is empty in reecenichols'
        message.append(msg)
    if agent_phone_ == []:
        msg = 'agent_phone fields is empty in reecenichols'
        message.append(msg)
    if name_ == []:
        msg = 'name fields is empty in reecenichols'
        message.append(msg)
    if office_name_ == []:
        msg = 'office_name fields is empty in reecenichols'
        message.append(msg)
    if image_url_ == []:
        msg = 'image_url_ fields is empty in reecenichols'
        message.append(msg)
    # if email_ == []:
    #     msg = 'email_ fields is empty in reecenichols'
    #     message.append(msg)
    if description_ == []:
        msg = 'description fields is empty in reecenichols'
        message.append(msg)
    if social_ == []:
        msg = 'social fields is empty in reecenichols'
        message.append(msg)
    if city_ == []:
        msg = 'city fields is empty in reecenichols'
        message.append(msg)
    if state_ ==[]:
        msg = 'state fields is empty in reecenichols'
        message.append(msg)   
    if zipcode_ == []:
        msg = 'zipcode fields is empty in reecenichols'
        message.append(msg)     
    slack_note(message,domain)


def rector_hyden_fun(agent_list):
    print('rector_hyden')
    name_ = []
    title_ = []
    agent_phone_ = []
    office_phone_ = []
    office_name_ = []
    office_address_ = []
    office_city_state_ = []
    image_url_ = []
    description_ = []
    address_ = []
    social_ = []
    message = []
    count = 0
    languages = ''
    email = ''
    country = 'United States'
    domain = 'rector_hayden'
    row_data = []
    for agent in agent_list:
        count = count + 1
        profile_url = agent.xpath(
            rector_hyden.PROFILE_URL_XPATH).extract_first('')
        name = agent.xpath(
            rector_hyden.NAME_XPATH).extract_first('').strip()
        title = agent.xpath(
            rector_hyden.TITLE_XPATH).extract_first('').strip()
        agent_phone = agent.xpath(
            rector_hyden.AGENT_PHONE_XPATH).extract_first('')
        office_phone = agent.xpath(
            rector_hyden.OFFICE_PHONE_XPATH).extract_first('')
        office_name = agent.xpath(
            rector_hyden.OFFICE_NAME_XPATH).extract_first('')
        office_address = agent.xpath(
            rector_hyden.OFFICE_ADDRESS_XPATH).extract_first('')
        office_city_state = ''.join(agent.xpath(
            rector_hyden.OFFICE_CITY_XPATH).extract())
        image_url = agent.xpath(rector_hyden.IMAGE_XPATH).extract_first('')
        res = requests.get(profile_url, headers=headers,proxies=proxies)
        sel = Selector(text=res.content)
        description = ''.join(
            sel.xpath(rector_hyden.DESCRIPTION_XPATH).extract())
        address1 = sel.xpath(
            rector_hyden.ADDRESS_XPATH_1).extract_first('').strip()
        address2 = sel.xpath(
            rector_hyden.ADDRESS_XPATH_2).extract_first('')
        address3 = sel.xpath(
            rector_hyden.ADDRESS_XPATH_3).extract_first('').strip()
        facebook_url = sel.xpath(
            rector_hyden.FACEBOOK_XPATH).extract_first('')
        linkedin_url = sel.xpath(
            rector_hyden.LINKEDIN_XPATH).extract_first('')
        twitter_url = sel.xpath(
            rector_hyden.TWITTER_XPATH).extract_first('')
        instagram_url = sel.xpath(
            rector_hyden.INSTAGRAM_XPATH).extract_first('')
        pinterest_url = sel.xpath(
            rector_hyden.PINTEREST_XPATH).extract_first('')
        youtube_url = sel.xpath(
            rector_hyden.YOUTUBE_XPATH).extract_first('')
        googleplus_url = sel.xpath(
            rector_hyden.GOOGLEPLUS_XPATH).extract_first('')
        profile_url = res.url
        website = res.url
        if count > 24:
            break

        social = []
        location = []
        location.append(address1) if address1 else ''
        location.append(address2) if address2 else ''
        location.append(address3) if address3 else ''
        address_.extend(location) if location else ''
        address = ''.join(location)
        social.append(facebook_url) if facebook_url else ''
        social.append(linkedin_url) if linkedin_url else ''
        social.append(twitter_url) if twitter_url else ''
        social.append(instagram_url) if instagram_url else ''
        social.append(pinterest_url) if pinterest_url else ''
        social.append(youtube_url) if youtube_url else ''
        social.append(googleplus_url) if googleplus_url else ''
        name_.append(name) if name else ''
        title_.append(title) if title else ''
        agent_phone_.append(agent_phone) if agent_phone else ''
        office_phone_.append(office_phone) if office_phone else ''
        office_name_.append(office_name) if office_name else ''
        office_address_.append(office_address) if office_address else ''
        office_city_state_.append(
            office_city_state) if office_city_state else ''
        image_url_.append(image_url) if image_url else ''
        description_.append(description) if description else ''

        social_.extend(social) if social else ''
        row = [profile_url, name, title, image_url, office_name, agent_phone, office_phone, location, description,
                location, location, location, country, languages, email, website, social]
        row_data.append(row)
        comparison.CollectDb(profile_url, name, title, image_url, office_name, agent_phone, office_phone, address, description,
                             address, address, address, country, languages, email, website, social, domain)
    Sample_Genaration(domain,row_data)
    if image_url_ == []:
        msg = 'image_url fields is empty in rector_hyden'
        message.append(msg)
    if name_ == []:
        msg = 'name fields is empty in rector_hyden'
        message.append(msg)
    if title_ == []:
        msg = 'title fields is empty in rector_hyden'
        message.append(msg)
    if agent_phone_ == []:
        msg = 'agent_phone fields is empty in rector_hyden'
        message.append(msg)
    if office_phone_ == []:
        msg = 'office_phone fields is empty in rector_hyden'
        message.append(msg)
    if office_name_ == []:
        msg = 'office_name fields is empty in rector_hyden'
        message.append(msg)
    if office_address_ == []:
        msg = 'officie address name fields is empty in rector_hyden'
        message.append(msg)
    if office_city_state_ == []:
        msg = 'office city state  fields is empty in rector_hyden'
        message.append(msg)

    if address_ == []:
        msg = 'address fields is empty in rector_hyden'
        message.append(msg)

    if description_ == []:
        msg = 'description fields is empty in rector_hyden'
        message.append(msg)
    if social_ == []:
        msg = 'social fields is empty in rector_hyden'
        message.append(msg)
    slack_note(message,domain)


def longrealty_fun(links, office_phone, office_name):
    print('longrealty')
    name_1 = []
    title_1 = []
    image_url_1 = []
    agent_phone_1 = []
    email_1 = []
    address_1 = []
    city_1 = []
    state_1 = []
    zipcode_1 = []
    social_1 = []
    message = []
    description = ''
    domain = 'longrealty_data_v1'
    country = 'United States'
    website = ''
    languages = ''
    row_data = []
    for link in links:
        response = requests.get(link, headers=headers,proxies=proxies)
        # response = requests.get(link, headers=headers)
        sel = Selector(text=response.content)
        name = ''.join(sel.xpath(longrealty.NAME_XPATH).extract())
        title_ = sel.xpath(longrealty.TITLE_XPATH).extract()
        title_ = ''.join(title_).strip()
        title = title_.split('-')[0].strip()
        image = sel.xpath(longrealty.IMAGE_XPATH).extract()
        image = ''.join(image)
        if 'gif' not in image:
            # print(image)
            image_url = image
        agent_phone_no = []
        agent_phone_numbers = sel.xpath(
            longrealty.AGENT_PHONE_XPATH).extract_first('')
        if agent_phone_numbers:
            if 'Cell:' in agent_phone_numbers:
                agent_phone_numbers = agent_phone_numbers.split(
                    'Cell:')
                agent_phone_no.append(agent_phone_numbers[1])
            elif 'Direct:' in agent_phone_numbers:
                agent_phone_numbers = agent_phone_numbers.split(
                    'Direct:') if agent_phone_numbers else ''
                agent_phone_no.append(agent_phone_numbers[1]) if agent_phone_numbers else ''
            elif'Mobile Phone:' in agent_phone_numbers:
                agent_phone_numbers = agent_phone_numbers.split(
                    'Mobile Phone:') if agent_phone_numbers else ''
                agent_phone_no.append(agent_phone_numbers[1]) if agent_phone_numbers else ''
        else:
            agent_phone_no = []
        email = sel.xpath(longrealty.EMAIL_XPATH).extract()
        email = ''.join(email).strip()
        email = email.replace('mailto:', '')
        address = sel.xpath(longrealty.ADDRESS_XPATH).extract()[-2]
        address = ''.join(address).strip()
        city_state = sel.xpath(longrealty.CITY_XPATH).extract()[-1]
        city_state = ''.join(city_state)
        city = city_state.split(', ') if city_state else ''
        CITY = city[0] if city else ''
        zipcode_ = city[1].split(' ')
        if zipcode_:
            zipcode_ = zipcode_
        else:
            zipcode_ = ''
        zip_code = zipcode_[1]
        state = zipcode_[0]

        facebook_url = sel.xpath(
            longrealty.FACEBOOK_XPATH).extract_first('')
        instagram_url = sel.xpath(
            longrealty.INSTAGRAM_XPATH).extract_first('')
        youtube_url = sel.xpath(longrealty.YOUTUBE_XPATH).extract_first('')
        twitter_url = sel.xpath(longrealty.TWITTER_XPATH).extract_first('')
        blog_url = sel.xpath(longrealty.BLOG_XPATH).extract_first('')
        link = response.url

        name_1.append(name) if name else ''
        title_1.append(title) if title else ''
        image_url_1.append(image_url) if image_url else ''
        agent_phone_1.extend(agent_phone_no) if agent_phone_no else ''
        email_1.append(email) if email else ''
        address_1.append(address) if address else ''
        city_1.append(CITY) if CITY else ''
        zipcode_1.append(zip_code) if zip_code else ''
        state_1.append(state) if state else ''
        languages = []
        social = []
        social.append(facebook_url) if facebook_url else ''
        social.append(instagram_url) if instagram_url else ''
        social.append(youtube_url) if youtube_url else ''
        social.append(twitter_url) if twitter_url else ''
        social.append(blog_url) if blog_url else ''
        social_1.extend(social) if social else ''
        row = [link, name, title, image_url, office_name, agent_phone_no, office_phone[0], address, description,
                CITY, zip_code, state, country, languages, email, link, social]
        row_data.append(row)
        comparison.CollectDb(link, name, title, image_url, office_name, agent_phone_no, office_phone[0], address, description,
                CITY, zip_code, state, country, languages, email, link, social, domain)
    Sample_Genaration(domain,row_data)
    if image_url_1 == []:
        msg = 'image_url fields is empty in longrealty'
        message.append(msg)
    if name_1 == []:
        msg = 'name fields is empty in longrealty'
        message.append(msg)
    if title_1 == []:
        msg = 'title fields is empty in longrealty'
        message.append(msg)
    if agent_phone_1 == []:
        msg = 'agent_phone fields is empty in longrealty'
        message.append(msg)
    if email_1 == []:
        msg = 'email fields is empty in longrealty'
        message.append(msg)
    if address_1 == []:
        msg = 'address fields is empty in longrealty'
        message.append(msg)
    if office_phone == []:
        msg = 'office_phone fields is empty in longrealty'
        message.append(msg)
    if office_name == []:
        msg = 'office_name fields is empty in longrealty'
        message.append(msg)
    if city_1 == []:
        msg = 'city fields is empty in longrealty'
        message.append(msg)
    if state_1 == []:
        msg = 'state fields is empty longrealty'
        message.append(msg)
    if zipcode_1 == []:
        msg = 'zipcode fields is empty longrealty'
        message.append(msg)
    if social_1 == []:
        msg = 'social fields is empty in longrealty'
        message.append(msg)
    slack_note(message,domain)

def intero_realestate_fun(source):
    print('intero_realestate')
    name_ = []
    title_ = []
    email_ = []
    agent_phone_ = []
    office_phone_ = []
    office_name_ = []
    address_ = []
    city_ = []
    state_ = []
    zipcode_ = []
    social_ = []
    languages_ = []
    image_url_ = []
    description_ = []
    message = []
    count = 0
    website = ''
    country = 'United States'
    domain = 'intero_realestate_data'
    row_data = []
    for ite in source:
        user = ite.get('uuid')
        url = 'https://svc.moxiworks.com/service/profile/v2_insecure/offices/' + \
            str(user)+'/agents'
        response1 = requests.get(url, headers=headers,proxies=proxies)
        data = json.loads(response1.text)
        agents = data.get('data').get('result_list')
        for pro in agents:
            name = pro.get('display_name', '')
            title = pro.get('title')
            if title == None:
                title = ''
            first_name = pro.get('firstname', '')
            last_name = pro.get('lastname')
            middle_name = pro.get('middlename', '')
            email = pro.get('email', '')
            agent_phone_numbers = pro.get('mainphone')
            if agent_phone_numbers == None:
                # agent_phone_numbers = ''
                agent_phone_numbers = pro.get('cellphone', '')
            office_phone_numbers = pro.get('office').get('phone')
            office_name = pro.get('office').get('name')
            address = pro.get('office').get('location').get('address')
            city = pro.get('office').get('location').get('city')

            state = pro.get('office').get('location').get('state')
            zipcode = pro.get('office').get('location').get('zip')
            profile_url = 'https://www.intero.com/directory/agents/' + \
                pro.get('url_slug', '')
            social = pro.get('social_urls', '')
            if social == None:
                social = ''
            languages = ''
            langu = pro.get('languages')
            for f in langu:
                languages = f.get('languagename')
            img = pro.get('image')
            for im in img:
                image_url = im.get('raw_url')
            user_id = pro.get('user_id')
            description_url = 'https://svc.moxiworks.com/service/v1/profile/' + \
                str(user_id)
            response2 = requests.get(description_url, headers=headers,proxies=proxies)
            data = json.loads(response2.text)
            agentss = data.get('data').get('result_list')
            description = ''
            for pro1 in agentss:
                desc = pro1.get('contentblocks')
                if desc:
                    description = desc[0].get('body')
                cleanr = re.compile('<.*?>')
                cleantext = re.sub(cleanr, '', description)
            name_.append(name) if name else ''
            title_.append(title) if title else ''
            email_.append(email) if email else ''
            agent_phone_.append(
                agent_phone_numbers) if agent_phone_numbers else ''
            office_phone_.append(
                office_phone_numbers) if office_phone_numbers else ''
            office_name_.append(office_name) if office_name else ''
            address_.append(address) if address else ''
            city_.append(city) if city else ''
            state_.append(state) if state else ''
            zipcode_.append(zipcode) if zipcode else ''
            social_.append(social) if social else ''
            languages_.append(languages) if languages else ''
            image_url_.append(image_url) if image_url else ''
            description_.append(description) if description else ''
            count = count + 1

            if count > 24:
                break
            row = [profile_url, name, title, image_url, office_name, agent_phone_numbers, office_phone_numbers, address,
                    description, city, zipcode, state, country, languages, email, website, social]
            row_data.append(row)
            comparison.CollectDb(profile_url, name, title, image_url, office_name, agent_phone_numbers, office_phone_numbers, address,
                                 description, city, zipcode, state, country, languages, email, website, social, domain)

        if count > 24:
            break
    Sample_Genaration(domain,row_data)
    if name_ == []:
        msg = 'name fields is empty in  intero_realestate'
        message.append(msg)
    if title_ == []:
        msg = 'title field is empty in intero_realestate'
        message.append(msg)
    if email_ == []:
        msg = 'email field is empty in intero_realestate'
        message.append(msg)
    if agent_phone_ == []:
        msg = 'agent_phone field is empty in intero_realestate'
        message.append(msg)
    if office_phone_ == []:
        msg = 'office_phone field is empty in intero_realestate'
        message.append(msg)
    if office_name_ == []:
        msg = 'office_name field is empty in intero_realestate'
        message.append(msg)
    if address_ == []:
        msg = 'address field is empty in intero_realestate'
        message.append(msg)
    if city_ == []:
        msg = 'city field is empty in intero_realestate'
        message.append(msg)
    if state_ == []:
        msg = 'state field is empty in intero_realestate'
        message.append(msg)
    if zipcode_ == []:
        msg = 'zipcode field is empty in intero_realestate'
        message.append(msg)
    if social_ == []:
        msg = 'social field is empty in intero_realestate'
        message.append(msg)
    if languages_ == []:
        msg = 'languages field is empty inintero_realestate'
        message.append(msg)
    if image_url_ == []:
        msg = 'languages field is empty in intero_realestate'
        message.append(msg)
    if description_ == []:
        msg = 'Description field is empty in intero_realestate'
        message.append(msg)
    slack_note(message,domain)



def realty_south_fun(links):
    print('realty_south')
    name_ = []
    office_name_ = []
    address_ = []
    city_state_zip_ = []
    agent_phone_ = []
    image_url_ = []
    description_ = []
    social_ = []
    message = []
    title = ''
    country = 'United States'
    email = ''
    website = ''
    languages = ''
    domain = 'realtysouth_new_v2'
    office_phone = ''
    row_data = []
    for link in links:
        response = requests.get(link, headers=headers,proxies=proxies)
        sel = Selector(text=response.content)
        name = sel.xpath(realty_south.NAME_XPATH).extract_first('').strip()
        office_name = sel.xpath(
            realty_south.OFFICE_NAME_XPATH).extract_first('').strip()
        address = sel.xpath(
            realty_south.ADDRESS_XPATH).extract_first('').strip()
        city_state_zip = ''.join(
            sel.xpath(realty_south.LOCATION_XPATH).extract())
        agent_phone = sel.xpath(
            realty_south.AGENT_PHONE_XPATH).extract_first('').strip()
        image_url = sel.xpath(
            realty_south.IMAGE_XPATH).extract_first('').strip()
        description = ''.join(
            sel.xpath(realty_south.DESCRIPTION_XPATH).extract())
        social = sel.xpath(realty_south.SOCIAL_XPATH).extract()
        link = response.url

        name_.append(name) if name else ''
        office_name_.append(office_name) if office_name else ''
        address_.append(address) if address else ''
        city_state_zip_.append(city_state_zip) if city_state_zip else ''
        agent_phone_.append(agent_phone) if agent_phone else ''
        image_url_.append(image_url) if image_url else ''
        description_.append(description) if description else ''
        social_.extend(social) if social else ''
        row = [link, name, title, image_url, office_name, agent_phone, office_phone, address, description,
                city_state_zip, city_state_zip, city_state_zip, country, languages, email, website, social]
        row_data.append(row)
        comparison.CollectDb(link, name, title, image_url, office_name, agent_phone, office_phone, address, description,
                             city_state_zip, city_state_zip, city_state_zip, country, languages, email, website, social, domain)
    Sample_Genaration(domain,row_data)
    if name_ == []:
        msg = 'name fields is empty in  realty_south'
        message.append(msg)
    if office_name_ == []:
        msg = 'office_name fields is empty in  realty_south'
        message.append(msg)
    if address_ == []:
        msg = 'address fields is empty in  realty_south'
        message.append(msg)
    if city_state_zip_ == []:
        msg = 'city state zipcode fields is empty in  realty_south'
        message.append(msg)
    if agent_phone_ == []:
        msg = 'agent_phone fields is empty in  realty_south'
        message.append(msg)
    if image_url_ == []:
        msg = 'image_url fields is empty in  realty_south'
        message.append(msg)
    if description_ == []:
        msg = 'description fields is empty in  realty_south'
        message.append(msg)

    if social_ == []:
        msg = 'social fields is empty in  realty_south'
        message.append(msg)
    slack_note(message,domain)

