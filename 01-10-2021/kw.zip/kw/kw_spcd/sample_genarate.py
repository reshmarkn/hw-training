import csv
from datetime import datetime

today = datetime.now().strftime('%Y_%m_%d')

def Sample_Genaration(domain,row):
    fields = ['url', 'name', 'title', 'image', 'office_name', 'agent_phone', 'office_phone', 'address',
              'description', 'city', 'zipcode', 'state', 'country', 'languages', 'email', 'website', 'social']
    file_name = domain + '_' + today + '.csv'
    with open(file_name, 'w') as csvfile:
        csvwriter = csv.writer(csvfile)
        csvwriter.writerow(fields)
        csvwriter.writerows(row)