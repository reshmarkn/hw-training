import re
import csv
import json
import random
import urllib
import requests
import logging
import comparison
from xpath import *
from log_file import *
from slacker import Slacker
from datetime import datetime
from pymongo import MongoClient
from scrapy.selector import Selector
from proxy import tor_proxy
from proxy import microleaves_proxy
from proxy import storm_proxy
from w3lib.html import remove_tags

today = datetime.now().strftime('%Y_%m_%d')

headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
}
proxy_t = tor_proxy()
proxies_t = proxy_t['proxies']

proxy_m = microleaves_proxy()
proxies_m = proxy_m['proxies']

proxy_s = storm_proxy()
proxies_s = proxy_s['proxies']

country = 'United States'
email = ''
website = ''
language = ''
title = ''
description = ''
social = []


def denverrealestate_fun(links):
    print('denverrealestate')
    domain = 'denver_realestate'
    name_ = []
    title_ = []
    office_name_ = []
    agent_phone_ = []
    office_phone_ = []
    Website_ = []
    image_url_ = []
    languages_ = []
    location_ = []
    description_ = []
    social_ = []
    message = []
    row_data = []
    for link in links:
        response = requests.get(link, headers=headers, proxies=proxies_t)
        sel = Selector(text=response.content)
        link = response.url
        name = sel.xpath(
            denver_realestate.NAME_XPATH).extract_first('').strip()
        title = sel.xpath(
            denver_realestate.TITLE_XPATH).extract_first('').strip()
        office_name = sel.xpath(
            denver_realestate.OFFICE_NAME_XPATH).extract_first('').strip()
        agent_phone = sel.xpath(denver_realestate.AGENT_PHONE_XPATH).extract()
        office_phone = sel.xpath(
            denver_realestate.OFFICE_PHONE_XPATH).extract()
        website = sel.xpath(
            denver_realestate.WEBSITE_XPATH).extract_first('').strip()
        image_url = sel.xpath(
            denver_realestate.IMAGE_XPATH).extract_first('').strip()
        language = sel.xpath(denver_realestate.LANGUAGES_XPATH).extract()
        location = sel.xpath(denver_realestate.LOCATION_XPATH).extract()
        description = sel.xpath(denver_realestate.DESCRIPTION_XPATH).extract()
        facebook_url = sel.xpath(
            denver_realestate.FACEBOOK_XPATH).extract_first('').strip()
        linkedin_url = sel.xpath(
            denver_realestate.LINKEDIN_XPATH).extract_first('').strip()
        twitter_url = sel.xpath(
            denver_realestate.TWITTER_XPATH).extract_first('').strip()
        instagram_url = sel.xpath(
            denver_realestate.INSTAGRAM_XPATH).extract_first('').strip()
        pinterest_url = sel.xpath(
            denver_realestate.PINTEREST_XPATH).extract_first('').strip()
        youtube_url = sel.xpath(
            denver_realestate.YOUTUBE_XPATH).extract_first('').strip()
        googleplus_url = sel.xpath(
            denver_realestate.GOOGLEPLUS_XPATH).extract_first('').strip()
        if agent_phone == [] and office_phone == []:
            office_phone = sel.xpath(denver_realestate.OFFICE_PHONE_XPATH_2).extract()
        location = [x.strip() for x in location]
        location = ''.join(location)
        social = []
        social.append(facebook_url) if facebook_url else ''
        social.append(linkedin_url) if linkedin_url else ''
        social.append(twitter_url) if twitter_url else ''
        social.append(instagram_url) if instagram_url else ''
        social.append(pinterest_url) if pinterest_url else ''
        social.append(youtube_url) if youtube_url else ''
        social.append(googleplus_url) if googleplus_url else ''
        name_.append(name) if name else ''
        title_.append(title) if title else ''
        office_name_.append(office_name) if office_name else ''
        agent_phone_.append(agent_phone) if agent_phone else ''
        office_phone_.append(office_phone) if office_phone else ''
        Website_.append(website) if website else ''
        image_url_.append(image_url) if image_url else ''
        languages_.append(language)
        location_.append(location)
        description_.append(description)
        social_.extend(social)
        row = [link, name, title, image_url, office_name, agent_phone, office_phone, location,
               description, location, location, location, country, language, email, website, social, domain]
        row_data.append(row)
        comparison.CollectDb(link, name, title, image_url, office_name, agent_phone, office_phone, location,
                             description, location, location, location, country, language, email, website, social, domain)

    if name_ == []:
        msg = 'name field is empty in denverrealestate'
        message.append(msg)
    if title_ == []:
        msg = 'title field is empty in denverrealestate'
        message.append(msg)
    if office_name_ == []:
        msg = 'office_name field is empty in denverrealestate'
        message.append(msg)
    if agent_phone_ == []:
        msg = 'agent_phone field is empty in denverrealestate'
        message.append(msg)
    if office_phone_ == []:
        msg = 'office_phone field is empty in denverrealestate'
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in denverrealestate '
        message.append(msg)
    if Website_ == []:
        msg = 'website empty in denverrealestate'
        message.append(msg)
    if image_url_ == []:
        msg = 'image_url empty in denverrealestate'
        message.append(msg)
    if languages_ == []:
        msg = 'language empty in denverrealestate'
        message.append(msg)
    if location_ == []:
        msg = 'location empty in denverrealestate'
        message.append(msg)
    if social_ == []:
        msg = 'social empty in denverrealestate'
        message.append(msg)
    slack_note(message, domain)


def ebby_fun(links):
    print('ebby')
    name_ = []
    office_name_ = []
    office_phone_ = []
    agent_phone_ = []
    description_ = []
    image_url_ = []
    email_ = []
    title_ = []
    address_ = []
    location_ = []
    website_ = []
    social_ = []
    message = []
    city_ = []
    state_ = []
    zipcode_ = []
    domain = 'ebby_data'
    row_data = []
    for link in links:
        response = requests.get(link, headers=headers, proxies=proxies_t)
        sel = Selector(text=response.content)
        link = response.url
        city = ''
        state = ''
        zipcode = ''
        address = ''
        email = ''
        location = ''
        name = sel.xpath(ebby.NAME_XPATH).extract_first('')
        office_name = sel.xpath(ebby.OFFICE_NAME_XPATH).extract_first('').strip()
        description = sel.xpath(ebby.DESCRIPTION_XPATH).extract()
        image_url = sel.xpath(ebby.IMAGE_XPATH).extract_first('')
        title = sel.xpath(ebby.TITLE_XPATH).extract_first('').strip()
        location = sel.xpath(ebby.LOCATION_XPATH).extract()
        website = sel.xpath(ebby.WEBSITE_XPATH).extract_first('').strip()
        details = sel.xpath(ebby.DETALS_XPATH)
        agent_phone = ''
        office_phone = ''
        office_phone_numbers = []
        agent_phone_numbers = []
        for det in details:
            key = det.xpath('strong/text()').extract_first('').strip()
            if 'Office' in key:
                office_phone = det.xpath('a/text()').extract_first('').strip()
                office_phone_numbers.append(office_phone) if office_phone else ''
            if 'Primary' in key:
                agent_phone = det.xpath('a/text()').extract_first('').strip()
                agent_phone_numbers.append(agent_phone) if agent_phone else ''
            if 'Email' in key:
                email = det.xpath('a/text()').extract_first('').strip()

        description = [x.strip() for x in description if x.strip()]
        description = ' '.join(description)
        title = title.split(',')[0] if title else ''

        office_name = office_name.split('|')[1] if office_name else ''

        languages = []
        location = ''.join(location).strip()

        if location:
            try:
                city = re.findall('(.*)[A-Z]{2}.\d{5}',
                                  location)[0].split() if location else ''
            except:
                city = re.findall('(.*)[A-Z]{2}.\d{4}',
                                  location)[0].split() if location else ''

            city = ' '.join(city) if city else ''

            city = city.strip() if city else ''
            if ',' in city:
                city = city.replace(',', '')
            state = re.findall(
                '([A-Z]{2}).\d{5}', location)if location else ''
            state = state[0].strip() if state else ''
            zipcode = re.findall(
                '[A-Z]{2}(.\d{5})', location)if location else ''
            zipcode = zipcode[0].strip() if zipcode else ''
            if not state:
                state = re.findall('([A-Z]{2}).\d{4}', location)if location else ''
                state = state[0].strip() if state else ''
            if not zipcode:
                zipcode = re.findall(
                    '[A-Z]{2}(.\d{4})', location)if location else ''
                zipcode = zipcode[0].strip() if zipcode else ''

        facebook_url = sel.xpath(ebby.FACEBOOK_XPATH).extract_first('').strip()
        twitter_url = sel.xpath(ebby.TWITTER_XPATH).extract_first('').strip()
        other_urls = sel.xpath(ebby.OTHER_XPATH).extract_first('').strip()

        social = []
        social.append(facebook_url) if facebook_url else ''
        social.append(twitter_url) if twitter_url else ''
        social.append(other_urls) if other_urls else ''

        name_.append(name) if name else ''
        office_name_.append(office_name) if office_name else ''
        office_phone_.extend(office_phone_numbers) if office_phone_numbers else ''
        agent_phone_.extend(agent_phone_numbers) if agent_phone_numbers else ''
        description_.append(description) if description else ''
        image_url_.append(image_url) if image_url else ''
        email_.append(email) if email else ''
        title_.append(title) if title else ''
        address_.append(location) if location else ''
        social_.extend(social) if social else ''
        city_.append(city) if city else ''
        state_.append(state) if state else ''
        zipcode_.append(zipcode) if zipcode else ''

        row = [link, name, title, image_url, office_name, agent_phone, office_phone, location, description,
               city, zipcode, state, country, language, email, website, social, domain]
        row_data.append(row)
        comparison.CollectDb(link, name, title, image_url, office_name, agent_phone, office_phone, location, description,
                             city, zipcode, state, country, language, email, website, social, domain)

    if name_ == []:
        msg = 'name field is empty in ebby'
        message.append(msg)
    if office_name_ == []:
        msg = 'office_name field is empty in ebby'
        message.append(msg)
    if office_phone_ == []:
        msg = 'office_phone field is empty in ebby'
        message.append(msg)
    if agent_phone_ == []:
        msg = 'agent_phone field is empty in ebby'
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in ebby'
        message.append(msg)
    if image_url_ == []:
        msg = 'image_url field is empty in ebby'
        message.append(msg)
    if email_ == []:
        msg = 'email field is empty in ebby'
        message.append(msg)
    if title_ == []:
        msg = 'title field is empty in ebby'
        message.append(msg)
    if address_ == []:
        msg = 'address field is empty in ebby'
        message.append(msg)
    if city_ == []:
        msg = 'city field is empty in ebby'
        message.append(msg)
    if state_ == []:
        msg = 'state field is empty in ebby'
        message.append(msg)
    if zipcode_ == []:
        msg = 'zipcode field is empty in ebby'
        message.append(msg)
    if social_ == []:
        msg = 'social field is empty in ebby'
        message.append(msg)
    slack_note(message, domain)


def ewm_fun(links):
    print('ewm')
    domain = 'ewm_data'
    name_ = []
    languages_ = []
    description_ = []
    image_url_ = []
    title_ = []
    agent_phone_ = []
    office_phone_ = []
    office_name_ = []
    address_ = []
    city_ = []
    state_ = []
    zipcode_ = []
    social_ = []
    row_data = []
    for link in links:
        try:
            response = requests.get(link, headers=headers, proxies=proxies_t)
        except:
            try:
                response = requests.get(link, headers=headers, proxies=proxies_t)
            except:
                response = ''
        if response:
            sel = Selector(text=response.content)
            link = response.url
            name = sel.xpath(ewm.NAME_XPATH).extract_first('').strip()
            language = sel.xpath(ewm.LANGUAGES_XPATH).extract_first(
                '').replace('Fluent In: ', '').split(',')
            description = sel.xpath(ewm.DESCRIPTION_XPATH).extract()
            image_url = sel.xpath(ewm.IMAGE_XPATH).extract_first('').strip()
            title = sel.xpath(ewm.TITLE_XPATH).extract_first('').strip()
            agent_phone = sel.xpath(
                ewm.AGENT_PHONE_XPATH).extract_first('').strip()
            office_phone = sel.xpath(
                ewm.OFFICE_PHONE_XPATH).extract_first('').strip()
            office_name = sel.xpath(
                ewm.OFFICE_NAME_XPATH).extract_first('').strip()
            address = sel.xpath(ewm.ADRRESS_XPATH).extract_first('').strip()
            city = sel.xpath(ewm.CITY_XPATH).extract_first('').strip()
            state = sel.xpath(ewm.STATE_XPATH).extract_first('').strip()
            zipcode = sel.xpath(ewm.ZIPCODE_XPATH).extract_first('').strip()
            facebook_url = sel.xpath(ewm.FACEBOOK_XPATH).extract_first('').strip()
            linkedin_url = sel.xpath(ewm.LINKEDIN_XPATH).extract_first('').strip()
            twitter_url = sel.xpath(ewm.TWITTER_XPATH).extract_first('').strip()
            instagram_url = sel.xpath(
                ewm.INSTAGRAM_XPATH).extract_first('').strip()
            pinterest_url = sel.xpath(
                ewm.PINTEREST_XPATH).extract_first('').strip()
            youtube_url = sel.xpath(ewm.YOUTUBE_XPATH).extract_first('').strip()
            googleplus_url = sel.xpath(
                ewm.GOOGLEPLUS_XPATH).extract_first('').strip()
            blog_url = sel.xpath(ewm.GOOGLEPLUS_XPATH).extract_first('').strip()
            language = [] if language == [''] else language
            social = []
            social.append(facebook_url) if facebook_url else ''
            social.append(linkedin_url) if linkedin_url else ''
            social.append(twitter_url) if twitter_url else ''
            social.append(instagram_url) if instagram_url else ''
            social.append(pinterest_url) if pinterest_url else ''
            social.append(youtube_url) if youtube_url else ''
            social.append(googleplus_url) if googleplus_url else ''
            social.append(blog_url) if blog_url else ''
            name_.append(name) if name else ''
            languages_.append(language) if language else ''
            description_.append(description) if description else ''
            image_url_.append(image_url) if image_url else ''
            title_.append(title) if title else ''
            agent_phone_.append(agent_phone) if agent_phone else ''
            office_phone_.append(office_phone) if office_phone else ''
            office_name_.append(office_name) if office_name else ''
            address_.append(address) if address else ''
            city_.append(city) if city else ''
            state_.append(state) if state else ''
            zipcode_.append(zipcode) if zipcode else ''
            social_.extend(social) if social else ''
            row = [link, name, title, image_url, office_name, agent_phone, office_phone, address, description,
                   city, zipcode, state, country, language, email, website, social]
            row_data.append(row)
            comparison.CollectDb(link, name, title, image_url, office_name, agent_phone, office_phone, address, description,
                                 city, zipcode, state, country, language, email, website, social, domain)

    if name_ == []:
        msg = 'name field is empty in ewm'
        message.append(msg)
    if languages_ == []:
        msg = 'languages field is empty in ewm'
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in ewm'
        message.append(msg)
    if image_url_ == []:
        msg = 'image_url field is empty in ewm'
        message.append(msg)
    if title_ == []:
        msg = 'title field is empty in ewm'
        message.append(msg)
    if agent_phone_ == []:
        msg = 'agent_phone field is empty in ewm'
        message.append(msg)
    if office_phone_ == []:
        msg = 'office_phone field is empty in ewm'
        message.append(msg)
    if office_name_ == []:
        msg = 'office_name field is empty in ewm'
        message.append(msg)
    if address_ == []:
        msg = 'address field is empty in ewm'
        message.append(msg)
    if city_ == []:
        msg = 'city field is empty in ewm'
        message.append(msg)
    if state_ == []:
        msg = 'state field is empty in ewm'
        message.append(msg)
    if zipcode_ == []:
        msg = 'zipcode field is empty in ewm'
        message.append(msg)
    if social_ == []:
        msg = 'social field is empty in ewm'
        message.append(msg)
    slack_note(message, domain)


def iowarealty_fun(links):
    print('iowarealty')
    count = 0
    name_ = []
    titles_ = []
    office_name_ = []
    image_url_ = []
    agent_phone_numbers_ = []
    office_phone_numbers_ = []
    address_ = []
    description_ = []
    city_ = []
    zipcode_ = []
    state_ = []
    country_ = []
    language_ = []
    email_ = []
    social_ = []
    message = []
    Website_ = []
    row_data = []
    domain = 'iowarealty_data'
    for link in links:
        count = count + 1
        try:
            response = requests.get(link, headers=headers, proxies=proxies_s)
        except:
            try:
                response = requests.get(link, headers=headers, proxies=proxies_s)
            except:
                response = ''
        if response:
            sel = Selector(text=response.content)
            name = ''.join(sel.xpath(iowarealty.NAME_XPATH).extract())
            title_ = sel.xpath(iowarealty.TITLE_XPATH).extract_first('').strip()
            office_name = sel.xpath(iowarealty.OFFICE_NAME_XPATH).extract_first('')
            location = sel.xpath(iowarealty.ADDRESS_XPATH_1).extract()
            img = ''
            img = sel.xpath(iowarealty.IMAGE_XPATH).extract_first('')
            image = img.strip("'background-image: url(').strip(');")
            # if image:
            #     image_url = response.urljoin(image)
            title = ''.join(title_).strip()
            if office_name == 'Ohl Iowa Realty Real Estate & Insurance, Inc.':
                address_ = sel.xpath(iowarealty.ADDRESS_XPATH_1).extract()
                addres = ' '.join(' '.join(address_).split()
                                  ).strip() if address_ else ''
                address = addres.replace(office_name, '').strip()
                zipcode = ''
                state_zip = ''
                state = ''

                city = address.split(',', 1)[0]
                state_zip = address.split(',', 1)[1].strip() if address else ''
                state = state_zip.split(' ')[0] if state_zip else ''
                zipcode = state_zip.split(' ')[1] if state_zip else ''
            else:
                address_ = sel.xpath(iowarealty.ADDRESS_XPATH_1).extract()
                addres = ' '.join(' '.join(address_).split()
                                  ).strip() if address_ else ''
                addr_ = sel.xpath(iowarealty.ADDRESS_XPATH_2).extract_first('').replace('<br>', '')
                address = addres.replace(addr_, '').strip()

                zipcode = ''
                state_zip = ''
                state = ''

                city = address.split(',', 1)[0]
                state_zip = address.split(',', 1)[1].strip() if address else ''
                state = state_zip.split(' ')[0] if state_zip else ''
                zipcode = state_zip.split(' ')[1] if state_zip else ''
            office_phone_numbers = []
            office_phone = sel.xpath(iowarealty.OFFICE_PHONE_XPATH).extract()
            office_phone_ = ''.join(office_phone)
            office_phone_number = re.findall('\d+-\d+-\d+', office_phone_)
            if office_phone_number:
                for j in office_phone_number:
                    office_phone_numbers.append(j)
            agent_phone_numbers = []
            agent_phone = sel.xpath(iowarealty.AGENT_PHONE_XPATH).extract()
            agent_phone_ = ''.join(agent_phone)
            agent_phone_number = re.findall('\d+-\d+-\d+', agent_phone_)
            if agent_phone_number:
                for i in agent_phone_number:
                    agent_phone_numbers.append(i)
            email = sel.xpath(iowarealty.EMAIL_XPATH).extract_first('')
            if email:
                email = ''.join(email).strip()

            description_1 = sel.xpath(iowarealty.DESCRIPTION_XPATH_1).extract()
            description_2 = sel.xpath(iowarealty.DESCRIPTION_XPATH_2).extract()
            description_3 = sel.xpath(iowarealty.DESCRIPTION_XPATH_3).extract()
            description = ''

            if description_1:
                description = ' '.join(''.join(description_1).split())
            if description_2:
                description = ' '.join(''.join(description_2).split())
            if description_3:
                description = ' '.join(''.join(description_3).split())
            social = sel.xpath(iowarealty.SOCIAL_XPATH).extract()
            name_.append(name) if name else ''
            titles_.append(title) if title else ''
            office_name_.append(office_name) if office_name else ''
            image_url_.append(image) if image else ''
            agent_phone_numbers_.append(agent_phone_numbers) if agent_phone_numbers else ''
            office_phone_numbers_.append(office_phone_numbers) if office_phone_numbers else ''
            address_.append(address) if address else ''
            description_.append(description) if description else ''
            city_.append(city) if city else ''
            zipcode_.append(zipcode) if zipcode else ''
            state_.append(state) if state else ''
            country_.append(country) if country else ''
            language_.append(language) if language else ''
            email_.append(email) if email else ''
            social_.extend(social) if social else ''
            row = [link, name, title, image, office_name, agent_phone_numbers, office_phone_numbers, address, description,
                   city, zipcode, state, country, language, email, website, social]
            row_data.append(row)
            comparison.CollectDb(link, name, title, image, office_name, agent_phone_numbers, office_phone_numbers, address, description,
                                 city, zipcode, state, country, language, email, website, social, domain)

    if name_ == []:
        msg = 'name field is empty in iowarealty'
        message.append(msg)
    if titles_ == []:
        msg = 'title field is empty in iowarealty'
        message.append(msg)
    if office_name_ == []:
        msg = 'office name field is empty in iowarealty'
        message.append(msg)
    if image_url_ == []:
        msg = 'image_url field is empty in iowarealty'
        message.append(msg)
    if agent_phone_numbers_ == []:
        msg = 'agent_phone_numbers field is empty in iowarealty'
        message.append(msg)
    if office_phone_numbers_ == []:
        msg = 'office_phone_numbers field is empty in iowarealty'
        message.append(msg)
    if address_ == []:
        msg = 'address field is empty in iowarealty'
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in iowarealty'
        message.append(msg)
    if city_ == []:
        msg = 'city field is empty in iowarealty'
        message.append(msg)
    if zipcode_ == []:
        msg = 'zipcode field is empty in iowarealty'
        message.append(msg)
    if state_ == []:
        msg = 'state field is empty in iowarealty'
        message.append(msg)
    if country_ == []:
        msg = 'country field is empty in iowarealty'
        message.append(msg)
    # if language_ == []:
    #     msg = 'language field is empty in iowarealty'
    #     message.append(msg)
    if email_ == []:
        msg = 'email field is empty in iowarealty'
        message.append(msg)
    if social_ == []:
        msg = 'social field is empty in iowarealty'
        message.append(msg)
    slack_note(message, domain)


def semonin_fun(agent_list):
    print('semonin-realtor')
    count = 0
    name_ = []
    title_ = []
    image_url_ = []
    office_name_ = []
    agent_phone_numbers_ = []
    office_phone_numbers_ = []
    address_ = []
    country_ = []
    language_ = []
    email_ = []
    website_ = []
    social_ = []
    message = []
    domain = 'semonin_realtors'
    row_data = []
    for agent in agent_list:
        count = count + 1
        name = agent.xpath(semonin_realtor.NAME_XPATH).extract_first('').strip()
        title = agent.xpath(semonin_realtor.TITLE_XPATH).extract_first('').strip()
        agent_phone = agent.xpath(semonin_realtor.AGENT_PHONE_XPATH).extract()
        office_phone = agent.xpath(semonin_realtor.OFFICE_PHONE_XPATH).extract()
        url = agent.xpath(semonin_realtor.LINK_XPATH).extract_first('')
        agent_phone_numbers = []
        office_phone_numbers = []
        for number in agent_phone:
            number = number.strip()
            agent_phone_numbers.append(number)
        for num in office_phone:
            num = num.strip()
            office_phone_numbers.append(num)

        res = requests.get(url, headers=headers, proxies=proxies_t)
        sel = Selector(text=res.content)
        link = res.url
        office_name = sel.xpath(semonin_realtor.OFFICE_NAME_XPATH).extract_first('').strip()
        address = sel.xpath(semonin_realtor.ADDRESS_XPATH).extract_first('').strip()
        if address:
            address = sel.xpath(semonin_realtor.POSTAL_XPATH).extract_first('').split(',')
        if address == '':
            address = sel.xpath(semonin_realtor.ADDRESS_DETAILS).extract_first('').strip()
        social = sel.xpath(semonin_realtor.SOCIAL_XPATH).extract()
        description = sel.xpath(semonin_realtor.DESCRIPTION_XPATH).extract()
        description = ' '.join(''.join(description).split())
        image_url1 = sel.xpath(semonin_realtor.IMAGE_XPATH1).extract_first('').strip()
        image_url2 = sel.xpath(semonin_realtor.IMAGE_XPATH2).extract_first('').strip()
        if image_url2:
            image_url2 = re.findall("https.*\w", image_url2)
            image_url2 = ''.join(image_url2)
        if image_url1:
            image_url = image_url1
        else:
            image_url = image_url2

        if 'no-agent-photo' in image_url:
            image_url = ''
        name_.append(name) if name else ''
        title_.append(title) if title else ''
        image_url_.append(image_url) if image_url else ''
        office_name_.append(office_name) if office_name else ''
        agent_phone_numbers_.extend(office_phone_numbers) if office_phone_numbers else ''
        office_phone_numbers_.extend(agent_phone_numbers) if agent_phone_numbers else ''
        address_.append(address) if address else ''
        country_.append(country) if country else ''
        language_.extend(language) if language else ''
        # email_.append(email) if email else ''
        website_.append(link) if link else ''
        social_.extend(social) if social else ''
        row = [url, name, title, image_url, office_name, agent_phone_numbers, office_phone_numbers, address, description,
               address, address, address, country, language, email, link, social]
        row_data.append(row)
        comparison.CollectDb(url, name, title, image_url, office_name, agent_phone_numbers, office_phone_numbers, address, description,
                             address, address, address, country, language, email, link, social, domain)
        if count > 24:
            break

    if name_ == []:
        msg = 'name field is empty in semonin_realtors'
        message.append(msg)
    if title_ == []:
        msg = 'title field is empty in semonin_realtors'
        message.append(msg)
    if image_url_ == []:
        msg = 'image_url field is empty in semonin_realtors'
        message.append(msg)
    if office_name_ == []:
        msg = 'office_name field is empty in semonin_realtors'
        message.append(msg)
    if agent_phone_numbers_ == []:
        msg = 'agent_phone_numbers field is empty in semonin_realtors'
        message.append(msg)
    if office_phone_numbers_ == []:
        msg = 'office_phone_numbers field is empty in semonin_realtors'
        message.append(msg)
    if address_ == []:
        msg = 'address field is empty in semonin_realtors'
        message.append(msg)
    if country_ == []:
        msg = 'country field is empty in semonin_realtors'
        message.append(msg)
    # if language_ ==  []:
    #     msg = 'language field is empty in semonin_realtors'
    #     message.append(msg)
    # if email_ == []:
    #     msg = 'email field is empty in semonin_realtors'
    #     message.append(msg)
    if website_ == []:
        msg = 'website field is empty in semonin_realtors'
        message.append(msg)
    if social_ == []:
        msg = 'social field is empty in semonin_realtors'
        message.append(msg)
    slack_note(message, domain)


def century21global_fun(links):
    print('century21global')
    name_ = []
    title_ = []
    image_ = []
    office_ = []
    agent_phn_ = []
    office_phn_ = []
    location_ = []
    description_ = []
    city_ = []
    zipcode_ = []
    state_ = []
    country_ = []
    languages_ = []
    email_ = []
    website_ = []
    social_ = []
    message = []
    domain = 'century21global'
    row_data = []
    for link in links:
        response = requests.get(link, headers=headers, proxies=proxies_t)
        sel = Selector(text=response.content)
        name = sel.xpath(century21global.NAME_XPATH).extract_first('')
        office_name = sel.xpath(century21global.OFFICE_NAME_XPATH).extract_first('')
        languages = sel.xpath(century21global.LANGUAGES_XPATH).extract()
        description = sel.xpath(century21global.DESCRIPTION_XPATH).extract()
        image = sel.xpath(century21global.IMAGE_XPATH).extract_first('')
        location = sel.xpath(century21global.LOCATION_XPATH).extract()
        languages = ' '.join(''.join(languages).replace(':', '').split())
        language = languages.split(',')
        language_ = []
        for lang in language:
            lang_ = lang.strip()
            language_.append(lang_)

        if language_ == ['']:
            language_ = []

        description = ' '.join(
            ' '.join(description).split()).strip() if description else ''

        phone = sel.xpath(century21global.PHONE_XPATH).extract()
        phone = [phone_text.strip()
                 for phone_text in phone if phone_text.strip()]
        agent_phn = []
        office_phn = []
        for phn in phone:
            if re.findall(r'Cell Phone:\s+?(.*)', phn):
                agent_num = re.findall(
                    r'Cell Phone:\s?(.*)', phn)[0].strip()
                agent_phn.append(agent_num)
            elif re.findall(r'Phone:\s+?(.*)', phn):
                office_num = re.findall(r'Phone:\s?(.*)', phn)[0].strip()
                office_phn.append(office_num)
        if 'https' not in image:
            image = 'https://www.century21global.com' + image

        if 'noPhoto-agent' in image:
            image = ''
        location = ' '.join(' '.join(location).split()
                            ).strip() if location else ''
        country = sel.xpath(century21global.COUNTRY_XPATH).extract()
        country = ''.join(country).strip()

        states = sel.xpath(century21global.STATE_XPATH).extract()
        if states:
            states = ''.join(states).strip()
            state = states.replace('city', '').strip()
        else:
            states = sel.xpath(century21global.STATE_XPATH_2).extract()[1]
            states = states.strip()

        city = sel.xpath(century21global.CITY_XPATH).extract()
        city = ''.join(city).strip()
        if city == '':
            city = state
            state = ''
        zipcode = ''
        zip_ = re.findall(r'[A-Z]\d[A-Z] *\d[A-Z]\d', location)
        zipcode = ''.join(zip_).strip()
        zipcode = ''.join(zip_).strip()

        if zipcode == '':
            destination = sel.xpath(century21global.DESTINATION_XPATH).extract()
            loc = []

            for content in [content.strip() for content in destination if content.strip()]:

                if 'phone' not in content.lower():
                    loc.append(content)
            locs = []
            for content in [content.strip() for content in loc if content.strip()]:

                if 'fax' not in content.lower():
                    locs.append(content)
            for num in locs:
                zip_ = re.findall(r'[0-9]{3,7}', num)
                if zip_:
                    zipcode = zip_
            if len(zipcode) == 2:
                zipcode = '-'.join(zipcode).strip()
            else:
                zipcode = ' '.join(zipcode).strip()

        address_ = location.split(city)[0] if city else ''
        address_ = ''.join(address_).strip(', ')
        address = ''
        if address_ == '':
            address = sel.xpath(century21global.ADDRESS_XPATH).extract_first('').strip()
        else:
            address = address_
        url = response.url
        profile_url = urllib.parse.unquote_plus(url)
        office = urllib.parse.unquote_plus(office_name)
        address = urllib.parse.unquote_plus(address)

        name_.append(name) if name else ''
        # title_.append(title) if title else ''
        image_.append(image) if image else ''
        office_.append(office) if office else ''
        agent_phn_.extend(agent_phn) if agent_phn else ''
        office_phn_.extend(office_phn) if office_phn else ''
        location_.append(address) if address else ''
        description_.append(description) if description else ''
        city_.append(city) if city else ''
        zipcode_.append(zipcode) if zipcode else ''
        state_.append(state) if state else ''
        country_.append(country) if country else ''
        languages_.exend(language_) if language_ else ''
        email_.append(email) if email else ''
        website_.append(website) if website else ''
        social_.extend(social) if social else ''
        row = [link, name, title, image, office, agent_phn, office_phn, address, description,
               city, zipcode, state, country, language_, email, website, social]
        row_data.append(row)

        comparison.CollectDb(link, name, title, image, office, agent_phn, office_phn, address, description,
                             city, zipcode, state, country, language_, email, website, social, domain)

    if name_ == []:
        msg = 'name field is empty in century21global'
        message.append(msg)
    # if title_ == []:
    #     msg = 'title_ field is empty in century21global'
    #     message.append(msg)
    if image_ == []:
        msg = 'image_ field is empty in century21global'
        message.append(msg)
    if office_ == []:
        msg = 'office field is empty in century21global'
        message.append(msg)
    if agent_phn_ == []:
        msg = 'agent_phone field is empty in century21global'
        message.append(msg)
    if office_phn_ == []:
        msg = 'office_phone field is empty in century21global'
        message.append(msg)
    if address_ == []:
        msg = 'address field is empty in century21global'
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in century21global'
        message.append(msg)
    if city_ == []:
        msg = 'city field is empty in century21global'
        message.append(msg)
    if zipcode_ == []:
        msg = 'zipcode field is empty in century21global'
        message.append(msg)
    if state_ == []:
        msg = 'state field is empty in century21global'
        message.append(msg)
    if country_ == []:
        msg = 'country field is empty in century21global'
        message.append(msg)
    if languages_ == []:
        msg = 'languages field is empty in century21global'
        message.append(msg)
    if email_ == []:
        msg = 'email field is empty in century21global'
        message.append(msg)
    if website_ == []:
        msg = 'website field is empty in century21global'
        message.append(msg)
    if social_ == []:
        msg = 'social field is empty in century21global'
        message.append(msg)
    slack_note(message, domain)


def exprealty_fun(agent_list):
    print('exprealty')
    name_1 = []
    title_1 = []
    image_url_1 = []
    office_name_1 = []
    agent_phone_numbers_1 = []
    office_phone_numbers_1 = []
    address_1 = []
    description_1 = []
    city_1 = []
    zipcode_1 = []
    state_1 = []
    country_1 = []
    email_1 = []
    website_1 = []
    social_1 = []
    message = []
    count = 0
    domain = 'exprealty'
    row_data = []
    for agent in agent_list:
        data = agent.get('_source')
        count = count + 1
        if data:
            city = ''
            state = ''
            zipcode = ''
            agent_phone_numbers = [data.get('primaryPhone', '')] if data.get(
                'primaryPhone', '') else ''
            agent_loc = data.get('agentPrimaryLocation')
            if agent_loc:
                city = agent_loc[0].get('city', '')
                state = agent_loc[0].get('state', '')
                zipcode_ = agent_loc[0].get('zipcode', '')
                if re.findall(r'\d{4,}', zipcode_):
                    zipcode = ', '.join(
                        re.findall(r'\d{4,}', zipcode_))
                    country = 'United States'
                elif re.findall(r'\w\d\w\s?-?\d\w\d', zipcode_):
                    zipcode = zipcode_.upper()
                    country = 'Canada'
                else:
                    for loc in data.get('activeLocations'):
                        if loc.get('stateName') == state:
                            country = loc.get('countryName')
                        elif loc.get('city') == city:
                            country = loc.get('countryName')
                        else:
                            country = ''
                    zipcode = ''
            address = ''
            description = remove_tags(
                data.get('bio', '')).strip() if data.get('bio', '') else ''
            if description == "":
                description = data.get('AgentMarketingCenter')
                if description:
                    for i in description:
                        description = i.get('Bio', '')
                        description = remove_tags(description)
                        description = description.replace(
                            '*', '').strip()
                    # print(description)
                else:
                    description = ''

            email = data.get('primaryEmail', '')
            first_name = data.get('firstName', '')
            image_url = 'https://experts.expcloud.com/agentphoto/' + \
                data.get(
                    'agentPhoto', '') + '.png' if not data.get('agentPhoto', '') == '0' else ''
            languages = []
            last_name = data.get('lastName', '')
            middle_name = ''
            office_name = 'eXp Realty'
            office_phone_numbers = []
            url = data.get('directlink', '')
            if 'htt' in url:
                profile_url = url
            else:
                profile_url = (
                    'https://experts.expcloud.com/' + data.get('directlink', '')).strip('/')

            title = data.get('title', '').strip()
            website = ''
            data2 = data.get('AgentMarketingCenter')
            if data2:
                for i in data2:
                    website = i.get('Website', '')
                    linkedin_url = i.get('LinkedIn_URL', '')
                    facebook_url = i.get('Facebook_URL', '')
                    twitter_url = i.get('Twitter', '')
            name_ = []
            name_.append(first_name) if first_name else ''
            name_.append(middle_name) if middle_name else ''
            name_.append(last_name) if last_name else ''
            names = ''.join(name_)
            social = []
            social.append(linkedin_url) if linkedin_url else ''
            social.append(facebook_url) if facebook_url else ''
            social.append(twitter_url) if twitter_url else ''

            name_1.append(names) if names else ''
            title_1.append(title) if title else ''
            image_url_1.append(image_url) if image_url else ''
            office_name_1.append(office_name) if office_name else ''
            agent_phone_numbers_1.extend(agent_phone_numbers) if agent_phone_numbers else ''
            office_phone_numbers_1.extend(office_phone_numbers) if office_phone_numbers else ''
            address_1.append(address) if address else ''
            description_1.append(description) if description else ''
            city_1.append(city) if city else ''
            zipcode_1.append(zipcode) if zipcode else ''
            state_1.append(state) if state else ''
            country_1.append(country) if country else ''
            email_1.append(email) if email else ''
            website_1.append(website) if website else ''
            social_1.extend(social) if social else ''
            row = [profile_url, names, title, image_url, office_name, agent_phone_numbers, office_phone_numbers, address, description,
                   city, zipcode, state, country, languages, email, website, social]
            row_data.append(row)
            comparison.CollectDb(profile_url, names, title, image_url, office_name, agent_phone_numbers, office_phone_numbers, address, description,
                                 city, zipcode, state, country, languages, email, website, social, domain)
        if count > 24:
            break

    if name_1 == []:
        msg = 'name field is empty in exprealty'
        message.append(msg)
    if title_1 == []:
        msg = 'title field is empty in exprealty'
        message.append(msg)
    if image_url_1 == []:
        msg = 'image_url field is empty in exprealty'
        message.append(msg)
    if office_name_1 == []:
        msg = 'office_name field is empty in exprealty'
        message.append(msg)
    if agent_phone_numbers_1 == []:
        msg = 'agent_numbers field is empty in exprealty'
        message.append(msg)
    if office_phone_numbers_1 == []:
        msg = 'office_numbers field is empty in exprealty'
        message.append(msg)
    if address_1 == []:
        msg = 'social field is empty in exprealty'
        message.append(msg)
    if description_1 == []:
        msg = 'address field is empty in exprealty'
        message.append(msg)
    if city_1 == []:
        msg = 'city field is empty in exprealty'
        message.append(msg)
    if zipcode_1 == []:
        msg = 'zipcode field is empty in exprealty'
        message.append(msg)
    if state_1 == []:
        msg = 'state field is empty in exprealty'
        message.append(msg)
    if country_1 == []:
        msg = 'country field is empty in exprealty'
        message.append(msg)
    if email_1 == []:
        msg = 'social field is empty in exprealty'
        message.append(msg)
    if website_1 == []:
        msg = 'Website field is empty in exprealty'
        message.append(msg)
    if social_1 == []:
        msg = 'social field is empty in exprealty'
        message.append(msg)
    slack_note(message, domain)


def compass_fun(links):
    print('compass')
    name_ = []
    title_ = []
    image_url_ = []
    office_name_ = []
    agent_phone_numbers_ = []
    office_phone_numbers_ = []
    address_ = []
    description_ = []
    country_ = []
    languages_ = []
    email_ = []
    website_ = []
    social_ = []
    message = []
    domain = 'compass'
    row_data = []
    city_ = []
    for link in links:
        response = requests.get(link, headers=headers, proxies=proxies_t)
        sel = Selector(text=response.content)
        url = response.url
        name = sel.xpath(compass.NAME_XPATH).extract_first('').strip()
        title = sel.xpath(compass.TITLE_XPATH).extract_first('').strip()
        email = sel.xpath(compass.EMAIL_XPATH).extract_first('').strip()
        phone_numbers = sel.xpath(compass.PHONE_NUMBERS_XPATH).extract()
        office_numbers = sel.xpath(compass.OFFICE_NUMBER_XPATH).extract_first('').strip()
        image_url = sel.xpath(compass.IMAGE_XPATH).extract_first('').strip()
        address = sel.xpath(compass.ADDRESS_XPATH).extract()
        location = sel.xpath(compass.LOCATION_XPATH).extract()
        office_name = sel.xpath(compass.OFFICE_NAME_XPATH).extract_first('')
        social = sel.xpath(compass.SOCIAL_XPATH).extract()
        agent_phone_numbers = sel.xpath(compass.PHONE_NUMBERS_XPATH).extract_first('')
        office_phone_numbers = sel.xpath(compass.OFFICE_NUMBER_XPATH).extract_first('')
        language = sel.xpath(compass.LANGUAGES_XPATH).extract()
        k = response.text
        data = k.replace('</b>', '</style>')
        des = sel.xpath(compass.DESCRIPTION_XPATH_2).extract()
        description = ' '.join(' '.join(des).split()).split(
            'Client Testimonials', 1)[0].strip()
        # city = sel.xpath(compass.CITY_XPATH).extract_first('').strip()
        all_language = ['English', 'Bulgarian', 'French', 'Polish', 'Wolof', 'Serer', 'Japanese', 'Spanish', 'Persian', 'Malayalam', 'Tamil', 'Telugu', 'Slovak', 'Russian', 'Vietnamese', 'Hindi', 'Mandarin', 'Taiwanes', 'Italian', 'Cham', 'Danish', 'Afrikaans', 'Korean', 'Albanian', 'Arabic',
                        'Punjabi', 'German', 'Dutch', 'Tagalog', 'Swedish', 'Hebrew', 'Serbian', 'Bosnian', 'Croatian', 'Macedonia', 'Assyriann', 'Slovenian', 'Portuguese', 'Lebanese', 'Farsi', 'Urdu', 'Hakka', 'Chinese', 'Yue Chinese/Cantonese', 'Ewe', 'Yoruba', 'Mina', 'Ossetic', 'Czech', 'Thai', 'Ukrainian']
        languages = []
        for lang in language:
            for j in all_language:
                if j in lang:
                    languages.append(j)

        if agent_phone_numbers:
            if 'M:' in agent_phone_numbers:
                agent_phone_numbers = agent_phone_numbers.replace(
                    'M:', '').strip()
        if office_phone_numbers:
            if 'O:' in office_phone_numbers:
                office_phone_numbers = office_phone_numbers.replace(
                    'O:', '').strip()
        agent_phone = []
        office_phone = []

        agent_phone.append(agent_phone_numbers) if agent_phone_numbers else ''
        office_phone.append(office_phone_numbers) if office_phone_numbers else ''
        city = sel.xpath(compass.CITY_XPATH).extract()
        city = city[1].strip() if len(city) > 1 else ''

        name_.append(name) if name else ''
        title_.append(title) if title else ''
        image_url_.append(image_url) if image_url else ''
        office_name_.append(office_name) if office_name else ''
        agent_phone_numbers_.extend(agent_phone) if agent_phone else ''
        office_phone_numbers_.extend(office_phone) if office_phone else ''
        address_.extend(address) if address else ''
        description_.append(description) if description else ''
        country_.append(country) if country else ''
        languages_.extend(languages) if languages else ''
        email_.append(email) if email else ''
        website_.append(website) if website else ''
        social_.extend(social) if social else ''
        city_.append(city) if city else ''

        row = [url, name, title, image_url, office_name, agent_phone_numbers, office_phone_numbers, address, description,
               city, address, address, country, languages, email, website, social]
        row_data.append(row)
        comparison.CollectDb(url, name, title, image_url, office_name, agent_phone_numbers, office_phone_numbers, address, description,
                             city, address, address, country, languages, email, website, social, domain)

    if name_ == []:
        msg = 'name field is empty in compass'
        message.append(msg)
    if title_ == []:
        msg = 'title field is empty in compass'
        message.append(msg)
    if image_url_ == []:
        msg = 'image_url field is empty in compass'
        message.append(msg)
    # if office_name_ == []:
    #     msg = 'office_name field is empty in compass'
    #     message.append(msg)
    if agent_phone_numbers_ == []:
        msg = 'agent_phone_numbers field is empty in compass'
        message.append(msg)
    if office_phone_numbers_ == []:
        msg = 'office_phone_numbers field is empty in compass'
        message.append(msg)
    # if address_ == []:
    #     msg = 'address field is empty in compass'
    #     message.append(msg)
    if description_ == []:
        msg = 'description field is empty in compass'
        message.append(msg)
    if country_ == []:
        msg = 'country field is empty in compass'
        message.append(msg)
    if languages_ == []:
        msg = 'languages field is empty in compass'
        message.append(msg)
    if email_ == []:
        msg = 'email field is empty in compass'
        message.append(msg)
    # if website_ == []:
    #     msg = 'website field is empty in compass'
    #     message.append(msg)
    if social_ == []:
        msg = 'social field is empty in compass'
        message.append(msg)
    if city_ == []:
        msg = 'city field is empty in compass'
        message.append(msg)

    slack_note(message, domain)


def realliving_realestate_fun(agent_list):
    print('realliving_realestate')
    name_ = []
    title_ = []
    image_url_ = []
    office_name_ = []
    agent_phone_ = []
    office_phone_ = []
    address_ = []
    description_ = []
    location_ = []
    country_ = []
    language_ = []
    email_ = []
    website_ = []
    social_ = []
    message = []
    count = 0
    domain = 'realliving_realestate'
    row_data = []
    for agent in agent_list:
        count = count + 1
        link = agent.xpath(realliving_realestate.LINKS_XPATH).extract_first('').strip()
        name = agent.xpath(realliving_realestate.NAME_XPATH).extract_first('').strip()
        image_url = agent.xpath(realliving_realestate.IMAGE_XPATH).extract_first('').strip()
        agent_phone = agent.xpath(realliving_realestate.AGENT_PHONE_XPATH).extract()
        office_phone = agent.xpath(realliving_realestate.OFFICE_NUMBER_XPATH).extract()
        website = agent.xpath(realliving_realestate.WEBSITE_XPATH).extract_first('')
        address = agent.xpath(realliving_realestate.ADRRESS_XPATH).extract_first('').strip()
        office_name = agent.xpath(realliving_realestate.OFFICE_NAME_XPATH).extract_first('').strip()
        social = agent.xpath(realliving_realestate.SOCIAL_XPATH).extract()
        location = ''.join(agent.xpath(realliving_realestate.LOCATION_XPATH).extract())
        agent_phone = [''.join(agent_phone).strip()]
        office_phone = [''.join(office_phone).strip()]
        response = requests.get(link, headers=headers, proxies=proxies_t)
        sel = Selector(text=response.content)
        description = sel.xpath(realliving_realestate.DESCRIPTION_XPATH).extract()
        description = ''.join(description).replace('\r\n', '').strip()
        title = sel.xpath(realliving_realestate.TITLE_XPATH).extract()
        title = ''.join(title).strip()
        email1 = sel.xpath(realliving_realestate.EMAIL_XPATH_1).extract_first('')
        email2 = sel.xpath(realliving_realestate.EMAIL_XPATH_2).extract_first('')
        if email1:
            email = email1
        elif email2:
            email2 = ''.join(email2).split()[0]
            email = email2
        else:
            email = ''
        name_.append(name) if name else ''
        title_.append(title) if title else ''
        image_url_.append(image_url) if image_url else ''
        office_name_.append(office_name) if office_name else ''
        agent_phone_.extend(agent_phone) if agent_phone else ''
        office_phone_.extend(office_phone) if office_phone else ''
        address_.append(address) if address else ''
        description_.append(description) if description else ''
        location_.append(location) if location else ''
        country_.append(country) if country else ''
        email_.append(email) if email else ''
        website_.append(website) if website else ''
        social_.extend(social) if social else ''
        row = [link, name, title, image_url, office_name, agent_phone, office_phone, address, description,
               location, location, location, country, language, email, website, social]
        row_data.append(row)
        comparison.CollectDb(link, name, title, image_url, office_name, agent_phone, office_phone, address, description,
                             location, location, location, country, language, email, website, social, domain)
        if count > 24:
            break

    if name_ == []:
        msg = 'name field is empty in realliving_realestate'
        message.append(msg)
    # if title_ == []:
    #     msg = 'title field is empty in realliving_realestate'
    #     message.append(msg)
    if image_url_ == []:
        msg = 'image_url field is empty in realliving_realestate'
        message.append(msg)
    if office_name_ == []:
        msg = 'office_name field is empty in realliving_realestate'
        message.append(msg)
    if agent_phone_ == []:
        msg = 'agent_phone field is empty in realliving_realestate'
        message.append(msg)
    if office_phone_ == []:
        msg = 'office_phone field is empty in realliving_realestate'
        message.append(msg)
    if address_ == []:
        msg = 'address field is empty in realliving_realestate'
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in realliving_realestate'
        message.append(msg)
    if location_ == []:
        msg = 'location field is empty in realliving_realestate'
        message.append(msg)
    if country_ == []:
        msg = 'country field is empty in realliving_realestate'
        message.append(msg)
    # if language_ == []:
    #     msg = 'language field is empty in realliving_realestate'
    #     message.append(msg)
    if email_ == []:
        msg = 'email field is empty in realliving_realestate'
        message.append(msg)
    if website_ == []:
        msg = 'website field is empty in realliving_realestate'
        message.append(msg)
    if social_ == []:
        msg = 'social field is empty in realliving_realestate'
        message.append(msg)
    slack_note(message, domain)


def bhgre_fun(links):
    print('bhgre')
    name_ = []
    title_ = []
    image_url_ = []
    office_name_ = []
    agent_phone_numbers_ = []
    office_phone_numbers_ = []
    address_ = []
    description_ = []
    city_ = []
    zipcode_ = []
    state_ = []
    country_ = []
    language_ = []
    social_ = []
    message = []
    domain = 'bhgre'
    row_data = []
    headers = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
               'accept-encoding': 'gzip, deflate',
               'accept-language': 'en-GB,en-US;q=0.8,en;q=0.6',
               'connection': 'keep-alive',
               'upgrade-insecure-requests': '1',
               'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36'}
    for link in links:
        proxy = storm_proxy()
        proxies = proxy['proxies']
        try:
            res = requests.get(url=link, headers=headers, proxies=proxies_t)
        except:
            try:
                res = requests.get(url=link, headers=headers, proxies=proxies_t)
            except:
                res = ''
        if res:
            sel = Selector(text=res.content)
            name = sel.xpath(bhgre.NAME_XPATH).extract_first('')
            image_url = sel.xpath(bhgre.IMAGE_XPATH).extract()
            description = ''.join(sel.xpath(bhgre.DESCRIPTION_XPATH).extract())
            phone_numbers_ = sel.xpath(bhgre.PHONE_NUM_XPATH).extract_first('').strip()
            languages = sel.xpath(bhgre.LANGUAGES_XPATH).extract()
            social = sel.xpath(bhgre.SOCIAL_XPATH).extract()
            image_url = image_url[0].strip() if image_url else ''
            agent_phone_numbers = []
            agent_phone_numbers.append(phone_numbers_)
            res_body = re.sub(b",\n\s*\"description\":\s\"(?:.|\n)*?\"", b"", res.content)
            sel_ = Selector(text=res_body)
            json_ = sel_.xpath(bhgre.JSON_XPATH).extract()
            if json_:
                office_phone_numbers = []
                json_ = ' '.join(' '.join(json_).split()).strip().replace(name, "") if json_ else ''
                json_data = json.loads(json_)
                agent_address = json_data.get('about', {}).get('affiliation', {}).get('address', {})
                address = agent_address.get('streetAddress', '')
                zipcode = agent_address.get('postalCode', '')
                city = agent_address.get('addressLocality', '')
                state = agent_address.get('addressRegion', '')

                office_name = json_data.get('about', {}).get(
                    'affiliation', {}).get('name', '')
                office_phone = json_data.get('about', {}).get(
                    'affiliation', {}).get('telephone', '')
                office_phone_numbers.append(office_phone)
                name_.append(name) if name else ''
                title_.append(title) if title else ''
                image_url_.append(image_url) if image_url else ''
                office_name_.append(office_name) if office_name else ''
                agent_phone_numbers_.extend(agent_phone_numbers) if agent_phone_numbers else ''
                office_phone_numbers_.extend(office_phone_numbers) if office_phone_numbers else ''
                address_.append(address) if address else ''
                description_.append(description) if description else ''
                city_.append(city) if city else ''
                zipcode_.append(zipcode) if zipcode else ''
                state_.append(state) if state else ''
                country_.append(country) if country else ''
                language_.extend(languages) if languages else ''
                social_.extend(social) if social else ''
                row = [link, name, title, image_url, office_name, agent_phone_numbers, office_phone_numbers, address, description,
                       city, zipcode, state, country, languages, email, website, social]
                row_data.append(row)
                comparison.CollectDb(link, name, title, image_url, office_name, agent_phone_numbers, office_phone_numbers, address, description,
                                     city, zipcode, state, country, languages, email, website, social, domain)

    if name_ == []:
        msg = 'name field is empty in bhgre'
        message.append(msg)
    # if title_ == []:
    #     msg = 'title field is empty in bhgre'
    #     message.append(msg)
    if image_url_ == []:
        msg = 'image_url field is empty in bhgre'
        message.append(msg)
    if office_name_ == []:
        msg = 'office_name field is empty in bhgre'
        message.append(msg)
    if agent_phone_numbers_ == []:
        msg = 'agent_phone_numbers field is empty in bhgre'
        message.append(msg)
    if office_phone_numbers_ == []:
        msg = 'office_phone_numbers field is empty in bhgre'
        message.append(msg)
    if address_ == []:
        msg = 'address field is empty in bhgre'
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in bhgre'
        message.append(msg)
    if city_ == []:
        msg = 'city field is empty in bhgre'
        message.append(msg)
    if zipcode_ == []:
        msg = 'zipcode field is empty in bhgre'
        message.append(msg)
    if state_ == []:
        msg = ' state field is empty in bhgre'
        message.append(msg)
    if country_ == []:
        msg = 'country field is empty in bhgre'
        message.append(msg)
    if language_ == []:
        msg = 'language_ field is empty in bhgre'
        message.append(msg)
    if social_ == []:
        msg = 'social field is empty in bhgre'
        message.append(msg)
    slack_note(message, domain)


def berkshire_fun(links):
    print('berkshire')
    name_ = []
    title_ = []
    image_ = []
    office_name_ = []
    mobile_number1_ = []
    phone_number1_ = []
    address_ = []
    description_ = []
    city_ = []
    zipcode_ = []
    state_ = []
    country_ = []
    languages_1 = []
    email_ = []
    social_ = []
    message = []
    domain = 'berkshire'
    row_data = []
    for link in links:
        response = requests.get(link, headers=headers, proxies=proxies_t)
        sel = Selector(text=response.content)
        name = sel.xpath(berkshire.NAME_XPATH).extract_first('')
        mobile_number = sel.xpath(berkshire.MOBILE_NUMBER).extract()
        phone_number = sel.xpath(berkshire.PHONE_NUMBER).extract()
        image = sel.xpath(berkshire.IMAGE_XPATH).extract_first('').strip()
        location = sel.xpath(berkshire.LOCATION_XPATH).extract()
        languages = sel.xpath(berkshire.LANGUAGES_XPATH).extract()
        social = sel.xpath(berkshire.SOCIAL_XPATH).extract()
        email = sel.xpath(berkshire.EMAIL_XPATH).extract_first('').strip()
        title = sel.xpath(berkshire.TITLE_XPATH).extract_first('').strip()
        mobile_number1 = []
        phone_number1 = []
        if phone_number:
            if phone_number[0] == 'office':
                phone_number1.append(phone_number[1])
        if mobile_number:
            if mobile_number[0] == 'mobile':
                mobile_number1.append(mobile_number[1])
        languages_ = []
        for lan in languages:
            languages = lan.strip()
            languages_.append(languages)
        if 'no_user_image' in image:
            image = ''
        elif 'AgentNoPhotoAvailable' in image:
            image = ''
        else:
            image = image
        office_name = ''.join(location).split('\n')[2].strip()
        address = "".join(location).split('\n')[3].strip()
        location = location[0].strip() if location else ''
        if location:
            city = re.findall('(.*)[A-Z]{2}.\d{5}',
                              location)[0].split() if location else ''
            city = ' '.join(city) if city else ''
            city = city.strip() if city else ''
            if ',' in city:
                city = city.replace(',', '')
            state = re.findall(
                '([A-Z]{2}).\d{5}', location)if location else ''
            state = state[0].strip() if state else ''
            zipcode = re.findall(
                '[A-Z]{2}(.\d{5})', location)if location else ''
            zipcode = zipcode[0].strip() if zipcode else ''
            name_.append(name) if name else ''
            title_.append(title) if title else ''
            image_.append(image) if image else ''
            office_name_.append(office_name) if office_name else ''
            mobile_number1_.extend(mobile_number1) if mobile_number1 else ''
            phone_number1_.extend(phone_number1) if phone_number1 else ''
            address_.append(address) if address else ''
            description_.append(description) if description else ''
            city_.append(city) if city else ''
            zipcode_.append(zipcode) if zipcode else ''
            state_.append(state) if state else ''
            country_.append(country) if country else ''
            languages_1.extend(languages_) if languages_ else ''
            email_.append(email) if email else ''
            social_.extend(social) if social else ''
        row = [link, name, title, image, office_name, mobile_number1, phone_number1, address, description,
               city, zipcode, state, country, languages_, email, website, social]
        row_data.append(row)
        comparison.CollectDb(link, name, title, image, office_name, mobile_number1, phone_number1, address, description,
                             city, zipcode, state, country, languages_, email, website, social, domain)

    if name_ == []:
        msg = 'name field is empty in berkshire'
        message.append(msg)
    if title_ == []:
        msg = 'title field is empty in berkshire'
        message.append(msg)
    if image_ == []:
        msg = 'image field is empty in berkshire'
        message.append(msg)
    if office_name_ == []:
        msg = 'office_name field is empty in berkshire'
        message.append(msg)
    if mobile_number1_ == []:
        msg = 'agent_phone_numbers field is empty in berkshire'
        message.append(msg)
    if phone_number1_ == []:
        msg = 'office_numbers field is empty in berkshire'
        message.append(msg)
    if address_ == []:
        msg = 'address field is empty in berkshire'
        message.append(msg)
    # if description_ == []:
    #     msg = 'description field is empty in berkshire'
    #     message.append(msg)
    if city_ == []:
        msg = 'city field is empty in berkshire'
        message.append(msg)
    if zipcode_ == []:
        msg = 'zipcode field is empty in berkshire'
        message.append(msg)
    if state_ == []:
        msg = 'social field is empty in berkshire'
        message.append(msg)
    if country_ == []:
        msg = 'country field is empty in berkshire'
        message.append(msg)
    if languages_1 == []:
        msg = 'languages field is empty in berkshire'
        message.append(msg)
    if email_ == []:
        msg = 'email field is empty in berkshire'
        message.append(msg)
    if social_ == []:
        msg = 'social field is empty in berkshire'
        message.append(msg)
    slack_note(message, domain)


def century21_us_fun(links):
    print('century21_us')
    name_ = []
    image_url_ = []
    company_name1_ = []
    mobilenum_ = []
    phonenum_ = []
    address_1 = []
    description_s = []
    city_ = []
    zipcode_ = []
    state_ = []
    country_ = []
    languages_ = []
    message = []
    company_name1 = ''
    address_ = ''
    city = ''
    zip_ = ''
    state = ''
    domain = 'century21_us'
    row_data = []
    for link in links:
        try:
            response = requests.get(link, headers=headers, proxies=proxies_t, verify=False)
        except:
            try:
                response = requests.get(link, headers=headers, proxies=proxies_t, verify=False)
            except:
                response = ''
        if response:
            sel = Selector(text=response.content)
            address_office = []
            co_name = sel.xpath(century21_us.CO_NAME).extract()
            image_url = sel.xpath(century21_us.IMAGE_URL).extract()
            phonenum = sel.xpath(century21_us.PHONENUM).extract()
            mobilenum = sel.xpath(century21_us.MOBILENUM).extract()
            languages = sel.xpath(century21_us.LANGUAGES_XAPTH).extract()
            address = sel.xpath(century21_us.ADDRESS).extract()
            name = ''.join(sel.xpath(century21_us.NAME).extract()).strip()

            co_name = ' '.join(''.join(co_name).strip().split()) if co_name else ''
            if '21' in co_name:
                company_name = co_name.split(' 21 ')
                if 'Affiliated' in company_name:
                    ''
                else:
                    company_name1 = company_name[1]

            image_url = ''.join(image_url) if image_url else ''
            language = []
            for lang in languages:
                lan = lang.strip()
                language.append(lan)
            address = [x.strip() for x in address] if address else []
            address = [x.strip() for x in address if x] if address else []
            address_office = [x.strip()
                              for x in address_office] if address_office else []
            address_office = [x.strip()
                              for x in address_office if x] if address_office else []
            address_office = ' '.join(
                address_office).strip() if address_office else ''
            if len(address) >= 2:
                address_ = address[0].strip()
                city_state_zip = address[1].strip()
                if ',' in city_state_zip:
                    city_state_zip_list = city_state_zip.split(',')
                    if len(city_state_zip_list) == 2:
                        city = city_state_zip_list[0].strip()
                        zip_ = re.findall(r'\d+', city_state_zip_list[1])
                        zip_ = zip_[0].strip() if zip_ else ''
                        state = city_state_zip_list[1].strip(
                            zip_).strip() if zip_ else city_state_zip_list[1].strip()
            if len(address) >= 3:
                address_ = address[0].strip()
                city_state_zip = address[2].strip()
                if ',' in city_state_zip:
                    city_state_zip_list = city_state_zip.split(',')
                    if len(city_state_zip_list) == 2:
                        city = city_state_zip_list[0].strip()
                        zip_ = re.findall(r'\d+', city_state_zip_list[1])
                        zip_ = zip_[0].strip() if zip_ else ''
                        state = city_state_zip_list[1].strip(
                            zip_).strip() if zip_ else city_state_zip_list[1].strip()
            description = sel.xpath(century21_us.DESCRIPTION_XPATH).extract()
            if description:
                description1 = description
                description_ = ' '.join(description1).split()
                description_ = ' '.join(description_)
                description_ = description_ if description_ else ''
            else:
                response1 = ''
                description_url = sel.xpath(century21_us.DESCRIPTION_URL_XPATH).extract_first('')
            response1 = ''
            if description_url:
                response1 = requests.get(description_url, headers=headers, proxies=proxies_s, verify=False)
                sel1 = Selector(text=response1.content)
                description = sel1.xpath(century21_us.DESCRIPTION_XPATH_2).extract()
                description1 = description
                description_ = ' '.join(description1).split()
                description_ = ' '.join(description_)
                description_ = description_ if description_ else ''
            else:
                description_ = ''
            name_.append(name) if name else ''
            image_url_.append(image_url) if image_url else ''
            company_name1_.append(company_name1) if company_name1 else ''
            mobilenum_.extend(mobilenum) if mobilenum else ''
            phonenum_.extend(phonenum) if phonenum else ''
            address_1.append(address_) if address_ else ''
            description_s.append(description) if description else ''
            city_.append(city) if city else ''
            zipcode_.append(zip_) if zip_ else ''
            state_.append(state) if state else ''
            country_.append(country) if country else ''
            languages_.append(language) if language else ''
            row = [link, name, title, image_url, company_name1, mobilenum, phonenum, address_, description_,
                   city, zip_, state, country, language, email, website, social]
            row_data.append(row)
            comparison.CollectDb(link, name, title, image_url, company_name1, mobilenum, phonenum, address_, description_,
                                 city, zip_, state, country, language, email, website, social, domain)

    if name_ == []:
        msg = 'name field is empty in century21'
        message.append(msg)
    if image_url_ == []:
        msg = 'image_url field is empty in century21'
        message.append(msg)
    if company_name1_ == []:
        msg = 'office_name field is empty in century21'
        message.append(msg)
    if mobilenum_ == []:
        msg = 'agentphone field is empty in century21'
        message.append(msg)
    if phonenum_ == []:
        msg = 'office_phone field is empty in century21'
        message.append(msg)
    if address_1 == []:
        msg = 'address field is empty in century21'
        message.append(msg)
    if description_s == []:
        msg = 'description field is empty in century21'
        message.append(msg)
    if city_ == []:
        msg = 'city field is empty in century21'
        message.append(msg)
    if zipcode_ == []:
        msg = 'zipcode field is empty in century21'
        message.append(msg)
    if state_ == []:
        msg = 'state field is empty in century21'
        message.append(msg)
    if country_ == []:
        msg = 'country field is empty in century21'
        message.append(msg)
    if languages_ == []:
        msg = 'language field is empty in century21'
        message.append(msg)
    slack_note(message, domain)


def coldwellbanker_fun(links):
    print('coldwellbanker')
    name_ = []
    image_url_ = []
    company_name_ = []
    agent_phone_ = []
    office_phone_ = []
    address_1 = []
    biography_ = []
    city_ = []
    zip_code_ = []
    state_ = []
    country_ = []
    language_spoken_ = []
    social_ = []
    message = []
    address_office = ''
    row_data = []
    headers = {
        "authority": "www.coldwellbanker.com",
        "method": "GET",
        "scheme": "https",
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
        "accept-encoding": "gzip, deflate, br",
        "accept-language": "en-GB,en-US;q=0.9,en;q=0.8,ml;q=0.7",
        "cache-control": "no-cache",
        "pragma": "no-cache",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "none",
        "upgrade-insecure-requests": "1",
        "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36"
    }
    domain = 'coldwellbanker_us_data'
    row_data = []
    for link in links:
        response = requests.get(link, headers=headers, proxies=proxies_s)
        sel = Selector(text=response.content)
        name = sel.xpath(coldwell_banker.NAME_XPATH).extract_first('').strip()
        image = sel.xpath(coldwell_banker.IMAGE_XPATH).extract_first('').strip()
        biography = sel.xpath(coldwell_banker.BIOGRAPHY_XPATH).extract()
        language_spoken = sel.xpath(coldwell_banker.LANGUAGES_XPATH).extract()
        numbers = sel.xpath(coldwell_banker.NUMBERS_XPATH).extract()
        social = sel.xpath(coldwell_banker.SOCIAL_XPATH).extract()
        company_name = sel.xpath(coldwell_banker.COMPANY_XPATH).extract_first('').strip()
        address = sel.xpath(coldwell_banker.ADDRESS_XPATH).extract()
        phones = sel.xpath(coldwell_banker.PHONE_XPATH).extract()

        image_url = '' if 'no-agent' in image else image
        biography = [x.strip() for x in biography] if biography else []
        biography = [x.strip()
                     for x in biography if x] if biography else []
        biography = ' '.join(biography).strip() if biography else ''
        language_spoken = list(set([x.strip() for x in language_spoken])) if language_spoken else []

        numbers = list(set([x.strip().replace('tel:', '').replace(
            '.', '').strip() for x in numbers])) if numbers else []
        phone_numbers = []
        agent_phone = []
        office_phone_ = []
        office_phone = []
        if len(numbers) == 1:
            agent_phone = numbers
        else:
            for number in numbers:
                phone_data = number
                agent_phone.append(phone_data)
                phone_numbers.append(phone_data)
        for phone in phones:
            phone_data = phone
            office_phone_.append(phone_data.strip())
            office_phone.append(phone_data.strip())
            phone_numbers.append(phone_data.strip())

        office_phone = office_phone if office_phone else office_phone_
        company_name = company_name if company_name else ''

        address = [x.strip() for x in address if x] if address else []
        address_office = [x.strip()
                          for x in address_office] if address_office else []
        address_office = [x.strip()
                          for x in address_office if x] if address_office else []
        address_office = ' '.join(
            address_office).strip() if address_office else ''
        address_ = ''
        city = ''
        zip_ = ''
        state = ''
        if len(address) >= 9:
            address_ = address[4].strip()
            city_state_zip = address[5].strip()
            if ',' in city_state_zip:
                city_state_zip_list = city_state_zip.split(',')
                if len(city_state_zip_list) == 2:
                    city = city_state_zip_list[0].strip()
                    zip_ = re.findall(r'\d+', city_state_zip_list[1])
                    zip_ = zip_[0].strip() if zip_ else ''
                    state = city_state_zip_list[1].strip(
                        zip_).strip() if zip_ else city_state_zip_list[1].strip()
        name_.append(name) if name else ''
        image_url_.append(image_url) if image_url else ''
        company_name_.append(company_name) if company_name else ''
        agent_phone_.extend(agent_phone) if agent_phone else ''
        office_phone_.extend(office_phone) if office_phone else ''
        address_1.append(address_) if address_ else ''
        biography_.append(biography) if biography else ''
        city_.append(city) if city else ''
        zip_code_.append(zip_) if zip_ else ''
        state_.append(state) if state else ''
        country_.append(country) if country else ''
        language_spoken_.append(language_spoken) if language_spoken else ''
        social_.extend(social) if social else ''
        row = [link, name, title, image_url, company_name, agent_phone, office_phone, address_, biography,
               city, zip_, state, country, language_spoken, email, website, social]
        row_data.append(row)
        comparison.CollectDb(link, name, title, image_url, company_name, agent_phone, office_phone, address_, biography,
                             city, zip_, state, country, language_spoken, email, website, social, domain)

    if name_ == []:
        msg = 'name field is empty in coldwellbanker'
        message.append(msg)
    if image_url_ == []:
        msg = 'image_url field is empty in coldwellbanker'
        message.append(msg)
    if company_name_ == []:
        msg = 'office_name field is empty in coldwellbanker'
        message.append(msg)
    if agent_phone_ == []:
        msg = 'agentPhone field is empty in coldwellbanker'
        message.append(msg)
    if office_phone_ == []:
        msg = 'office_phone field is empty in coldwellbanker'
        message.append(msg)
    if address_1 == []:
        msg = 'address field is empty in coldwellbanker'
        message.append(msg)
    if biography_ == []:
        msg = 'description field is empty in coldwellbanker'
        message.append(msg)
    if city_ == []:
        msg = 'city field is empty in coldwellbanker'
        message.append(msg)
    if zip_code_ == []:
        msg = 'zipcode field is empty in coldwellbanker'
        message.append(msg)
    if state_ == []:
        msg = 'state field is empty in coldwellbanker'
        message.append(msg)
    if country_ == []:
        msg = 'country field is empty in coldwellbanker'
        message.append(msg)
    if language_spoken_ == []:
        msg = 'language field is empty in coldwellbanker'
        message.append(msg)
    if social_ == []:
        msg = 'social field is empty in coldwellbanker'
        message.append(msg)
    slack_note(message, domain)


def coldwell_internatinal_fun(links):
    print('coldwell_internatinal')
    name_ = []
    title_ = []
    image_url_ = []
    office_name_ = []
    agent_numbers_ = []
    office_numbers_ = []
    address_ = []
    description_ = []
    city_ = []
    zipcode_1 = []
    state_ = []
    country_ = []
    languages_ = []
    email_ = []
    social_ = []
    message = []

    domain = 'coldwellbanker_international'
    headers = {
        'accept': 'text/html, */*; q=0.01',
        'accept-encoding': 'gzip, deflate, br',
        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36',
    }
    countries = {'us': 'USA', 'ar': 'Argentina', 'aw': 'Aruba', 'bm': 'Bermuda', 'vg': 'British Virgin Islands', 'ca': 'Canada', 'ky': 'Cayman Islands', 'cn': 'China', 'co': 'Colombia', 'cr': 'Costa Rica', 'cw': 'Curacao', 'do': 'Dominican Republic', 'eg': 'Egypt', 'fr': 'France', 'de': 'Germany', 'gh': 'Ghana', 'gd': 'Grenada', 'gt': 'Guatemala', 'in': 'India', 'id': 'Indonesia', 'ie': 'Ireland', 'it': 'Italy', 'jm': 'Jamaica',
                 'ke': 'Kenya', 'mt': 'Malta', 'mx': 'Mexico', 'mc': 'Monaco', 'an': 'Netherlands Antilles', 'pa': 'Panama', 'pt': 'Portugal', 'pr': 'Puerto Rico', 'ro': 'Romania', 'kn': 'Saint Kitts and Nevis', 'sg': 'Singapore', 'es': 'Spain', 'th': 'Thailand', 'bs': 'The Bahamas', 'nl': 'The Netherlands', 'tr': 'Turkey', 'tc': 'Turks and Caicos Islands', 'ae': 'United Arab Emirates', 'vi': 'United States Virgin Islands', 'uy': 'Uruguay'}
    row_data = []
    for link in links:
        response = requests.get(link, headers=headers, proxies=proxies_t)
        sel = Selector(text=response.content)
        country_code = sel.xpath(coldwell_internatinal.COUNTRY_CODE_XPATH).extract_first('')
        country = countries.get(country_code)
        name = sel.xpath(coldwell_internatinal.NAME_XPATH).extract_first('').strip()
        image = sel.xpath(coldwell_internatinal.IMAGE_XPATH).extract_first('')
        title = sel.xpath(coldwell_internatinal.TITLE_XPATH).extract_first('').strip()
        office_name = sel.xpath(coldwell_internatinal.OFFICE_NAME).extract_first('').strip()
        description = sel.xpath(coldwell_internatinal.DESCRIPTION_XPATH).extract()
        languages = sel.xpath(coldwell_internatinal.LANGUAGES_XPATH).extract()
        address = sel.xpath(coldwell_internatinal.ADDRESS_XPATH).extract_first('')
        agent_numbers = sel.xpath(coldwell_internatinal.AGENT_NUMBERS_XPATH).extract()
        office_numbers = sel.xpath(coldwell_internatinal.OFFICE_NUMBER_XPATH).extract()
        facebook_url = sel.xpath(coldwell_internatinal.FACEBOOK_XPATH).extract_first('')
        linkedin_url = sel.xpath(coldwell_internatinal.LINKEDIN_XPATH).extract_first('')
        instagram_url = sel.xpath(coldwell_internatinal.INSTAGRAM_XPATH).extract_first('')
        twitter_url = sel.xpath(coldwell_internatinal.TWITTER_XPATH).extract_first('')
        youtube_url = sel.xpath(coldwell_internatinal.YOUTUBE_XPATH).extract_first('')
        googleplus_url = sel.xpath(coldwell_internatinal.GOOGLEPLUS_XPATH).extract_first('')
        pinterest_url = sel.xpath(coldwell_internatinal.PINTEREST_XPATH).extract_first('')
        social = []
        social.append(facebook_url) if facebook_url else ''
        social.append(linkedin_url) if linkedin_url else ''
        social.append(instagram_url) if instagram_url else ''
        social.append(twitter_url) if twitter_url else ''
        social.append(youtube_url) if youtube_url else ''
        social.append(googleplus_url) if googleplus_url else ''
        social.append(pinterest_url) if pinterest_url else ''
        image_url = image if image else ''
        if 'user-default' in image_url:
            image_url = ''
        description = ' '.join(' '.join(description).split()
                               ).strip() if description else ''

        lan = []
        for lang in languages:
            language = lang.strip()
            lan.append(language)

        address = address if address else ''
        agent_numbers = [i.strip() for i in agent_numbers if i.strip()]
        office_numbers = [i.strip() for i in office_numbers if i.strip()]
        zipcode = ''
        zipcode_ = ''
        zip_1 = ''

        url = response.url
        url1 = url.rsplit('/', 2)[-2]
        zip1 = re.findall(r'\w+$|\d+', url1)

        if len(zip1) == 0:
            zip_1 = ''
        elif len(zip1) == 1:
            zipp__ = ''.join(zip1)
            zip__1 = re.findall(r'^[a-zA-Z]+\d{2}', zipp__)
            zip__2 = re.findall(r'^[\d]+', zipp__)
            if zip__1:
                zip_1 = zip1
            elif zip__2:
                if len(zip__2[0]) > 1:

                    zip_1 = zip1
            else:
                zip_1 = ''
        elif len(zip1) == 2:

            zip_1 = zip1[0] + '-' + zip1[1]
            zip_1 = re.sub('-[A-z]+.*', '', zip_1)
        zip_1 = ''.join(zip_1).strip()

        if zip_1:
            if re.search(r'^\d\-', zip_1):
                zip_text = sel.xpath(coldwell_internatinal.ZIPCODE_XPATH).extract()
                zip_text = ''.join(zip_text).strip()
                zip_caps = re.findall(r'[A-Z]{2}', zip_text)
                zip_caps = ''.join(zip_caps).strip()
                zipcode = zip_caps + zip_1
            else:
                zipcode = zip_1
        zipcode = ''.join(zipcode).strip()

        city1 = sel.xpath(coldwell_internatinal.CITY_XPATH).extract()

        if zipcode == '':
            location = ''.join(city1)
            postalcode = re.findall(
                r'[a-zA-Z]\d[a-zA-Z]\d[a-zA-Z]\d', location)
            zipcode2 = ''.join(postalcode)
            if zipcode2 == '':
                zipcode3 = re.findall('P.O. Box.*\d+', address)
                if zipcode3:
                    zipcode_ = zipcode3[0].replace('P.O. Box ', '')

            else:
                zipcode_ = zipcode2.strip()
            zipcode = ''.join(zipcode_).strip()
        if len(zip1[0]) > 9:
            zip_text = sel.xpath(coldwell_internatinal.ZIPCODE_XPATH).extract()
            zip_text = zip_text[0].split(' ')
            zipcode = zip_text[-1]
            zipcode = zipcode.strip()

# -------------------------------------------
        state = ''
        city = ''
        if city1:
            if city1[0].replace(zipcode, '').strip().lower().endswith('city'):
                citynew = ''.join(city1).split(',')
                if len(citynew) == 2:
                    city = citynew[0]
                    city = ''.join(city)
                    state = citynew[1].replace(
                        ' city', '').replace('City', '').replace(zipcode, '').strip()
                    state = ''.join(state)
                elif len(citynew) == 1:
                    city = citynew[0].replace(zipcode, '').strip().split(',')
                    city = ''.join(city)
                    state = ''
                else:
                    city = ''
                    state = ''
            else:
                citynew = ''.join(city1).split(',')
                if len(citynew) == 2:
                    city = citynew[0]
                    city = ''.join(city)
                    state = citynew[1].replace(
                        ' city', '').replace(zipcode, '').replace('City', '').strip()
                    state = ''.join(state)
                elif len(citynew) == 1:
                    city = citynew[0].replace(zipcode, '').strip().split(',')
                    city = ''.join(city)
                    state = ''
                else:
                    city = ''
                    state = ''

        email = sel.xpath(coldwell_internatinal.EMAIL_XPATH).extract_first('').replace('mailto:', '')
        name_.append(name) if name else ''
        title_.append(title) if title else ''
        image_url_.append(image_url) if image_url else ''
        office_name_.append(office_name) if office_name else ''
        agent_numbers_.extend(agent_numbers) if agent_numbers else ''
        office_numbers_.extend(office_numbers) if office_numbers else ''
        address_.append(address) if address else ''
        description_.append(description) if description else ''
        city_.append(city) if city else ''
        zipcode_1.append(zipcode) if zipcode else ''
        state_.append(state) if state else ''
        country_.append(country) if country else ''
        languages_.extend(lan) if lan else ''
        email_.append(email) if email else ''
        social_.extend(social) if social else ''
        row = [link, name, title, image_url, office_name, agent_numbers, office_numbers, address, description,
               city, zipcode, state, country, lan, email, website, social]
        row_data.append(row)
        comparison.CollectDb(link, name, title, image_url, office_name, agent_numbers, office_numbers, address, description,
                             city, zipcode, state, country, lan, email, website, social, domain)

    if name_ == []:
        msg = 'name field is empty in coldwellbanker_international'
        message.append(msg)
    if title_ == []:
        msg = 'title field is empty in coldwellbanker_international'
        message.append(msg)
    if image_url_ == []:
        msg = 'social field is empty in coldwellbanker_international'
        message.append(msg)
    if office_name_ == []:
        msg = 'office_name field is empty in coldwellbanker_international'
        message.append(msg)
    if agent_numbers_ == []:
        msg = 'agent_numbers field is empty in coldwellbanker_international'
        message.append(msg)
    if office_numbers_ == []:
        msg = 'office_numbers field is empty in coldwellbanker_international'
        message.append(msg)
    if address_ == []:
        msg = 'address field is empty in coldwellbanker_international'
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in coldwellbanker_international'
        message.append(msg)
    if city_ == []:
        msg = 'city field is empty in coldwellbanker_international'
        message.append(msg)
    if zipcode_1 == []:
        msg = 'zipcode field is empty in coldwellbanker_international'
        message.append(msg)
    if state_ == []:
        msg = 'state field is empty in coldwellbanker_international'
        message.append(msg)
    if country_ == []:
        msg = 'country field is empty in coldwellbanker_international'
        message.append(msg)
    if languages_ == []:
        msg = 'social field is empty in coldwellbanker_international'
        message.append(msg)
    if email_ == []:
        msg = 'email field is empty in coldwellbanker_international'
        message.append(msg)
    if social_ == []:
        msg = 'social field is empty in coldwellbanker_international'
        message.append(msg)
    slack_note(message, domain)


def edinarealty_fun(agents):
    print('edinarealty')
    name_1 = []
    title_ = []
    image_url_ = []
    office_name_ = []
    agent_phone_numbers_ = []
    office_phone_numbers_ = []
    address_ = []
    description_ = []
    city_ = []
    zipcode_ = []
    state_ = []
    country_ = []
    languages_1 = []
    email_ = []
    website_ = []
    socials_ = []
    message = []
    domain = 'edinarealty_data'
    row_data = []
    for agent in agents:
        first_name = agent.get('firstName', '')
        middle_name = agent.get('middleName')
        last_name = agent.get('lastName')
        title = agent.get('title')
        email = agent.get('emailAddress')
        image_url = agent.get('portraitUrl')
        languages_ = agent.get('languages')
        website = agent.get('websiteUrll')
        office_name = agent.get('primaryOffice').get('name')
        office_name = office_name + ' ' + 'office'
        city = agent.get('primaryOffice').get('city')
        state = agent.get('primaryOffice').get('state')
        zipcode = agent.get('primaryOffice').get('postalCode')
        address = agent.get('primaryOffice').get('addressLine1')
        phone_numbers = agent.get('agentPhones')
        for phone in phone_numbers:
            if phone.get('type') == "Preferred":
                agent_phone_numbers = [phone.get('number')]
            elif phone.get('type') == "Text":
                office_phone_numbers = [phone.get('number')]

        if agent_phone_numbers == office_phone_numbers:
            office_phone_numbers = ''
        social = []
        social_ = agent.get('agentSocialUrls', '')
        for soc in social_:
            if soc.get('type') == "Facebook":
                facebook_url = soc.get('url')
                social.append(facebook_url)
            elif soc.get('type') == "LinkedIn":
                linkedin_url = soc.get('url')
                social.append(linkedin_url)
            elif soc.get('type') == "Instagram":
                instagram_url = soc.get('url')
                social.append(instagram_url)
            elif soc.get('type') == "Twitter":
                twitter_url = soc.get('url')
                social.append(twitter_url)
            else:
                other_urls = soc.get('url')
                social.append(other_urls)
        name = []
        name.append(first_name) if first_name else ''
        name.append(middle_name) if middle_name else ''
        name.append(last_name) if last_name else ''
        name_ = ' '.join(name)
        slug = agent.get('slug', '')
        profile_url = 'https://www.edinarealty.com/' + slug
        image_url = image_url if image_url else ''
        languages = languages if languages_ else []
        address = address if address else ''
        state = state if state else ''
        website = website if website else ''
        zipcode = zipcode if zipcode else ''
        city = city if city else ''
        office_name = office_name if office_name else ''
        response = requests.get(url=profile_url, headers=headers, proxies=proxies_t)
        sel = Selector(text=response.content)
        description = sel.xpath(edinarealty.DESCRIPTION_XPATH).extract()
        description = ''.join(description).strip()
        name_1.append(name_) if name_ else ''
        title_.append(title) if title else ''
        image_url_.append(image_url) if image_url else ''
        office_name_.append(office_name) if office_name else ''
        agent_phone_numbers_.extend(agent_phone_numbers) if agent_phone_numbers else ''
        office_phone_numbers_.extend(office_phone_numbers) if office_phone_numbers else ''
        address_.append(address) if address else ''
        description_.append(description) if description else ''
        city_.append(city) if city else ''
        zipcode_.append(zipcode) if zipcode else ''
        state_.append(state) if state else ''
        country_.append(country) if country else ''
        languages_1.extend(languages) if languages else ''
        email_.append(email) if email else ''
        website_.append(website) if website else ''
        socials_.extend(social) if social else ''
        row = [profile_url, name_, title, image_url, office_name, agent_phone_numbers, office_phone_numbers, address, description,
               city, zipcode, state, country, languages, email, website, social]
        row_data.append(row)
        comparison.CollectDb(profile_url, name_, title, image_url, office_name, agent_phone_numbers, office_phone_numbers, address, description,
                             city, zipcode, state, country, languages, email, website, social, domain)

    if name_1 == []:
        msg = 'name field is empty in edinarealty'
        message.append(msg)
    if title_ == []:
        msg = 'title field is empty in edinarealty'
        message.append(msg)
    if image_url_ == []:
        msg = 'image_url field is empty in edinarealty'
        message.append(msg)
    if office_name_ == []:
        msg = 'office_name field is empty in edinarealty'
        message.append(msg)
    if agent_phone_numbers_ == []:
        msg = 'agent_numbers field is empty in edinarealty'
        message.append(msg)
    if office_phone_numbers_ == []:
        msg = 'office_numbers field is empty in edinarealty'
        message.append(msg)
    if address_ == []:
        msg = 'address field is empty in edinarealty'
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in edinarealty'
        message.append(msg)
    if city_ == []:
        msg = 'city field is empty in edinarealty'
        message.append(msg)
    if zipcode_ == []:
        msg = 'zipcode field is empty in edinarealty'
        message.append(msg)
    if state_ == []:
        msg = 'state field is empty in edinarealty'
        message.append(msg)
    if country_ == []:
        msg = 'country field is empty in edinarealty'
        message.append(msg)
    if languages_1 == []:
        msg = 'languages field is empty in edinarealty'
        message.append(msg)
    if email_ == []:
        msg = 'email field is empty in edinarealty'
        message.append(msg)
    if website_ == []:
        msg = 'website field is empty in edinarealty'
        message.append(msg)
    if socials_ == []:
        msg = 'social field is empty in edinarealty'
        message.append(msg)
    slack_note(message, domain)


def firstweber_fun(links):
    print('firstweber')
    name_ = []
    title_ = []
    image_url_ = []
    office_name_ = []
    agent_phone_numbers_ = []
    office_phone_numbers_ = []
    address_ = []
    description_ = []
    city_ = []
    zipcode_ = []
    state_ = []
    country_ = []
    email_ = []
    website_ = []
    social_ = []
    message = []
    domain = 'firstweber'
    row_data = []
    for link in links:
        link = 'https://www.firstweber.com' + link
        response = requests.get(link, headers=headers, proxies=proxies_s)
        # response = requests.get(link,headers=headers)
        sel = Selector(text=response.content)
        name = sel.xpath(firstweber.NAME_XPATH).extract_first('')
        title = sel.xpath(firstweber.TITLE_XPATH).extract_first('')
        description = sel.xpath(firstweber.DESCRIPTION_XPATH).extract()
        facebook_url = sel.xpath(firstweber.FACEBOOK_XPATH).extract_first('')
        twitter_url = sel.xpath(firstweber.TWITTER_XPATH).extract_first('')
        linkedin_url = sel.xpath(firstweber.LINKEDIN_XPATH).extract_first('')
        pinterest_url = sel.xpath(firstweber.PINTEREST_XPATH).extract_first('')
        googleplus_url = sel.xpath(firstweber.GOOGLEPLUS_XPATH).extract_first('')
        instagram_url = sel.xpath(firstweber.INSTAGRAM_XPATH).extract_first('')
        blog_url = sel.xpath(firstweber.BLOG_XPATH).extract_first('')
        home_phone = sel.xpath(firstweber.HOME_PHONE_XPATH).extract_first('')
        mobile_phone = sel.xpath(firstweber.MOBILE_PHONE_XPATH).extract_first('')
        work_phone = sel.xpath(firstweber.WORK_PHONE_XPATH).extract_first('')
        direct_phone = sel.xpath(firstweber.DIRECT_PHONE_XPATH).extract_first('')

        description = ' '.join(''.join(description).split())
        agent_phone_numbers = []
        office_phone_numbers = []
        award = sel.xpath(firstweber.AWARD_XPATH).extract_first('').strip().replace('\r\n', ' ')
        res_body = re.sub(b",\n\s*\"description\":\s\"(?:.|\n)*?\"", b"", response.content)
        sel_ = Selector(text=res_body)

        json_ = sel_.xpath(firstweber.JSON_XPATH).extract()
        if json_:
            json_ = ' '.join(' '.join(json_).split()).strip(
            ).replace(name, "").replace(award, "") if json_ else ''
            try:
                json_data = json.loads(json_)
            except:
                pass
            office_name = json_data.get('location', {}).get('name', '')
            office_name = office_name + ' ' + 'office'
            email = json_data.get('email', '')
            image_url = json_data.get('image', '')
            website = json_data.get('url', '')
            if website == 'https://':
                website = ''
            elif website == 'http://':
                website = ''

            agent_address = json_data.get('address', {})
            address = agent_address.get('streetAddress', '')
            zipcode = agent_address.get('postalCode', '')
            city = agent_address.get('addressLocality', '')
            state = agent_address.get('addressRegion', '')

        if mobile_phone:
            agent_phone_number = mobile_phone.replace('Mobile:', '')
            agent_phone_numbers.append(agent_phone_number)
        if work_phone:
            office_phone_number = work_phone.replace('Work:', '')
            office_phone_numbers.append(office_phone_number)
        if direct_phone:
            direct_phone_number = direct_phone.replace('Direct:', '')
            agent_phone_numbers.append(direct_phone_number)
        social = []
        social.append(facebook_url) if facebook_url else ''
        social.append(twitter_url) if twitter_url else ''
        social.append(linkedin_url) if linkedin_url else ''
        social.append(pinterest_url) if pinterest_url else ''
        social.append(googleplus_url) if googleplus_url else ''
        social.append(instagram_url) if instagram_url else ''
        social.append(blog_url) if blog_url else ''
        name_.append(name) if name else ''
        title_.append(title) if title else ''
        image_url_.append(image_url) if image_url else ''
        office_name_.append(office_name) if office_name else ''
        agent_phone_numbers_.extend(agent_phone_numbers) if agent_phone_numbers else ''
        office_phone_numbers_ .extend(office_phone_numbers) if office_phone_numbers else ''
        address_.append(address) if address else ''
        description_.append(description) if description else ''
        city_.append(city) if city else ''
        zipcode_.append(zipcode) if zipcode else ''
        state_.append(state) if state else ''
        country_.append(country) if country else ''
        email_.append(email) if email else ''
        website_.append(website) if website else ''
        social_.extend(social) if social else ''
        row = [link, name, title, image_url, office_name, agent_phone_numbers, office_phone_numbers, address, description,
               city, zipcode, state, country, language, email, website, social]
        row_data.append(row)
        comparison.CollectDb(link, name, title, image_url, office_name, agent_phone_numbers, office_phone_numbers, address, description,
                             city, zipcode, state, country, language, email, website, social, domain)

    if name_ == []:
        msg = 'name field is empty in firstweber'
        message.append(msg)
    if title_ == []:
        msg = 'title field is empty in firstweber'
        message.append(msg)
    if image_url_ == []:
        msg = 'image_url field is empty in firstweber'
        message.append(msg)
    if office_name_ == []:
        msg = 'office_name field is empty in firstweber'
        message.append(msg)
    if agent_phone_numbers_ == []:
        msg = 'agent_numbers field is empty in firstweber'
        message.append(msg)
    if office_phone_numbers_ == []:
        msg = 'office_numbers field is empty in firstweber'
        message.append(msg)
    if address_ == []:
        msg = 'address field is empty in firstweber'
        message.append(msg)
    if description_ == []:
        msg = 'social field is empty in firstweber'
        message.append(msg)
    if city_ == []:
        msg = 'city field is empty in firstweber'
        message.append(msg)
    if zipcode_ == []:
        msg = 'zipcode field is empty in firstweber'
        message.append(msg)
    if state_ == []:
        msg = 'state field is empty in firstweber'
        message.append(msg)
    if country_ == []:
        msg = 'country field is empty in firstweber'
        message.append(msg)
    if email_ == []:
        msg = 'email field is empty in firstweber'
        message.append(msg)
    if website_ == []:
        msg = 'Website field is empty in firstweber'
        message.append(msg)
    if social_ == []:
        msg = 'social field is empty in firstweber'
        message.append(msg)
    slack_note(message, domain)


def global_remax_fun(links):
    print('global_remax')
    count = 0
    name_ = []
    image_url_ = []
    office_name_ = []
    agent_phone_1 = []
    office_phone_1 = []
    address_ = []
    description_ = []
    city_ = []
    postalCode_ = []
    state_ = []
    country_ = []
    language_ = []
    website_ = []
    social_ = []
    message = []
    domain = 'global_remax'
    row_data = []
    for link in links:
        count = count + 1
        response = requests.get(link, headers=headers, proxies=proxies_t)
        sel = Selector(text=response.content)
        name = sel.xpath(global_remax.NAME_XPATH).extract()
        office_name = sel.xpath(global_remax.OFFICE_NAME_XPATH).extract()
        address = sel.xpath(global_remax.ADDRESS_XPATH).extract_first('')
        city = sel.xpath(global_remax.CITY_XPATH).extract_first('').strip()
        state = sel.xpath(global_remax.STATE_XPATH).extract_first('').strip()
        country_path1 = sel.xpath(global_remax.COUNTRY1).extract_first('').strip()
        country_path2 = sel.xpath(global_remax.COUNTRY2).extract_first('')
        postalCode = sel.xpath(global_remax.ZIPCODE_XPATH).extract_first('').strip()
        image_url = sel.xpath(global_remax.IMAGE_URL_XPATH).extract_first('')
        # title = response.xpath(TITLE_XPATH).extract_first('')
        website = sel.xpath(global_remax.WEBSITES_XPATH).extract_first('')
        office_phone = sel.xpath(global_remax.OFFICE_PHONE_XPATH).extract()
        agent_phone = sel.xpath(global_remax.AGENT_PHONE_XPATH).extract()
        description = sel.xpath(global_remax.DESCRIPTION_XPATH).extract()
        language = sel.xpath(global_remax.LANGUAGES_XPATH).extract()
        whatsapp_url = sel.xpath(global_remax.WHATSAPP_XPATH).extract_first('').strip()

        office_name = office_name[-1].strip() if office_name else ''
        address = address.replace(',,', ',').strip()
        address = ' '.join(''.join(address).split())
        office_phone_ = []
        for num in office_phone:
            num = ''.join(num).strip()
            office_phone_.append(num)

        agent_phone_ = []
        for num in agent_phone:
            num = ''.join(num).strip()
            agent_phone_.append(num)

        language = language if language else []
        description = ' '.join(' '.join(description).split()
                               ).strip() if description else ''
        if 'default' in image_url:
            image_url = ''
        else:
            image_url = image_url.replace(
                'https://remax.azureedge.net', 'https://global.remax.com',) if image_url else ''

        city = city.split(',')[0]
        state = state.split(',')[0]

        if country_path1:
            country = country_path1
        else:
            if country_path2:
                if '|' in country_path2:
                    country = country_path2.split(
                        '|')[1].strip() if country_path2 else ''
                    if country == 'RE/MAX, LLC.' and country == 'RE/MAX Global':
                        country = ''
            else:
                country = ''
        social = []
        social.append(whatsapp_url) if whatsapp_url else ''
        name_.extend(name) if name else ''
        image_url_.append(image_url) if image_url else ''
        office_name_.append(office_name) if office_name else ''
        agent_phone_1.extend(agent_phone_) if office_phone_ else ''
        office_phone_1.extend(office_phone_) if office_phone_ else ''
        address_.append(address) if address else ''
        description_.append(description) if description else ''
        city_.append(city) if city else ''
        postalCode_.append(postalCode) if postalCode else ''
        state_.append(state) if state else ''
        country_.append(country) if country else ''
        language_.extend(language) if language else ''
        website_.append(website) if website else ''
        social_.extend(social)if social else ''
        row = [name, title, image_url, office_name, agent_phone_, office_phone_, address, description,
               city, postalCode, state, country, language, email, website, social]
        row_data.append(row)
        comparison.CollectDb(link, name, title, image_url, office_name, agent_phone_, office_phone_, address, description,
                             city, postalCode, state, country, language, email, website, social, domain)

    if name_ == []:
        msg = 'name field is empty in global_remax'
        message.append(msg)
    if image_url_ == []:
        msg = 'image_url field is empty in global_remax'
        message.append(msg)
    if office_name_ == []:
        msg = 'office_name field is empty in global_remax'
        message.append(msg)
    if agent_phone_1 == []:
        msg = 'agent_numbers field is empty in global_remax'
        message.append(msg)
    if office_phone_1 == []:
        msg = 'office_numbers field is empty in global_remax'
        message.append(msg)
    if address_ == []:
        msg = 'address field is empty in global_remax'
        message.append(msg)
    if description_ == []:
        msg = 'social field is empty in global_remax'
        message.append(msg)
    if city_ == []:
        msg = 'city field is empty in global_remax'
        message.append(msg)
    if postalCode_ == []:
        msg = 'zipcode field is empty in global_remax'
        message.append(msg)
    if state_ == []:
        msg = 'state field is empty in global_remax'
        message.append(msg)
    if country_ == []:
        msg = 'social field is empty in global_remax'
        message.append(msg)
    if language_ == []:
        msg = 'language field is empty in global_remax'
        message.append(msg)
    if website_ == []:
        msg = 'website field is empty in global_remax'
        message.append(msg)
    # if social_ == []:
    #     msg = 'social field is empty in global_remax'
    #     message.append(msg)
    slack_note(message, domain)


def long_foster_fun(datas):
    print('long and foster')
    name_ = []
    title_ = []
    image_url_ = []
    office_name_ = []
    agent_phone_numbers_ = []
    office_phone_numbers_ = []
    address_ = []
    description_ = []
    city_ = []
    zipcode_ = []
    state_ = []
    country_ = []
    language_ = []
    email_ = []
    website_ = []
    social_ = []
    message = []
    domain = 'longandfoster'
    row_data = []
    for data in datas:
        name = data.get('DisplayName', '')
        Id_ = data.get('PersonID', '')
        address = data.get('StreetAddress1', '')
        city = data.get('CityDisplayName', '')
        state = data.get('StateCode', '')
        zipcode = data.get('Zip', '')
        country = data.get('CountryName', '')
        office_name = data.get('OfficeName', '')
        office_phone = data.get('Phone', '')
        agent_phone = data.get('Cell', '')
        email = data.get('Email', '')
        image_url = data.get('PortraitUrl', '')
        website = data.get('PrimaryWebsiteURL', '')
        facebook_url = data.get('FacebookURL', '')
        twitter_url = data.get('TwitterURL', '')
        linkedin_url = data.get('LinkedInURL', '')
        instagram_url = data.get('InstagramURL', '')
        pinterest_url = data.get('PinterestURL', '')
        googleplus_url = data.get('GoogleURL', '')
        youtube_url = data.get('YoutubeURL', '')
        tumblr_url = data.get('TumblrURL', '')
        myspace_url = data.get('MySpaceURL', '')
        oth_url = data.get('OtherURL', '')
        language = data.get('Languages', [])
        language = [lang.strip()
                    for lang in language.split(',') if language]
        if image_url:
            if '/AgentNoPhotoAvailable' in image_url:
                image_url = ''

        website = website
        agent_phone_numbers = [agent_phone]
        if agent_phone_numbers == [None]:
            agent_phone_numbers = []
        office_phone_numbers = [office_phone]
        if office_phone_numbers == [None]:
            office_phone_numbers = []
        social = []
        social.append(facebook_url) if facebook_url else ''
        social.append(twitter_url) if twitter_url else ''
        social.append(linkedin_url) if linkedin_url else ''
        social.append(instagram_url) if instagram_url else ''
        social.append(pinterest_url) if pinterest_url else ''
        social.append(googleplus_url) if googleplus_url else ''
        social.append(youtube_url) if youtube_url else ''
        profile_url = 'https://www.longandfoster.com/AgentSearch/AgentInfo.aspx?PersonID=' + str(Id_)
        res = requests.get(profile_url, headers=headers, proxies=proxies_t)
        sel = Selector(text=res.content)
        description = sel.xpath(long_foster.DESCRIPTION_XPATH).extract()
        description = ' '.join(''.join(description).split())
        name_.append(name) if name else ''
        title_.append(title) if title else ''
        image_url_.append(image_url) if image_url else ''
        office_name_.append(office_name) if office_name else ''
        agent_phone_numbers_.extend(agent_phone_numbers) if agent_phone_numbers else ''
        office_phone_numbers_.extend(office_phone_numbers) if office_phone_numbers else ''
        address_.append(address) if address else ''
        description_.append(description) if description else ''
        city_.append(city) if city else ''
        zipcode_.append(zipcode) if zipcode else ''
        state_.append(state) if state else ''
        country_.append(country) if country else ''
        language_.extend(language) if language else ''
        email_.append(email) if email else ''
        website_.append(website) if website else ''
        social_.extend(social) if social else ''
        row = [profile_url, name, title, image_url, office_name, agent_phone_numbers, office_phone_numbers, address, description,
               city, zipcode, state, country, language, email, website, social]
        row_data.append(row)
        comparison.CollectDb(profile_url, name, title, image_url, office_name, agent_phone_numbers, office_phone_numbers, address, description,
                             city, zipcode, state, country, language, email, website, social, domain)

    if name_ == []:
        msg = 'name field is empty in longandfoster'
        message.append(msg)
    # if title_ == []:
    #     msg = 'title field is empty in longandfoster'
    #     message.append(msg)
    if image_url_ == []:
        msg = 'image_url field is empty in longandfoster'
        message.append(msg)
    if office_name_ == []:
        msg = 'office_name field is empty in longandfoster'
        message.append(msg)
    if agent_phone_numbers_ == []:
        msg = 'agent_numbers field is empty in longandfoster'
        message.append(msg)
    if office_phone_numbers_ == []:
        msg = 'office_phone_numbers field is empty in longandfoster'
        message.append(msg)
    if address_ == []:
        msg = 'address field is empty in longandfoster'
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in longandfoster'
        message.append(msg)
    if city_ == []:
        msg = 'city field is empty in longandfoster'
        message.append(msg)
    if zipcode_ == []:
        msg = 'zipcode field is empty in longandfoster'
        message.append(msg)
    if state_ == []:
        msg = 'state field is empty in longandfoster'
        message.append(msg)
    if country_ == []:
        msg = 'country field is empty in longandfoster'
        message.append(msg)
    if language_ == []:
        msg = 'language field is empty in longandfoster'
        message.append(msg)
    if email_ == []:
        msg = 'email field is empty in longandfoster'
        message.append(msg)
    if website_ == []:
        msg = 'website field is empty in longandfoster'
        message.append(msg)
    if social_ == []:
        msg = 'social field is empty in longandfoster'
        message.append(msg)
    slack_note(message, domain)


def remax_fun(links):
    print('remax')
    name_1 = []
    title_1 = []
    image_url_1 = []
    office_name_1 = []
    agent_phone_numbers_1 = []
    office_phone_numbers_1 = []
    address_1 = []
    description_1 = []
    city_1 = []
    zipcode_1 = []
    state_1 = []
    country_1 = []
    languages_1 = []
    email_1 = []
    website_1 = []
    social_1 = []
    message = []
    domain = 'remax_us'
    row_data = []
    for link in links:
        response = requests.get(link, headers=headers, proxies=proxies_t)
        sel = Selector(text=response.content)
        data = json.loads(response.text)
        pro = data.get('data')
        list_ = []
        id_ = pro.get('masterCustomerId', '')
        first_name = pro.get('firstName', '')
        f_name = first_name.replace(' ', '')
        middle_name = pro.get('middleName', '')
        if middle_name == None:
            middle_name = ''
        m_name = middle_name.replace(' ', '') if middle_name else ''
        last_name = pro.get('lastName', '')
        l_name = last_name.replace(' ', '')
        office = pro.get('officeMembership')[0].get(
            'office') if pro.get('officeMembership') else ''
        state = office.get('state', '')
        if state == None:
            state = ''
        if not state:
            state = pro.get('licenses', '')[0].get(
                'state', '') if pro.get('licenses') else ''

        zipcode = office.get('postalCode', '')
        city = office.get('city', '')
        if not city:
            city = pro.get('officeMembershipRolesPrimary')[0].get(
                'office') if pro.get('officeMembershipRolesPrimary') else ''
            city = city.get(
                'office', '') if city else ''

        city_ = city.replace(' ', '')
        state_ = state.replace(' ', '')
        address = office.get('address1', '')
        office_phone_numbers = []
        office_phone_number = office.get('phones')[0].get(
            'phoneNumber') if office.get('phones') else ''
        office_phone_numbers.append(office_phone_number)
        office_name = office.get('officeName', '')
        website = pro.get('webSites')[0].get(
            'webAddress') if pro.get('webSites') else ''
        email = pro.get('emails')[0].get(
            'emailAddress') if pro.get('emails') else ''
        agent_phone_numbers = []

        agent_phone = pro.get('phones', '')
        if agent_phone:
            for phone in agent_phone:
                agent_phone_number = phone.get(
                    'phoneNumber') if pro.get('phones') else ''
                if office_phone_number != phone:
                    agent_phone_numbers.append(agent_phone_number)

        description = pro.get('biography')[0].get(
            'biographyText') if pro.get('biography') else ''
        image = pro.get('photos') if pro.get('photos') else ''
        image_url = ''
        for img in image:
            images = img['typeCode']
            if images == 'MainPhoto':
                image_url = img.get('url')
        languages = pro.get('languages') if pro.get('languages') else ''
        language = []
        for i in languages:
            lang = i.get('languageDescr')
            language.append(lang)
        social = []
        title = pro.get('jobTitle', '')
        if title == None:
            title = ''
        list_.append(f_name) if f_name else ''
        list_.append(m_name) if m_name else ''
        list_.append(l_name) if l_name else ''
        list_.append(city_) if city_ else ''
        list_.append(state_) if state_ else ''
        slug = '-'.join(list_)
        name_ = []
        name_.append(f_name) if f_name else ''
        name_.append(m_name) if m_name else ''
        name_.append(l_name) if l_name else ''
        name = ' '.join(name_)
        profile_url = 'https://www.remax.com/real-estate-agents/' + str(slug) + '/' + str(id_)
        name_1.append(name) if name else ''
        title_1 .append(title) if title else ''
        image_url_1.append(image_url) if image_url else ''
        office_name_1.append(office_name) if office_name else ''
        agent_phone_numbers_1.extend(agent_phone_numbers) if agent_phone_numbers else ''
        office_phone_numbers_1.extend(office_phone_numbers) if office_phone_numbers else ''
        address_1.append(address) if address else ''
        description_1.append(description) if description else ''
        city_1.append(city) if city else ''
        zipcode_1.append(zipcode) if zipcode else ''
        state_1.append(state) if state else ''
        country_1.append(country) if country else ''
        languages_1.extend(language) if language else ''
        email_1.append(email) if email else ''
        website_1.append(website) if website else ''
        social_1.extend(social) if social else ''

        row = [profile_url, name, title, image_url, office_name, agent_phone_numbers, office_phone_numbers, address, description,
               city, zipcode, state, country, language, email, website, social]
        row_data.append(row)
        comparison.CollectDb(profile_url, name, title, image_url, office_name, agent_phone_numbers, office_phone_numbers, address, description,
                             city, zipcode, state, country, language, email, website, social, domain)

    if name_1 == []:
        msg = 'name field is empty in remax_us'
        message.append(msg)
    if title_1 == []:
        msg = 'title field is empty in remax_us'
        message.append(msg)
    if image_url_1 == []:
        msg = 'image_url field is empty in remax_us'
        message.append(msg)
    if office_name_1 == []:
        msg = 'office_name field is empty in remax_us'
        message.append(msg)
    if agent_phone_numbers_1 == []:
        msg = 'agent_numbers field is empty in remax_us'
        message.append(msg)
    if office_phone_numbers_1 == []:
        msg = 'office_numbers field is empty in remax_us'
        message.append(msg)
    if address_1 == []:
        msg = 'address field is empty in remax_us'
        message.append(msg)
    if description_1 == []:
        msg = 'description field is empty in remax_us'
        message.append(msg)
    if city_1 == []:
        msg = 'social field is empty in remax_us'
        message.append(msg)
    if zipcode_1 == []:
        msg = 'zipcode field is empty in remax_us'
        message.append(msg)
    if state_1 == []:
        msg = 'state field is empty in remax_us'
        message.append(msg)
    if country_1 == []:
        msg = 'country field is empty in remax_us'
        message.append(msg)
    if languages_1 == []:
        msg = 'language field is empty in remax_us'
        message.append(msg)
    if email_1 == []:
        msg = 'email field is empty in remax_us'
        message.append(msg)
    if website_1 == []:
        msg = 'website field is empty in remax_us'
        message.append(msg)
    # if social_1 == []:
    #     msg = 'social field is empty in remax_us'
    #     message.append(msg)
    slack_note(message, domain)


def sutton_fun(p_urls):
    print('sutton')
    name_1 = []
    title_1 = []
    image_url_1 = []
    office_name_1 = []
    agent_phone_numbers_1 = []
    office_phone_numbers_1 = []
    address_1 = []
    description_1 = []
    city_1 = []
    zipcode_1 = []
    state_1 = []
    country_1 = []
    languages_1 = []
    email_1 = []
    website_1 = []
    social_1 = []
    message = []
    domain = 'sutton'
    row_data = []
    for url in p_urls:
        response = requests.get(url, headers=headers, proxies=proxies_t)
        sel = Selector(text=response.content)
        data = sel.xpath(
            '//*[contains(text(),"Functions.AgentProfile")]/text()').extract_first('')
        data = ''.join(re.findall('Functions.AgentProfile.*?,(.*)\);', data))
        data = data.strip('"HmWerNBrAd6NGtnppyOo"').strip()
        data = data.strip(',').strip()
        try:
            json_data = json.loads(data)
        except:
            json_data = ''
        if json_data:
            linkedin_url = ''
            facebook_url = ''
            twitter_url = ''
            middle_name = ''
            other_urls = []
            links_ = []
            office_phone = []
            agent_phone = []
            if json_data:
                first_name1 = json_data.get('firstName')
                last_name1 = json_data.get('lastName')
                email = json_data.get('email')
                title = json_data.get('title')
                websites = json_data.get('website')
                office_name = json_data.get('officeMetaData').get('name')
                #address = data.get('officeMetaData').get('address').get('fullAddress')
                address = json_data.get('officeMetaData').get(
                    'address').get('address1')
                city = json_data.get('officeMetaData').get('address').get('city')
                state = json_data.get('officeMetaData').get('address').get('state')
                zipcode = json_data.get('officeMetaData').get('address').get('zip')
                country = json_data.get('officeMetaData').get(
                    'address').get('country')
                image_url = json_data.get('avatar').get('uri')
                description = json_data.get('profile').get('biography', '')
                languages_ = json_data.get('profile').get('languages')
                languages = [lan['name'] for lan in languages_]
                social_ = json_data.get('profile').get('socialNetworks')
                social = []
                for soc in social_:
                    link = soc.get('link')
                    if 'facebook' in link:
                        facebook_url = link
                        social.append(facebook_url)
                    elif 'twitter' in link:
                        twitter_url = link
                        social.append(twitter_url)
                    elif 'linkedin' in link:
                        linkedin_url = link
                        social.update(linkedin_url)
                    else:
                        other_urls.append(link)
                        social.append(other_urls)

                phone_numbers = json_data.get('profile').get('phoneNumbers')
                for phone in phone_numbers:
                    if phone.get('type') == "Work":
                        office_phone = [phone.get('number')]
                    elif phone.get('type') == "Mobile":
                        agent_phone = [phone.get('number')]
                if description:
                    description = remove_tags(description)
                    desc = ' '.join(''.join(description).split())
                else:
                    desc = ''
                image_url = image_url if image_url else ''
                websites = websites if websites else ''
                name = []
                name.append(first_name1) if first_name1 else ''
                name.append(last_name1) if last_name1 else ''
                name_ = ''.join(name) if name else ''
                name_1.append(name_) if name_ else ''
                title_1.append(title) if title else ''
                image_url_1.append(image_url) if image_url else ''
                office_name_1.append(office_name) if office_name else ''
                agent_phone_numbers_1.extend(agent_phone) if agent_phone else ''
                office_phone_numbers_1.extend(office_phone) if office_phone else ''
                address_1.append(address) if address else ''
                description_1.append(desc) if desc else ''
                city_1.append(city) if city else ''
                zipcode_1.append(zipcode) if zipcode else ''
                state_1.append(state) if state else ''
                country_1.append(country) if country else ''
                languages_1.extend(languages) if languages else ''
                email_1.append(email) if email else ''
                website_1.append(websites) if websites else ''
                social_1.extend(social) if social else ''
                row = [url, name_, title, image_url, office_name, agent_phone, office_phone, address, desc,
                       city, zipcode, state, country, languages, email, websites, social]
                row_data.append(row)
                comparison.CollectDb(url, name_, title, image_url, office_name, agent_phone, office_phone, address, desc,
                                     city, zipcode, state, country, languages, email, websites, social, domain)

    if name_1 == []:
        msg = 'name field is empty in sutton'
        message.append(msg)
    if title_1 == []:
        msg = 'title field is empty in sutton'
        message.append(msg)
    if image_url_1 == []:
        msg = 'image_url field is empty in sutton'
        message.append(msg)
    if office_name_1 == []:
        msg = 'office_name field is empty in sutton'
        message.append(msg)
    if agent_phone_numbers_1 == []:
        msg = 'agent_numbers field is empty in sutton'
        message.append(msg)
    if office_phone_numbers_1 == []:
        msg = 'office_numbers field is empty in sutton'
        message.append(msg)
    if address_1 == []:
        msg = 'address field is empty in sutton'
        message.append(msg)
    if description_1 == []:
        msg = 'description field is empty in sutton'
        message.append(msg)
    if city_1 == []:
        msg = 'social field is empty in sutton'
        message.append(msg)
    if zipcode_1 == []:
        msg = 'zipcode field is empty in sutton'
        message.append(msg)
    if state_1 == []:
        msg = 'state field is empty in sutton'
        message.append(msg)
    if country_1 == []:
        msg = 'country field is empty in sutton'
        message.append(msg)
    if languages_1 == []:
        msg = 'language field is empty in sutton'
        message.append(msg)
    if email_1 == []:
        msg = 'email field is empty in sutton'
        message.append(msg)
    if website_1 == []:
        msg = 'website field is empty in sutton'
        message.append(msg)
    # if social_1 == []:
    #     msg = 'social field is empty in sutton'
    #     message.append(msg)
    slack_note(message, domain)
