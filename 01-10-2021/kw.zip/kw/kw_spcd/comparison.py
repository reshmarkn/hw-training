import csv
import json
# import data
import random
import requests

# from xpath import *
from slacker import Slacker
from datetime import datetime
from pymongo import MongoClient
from scrapy.selector import Selector
from log_file import *



headers = {

    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
}
db = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false').kw_monthly_2021_03


def CollectDb(link, name, title, image, office_name, agent_phone, office_phone, address,
              description, city, zipcode, state, country, languages, email, website, social, domain):

    for item in db[domain].find(no_cursor_timeout=True):
        message_ = []
        if link == item.get('profile_url'):
            json_data = item
            if json_data.get('first_name') and json_data.get('last_name') in name:
                msg = 'name success ' + domain
                message_.append(msg)
            else:
                msg = 'name failed ' + domain
                message_.append('msg')
            if json_data.get('title') in title:
                msg = 'title success ' + domain
                message_.append(msg)
            else:
                msg = 'title failed ' + domain
                message_.append(msg)
            if json_data.get('image_url') in image:
                msg = 'image_url success ' + domain
                message_.append(msg)
            else:
                msg = 'image_url failed' + domain
                message_.append(msg)
            if json_data.get('office_name') in office_name:
                msg = 'office_name success ' + domain
                message_.append(msg)
            else:
                msg = 'office_name failed ' + domain
                message_.append(msg)
            pre_agentphone = json_data.get('agent_phone_numbers')
            if pre_agentphone:
                if agent_phone:
                    result1 = [
                        j for i in pre_agentphone for j in agent_phone if i in j]
                    msg = 'agent_phone_numbers success ' + domain
                    message_.append(msg)
                else:
                    msg = 'agent_phone_numbers failed ' + domain
                    message_.append(msg)
            pre_officephone = json_data.get('office_phone_numbers')
            if pre_officephone:
                if office_phone:
                    result2 = [
                        j for i in pre_officephone for j in office_phone if i in j]

                    msg = 'office_phone_numbers success ' + domain
                    message_.append(msg)
                else:
                    msg = 'office_phone_numbers failed ' + domain
                    message_.append(msg)
            if json_data.get('address') in address:
                msg = 'address success ' + domain
                message_.append(msg)
            else:
                msg = 'address failed ' + domain
                message_.append(msg)
            if json_data.get('city') in city:
                msg = 'city success ' + domain
                message_.append(msg)
            else:
                if json_data.get('city') in address:
                    msg = 'city success ' + domain
                    message_.append(msg)
                else:
                    msg = 'city failed ' + domain
                    message_.append(msg)
            if json_data.get('zipcode') in zipcode:
                msg = 'zipcode success ' + domain
                message_.append(msg)
            else:
                if json_data.get('zipcode') in address:
                    msg = 'zipcode success ' + domain
                    message_.append(msg)
                else:
                    msg = 'zipcode failed ' + domain
                    message_.append(msg)
            if json_data.get('state') in state:
                msg = 'state success ' + domain
                message_.append(msg)
            else:
                if json_data.get('state') in address:
                    msg = 'state success ' + domain
                    message_.append(msg)
                else:
                    msg = 'state failed ' + domain
                    message_.append(msg)
            if json_data.get('country') in country:
                msg = 'country success ' + domain
                message_.append(msg)
            pre_languages = json_data.get('languages')
            if pre_languages:
                if languages:
                    result3 = [
                        j for i in pre_languages for j in languages if i in j]
                    msg = 'languages success ' + domain
                    message_.append(msg)
                else:
                    msg = 'languages failed ' + domain
                    message_.append(msg)

            if json_data.get('email') in email:
                msg = 'email success ' + domain
                message_.append(msg)
            else:
                msg = 'email failed ' + domain
                message_.append(msg)

            if json_data.get('website') in website:
                msg = 'website success ' + domain
                message_.append(msg)
            else:
                msg = 'website failed ' + domain
                message_.append(msg)
            if social:
                for i in social:
                    if 'linkedin' in i:
                        if json_data.get('social').get('linkedin_url') == i:
                            msg = 'social success ' + domain
                            message_.append(msg)
                        else:
                            msg = 'social failed ' + domain
                            message_.append(msg)
                    if 'facebook' in i:
                        if json_data.get('social').get('facebook_url') == i:
                            msg = 'social success ' + domain
                            message_.append(msg)
                        else:
                            msg = 'social failed ' + domain
                            message_.append(msg)
                    if 'twitter' in i:
                        if json_data.get('social').get('twitter_url') == i:
                            msg = 'social success ' + domain
                            message_.append(msg)
                        else:
                            msg = 'social failed ' + domain
                            message_.append(msg)
            # logging.info('%s', format('\n'.join([str(msg_) for msg_ in message_])))
            if message_:
                # comparison_log(message_)
                f = open('comparison_log.txt', 'a')
                f.write(str(message_) + '\n')
                f.close()
