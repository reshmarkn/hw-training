import io
import re
import ast
import json
import data
import gzip
import random
# import logging
import phase_2
import requests
from io import StringIO
from xpath import *
from log_file import *
from time import sleep
from slacker import Slacker
from xml.dom import minidom
from datetime import datetime
from string import ascii_lowercase
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from proxy import tor_proxy
from proxy import microleaves_proxy
from proxy import storm_proxy



logging.basicConfig(filename = 'spider_error.log', level = logging.INFO)
Slack = Slacker(
    'xoxp-24300212688-35464554529-262255845088-43b7f5b45d669c16a2fc81caa80fa6e2')
USERS = ['@sisira','@avinash','@kiran']

headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
}
api_headers = {'accept': 'application/json, text/plain, */*',
               'accept-encoding': 'gzip, deflate, br',
               'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', }


proxy_t = tor_proxy()
proxies_t = proxy_t['proxies']

proxy_m = microleaves_proxy()
proxies_m = proxy_m['proxies']

proxy_s = storm_proxy()
proxies_s = proxy_s['proxies']

def message_url(domain):
    message = 'agent links xpath is updated in ' + domain
    slack_note(message,domain)


def message_pagination(domain):
    message = 'pagination link xpath updated in ' + domain
    slack_note(message,domain)

def alliebeth_():
    url = 'http://www.alliebeth.com/associates/int'
    response = requests.get(url, headers=headers, proxies=proxies_t)
    # response = requests.get(url, headers=headers)
    sel = Selector(text=response.content)
    domain = url.split('.')[1]
    if response.status_code == 200:
        links = sel.xpath(alliebeth.LINKS_XPATH).extract()
        next_ = sel.xpath(alliebeth.NEXT_XPATH).extract()
        if links:
            item = data.alliebeth_fun(links)
        else:
            message_url(domain)
        if not next_:
            message_pagination(domain)


def harrynorman_():
    url = 'https://www.harrynorman.com/agents'
    response = requests.get(url, headers=headers, proxies=proxies_t)
    # response = requests.get(url, headers=headers)
    sel = Selector(text=response.content)
    domain = url.split('.')[1]
    if response.status_code == 200:
        links = sel.xpath(harrynorman.LINKS_XPATH).extract()
        next_ = sel.xpath(harrynorman.NEXT_XPATH).extract()
        if links:
            item = data.harrynorman_fun(links)
        else:
            message_url(domain)
        if not next_:
            message_pagination(domain)


def homerealestate_():
    url = 'https://www.homerealestate.com/?p=agentResults.asp'
    response = requests.get(url, headers=headers, proxies=proxies_t)
    # response = requests.get(url, headers=headers)
    sel = Selector(text=response.content)
    domain = url.split('.')[1]
    if response.status_code == 200:
        agent_list = sel.xpath(home_realestate.AGENT_LIST_XPATH)
        if agent_list:
            item = data.homerealestate_fun(agent_list)
        else:
            message_url(domain)


def royallepage_():
    url = 'https://www.royallepage.ca/'
    response = requests.get(url, headers=headers, proxies=proxies_t)
    sel = Selector(text=response.content)
    domain = url.split('.')[1]
    next_ = []
    link_ = []
    if response.status_code == 200:
        location_url = sel.xpath(royallepage.LOCATION_URL_XPATH).extract()
        for link in location_url:
            link = 'https://www.royallepage.ca/' + link
            response1 = requests.get(link, headers=headers, proxies=proxies_t)
            sel1 = Selector(text=response1.content)
            office_url = sel1.xpath(royallepage.OFFICE_URL_XPATH).extract()
            for url_ in office_url:
                url_ = 'https://www.royallepage.ca/en/search/get-list/agent/' + \
                    url_.strip('/').split('/')[-1]
                response2 = requests.get(
                    url_, headers=headers, proxies=proxies_t)
                body = json.loads(response2.text.strip(
                    ');').strip('(')).get('html', '')
                sel2 = Selector(text=body)
                link_.extend(sel2.xpath(
                    royallepage.PROFILE_URL_XPATH).extract())
                next_page = sel2.xpath(
                    royallepage.NEXT_PAGE_XPATH).extract_first('')
                next_.append(next_page) if next_page else ''

                if len(link_) > 24:
                    break
            break
    if link_:
        item = data.royallepage_fun(link_)
    else:
        message_url(domain)
    if not next_:
        message_pagination(domain)


def guarantee_():
    url = 'http://www.guarantee.com/offices/'
    response = requests.get(url, headers=headers, proxies=proxies_t)
    sel = Selector(text=response.content)
    domain = url.split('.')[1]
    if response.status_code == 200:
        agent_list = sel.xpath(guarantee.AGENT_LIST_XPATH).extract()
        if agent_list:
            item = data.guarantee_fun(agent_list)
        else:
            message_url(domain)


def huff_realty_():
    url = 'https://www.huff.com/index.asp?p=agentResults.asp&search=%%'
    response = requests.get(url, headers=headers, proxies=proxies_t)
    sel = Selector(text=response.content)
    domain = url.split('.')[1]
    agent_list = sel.xpath(huff_realty.AGENT_LIST_XPATH)
    if agent_list:
        item = data.huff_realty_fun(agent_list)
    else:
        message_url(domain)


def houlihanlawrence_():
    url = 'http://www.houlihanlawrence.com/agents_offices/'
    domain = url.split('.')[1]
    offices = []
    for alpha in ascii_lowercase:
        form_data = {'houlihan_keywords': alpha,
                     'Search': 'search'}
        response = requests.get(url, headers=headers,
                                data=form_data, proxies=proxies_t)
        sel = Selector(text=response.content)
        if response.status_code == 200:
            office_data = re.findall(
                "office_points.push\((\{(?:.|\n)*?\})\);", response.text)
            for data_ in office_data:
                office = ' '.join(data_.split())
                office = ast.literal_eval(office)
                offices.append(office)
            profile_url = sel.xpath(
                houlihanlawrence.OFFICE_URL_XPATH).extract()

            break
    if profile_url:
        item = data.houlihanlawrence_fun(profile_url, offices)

    else:
        message_url(domain)


def robertbrothers_():
    url = 'http://www.robertsbrothers.com/our-realestate-agents'
    domain = url.split('.')[1]
    response = requests.get(url, headers=headers, proxies=proxies_t)
    sel = Selector(text=response.content)
    agent_list = sel.xpath(robertsbrothers.AGENT_LIST_XPATH)
    if agent_list:
        item = data.robertsbrothers_fun(agent_list)
    else:
        message_url(domain)


def wrrealtor_():
    url = 'https://www.wrrealtors.com/agents/'
    domain = url.split('.')[1]
    response = requests.get(url, headers=headers, proxies=proxies_t)
    sel = Selector(text=response.content)
    links = sel.xpath(wrrealtors.AGENTS_LINK_XPATH).extract()
    if links:
        item = data.wrrealtors_fun(links)
    else:
        message_url(domain)


def rubinarealestate_():
    url = 'https://www.rubinarealestate.com/en/our-team/'
    domain = url.split('.')[1]
    response = requests.get(url, headers=headers)
    sel = Selector(text=response.content)
    if response.status_code == 200:
        agent_list = sel.xpath(rubina_realestate.AGENTS_DETAIL_XPATH)
        if agent_list:
            item = data.rubinarealestate_fun(agent_list)
        else:
            message_url(domain)


def woodbros_():
    url = 'https://www.woodsbros.com/roster/agents'
    domain = url.split('.')[1]
    response = requests.get(url, headers=headers, proxies=proxies_t)
    sel = Selector(text=response.content)
    if response.status_code == 200:
        agent_list = sel.xpath(woodbros.AGENT_LIST_XPATH)
        if agent_list:
            item = data.woodbros_fun(agent_list)
        else:
            message_url(domain)


def reecenichols_():
    url = 'https://www.reecenichols.com/AgentSearch/Results.aspx?SearchType=agent&FirstName=&LastName=&OfficeName=&Address=&City=&State=&Country=-32768&Zip=&Languages=&Titles=&Specialties=&Accreditations=&Areas=&rpp=50&page=2&SortOrder='
    domain = url.split('.')[1]
    response = requests.get(url, headers=headers)
    sel = Selector(text=response.content)
    if response.status_code == 200:
        agents_list = sel.xpath(reecenichols.AGENT_LIST_XPATH)
        if agents_list:
            item = data.reecenichols_fun(agents_list)
        else:
            message_url(domain)


def rector_hyden_():
    url = 'http://www.rhr.com/rhnr/index.asp?p=agentResults.asp&search=%%'
    domain = url.split('.')[1]
    response = requests.get(url, headers=headers, proxies=proxies_t)
    sel = Selector(text=response.content)
    if response.status_code == 200:
        agents_list = sel.xpath(rector_hyden.AGENT_LIST_XPATH)
        if agents_list:
            item = data.rector_hyden_fun(agents_list)
        else:
            message_url(domain)


def longrealty_():
    url = 'https://www.longrealty.com/agents.php?p=1'
    domain = url.split('.')[1]
    links = []
    next_page = []
    office_phone = []
    office_name = ''
    response = requests.get(url, headers=headers, proxies=proxies_t)
    # response = requests.get(url, headers=headers)
    sel = Selector(text=response.content)
    office_list = sel.xpath(longrealty.OFFICE_LIST_XPATH).extract()
    base_url = 'https://www.longrealty.com/'
    for office in office_list:
        office_url = base_url + office
        response1 = requests.get(
            office_url, headers=headers, proxies=proxies_t)
        # response1 = requests.get(office_url, headers=headers)
        sel1 = Selector(text=response1.content)
        agent_list = sel1.xpath(longrealty.AGENT_LIST_XPATH).extract()
        next_page.extend(sel1.xpath(longrealty.NEXT_PAGE_XPATH).extract())
        office_phone.extend(sel1.xpath(
            longrealty.OFFICE_PHONE_XPATH).extract())
        office_name_1 = sel1.xpath(longrealty.OFFICE_NAME_XPATH).extract()
        for office in office_name_1:
            if office:
                office_name = office
        for agent in agent_list:
            if 'tel:(' not in agent:
                links.append(agent)
            if len(links) > 24:
                break
        if len(links) > 24:
            break
    # if not next_page:
    #     message_pagination(domain)
    if links:
        item = data.longrealty_fun(links, office_phone, office_name)
    else:
        message_url(domain)


def intero_realestate_():
    url = 'https://svc.moxiworks.com/service/v1/profile/offices/search?company_uuid=3220480'
    domain = 'intero_realestate'
    response = requests.get(url, headers=headers, proxies=proxies_t)
    if response.status_code == 200:
        profile_data = json.loads(response.text)
        source = profile_data.get('data').get('result_list')
        if source:
            item = data.intero_realestate_fun(source)
        else:
            message_url(domain)


def realty_south_():
    url = 'https://www.realtysouth.com/AgentSearch/Results.aspx?SearchType=agent&FirstName=&LastName=&OfficeName=&Address=&City=&State=&Country=-32768&Zip=&Languages=&Titles=&Specialties=&Accreditations=&Areas=&rpp=30&page=2'
    domain = url.split('.')[1]
    response = requests.get(url, headers=headers, proxies=proxies_t)
    sel = Selector(text=response.content)
    if response.status_code == 200:
        links = sel.xpath(realty_south.AGENT_LIST_XPATH).extract()
        if links:
            item = data.realty_south_fun(links)
        else:
            message_url(domain)

# phase - 2  site pattern change detection module
# -------------------------------------------------


def denver_realestate_():
    url = 'http://www.denverrealestate.com/agents.xml'
    domain = url.split('.')[1]
    link_ = []
    response = requests.get(url, headers=headers, proxies=proxies_t)
    if response.status_code == 200:
        xmldoc = minidom.parseString(response.content)
        LOCS = xmldoc.getElementsByTagName('loc')
        LOCS.pop(0)
        for loc in LOCS:
            p_url = loc.childNodes[0].data
            link_.append(p_url)
            if len(link_) > 24:
                break
        if link_:
            item = phase_2.denverrealestate_fun(link_)
        else:
            message_url(domain)


def ebby_():
    url = 'https://www.ebby.com/roster/agents'
    domain = url.split('.')[1]
    link_ = []
    response = requests.get(url, headers=headers, proxies=proxies_t)
    sel = Selector(text=response.content)
    agent_links = sel.xpath(ebby.LINK_XPATH).extract()
    for url in agent_links:
        p_url = response.urljoin(url)
        link_.append(p_url)
        if len(link_) > 24:
            break
    if link_:
        item = phase_2.ebby_fun(link_)
    else:
        message_url(domain)

def ewm_():
    url = 'https://www.ewm.com/agent.xml'
    domain = url.split('.')[1]
    link_ = []
    response = requests.get(url, headers=headers, proxies=proxies_t)
    if response.status_code == 200:
        xmldoc = minidom.parseString(response.content)
        LOCS = xmldoc.getElementsByTagName('loc')
        LOCS.pop(0)
        for loc in LOCS:
            p_url = loc.childNodes[0].data
            link_.append(p_url)
            if len(link_) > 24:
                break
        if link_:
            print(len(link_))
            item = phase_2.ewm_fun(link_)
        else:
            message_url(domain)


def iowarealty_():
    url = 'https://www.iowarealty.com/real-estate-agents'
    next_ = 'https://www.iowarealty.com/real-estate-agents/sort-sn/4'
    domain = url.split('.')[1]
    link_ = []
    res_nxt = requests.get(next_, headers=headers, proxies=proxies_t)
    sel_nxt = Selector(text=res_nxt.content)
    response = requests.get(url, headers=headers, proxies=proxies_t)
    sel = Selector(text=response.content)
    if res_nxt.status_code == 200:
        next_agents = sel_nxt.xpath(iowarealty.AGENT_LIST_XPATH).extract()
        if not next_agents:
            message_pagination(domain)
    if response.status_code == 200:
        agents = sel.xpath(iowarealty.AGENT_LIST_XPATH).extract()
        if agents:
            item = phase_2.iowarealty_fun(agents)
        else:
            message_url(domain)


def semonin_realtor_():
    url = 'https://www.semonin.com/Roster/Offices/elizabethtown'
    domain = url.split('.')[1]
    response = requests.get(url, headers=headers, proxies=proxies_t)
    sel = Selector(text=response.content)
    if response.status_code == 200:
        agent_list = sel.xpath(semonin_realtor.AGENT_LIST_XPATH)
        if agent_list:
            item = phase_2.semonin_fun(agent_list)
        else:
            message_url(domain)


def century21global_():
    url = 'https://www.century21global.com/real-estate-agents/sitemap'
    domain = url.split('.')[1]
    agent_link = []
    response = requests.get(url, headers=headers, proxies=proxies_t)
    sel = Selector(text=response.content)
    if response.status_code == 200:
        list_ = sel.xpath(century21global.AGENT_LIST_XPATH).extract()
        if list_:
            for url in list_:
                if '/USA' not in url:
                    url = 'https://www.century21global.com' + url
                    response1 = requests.get(url, headers=headers)
                    sel1 = Selector(text=response1.content)
                    links = sel1.xpath(century21global.LINKS_XPATH).extract()
                    if links:
                        for link in links:
                            link = 'https://www.century21global.com' + link
                            agent_link.append(link)
                            if len(agent_link) >= 24:
                                break
                    else:
                        message_url(domain)
                break
        else:
            message_url(domain)
        if agent_link:
            item = phase_2.century21global_fun(agent_link)
        else:
            message_url(domain)


def exprealty_():
    url = 'https://experts.expcloud.com/api4/std?searchterms=CA&size=3000&from=0'
    response = requests.get(url, headers=api_headers, proxies=proxies_t)
    domain = url.split('.')[1]
    json_data = json.loads(response.text)
    if json_data.get('hits'):
        if json_data['hits'].get('hits'):
            agents_data = json_data['hits']['hits']
            item = phase_2.exprealty_fun(agents_data)
        else:
            message_url(domain)


def compass_():
    url = 'https://www.compass.com/sitemaps/agent-pages/sitemap_1.xml'
    domain = url.split('.')[1]
    agent_link = []
    response = requests.get(url, headers=headers, proxies=proxies_t)
    sel = Selector(text=response.content)
    urls = re.findall('https.*?>', response.text)
    if urls:
        for links in urls:
            link = links.replace('</loc>', '')
            agent_link.append(link)
            if len(agent_link) >= 24:
                break
    if agent_link:
        item = phase_2.compass_fun(agent_link)
    else:
        message_url(domain)


def realliving_realestate_():
    url = 'https://www.realliving.com/AgentSearch/Results.aspx?SearchType=agent&FirstName=&LastName=&OfficeName=&Address=&City=&State=&Country=-32768&Zip=&Languages=&Titles=&Specialties=&Accreditations=&Areas=&rpp=50&page=1&SortOrder='
    domain = url.split('.')[1]
    agent_link = []
    response = requests.get(url, headers=headers, proxies=proxies_t)
    sel = Selector(text=response.content)
    pagination_url = 'https://www.realliving.com/AgentSearch/Results.aspx?SearchType=agent&FirstName=&LastName=&OfficeName=&Address=&City=&State=&Country=-32768&Zip=&Languages=&Titles=&Specialties=&Accreditations=&Areas=&rpp=50&page=3&SortOrder='
    response2 = requests.get(
        pagination_url, headers=headers, proxies=proxies_t)
    sel2 = Selector(text=response2.content)
    agent_list = sel2.xpath(realliving_realestate.AGENT_LIST_XPATH)
    if not agent_list:
        message_pagination(domain)
    if response.status_code == 200:
        agent_list = sel.xpath(realliving_realestate.AGENT_LIST_XPATH)
        if agent_list:
            item = phase_2.realliving_realestate_fun(agent_list)
        else:
            message_url(domain)


def bhgre_():
    url = 'https://www.bhgre.com/sitemap_brokers_index.xml'
    domain = url.split('.')[1]
    links = []
    response = requests.get(url, headers=headers, proxies=proxies_s)
    sel = Selector(text=response.content)
    urls = re.findall('https.*?xml', response.text)
    if urls:
        for link in urls:
            if 'https' in link:
                link = link.strip('>')
                response2 = requests.get(
                    link, headers=headers, proxies=proxies_s)
                xmldoc = minidom.parseString(response2.text)
                LOCS = xmldoc.getElementsByTagName('loc')
                LOCS.pop(0)
                for loc in LOCS:
                    p_url = loc.childNodes[0].data
                    if '-office-' not in p_url:
                        if '/buying-a-house' in p_url:
                            p_url = p_url.replace('/buying-a-house', '')
                        if '/selling-a-house' in p_url:
                            p_url = p_url.replace('/selling-a-house', '')
                        links.append(p_url)
                        if len(links) >= 24:
                            break
            break
        item = phase_2.bhgre_fun(links)
    else:
        message_url(domain)


def berkshire_():
    url = 'https://www.bhhs.com/bin/bhhs/agentSearchServlet?sortType=5&resultSize=10000&state=PA&page=1'
    headers = {
        'authority': 'www.bhhs.com',
        'method': 'GET',
        # 'path': '/bin/bhhs/officeSearchServlet?PageSize=10&Sort=1&Page=1',
        'scheme': 'https',
        'accept': 'application/json, text/javascript, */*; q=0.01',
        'accept-encoding': 'gzip, deflate, br',
        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
        'pragma': 'no-cache',
        'referer': 'https://www.bhhs.com/office-results-list',
        'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
        'x-requested-with': 'XMLHttpRequest',
    }
    domain = url.split('.')[1]
    links = []
    response = requests.get(url, headers=headers, proxies=proxies_t)
    json_data = json.loads(response.text)
    if json_data.get('@odata.count'):
        total_count = json_data.get('@odata.count')
    if json_data.get('value'):
        for data in json_data.get('value'):
            agent_url = data.get('BhhsWebsiteUrl')
            links.append(agent_url)
            if len(links) >= 24:
                break
        if links:
            item = phase_2.berkshire_fun(links)
        else:
            message_url(domain)


def century21_us_():
    url = 'https://www.century21.com/c21sitemaps/sitemapc21agents.xml'
    domain = url.split('.')[1]
    links = []
    response = requests.get(url, headers=headers, proxies=proxies_s)
    xmldoc = minidom.parseString(response.content)
    LOCS = xmldoc.getElementsByTagName('loc')
    for loc in LOCS:
        p_url = loc.childNodes[0].data
        p_url = p_url.strip()
        response1 = requests.get(p_url, headers=headers, proxies=proxies_s)
        compressedFile = io.BytesIO()
        compressedFile.write(response1.content)
        compressedFile.seek(0)
        decompressedFile = gzip.GzipFile(fileobj=compressedFile, mode='rb')
        sitemap_data = decompressedFile.read()
        xmldoc1 = minidom.parseString(sitemap_data)
        LOCS1 = xmldoc1.getElementsByTagName('loc')
        for loc1 in LOCS1:
            p_urls = loc1.childNodes[0].data
            if 'www.century21.com' in p_urls:
                if '/buying-a-house' in p_urls:
                    p_urls = p_urls.replace('/buying-a-house', '')
                if '/selling-a-house' in p_urls:
                    p_urls = p_urls.replace('/selling-a-house', '')
                links.append(p_urls)
                print(len(links))
                if len(links) >= 24:
                    break
        if len(links) >= 24:
            break
    if links:
        print(len(links))
        item = phase_2.century21_us_fun(links)
    else:
        message_url(domain)


def coldwellbanker_():
    url = 'https://www.coldwellbanker.com/sitemap_brokers_index.xml'
    domain = url.split('.')[1]
    links = []
    response = requests.get(url, headers=headers, proxies=proxies_s)
    sel = Selector(text=response.content)
    URLS = sel.xpath(coldwell_banker.LINKS_XPATH).extract()
    for url in URLS:
        url = url.strip()
        if url.endswith('.xml'):
            response1 = requests.get(url, headers=headers, proxies=proxies_s)
            sel1 = Selector(text=response1.content)
            URLS = sel1.xpath(coldwell_banker.LINKS_XPATH).extract()
            for url2 in URLS:
                url2 = url2.strip()
                if '/Coldwell-Banker' in url2:
                    if '/buying-a-house' in url2:
                        url2 = url2.replace('/buying-a-house', '')
                    if '/selling-a-house' in url2:
                        url2 = url2.replace('/selling-a-house', '')
                    links.append(url2)
                if len(links) >= 24:
                    break
        else:
            if '/Coldwell-Banker' in url:
                if '/buying-a-house' in url:
                    url = url.replace('/buying-a-house', '')
                if '/selling-a-house' in url:
                    url = url.replace('/selling-a-house', '')
                links.append(url)
            if len(links) >= 24:
                break
        if len(links) >= 24:
            break
    if links:
        item = phase_2.coldwellbanker_fun(links)
    else:
        message_url(domain)


def coldwellbanker_international_():
    url = 'https://www.coldwellbankerinternational.com/agents/ca/page/1/?sort=newest&query_type=all-agents&ExpandQuery=true&_pjax=%23proxio-card-list-agent-widget'
    domain = url.split('.')[1]
    links = []
    response = requests.get(url, headers=headers, proxies=proxies_t)
    sel = Selector(text=response.content)
    NAME_SELECTORS = sel.xpath(coldwell_internatinal.NAME_SELECTOR_XPATH)
    next_page = sel.xpath(coldwell_internatinal.NEXT_XPATH).extract_first('')
    if not next_page:
        message_pagination(domain)
    if NAME_SELECTORS:
        for name_selector in NAME_SELECTORS:
            link = name_selector.xpath('@href').extract_first('')
            name = name_selector.xpath(
                coldwell_internatinal.NAME_XPATH).extract_first('').strip()
            if link and name:
                links.append(link)
            if len(links) >= 24:
                break
        item = phase_2.coldwell_internatinal_fun(links)
    else:
        message_url(domain)


def edinarealty_():
    headers1 = {'Accept': 'application/json, text/plain, */*',
                'Origin': 'https://www.edinarealty.com',
                'Referer': 'https://www.edinarealty.com/find-a-realtor-office',
                'Sec-Fetch-Mode': 'cors',
                'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36', }
    url1 = 'https://www.edinarealty.com/find-a-realtor-office#/'
    domain = url1.split('.')[1]
    response1 = requests.get(url1, headers=headers, proxies=proxies_t)
    sel1 = Selector(text=response1.content)
    res = response1.text
    api = re.findall('apiKey = "(.*?)";', res)
    api = api[0] if api else ''
    time_stamp = re.findall('timestamp = "(.*?)";', res)
    time_stamp = time_stamp[0] if time_stamp else ''
    headers1.update({'api-key': api, 'timestamp': time_stamp})
    # print(headers1)
    url2 = 'https://api.edinarealty.com/api/Person/AgentSearch?&SortBy=AgentLegalLastNameAtoZ&pgeNum=1'
    response = requests.get(url2, headers=headers1, proxies=proxies_t)
    office_phone_numbers = []
    if response.status_code == 200:
        data = json.loads(response.text)
        if data:
            agents = data.get('agents', [])
            if agents:
                item = phase_2.edinarealty_fun(agents)
            else:
                message_url(domain)
    else:
        message_url(domain)


def firstweber_():
    url = 'https://www.firstweber.com/find-wisconsin-real-estate-agent'
    domain = url.split('.')[1]
    links = []
    headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
               'Accept-Encoding': 'gzip, deflate, br',
               'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
               'Upgrade-Insecure-Requests': '1',
               'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}

    response = requests.get(url, headers=headers, proxies=proxies_t)
    # response = requests.get(url, headers=headers)
    sel = Selector(text=response.content)
    office_name = sel.xpath(firstweber.OFFICE_XPATH).extract()
    for office in office_name:
        if office != '':
            link = 'https://www.firstweber.com/vp/AgentServlet'
            formdata = {'fg_SummaryCntl': 'TRUE',
                        'SITE': 'FIRSTWEBER',
                        'ScreenID_Cur': 'SEARCH_AGENTS_P',
                        'ScreenID': 'AgentsSummary_Public',
                        'ScreenID_Alt': 'AGENT_DETAIL_P',
                        'fg_PublicWebPage': 'Y',
                        'Search': 'Search',
                        'A_FG_ACTIVE': 'Y',
                        'A_FG_PUBLICWEBPAGE': 'Y',
                        'A_CD_COMPANY': 'FIRSTWEBER',
                        'A_CD_AGENT': '',
                        'context': 'SEARCH_AGENTS_P_SEARCH',
                        'AGENT_NAME': '',
                        'A_CD_OFFICE': office,
                        'A_DS_LANGUAGES': '',
                        'A_DS_CREDITS': '',
                        'submit': 'View+agents'}
            response1 = requests.post(
                link, headers=headers, data=formdata, proxies=proxies_t)
            sel1 = Selector(text=response1.content)
            Profile_link = sel1.xpath(firstweber.LINK_XPATH).extract()
            if Profile_link:
                for agent_link in Profile_link:
                    links.append(agent_link)
                    if len(links) >= 24:
                        break
        if len(links) >= 25:
            break

    if links:
        item = phase_2.firstweber_fun(links)
    else:
        message_url(domain)


def global_remax_():
    url = 'https://global.remax.com/handlers/officeagentsearch.ashx?mode=list&type=2&regionId=53&page=1'
    domain = url.split('.')[1]
    response = requests.get(url, headers=headers, proxies=proxies_t)
    sel = Selector(text=response.content)
    links = sel.xpath(global_remax.LINKS_XPATH).extract()
    if links:
        item = phase_2.global_remax_fun(links)
    else:
        message_url(domain)


def long_foster_():
    url = 'https://www.longandfoster.com/include/ajax/api.aspx?op=SearchAgents&firstname=&lastname=&page=3&pagesize=50'
    domain = url.split('.')[1]
    links = []
    response = requests.get(url, headers=headers, proxies=proxies_t)
    sleep(0.001)
    if response.status_code == 200:
        response_data = json.loads(response.text)
        result = response_data.get('Entity', '')
        if result:
            datas = json.loads(result)
            if datas:
                item = phase_2.long_foster_fun(datas)
            else:
                message_url(domain)


def remax_():
    links = []
    for i in range(100000000, 200000000):
        url = 'https://public-api-gateway-prod.kube.remax.booj.io/personnel/agents/' + \
            str(i)+'/'
        domain = url.split('.')[1]
        response = requests.get(url, headers=headers, proxies=proxies_t)
        json_data = json.loads(response.text)
        active = json_data.get('data')
        active = active.get('status') if active else ''
        if active == "ACTIVE":
            p_url = response.url
            links.append(p_url)
            print(len(links))
        if len(links) >= 24:
            break
    if links:
        item = phase_2.remax_fun(links)
    else:
        message_url(domain)


def sutton_():
    url = 'https://www.sutton.com/Agents/'
    domain = url.split('.')[1]
    links = ['https://www.sutton.com/Agents/on/toronto/ann-hannah/59e3da51efda951300fd0718',
             'https://www.sutton.com/Agents/bc/vancouver/raymond-lui/59e3e469efda951300fd3044',
             'https://www.sutton.com/Agents/on/burlington/roger-starr/59e3f2dfefda951300fd8e85',
             'https://www.sutton.com/Agents/qc/montreal/danielle-allarie/5aeb4c70a7da921b90073824',
             'https://www.sutton.com/Agents/bc/surrey/sukhi-kang/5c5347b3fe4485252c23bc2c',
             'https://www.sutton.com/Agents/bc/white%20rock/harpal-lehal/59e3da77efda951300fd088c',
             'https://www.sutton.com/Agents/on/newmarket/dave-starr/59e3db37efda951300fd0d0c',
             'https://www.sutton.com/Agents/ab/calgary/mel-mills/59e3e265efda951300fd28f9',
             'https://www.sutton.com/Agents/bc/nanaimo/hunter-yu/59e3e59cefda951300fd351c',
             'https://www.sutton.com/Agents/on/london/philip-pattyn/59e3e639efda951300fd37d2',
             'https://www.sutton.com/Agents/on/toronto/carmine-pincente/59e3f4c9efda951300fda2b0',
             'https://www.sutton.com/Agents/qc/lasalle/gueorgui-kirioukhine/5e4c56ebc4d6d81b7432e5f2', ]
    item = phase_2.sutton_fun(links)
def error_fun(e):
    logging.exception(str(e))
    count = len(open('spider_error.log').readlines())
    if count > 0:
        f = open('spider_error.log')
        l = f.readlines()
        m = re.findall('requests.*ProxyError.*?peer.*',''.join(l))
        if m:
            for user in USERS:
                message = 'SPCD running stoped due to proxy fail'
                Slack.chat.post_message(user, message)
        else:
            for user in USERS:
                message = 'SPCD running stoped due to an exception is raised'
                Slack.chat.post_message(user, message)




try:
    alliebeth_()
except:
    try:
        alliebeth_()
    except Exception as e:
        spider = "alliebeth"
        error_fun(e,spider)
try:
    harrynorman_()
except:
    try:
        harrynorman_()
    except Exception as e:
        spider = "harrynorman"
        error_fun(e,spider)
try:
    homerealestate_()
except:
    try:
        homerealestate_()
    except Exception as e: 
        spider = "homerealestate"
        error_fun(e,spider)
try:
    royallepage_()
except:
    try:
        royallepage_()
    except Exception as e:
        spider = "royallepage"  
        error_fun(e,spider)
try:    
    guarantee_()
except:
    try:
        guarantee_()
    except Exception as e:
        spider = "guarantee"  
        error_fun(e,spider)
try:        
    huff_realty_()
except:
    try:
        huff_realty_()
    except Exception as e:
        spider = "huff_realty"  
        error_fun(e,spider)
try:
    houlihanlawrence_()
except:
    try:
        houlihanlawrence_()
    except Exception as e:
        spider = "houlihanlawrence"  
        error_fun(e,spider)
try:
    robertbrothers_()
except:
    try:
        robertbrothers_()
    except Exception as e:
        spider = "robertsbrothers"  
        error_fun(e,spider)
try:
    wrrealtor_()
except:
    try:
        wrrealtor_()
    except Exception as e:
        spider = "wrrealtors"  
        error_fun(e,spider)
try:
    rubinarealestate_()
except:
    try:
        rubinarealestate_()
    except Exception as e:
        spider = "rubinarealestate"  
        error_fun(e,spider)
try:
    woodbros_()
except:
    try:
        woodbros_()
    except Exception as e: 
        spider = "woodsbros" 
        error_fun(e,spider)
try:
    reecenichols_()
except:
    try:
        reecenichols_()
    except Exception as e:
        spider = "reecenichols"  
        error_fun(e,spider)
try:
    rector_hyden_()
except:
    try:
        rector_hyden_()
    except Exception as e:
        spider = "rector_hyden"  
        error_fun(e,spider)
try:
    longrealty_()
except:
    try:
        longrealty_()
    except Exception as e:
        spider = "longrealty"  
        error_fun(e,spider)
try:
    intero_realestate_()
except:
    try:
        intero_realestate_()
    except Exception as e:
        spider = "intero_realestate"  
        error_fun(e,spider)
try:
    realty_south_()
except:
    try:
        realty_south_()
    except Exception as e:
        spider = "realtysouth"  
        error_fun(e,spider)
    # phase - 2
    # ----------------
# try:
#     denver_realestate_()
# except:
#     try:
#         denver_realestate_()
#     except Exception as e:  
#         error_fun(e,spider)
try:
    ebby_()
except:
    try:
        ebby_()
    except Exception as e:
        spider = "ebby"  
        error_fun(e,spider)

try:
    iowarealty_()
except:
    try:
        iowarealty_()
    except Exception as e:
        spider = "iowarealty"  
        error_fun(e,spider)
try:
    semonin_realtor_()
except:
    try:
        semonin_realtor_()
    except Exception as e: 
        spider = "semonin_realtor" 
        error_fun(e,spider)
try:
    century21global_()
except:
    try:
        century21global_()
    except Exception as e: 
        spider = "century21global" 
        error_fun(e,spider)
try:
    exprealty_()
except:
    try:
        exprealty_()
    except Exception as e:
        spider = "exprealty"  
        error_fun(e,spider)
try:
    compass_()
except:
    try:
        compass_()
    except Exception as e:
        spider = "compass"  
        error_fun(e,spider)
try:
    realliving_realestate_()
except:
    try:
        realliving_realestate_()
    except Exception as e: 
        spider = "realliving_realestate" 
        error_fun(e,spider)
try:
    bhgre_()
except:
    try:
        bhgre_()
    except Exception as e:
        spider = "bhgre"  
        error_fun(e,spider)
try:
    global_remax_()
except:
    try:
        global_remax_()
    except Exception as e: 
        spider = "global_remax" 
        error_fun(e,spider)
try:
    long_foster_()
except:
    try:
        long_foster_()
    except Exception as e:
        spider = "longandfoster"  
        error_fun(e,spider)
try:
    coldwellbanker_international_()
except:
    try:
        coldwellbanker_international_()
    except Exception as e:  
        spider = "coldwellbankerinternational"
        error_fun(e,spider)
try:
    sutton_()
except:
    try:
        sutton_()
    except Exception as e: 
        spider = "sutton" 
        error_fun(e,spider)
try:
    remax_()
except:
    try:
        remax_()
    except Exception as e:
        spider = "remax"  
        error_fun(e,spider)
try:
    berkshire_()
except:
    try:
        berkshire_()
    except Exception as e:
        spider = "berkshire"  
        error_fun(e,spider)
try:
    coldwellbanker_()
except:
    try:
        coldwellbanker_()
    except Exception as e:
        spider = "coldwell_banker"  
        error_fun(e,spider)
try:
    edinarealty_()
except:
    try:
        edinarealty_()
    except Exception as e: 
        spider = "edinarealty" 
        error_fun(e,spider)
try:
    firstweber_()
except:
    try:
        firstweber_()
    except Exception as e: 
        spider = "firstweber" 
        error_fun(e,spider)
try:
    century21_us_()
except:
    try:
        century21_us_()
    except Exception as e:
        spider = "century21_us"  
        error_fun(e,spider)
try:
    ewm_()
except:
    try:
        ewm_()
    except Exception as e: 
        spider = "ewm" 
        error_fun(e,spider)
