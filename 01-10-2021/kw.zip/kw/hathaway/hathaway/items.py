# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class HathawayItem(scrapy.Item):
   
	name = scrapy.Field()
	image = scrapy.Field()
	address = scrapy.Field()
	phone_number = scrapy.Field()
	profile_url = scrapy.Field()