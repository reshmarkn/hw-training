# -*- coding: utf-8 -*-
import scrapy
from scrapy.http import Request
from hathaway.items import *
from hathaway.settings import *


class HathawaySpiderSpider(scrapy.Spider):
	name = 'hathaway_spider'
	#allowed_domains = ['http://www.bhhsfirstrealty.com']
	start_urls = ['http://www.bhhsfirstrealty.com/real-estate-agents']

	def parse(self, response):
		links = response.xpath('//h2[@itemprop="name"]/a/@href').extract()
		for link in links:
			yield Request(url=link,callback=self.parse_people)

		next_page = set(response.xpath('//li[@class="mobile"]/a/@href').extract())
		for next_ in next_page:
			yield Request(url=next_,callback=self.parse)

	def parse_people(self, response):
		name = response.xpath('//h1/text()').extract()
		image = response.xpath('//div[@class="Agent-footer-photo"]/img/@src').extract()
		address = response.xpath('//li[@class="business"]/text()').extract()
		phone_number = response.xpath('//strong/a/text()').extract()
		profile_url = response.url

		name = ''.join(name).strip()
		image = ''.join(image).strip()
		address = ''.join(address).strip()
		address = ' '.join(address.split())
		phone_number = ''.join(phone_number).strip()

		image = response.urljoin(image) if image else ''

		item = HathawayItem(
			name = name,
			image = image,
			address = address,
			phone_number =phone_number,
			profile_url = profile_url
			)
		yield item
