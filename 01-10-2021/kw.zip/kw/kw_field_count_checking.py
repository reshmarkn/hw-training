from pymongo import MongoClient
import slack
import collections
first_db='kw_monthly_2021_05'
first_col='coldwellbanker_com_data_v1'
second_db='kw_monthly_2021_06'
second_col='coldwellbanker_com_data'
token='xoxp-24300212688-35464554529-262255845088-43b7f5b45d669c16a2fc81caa80fa6e2'
username=['@Priyanka','@ramesh']
first=[]
client = MongoClient('mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017')
db = client[first_db]
searchString = {'_id': 0,'state':1}
result = db[first_col].find({}, searchString)
for item in result:
	first.append(item.get('state'))
second=[]
client = MongoClient('mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017')
db = client[second_db]
searchString = {'_id': 0,'state':1}
result = db[second_col].find({}, searchString)
for item in result:
	second.append(item.get('state'))
first_occu=collections.Counter(first)
first_occu=dict(first_occu)
second_occu=collections.Counter(second)
second_occu=dict(second_occu)
diff={x: first_occu[x] -second_occu[x] for x in first_occu if x in second_occu}
message='Differnce between {}[{}] and {}[{}]\n-------------------------------------------------------------\n'.format(first_db,first_col,second_db,second_col)
for item in diff:
	value=diff.get(item)
	if value<0:
		highlight='more'
		value=value*-1
	elif value>0:
		highlight='less'
	else:
		highlight='no chnage'
	if value>=500:
		message=message+"{}: {} {} than first count\n".format(item,value,highlight)
sc = slack.WebClient(token, timeout=60)
for user in username:
	sc.chat_postMessage(channel=user,text="```"+message+"```")
print(message)