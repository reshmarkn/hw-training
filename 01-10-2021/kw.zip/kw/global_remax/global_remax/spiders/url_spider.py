# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from global_remax.items import *
from global_remax.settings import *
from global_remax.proxy import parse_proxy
from scrapy.shell import inspect_response
from pymongo import MongoClient
from scrapy import signals
import subprocess
# from databasenotifier import automation_script
handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


class Global_RemaxSpider(Spider):
    name = 'global_remaxurl_crawler'
    allowed_domains = ['global.remax.com']
    start_urls = ['https://global.remax.com/']
    # db = MongoClient('mongodb://localhost').kw_nov_19

    # def __init__(self):
    #     self.db.remax_global_url_nov_3.create_index(
    #         'url', unique=True)
    # def spider_ended(self):
    # automation_script.Automation_Spider(MONGO_DB, MONGO_COLLECTION_URL)
    # subprocess.call("python q_insert.py ", shell=True)

    def parse(self, response):
        f = open("country_id.txt")
        for country in f.readlines():
            url = 'https://global.remax.com/handlers/officeagentsearch.ashx?mode=list&type=2&regionId=' + \
                country.strip() + '&page=1'
            yield Request(url=response.urljoin(url), callback=self.parse_urls, dont_filter=True)

    def parse_urls(self, response):
        # inspect_response(response, self)
        urls = response.xpath(
            '//div/a[@class="officeagent-pic"]/@href').extract()
        if urls:
            for url in urls:
                # meta = {'url': response.urljoin(url)}
                # db.global_remax_url.insert(dict(meta))
                item = GlobalRemaxUrlItem()
                item['url'] = response.urljoin(url)
                yield item

            nextpage = response.url.split(
                '&page=')[0] + '&page=' + str(int(response.url.split('&page=')[1]) + 1)
            yield Request(url=nextpage, callback=self.parse_urls, dont_filter=True)

    # @classmethod
    # def from_crawler(cls, crawler, *args, **kwargs):
    #     spider = super(Global_RemaxSpider, cls).from_crawler(
    #         crawler, *args, **kwargs)
    #     crawler.signals.connect(spider.spider_opened, signals.spider_opened)
    #     crawler.signals.connect(spider.spider_closed, signals.spider_closed)
    #     return spider

    # def spider_opened(self, spider):
    #     print('Opening {} spider'.format(spider.name))

    # def spider_closed(self, spider):
    #     print('%%%%%%%%%%%%%%%%%%%%%%%%%%')
    #     self.spider_ended()
    #     print('Closing {} spider'.format(spider.name))

# NOTE
# --------

# 1] check id.txt file and confirm the country codes, except us urls
# 2] make sure urls crawled are from remax-global
# 3] compare the url count
# ==================================================
