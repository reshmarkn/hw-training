import pika
import json

from pymongo import MongoClient
from time import sleep
import datetime

MONGO_URI = 'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false'  # shard


def ShardOutput(dbn, col, field):
    DB_NAME = dbn
    COLLECTION_NAME = col

    # client = MongoClient(
    #   'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')
    # client = MongoClient('mongodb://datahut:cGFzc21lMTIz@64.225.9.179:27017')
    client = MongoClient(MONGO_URI)

    if DB_NAME not in client.list_database_names():
        message = "Database Named {} not found in Shard".format(DB_NAME)

        exit()

    db = client[DB_NAME]
    if COLLECTION_NAME not in db.list_collection_names():
        message = "Collection named {} not Found in {} ".format(
            COLLECTION_NAME, DB_NAME)

        print(message)
        exit()
    try:
        doc = dict(db[COLLECTION_NAME].find_one())
        cols = ''
    except:
        doc = ''
        cols = ''
    if field not in doc.keys():
        message = "Field named {} not Found in {} ".format(
            field, COLLECTION_NAME)

        print(message)
        exit()
    else:
        result = db[COLLECTION_NAME].find({})

        try:
            distinct = len(result.distinct(field))
        except:
            distinct = "Too big to calculate"

        message = "----------{}[{}]----------\nTotal Count:{}\nDistinct {} Count:{}".format(
            DB_NAME, COLLECTION_NAME, result.count(), field, distinct)

    return result


# client = MongoClient('mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')
# client = MongoClient('mongodb://datahut:cGFzc21lMTIz@64.225.9.179:27017')
client = MongoClient(MONGO_URI)

DB_NAME = input('Enter 1st DB Name:')

db = client[DB_NAME]
colist = db.list_collection_names()
for j in colist:

    print(colist.index(j) + 1, j, ":", str(db[j].estimated_document_count()))

COLLECTION_NAME_1 = input('Enter First Collection Name:')

while(not COLLECTION_NAME_1):

    print(db.list_collection_names())
    COLLECTION_NAME_1 = input('Enter first Collection Name:')


doc = dict(db[COLLECTION_NAME_1].find_one())
for key in doc:
    print(key, ":", doc[key])
FIELD_1 = input('Enter FIELD:')
db1n = DB_NAME
col1 = COLLECTION_NAME_1
field1 = FIELD_1
result1 = ShardOutput(db1n, col1, field1)

DB_NAME = input('Enter 2nd DB Name:')

db = client[DB_NAME]
colist = db.list_collection_names()
for j in colist:

    print(colist.index(j) + 1, j, ":", str(db[j].estimated_document_count()))


COLLECTION_NAME_2 = input('Enter Second Collection Name:')

while(not COLLECTION_NAME_2):

    print(db.list_collection_names())
    COLLECTION_NAME_2 = input('Enter Second Collection Name:')


doc = dict(db[COLLECTION_NAME_2].find_one())
for key in doc:
    print(key, ":", doc[key])
FIELD_2 = input('Enter FIELD:')

db2n = DB_NAME
col2 = COLLECTION_NAME_2
field2 = FIELD_2
result2 = ShardOutput(db2n, col2, field2)

check = []
for data in result2:
    check.append(data[field2])

out = []


for data in result1:
    if data[field1] not in check:
        del data['_id']
        out.append(json.dumps(data))


message = "Missing count:{}".format(len(out))

print(message)

Hosts = ['134.209.174.206', '159.89.47.171', '138.197.109.170']

for i in Hosts:
    print(Hosts.index(i), "  ", i)


QUEUE_HOST = Hosts[int(input("Choose Host:"))]
# QUEUE_HOST = '159.89.47.171'  # load balancer

QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'
QUEUE_NAME = input("QUEUE NAME:")

credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
connection = pika.BlockingConnection(pika.ConnectionParameters(
    credentials=credentials, host=QUEUE_HOST, socket_timeout=3000))
channel = connection.channel()

URLS = out


channel.queue_declare(queue=QUEUE_NAME, durable=True)
count = len(URLS)


# print("QUEUE_IP="+QUEUE_HOST+"\n"+"QUEUE_NAME= "+QUEUE_NAME)
# print(QUEUE_HOST+":15672/")
# print("QUEUE Username:"+QUEUE_USER)
# print("QUEUE Password:"+QUEUE_PASS)
# print("Element Count="+str(len(URLS)))
message = "QUEUE_IP=" + QUEUE_HOST + "\n" + "QUEUE_NAME= " + QUEUE_NAME + "\n" + QUEUE_HOST + ":15672/" + "\nQUEUE Username:" + \
    QUEUE_USER + "\nQUEUE Password:" + QUEUE_PASS + "\nElement Count=" + str(count)
print(message)

for x in URLS:
    channel.basic_publish(exchange='', routing_key=QUEUE_NAME, body=x.strip())
    sleep(0.0001)
connection.close()
