# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html


from pymongo import MongoClient
from scrapy.exceptions import DropItem
from coldwellbanker.items import *
from coldwellbanker.settings import *

# MONGODB_COLLECTION_AGENT_2 = 'coldwellbanker_us_data_test'


class ColdwellbankerPipeline(object):

    def __init__(self, *args, **kwargs):
        # self.client = MongoClient()

        # self.db = MongoClient(
            # 'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')[MONGODB_DB]
        # self.db[MONGODB_COLLECTION_AGENT].create_index('profile_url', unique=True)
        # self.db[MONGODB_COLLECTION_URL_AGENT].create_index('profile_url', unique=True)

        self.client = MongoClient(
            'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
        try:
            self.client.admin.command("enablesharding", MONGODB_DB)
        except:
            pass
        try:
            self.client.admin.command(
                "shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION_URL, key={'url': 1})
        except:
            pass
        try:
            self.client.admin.command(
                "shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION, key={'profile_url': 1}, unique=True)
        except:
            pass
        # try:
        #     self.client.admin.command(
        #         "shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION_AGENT_2, key={'profile_url': 1}, unique=True)
        # except:
        #     pass

        self.db = self.client[MONGODB_DB]

    def process_item(self, item, spider):

        # self.db[MONGODB_COLLECTION_AGENT].insert(dict(item))

        if isinstance(item, ColdwellbankerItem):
            try:
                self.db[MONGODB_COLLECTION].insert(dict(item))
            except:
                raise DropItem("Dropping duplicate item")
        if isinstance(item, ColdwellbankerUrlItem):
            # try:
            self.db[MONGODB_COLLECTION_URL].insert(dict(item))
            # except:
            # raise DropItem("Dropping duplicate item")
        # if isinstance(item, ColdwellbankerCloudItem):
        #     # try:
        #     self.db[MONGODB_COLLECTION_AGENT_2].insert(dict(item))

        return item
