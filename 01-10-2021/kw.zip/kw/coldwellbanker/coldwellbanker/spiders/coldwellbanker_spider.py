# import scrapy
# import re
# import requests
# import json
# import urllib
# import logging

# from scrapy.spiders import Spider
# # from urlparse import urlparse, urljoin
# from scrapy.selector import Selector
# from scrapy.shell import inspect_response
# from scrapy.http import Request
# from datetime import datetime
# from scrapy.http import Request, FormRequest
# from scrapy.utils.log import configure_logging
# from pymongo import MongoClient

# from coldwellbanker.items import *
# from coldwellbanker.settings import *
# from coldwellbanker.storm_proxy import parse_proxy


# class coldwellbankerSpider(scrapy.Spider):
#     name = 'coldwellbanker'
#     allowed_domains = ["coldwellbanker.com"]
#     start_urls = ['https://www.coldwellbanker.com/sitemap_brokers_index.xml',
#                   ]  # Browse all
#     BASE_URL = 'https://www.coldwellbanker.com'
#     HEADERS = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
#                'Accept-Encoding': 'gzip, deflate, br',
#                'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
#                'Upgrade-Insecure-Requests': '1',
#                'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.82 Safari/537.36', }

#     configure_logging(install_root_handler=False)
#     logging.basicConfig(filename='spider.log', filemode='w',
#                         format='%(asctime)s - %(name)50s - %(levelname)10s - %(message)s', level=logging.DEBUG)
#     logging.basicConfig(filename='spider_error.log', filemode='w',
#                         format='%(asctime)s - %(name)50s - %(levelname)10s - %(message)s', level=logging.ERROR)

#     def parse(self, response):
#         sel = Selector(text=response.body)
#         URLS = sel.xpath('//loc/text()').extract()

#         for i, url in enumerate(URLS):
#             url = url.strip()
#             response = ''
#             if url.endswith('.xml'):
#                 yield Request(url=url, callback=self.parse,)
#             else:
#                 response = ''
#                 try:
#                     proxy = parse_proxy()
#                     proxies = proxy['proxies']
#                     req = requests.session()
#                     res = req.get('https://www.coldwellbanker.com',
#                                   headers=self.HEADERS, proxies=proxies)
#                     response = req.get(
#                         url, headers=self.HEADERS, proxies=proxies)
#                 except:
#                     try:
#                         proxy = parse_proxy()
#                         proxies = proxy['proxies']
#                         req = requests.session()
#                         res = req.get('https://www.coldwellbanker.com',
#                                       headers=self.HEADERS, proxies=proxies)
#                         response = req.get(
#                             url, headers=self.HEADERS, proxies=proxies)
#                     except:
#                         pass
#                 if response:
#                     item = self.parse_office(response)
#                     if item:
#                         yield item
#                     else:
#                         self.errback_httpbin(url)
#                 else:
#                     self.errback_httpbin(url)

#     def parse_office(self, response):
#         sel = Selector(text=response.content)
#         is_agent = sel.xpath('//body[@id="agent-homepage"]')
#         if is_agent:
#             url = response.url
#             items = ColdwellbankerUrlItem(
#                 profile_url=url,
#             )
#             if url:
#                 return items
#         else:
#             agent_urls = sel.xpath(
#                 '//div[@class="pod pod--rounded"]/div[@itemtype="http://schema.org/RealEstateAgent"]//a[@itemprop="url"]/@href').extract()
#             for url in agent_urls:
#                 url = url.strip()
#                 url = 'https://www.coldwellbanker.com' + url
#                 items = ColdwellbankerUrlItem(
#                     profile_url=url,
#                 )
#                 if url:
#                     return items

#     def errback_httpbin(self, url):
#         pass
#         # credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
#         # connection = pika.BlockingConnection(pika.ConnectionParameters(
#         #     credentials=credentials, host=QUEUE_IP, socket_timeout=600))
#         # channel = connection.channel()
#         # channel.queue_declare(queue=QUEUE_NAME, durable=True)
#         # channel.basic_publish(exchange='', routing_key=QUEUE_NAME, body=url)
#         # connection.close()
