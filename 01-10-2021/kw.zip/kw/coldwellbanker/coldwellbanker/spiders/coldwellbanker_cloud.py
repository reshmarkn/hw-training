# import re
# import pika
# import json
# import scrapy
# import urllib
# import logging
# import requests
# import requests
# import cloudscraper

# from scrapy import signals
# from datetime import datetime
# from pymongo import MongoClient
# from scrapy.http import Request
# from scrapy.spiders import Spider
# from coldwellbanker.items import *
# from coldwellbanker.settings import *
# from scrapy.selector import Selector
# # from coldwellbanker.tor_proxy import *
# from scrapy.shell import inspect_response
# from scrapy.shell import inspect_response
# from scrapy.http import Request, FormRequest
# from databasenotifier import automation_script
# from coldwellbanker.storm_proxy import parse_proxy
# # from coldwellbanker.tor_proxy import parse_proxy

# handler = logging.FileHandler('spider_error.log')
# handler.setLevel('ERROR')
# logging.root.addHandler(handler)
# logger = logging.getLogger('pika')
# logger.propagate = False


# class coldwellbankerSpider(scrapy.Spider):
#     name = 'coldwellbanker_cloud'
#     allowed_domains = ["coldwellbanker.com"]
#     start_urls = ['https://coldwellbanker.com',
#                   ]  # Browse all
#     BASE_URL = 'https://www.coldwellbanker.com'

#     headers = {
#         "authority": "www.coldwellbanker.com",
#         "method": "GET",
#         "scheme": "https",
#         "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
#         "accept-encoding": "gzip, deflate, br",
#         "accept-language": "en-GB,en-US;q=0.9,en;q=0.8,ml;q=0.7",
#         "cache-control": "no-cache",
#         "pragma": "no-cache",
#         "sec-fetch-mode": "navigate",
#         "sec-fetch-site": "none",
#         "upgrade-insecure-requests": "1",
#         "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36"
#     }
#     handle_httpstatus_list = [405, 403]

#     db = MongoClient(
#         'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017').kw_Jul_2020
#     dbname = 'kw_Jul_2020'
#     collection_name = 'coldwellbanker_us_data'

#     def spider_ended(self):
#         automation_script.Automation_Spider(dbname, collection_name)

#     def __init__(self, name=None, **kwargs):
#         self.client = MongoClient(MONGODB_SERVER)
#         self.db = self.client[MONGODB_DB]

#     def parse(self, response):
#         if READ_FROM_FILE == False:
#             credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
#             while True:
#                 connection = pika.BlockingConnection(pika.ConnectionParameters(
#                     credentials=credentials, host=QUEUE_IP, socket_timeout=300))
#                 channel = connection.channel()
#                 channel.basic_qos(prefetch_count=1)
#                 method, properties, url = channel.basic_get(queue=QUEUE_NAME)
#                 if not url.strip():
#                     break
#                 channel.basic_ack(delivery_tag=method.delivery_tag)
#                 connection.close()
#             # urls = ['https://www.coldwellbanker.com/Coldwell-Banker-Select-Realty-611c/Susan-Gallacher-190849a',
#             #         'https://www.coldwellbanker.com/Coldwell-Banker-Select-Realty-611c/Ron-Pollenz-190855a',
#             #         'https://www.coldwellbanker.com/Coldwell-Banker-Real-Estate-Now-48313c/RAY-ADDISON-201596a',
#             #         'https://www.coldwellbanker.com/Coldwell-Banker-Real-Estate-Group-45991c/Tom-Cofrin-665227a',
#             #         'https://www.coldwellbanker.com/Coldwell-Banker-ELEVATED-REAL-ESTATE-10383c/Billie-Hiatt-2394033a',
#             #         'https://www.coldwellbanker.com/Coldwell-Banker-Real-Estate-Now-48313c/EDEN-SMITH-201598a']
#             # for url in urls:
#                 if url.strip():
#                     url = url.strip()
#                     response = ''
#                     try:
#                         proxy = parse_proxy()
#                         proxies = proxy['proxies']
#                         req = requests.session()
#                         scraper = cloudscraper.create_scraper(sess=req)
#                         res = scraper.get('https://www.coldwellbanker.com/',
#                                       headers=self.headers, proxies=proxies)
#                         if res.status_code == 200:
#                             response = scraper.get(
#                                 url, headers=self.headers, proxies=proxies)
#                         else:
#                             if res.status_code == 404:
#                                 urls = {'url': url}
#                                 self.db['coldwellbanker_404'].insert(
#                                     dict(urls))
#                             else:

#                                 self.errback_httpbin(url)
#                     except:
#                         try:
#                             proxy = parse_proxy()
#                             proxies = proxy['proxies']
#                             req = requests.session()
#                             scraper = cloudscraper.create_scraper(sess=req)
#                             res = scraper.get(
#                                 'https://www.coldwellbanker.com/', headers=self.headers, proxies=proxies)
#                             if res.status_code == 200:
#                                 response = scraper.get(
#                                     url, headers=self.headers, proxies=proxies)
#                             else:
#                                 if res.status_code == 404:
#                                     urls = {'url': url}
#                                     self.db['coldwellbanker_404'].insert(
#                                         dict(urls))
#                                 else:
#                                     self.errback_httpbin(url)

#                         except:
#                             pass
#                     if response:
#                         item = self.parse_profile(response)
#                         if item:

#                             yield item
#                         else:
#                             self.errback_httpbin(url)
#                     else:
#                         self.errback_httpbin(url)


#     def parse_profile(self, response):
#         # inspect_response(response, self)
#         sel = Selector(text=response.content)
#         is_agent = sel.xpath('//body[@id="agent-homepage"]')

#         if is_agent:
#             office_name = ''
#             facebook_url = ''
#             youtube_url = ''
#             twitter_url = ''
#             linkedin_url = ''
#             other_urls = []
#             social = {}
#             first_name = ''
#             middle_name = ''
#             last_name = ''
#             city_state_zip = ''
#             city = ''
#             state = ''
#             zip_ = ''
#             address_office = []
#             address_ = ''
#             ofs_ar = ''

#             NAME_XPATH = '//div[@class="agent-heading"]/h1/text()'
#             IMAGE_XPATH = '//div[contains(@class,"agent-photo")]/img/@src'
#             BIOGRAPHY_XPATH = '//div[@id="jsAgentProfile"]//span//text()'
#             LANGUAGES_XPATH = '//h2[contains(text(),"I Speak")]/following-sibling::ul/li/text()'
#             NUMBERS_XPATH = '//div[contains(@class,"agent-phone")]/a/@href'
#             SOCIAL_XPATH = '//div[@class="agent-social"]/ul/li/a/@href'
#             COMPANY_XPATH = '//div[@class="media__content"]/span[@class="mls-company-name"]/text()'
#             ADDRESS_XPATH = '//div[@class="media__content"]/text()'
#             OFFICE_XPATH = '//span[@class="mls-company-name"]/text()'
#             PHONE_XPATH = '//div[@class="media__content"]/div[@class="smallVPad"]/strong/text()'

#             name = sel.xpath(NAME_XPATH).extract()
#             image = sel.xpath(IMAGE_XPATH).extract()
#             title = ''
#             website = ''
#             biography = sel.xpath(BIOGRAPHY_XPATH).extract()
#             language_spoken = sel.xpath(LANGUAGES_XPATH).extract()
#             numbers = sel.xpath(NUMBERS_XPATH).extract()
#             social_urls = sel.xpath(SOCIAL_XPATH).extract()
#             company_name = sel.xpath(COMPANY_XPATH).extract()
#             address = sel.xpath(ADDRESS_XPATH).extract()
#             phones = sel.xpath(PHONE_XPATH).extract()

#             name = name[0].strip() if name else ''
#             name_list = name.split(' ')
#             if len(name_list) > 3:
#                 first_name = name.strip()
#                 middle_name = ''
#                 last_name = ''
#             elif len(name_list) == 3:
#                 first_name = name_list[0].strip()
#                 middle_name = name_list[1].strip()
#                 last_name = name_list[2].strip()
#             elif len(name_list) == 2:
#                 first_name = name_list[0].strip()
#                 middle_name = ''
#                 last_name = name_list[1].strip()
#             elif len(name_list) == 1:
#                 first_name = name_list[0].strip()
#                 middle_name = ''
#                 last_name = ''
#             else:
#                 first_name = ''
#                 middle_name = ''
#                 last_name = ''

#             image = image[0].strip() if image else ''
#             image = '' if 'no-agent' in image else image

#             biography = [x.strip() for x in biography] if biography else []
#             biography = [x.strip()
#                          for x in biography if x] if biography else []
#             biography = ' '.join(biography).strip() if biography else ''

#             language_spoken = list(
#                 set([x.strip() for x in language_spoken])) if language_spoken else []

#             numbers = list(set([x.strip().replace('tel:', '').replace(
#                 '.', '').strip() for x in numbers])) if numbers else []
#             phone_numbers = []
#             agent_phone = []
#             office_phone_ = []
#             office_phone = []
#             if len(numbers) == 1:
#                 agent_phone = numbers
#             else:
#                 for number in numbers:
#                     phone_data = number
#                     agent_phone.append(phone_data)
#                     phone_numbers.append(phone_data)
#             for phone in phones:
#                 phone_data = phone
#                 office_phone_.append(phone_data.strip())
#                 office_phone.append(phone_data.strip())
#                 phone_numbers.append(phone_data.strip())

#             office_phone = office_phone if office_phone else office_phone_
#             company_name = company_name[0].strip() if company_name else ''

#             address = [x.strip() for x in address if x] if address else []
#             address_office = [x.strip()
#                               for x in address_office] if address_office else []
#             address_office = [x.strip()
#                               for x in address_office if x] if address_office else []
#             address_office = ' '.join(
#                 address_office).strip() if address_office else ''
#             if len(address) >= 9:
#                 address_ = address[4].strip()
#                 city_state_zip = address[5].strip()
#                 if ',' in city_state_zip:
#                     city_state_zip_list = city_state_zip.split(',')
#                     if len(city_state_zip_list) == 2:
#                         city = city_state_zip_list[0].strip()
#                         zip_ = re.findall(r'\d+', city_state_zip_list[1])
#                         zip_ = zip_[0].strip() if zip_ else ''
#                         state = city_state_zip_list[1].strip(
#                             zip_).strip() if zip_ else city_state_zip_list[1].strip()

#             if social_urls:
#                 for url_ in social_urls:
#                     url_ = url_.strip()
#                     if 'facebook.com' in url_.lower():
#                         facebook_url = url_
#                     elif 'youtube.com' in url_.lower():
#                         youtube_url = url_
#                     elif 'twitter.com' in url_.lower():
#                         twitter_url = url_
#                     elif 'linkedin.com' in url_.lower():
#                         linkedin_url = url_
#                     else:
#                         other_urls.append(url_)
#                 social = {
#                     'facebook_url': facebook_url,
#                     'twitter_url': twitter_url,
#                     'linkedin_url': linkedin_url,
#                     'other_urls': other_urls,
#                 }
#             else:
#                 social = {}

#             items = ColdwellbankerCloudItem(
#                 country='United States',
#                 first_name=first_name,
#                 middle_name=middle_name,
#                 last_name=last_name,
#                 image_url=image,
#                 title=title,
#                 office_name=company_name,
#                 description=biography,
#                 languages=language_spoken,
#                 address=address_,
#                 city=city,
#                 zipcode=zip_,
#                 state=state,
#                 agent_phone_numbers=agent_phone,
#                 office_phone_numbers=office_phone,
#                 social=social,
#                 website=website,
#                 email='',
#                 profile_url=response.url,
#             )
#             if first_name:
#                 return items

#         return

#     def errback_httpbin(self, url):
#         credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
#         connection = pika.BlockingConnection(pika.ConnectionParameters(
#             credentials=credentials, host=QUEUE_IP, socket_timeout=600))
#         channel = connection.channel()
#         channel.queue_declare(queue=QUEUE_NAME, durable=True)
#         channel.basic_publish(exchange='', routing_key=QUEUE_NAME, body=url)
#         connection.close()

#     @classmethod
#     def from_crawler(cls, crawler, *args, **kwargs):
#         spider = super(coldwellbankerSpider, cls).from_crawler(
#             crawler, *args, **kwargs)
#         crawler.signals.connect(spider.spider_opened, signals.spider_opened)
#         crawler.signals.connect(spider.spider_closed, signals.spider_closed)
#         return spider

#     def spider_opened(self, spider):

#         print('Opening {} spider'.format(spider.name))

#     def spider_closed(self, spider):
#         self.spider_ended()
#         print('Closing {} spider'.format(spider.name))
