import scrapy
import re
import requests
import json
import urllib
import logging

from scrapy.spiders import Spider
# from urlparse import urlparse, urljoin
from scrapy.selector import Selector
from scrapy.shell import inspect_response
from scrapy.http import Request
from datetime import datetime
from scrapy.http import Request, FormRequest
from scrapy.utils.log import configure_logging
from pymongo import MongoClient
from scrapy import signals
import subprocess
# from databasenotifier import automation_script
from coldwellbanker.items import *
from coldwellbanker.settings import *
from coldwellbanker.storm_proxy import parse_proxy

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
    'accept-encoding': 'gzip, deflate',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36'}

client = MongoClient('mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
try:
    client.admin.command("enablesharding", MONGODB_DB)
except:
    pass
try:
    client.admin.command(
        "shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION_URL, key={'url': 1})
except:
    pass
try:
    client.admin.command(
        "shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION_FAIL, key={'url': 1})
except:
    pass
db = client[MONGODB_DB]


class coldwellbankerSpider(scrapy.Spider):
    name = 'coldwellbanker_crawler'
    allowed_domains = ["coldwellbanker.com"]
    # Browse all
    handle_httpstatus_list = [503, 403, 307, 405]

    start_urls = ['https://www.coldwellbanker.com/sitemap_brokers_index.xml']
#     start_urls = ["https://www.coldwellbanker.com/coldwell-banker-professional-associates-1227c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-james-c.-otton-real-estate,-inc.-1148c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-country-realty-4532c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-barnes-50271c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-tomlinson-associates-46919c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-tomlinson-46917c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-walla-walla-7113c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-realty-_-new-jersey-12677c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-real-estate-services_-pittsburgh-12661c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-quality-realtors-7981c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-mulleady-inc.,-realtors-8947c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-regional-realty-11917c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-realty-12673c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-united-brokers-11105c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-brenizer,-realtors-7599c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-k_c-realty-12323c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-towne-%26-country-realty-8069c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-prime-11033c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-schmitt-real-estate-co.-11513c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-heart-of-oklahoma-real-estate-4819c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-charles-hayes-real-estate,-inc.-4811c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-cornerstone-4290c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-hobin-realty,-llc-4235c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-heritage-real-estate-3408c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-mendo-realty-5459c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-hearthside-612c/sitemap.xml",
#                     "https://www.coldwellbanker.com/coldwell-banker-360-team-42c/sitemap.xml",
# ]
    # start_urls = []

    BASE_URL = 'https://www.coldwellbanker.com'

    # def spider_ended(self):
    #     automation_script.Automation_Spider(MONGODB_DB, MONGODB_COLLECTION)
    # subprocess.call("python q_insert.py ", shell=True)

    def parse(self, response):
        if response.status == 200:
            sel = Selector(text=response.body)
            URLS = sel.xpath('//loc/text()').extract()
            for url in URLS:
                url = url.strip()
                if url.endswith('.xml'):
                    yield Request(url=url, callback=self.parse)
                else:
                    if '/Coldwell-Banker' in url:
                        if '/buying-a-house' in url:
                            url = url.replace('/buying-a-house', '')
                        if '/selling-a-house' in url:
                            url = url.replace('/selling-a-house', '')
                        urls = {'url': url}
                        print(urls)
                        db[MONGODB_COLLECTION_URL].insert(dict(urls))
        else:
            urls = response.url
            data = {'url':urls}
            db[MONGODB_COLLECTION_FAIL].insert(dict(data))
        client.close()
    @classmethod
    def from_crawler(cls, crawler, *args, **kwargs):
        spider = super(coldwellbankerSpider, cls).from_crawler(
            crawler, *args, **kwargs)
        crawler.signals.connect(spider.spider_opened, signals.spider_opened)
        crawler.signals.connect(spider.spider_closed, signals.spider_closed)
        return spider

    def spider_opened(self, spider):
        print('Opening {} spider'.format(spider.name))

    def spider_closed(self, spider):
        print('%%%%%%%%%%%%%%%%%%%%%%%%%%')
        self.spider_ended()
        print('Closing {} spider'.format(spider.name))
