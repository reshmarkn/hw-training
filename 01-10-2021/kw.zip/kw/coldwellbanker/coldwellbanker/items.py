# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class ColdwellbankerUrlItem(scrapy.Item):
    profile_url = scrapy.Field()


class ColdwellbankerItem(scrapy.Item):
    first_name = scrapy.Field()
    middle_name = scrapy.Field()
    last_name = scrapy.Field()
    image_url = scrapy.Field()
    title = scrapy.Field()
    office_name = scrapy.Field()
    description = scrapy.Field()
    languages = scrapy.Field()
    address = scrapy.Field()
    country = scrapy.Field()
    city = scrapy.Field()
    zipcode = scrapy.Field()
    state = scrapy.Field()
    agent_phone_numbers = scrapy.Field()
    office_phone_numbers = scrapy.Field()
    phone_numbers = scrapy.Field()
    social = scrapy.Field()
    website = scrapy.Field()
    email = scrapy.Field()
    profile_url = scrapy.Field()

class ColdwellbankerCloudItem(scrapy.Item):
    first_name = scrapy.Field()
    middle_name = scrapy.Field()
    last_name = scrapy.Field()
    image_url = scrapy.Field()
    title = scrapy.Field()
    office_name = scrapy.Field()
    description = scrapy.Field()
    languages = scrapy.Field()
    address = scrapy.Field()
    country = scrapy.Field()
    city = scrapy.Field()
    zipcode = scrapy.Field()
    state = scrapy.Field()
    agent_phone_numbers = scrapy.Field()
    office_phone_numbers = scrapy.Field()
    phone_numbers = scrapy.Field()
    social = scrapy.Field()
    website = scrapy.Field()
    email = scrapy.Field()
    profile_url = scrapy.Field()
