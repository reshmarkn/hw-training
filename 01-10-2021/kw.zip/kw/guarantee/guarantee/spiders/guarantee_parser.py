import scrapy
import re
import pika
import json
import logging
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from guarantee.items import *
from guarantee.settings import *
from guarantee.proxy import parse_proxy

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

h = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "Accept-Encoding": "gzip, deflate, br",
    "Accept-Language": "en-US,en;q=0.9",
    "Upgrade-Insecure-Requests": "1",
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36"
}


class GuaranteeSpider(Spider):
    name = 'guarantee_parser'
    allowed_domains = ['www.guarantee.com']

    def start_requests(self):
        for var in range(1, 40):
            url = 'https://www.guarantee.com/roster/agents/'+str(var)
            yield Request(url=url, callback=self.parse, dont_filter=True)

    def parse(self, response):

        agents_sel = response.xpath('//article')

        for a in agents_sel:
            city = ''
            state = ''
            country = ''
            zipcode = ''
            image = ''
            email = ''
            languages = []
            website = ''
            description = ''
            office_phone_numbers = []
            agent_phone_numbers = []
            other_urls = []
            social = {}

            first_name = ''
            middle_name = ''
            last_name = ''

            facebook_url = ''
            twitter_url = ''
            linkedin_url = ''
            name = ''.join(a.xpath('h1/text()').extract()).strip()
            name = name.strip() if name else ""
            if '&' in name:
                first_name = name.strip()
            else:
                agent_name = name.split()
                if len(agent_name) == 1:
                    first_name = agent_name[0]
                    middle_name = ''
                    last_name = ''
                if len(agent_name) == 2:
                    first_name = agent_name[0]
                    middle_name = ''
                    last_name = agent_name[1]
                if len(agent_name) == 3:
                    first_name = agent_name[0]
                    middle_name = agent_name[1]
                    last_name = agent_name[2]
                if len(agent_name) >= 4:
                    first_name = name.strip()
                    middle_name = ''
                    last_name = ''
            title = ''.join(
                a.xpath('h1/span[@class="account-title"]/text()').extract()).strip()
            title = title.strip() if title else ""
            image = ''.join(a.xpath('img/@src').extract()).strip()
            image = image.strip() if image else ""
            telephone = a.xpath('ul/li//text()').extract()
            tele = [t.strip() for t in telephone if t.strip() != '']
            office_phone_numbers = [tele[0].strip()]
            office_phone_numbers = office_phone_numbers if office_phone_numbers else ""
            agent_phone_numbers = [tele[1].strip()]
            agent_phone_numbers = agent_phone_numbers if agent_phone_numbers else ""
            website = ''.join(
                a.xpath('ul/li/a[contains(text(), " Website ")]/@href').extract()).strip()
            website = website.strip() if website else ""
            office_name = ''.join(a.xpath('p/strong/text()').extract())
            office_name = office_name.strip() if office_name else ""
            agent_address = a.xpath('p//text()').extract()
            add = [t.strip() for t in agent_address if t.strip() != '']
            address_ = add[-4].strip()
            address_ = address_.strip() if address_ else ""
            city = add[-3].strip()
            city = city.strip() if city else ""
            state = add[-2].strip().replace('|', '').strip().split(' ')[0]
            state = state.strip() if state else ""
            zipcode = add[-2].strip().replace('|', '').strip().split(' ')[1]
            zipcode = zipcode.strip() if zipcode else ""
            language = [''.join(a.xpath(
                'p[contains(text(), "Speaks:")]/text()').extract()).strip().replace('Speaks:', '').strip()]
            languages = language if language else ""
            full_name = name.replace(' ', '').replace(
                '.', '').replace('-', '').lower()
            profile_url = "https://www.guarantee.com/bio/" + full_name
            social_links = a.xpath(
                'ul/li[@class="rng-agent-profile-contact-social"]/a/@href').extract()

            other_urls = []
            social = {}

            if social_links:
                for url_ in social_links:
                    url_ = url_.strip()
                    if 'http' in url_:
                        if 'facebook.com' in url_.lower():
                            facebook_url = url_
                        elif 'twitter.com' in url_.lower():
                            twitter_url = url_
                        elif 'linkedin.com' in url_.lower():
                            linkedin_url = url_
                        else:
                            other_urls.append(url_)

                social = {
                    'facebook_url': facebook_url,
                    'twitter_url': twitter_url,
                    'linkedin_url': linkedin_url,
                    'other_urls': other_urls if other_urls else [],
                }
            else:
                social = {}
            descp_link = ''.join(
                a.xpath('a[@class="button hollow"]/@href').extract()).strip()
            meta = {'first_name': first_name, 'middle_name': middle_name,
                    'last_name': last_name, 'office_name': office_name, 'title': title, 'languages': languages, 'image_url': image, 'address_': address_, 'city': city, 'state': state, 'zipcode': zipcode, 'email': email, 'website': website, 'office_phone_numbers': office_phone_numbers, 'agent_phone_numbers': agent_phone_numbers, 'social': social, 'profile_url': profile_url}

            if descp_link:
                d_link = 'https://www.guarantee.com' + descp_link
                yield Request(url=d_link, callback=self.parse_data, meta=meta)
            else:
                # if first_name and 'Sales Manager' not in title:
                if first_name:
                    item = GuaranteeItem(
                        first_name=first_name,
                        middle_name=middle_name,
                        last_name=last_name,
                        office_name=office_name,
                        title=title,
                        description='',
                        languages=languages,
                        image_url=image,
                        address=address_,
                        city=city,
                        state=state,
                        country='United States',
                        zipcode=zipcode,
                        email=email,
                        website=website,
                        office_phone_numbers=office_phone_numbers,
                        agent_phone_numbers=agent_phone_numbers,
                        social=social,
                        profile_url=profile_url,
                    )
                    yield item

    def parse_data(self, response):
        data = response.meta
        first_name = data.get('first_name')
        title = data.get('title')

        description = ''.join(response.xpath(
            '//div[@class="col-xs-12 col-sm-8"]/p/text()').extract())
        # if first_name and 'Sales Manager' not in title:
        if first_name:
            item = GuaranteeItem(
                first_name=first_name,
                middle_name=data.get('middle_name'),
                last_name=data.get('last_name'),
                office_name=data.get('office_name'),
                title=data.get('title'),
                description=description,
                languages=data.get('languages'),
                image_url=data.get('image_url'),
                address=data.get('address_'),
                city=data.get('city'),
                state=data.get('state'),
                country='United States',
                zipcode=data.get('zipcode'),
                email=data.get('email'),
                website=data.get('website'),
                office_phone_numbers=data.get('office_phone_numbers'),
                agent_phone_numbers=data.get('agent_phone_numbers'),
                social=data.get('social'),
                profile_url=data.get('profile_url'),
            )
            yield item
