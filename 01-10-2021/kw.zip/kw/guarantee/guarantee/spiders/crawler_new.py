# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from guarantee.items import *
from guarantee.settings import *
from guarantee.proxy import parse_proxy


class GuaranteeUrlSpider(Spider):
    name = 'guarantee_crawler1'
    # start_urls = ['http://www.guarantee.com/agent-list/?fullName=']
    start_urls = ['http://www.guarantee.com/offices/']
    allowed_domains = []

    def parse(self, response):
        agents_list = response.xpath(
            '//a[@class="btn btn-primary"]/@href').extract()
        for agent in agents_list:
            yield Request(url=agent, callback=self.parse_agents)

    def parse_agents(self, response):
        agents = response.xpath(
            '//span[@class="ihf_officeroster_agentname"]/a/@href').extract()
        for url in agents:
            if 'guarantee.com' not in url:
                # print(url, 'kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk')
                f = open('urls_domain_dec.txt', 'a')
                f.write(url + '\n')
                f.close()

            elif 'https' in url:
                url = url.replace('https', 'http')
                if 'www' not in url:
                    url = url.split('http://')
                    url = ''.join(url)
                    url = 'http://www.' + url
                    # print(url, '*************')
                    f = open('urls_dec.txt', 'a')
                    f.write(url + '\n')
                    f.close()

            elif 'http' not in url:
                url = 'http://' + url
                if 'www' not in url:
                    url = url.split('http://')
                    url = ''.join(url)
                    url = 'http://www.' + url
                    # print(url, '|||||||||||||||||||||||||||')
                    f = open('urls_dec.txt', 'a')
                    f.write(url + '\n')
                    f.close()
            else:
                # print('------------------------')
                f = open('urls_dec.txt', 'a')
                f.write(url + '\n')
                f.close()
