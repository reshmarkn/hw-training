# # -*- coding: utf-8 -*-
# import scrapy
# import re
# import pika
# import json
# import logging
# # from dateutil import parser
# from scrapy.spiders import Spider
# from scrapy.selector import Selector
# from scrapy.http import Request, FormRequest
# from guarantee.items import *
# from guarantee.settings import *
# from guarantee.proxy import parse_proxy

# handler = logging.FileHandler('spider_error.log')
# handler.setLevel('ERROR')
# logging.root.addHandler(handler)
# logger = logging.getLogger('pika')
# logger.propagate = False


# class GuaranteeSpider(Spider):
#     name = 'guarantee1'
#     # start_urls = ['http://www.guarantee.com/agent-list/?fullName=']
#     start_urls = ['http://www.guarantee.com/offices/']
#     allowed_domains = ['www.guarantee.com']

#     """
#     # Queue implementation
#     def start_requests(self):
#         # Fetching URL from queue until queue is empty
#         credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
#         connection = pika.BlockingConnection(pika.ConnectionParameters(
#             credentials=credentials, host=QUEUE_IP, socket_timeout=300))
#         channel = connection.channel()
#         while True:
#             channel.basic_qos(prefetch_count=1)
#             method, properties, url = channel.basic_get(queue=QUEUE_NAME)
#             if not url.strip():
#                 break
#             channel.basic_ack(delivery_tag=method.delivery_tag)
#             url = str(url.strip(), encoding='utf-8')
#             if url.strip():
#                 yield Request(url=url.strip(), callback=self.parse,
#                 headers=self.headers, errback=lambda x:
#                 self.errback_httpbin(x, url.strip()))
#         connection.close()
#     """

#     def parse(self, response):
#         agents_list = response.xpath(
#             '//a[@class="btn btn-primary"]/@href').extract()
#         # agents_list = [
#         #     'http://www.guarantee.com/offices/Shaver-Lake-Real-Estate/1155/']
#         for agent in agents_list:
#             # print('1111111111111111111111111111')
#             yield Request(url=agent, callback=self.parse_agents)

#     def parse_agents(self, response):
#         # print('22222222222222222222222222222')
#         office_name = response.xpath('//title/text()').extract()
#         office_name = ''.join(office_name).strip()
#         office_name = office_name.split('|')[1].strip()
#         meta = {'office_name': office_name}

#         agents = response.xpath(
#             '//span[@class="ihf_officeroster_agentname"]/a/@href').extract()
#         for url in agents:
#             # print('4444444444444444444444444444444444444')
#             # f = open('urls_dec.txt')
#             # URLS = f.readlines()
#             # for url in URLS:
#             yield Request(url=url, callback=self.parse_data, meta=meta)

#     def parse_data(self, response):
#         office_name = response.meta['office_name']

#         first_name = ''
#         middle_name = ''
#         last_name = ''
#         city = ''
#         state = ''
#         country = ''
#         zipcode = ''
#         image_url = ''
#         eemail = ''
#         languages = []
#         website = ''
#         description = ''
#         office_phone_numbers = []
#         agent_phone_numbers = []
#         social = {}

#         name = response.xpath(
#             '//title/text()').extract_first('').split('|')[1].strip()
#         names = response.xpath('//h1/text()').extract()
#         title = response.xpath('//h1/text()').extract_first('')
#         img = response.xpath(
#             '//div[@class="ihf-agent-photo"]/img/@src').extract()
#         image = ''.join(img)
#         if 'blank.jpg' not in image:
#             image_url = image
#         agent_phone_numbers = response.xpath(
#             '//span[@class="ihf_officeroster_agent_officephone"]'
#             '/strong/b/text()').extract()
#         email = response.xpath(
#             '//span[@class="ihf_officeroster_agent_email"]//text()').extract()
#         website = response.xpath(
#             '//span[@class="ihf_officeroster_agent_url"]/a/@href').extract()
#         address = response.xpath(
#             '//span[@class="ihf_officeroster_agent_officeaddress"]'
#             '//text()').extract()
#         description_ = response.xpath(
#             '//div[@id="ihf-main-container"]//p//text() | //div[@id="ihf-main-container"]//p[contains(text(), "Member of:")]/following-sibling::text()').extract()

#         try:
#             title = title.split(',')[1].replace(name, '').strip()
#         except:
#             title = ''
#         title = re.sub('®.*,', '', title)

#         first_name = ''
#         middle_name = ''
#         last_name = ''
#         if '&' in names:
#             agent_name = names[0].split(',')
#             first_name = agent_name[0]
#         else:
#             if names:
#                 agent_name = names[0].split(',')
#                 agent_name = agent_name[0].split(' ')
#                 if len(agent_name) == 1:
#                     first_name = agent_name[0].replace(',', '')
#                     middle_name = ''
#                     last_name = ''
#                 if len(agent_name) == 2:
#                     first_name = agent_name[0].replace(',', '')
#                     middle_name = ''
#                     last_name = agent_name[1].replace(',', '')
#                 if len(agent_name) == 3:
#                     first_name = agent_name[0].replace(',', '')
#                     middle_name = agent_name[1].replace(',', '')
#                     last_name = agent_name[2].replace(',', '')
#                 if len(agent_name) >= 4:
#                     first_name = agent_name[0]
#                     middle_name = ''
#                     last_name = ''
#             else:
#                 agent_name = name.split()
#                 agent_name.remove(agent_name[-1])
#                 if '&' in agent_name:
#                     agent_name = agent_name.split(',')
#                     first_name = agent_name
#                     # first_name = name
#                 else:
#                     if len(agent_name) == 1:
#                         first_name = agent_name[0].replace(',', '')
#                         middle_name = ''
#                         last_name = ''
#                     if len(agent_name) == 2:
#                         first_name = agent_name[0].replace(',', '')
#                         middle_name = ''
#                         last_name = agent_name[1].replace(',', '')
#                     if len(agent_name) == 3:
#                         first_name = agent_name[0].replace(',', '')
#                         middle_name = agent_name[1].replace(',', '')
#                         last_name = agent_name[2].replace(',', '')
#                     if len(agent_name) >= 4:
#                         first_name = agent_name[0]
#                         middle_name = ''
#                         last_name = ''

#         email = ''.join(email).strip()
#         website = ''.join(website).strip()
#         address_ = address[0]
#         address_ = ''.join(address_).strip()
#         address2 = address[1]
#         zipcode_ = address2.rsplit(',', 1)[-1]
#         zipcode = zipcode_.strip()
#         cit_stat = address2.rsplit(',', 1)[0]
#         cit_stat = cit_stat.strip()
#         cit_stat = cit_stat.split(' ')
#         if len(cit_stat) == 2:
#             city = cit_stat[0]
#             state = cit_stat[1]
#         if len(cit_stat) == 3:
#             city1 = cit_stat[0]
#             city2 = cit_stat[1]
#             city = city1 + ' ' + city2
#             state = cit_stat[2]

#         description = ' '.join(''.join(description_).split())

#         # yield item
#         if first_name and 'SALES MANAGER' not in title:
#             item = GuaranteeItem(
#                 first_name=first_name,
#                 middle_name=middle_name,
#                 last_name=last_name,
#                 office_name=office_name,
#                 title=title,
#                 description=description,
#                 languages=languages,
#                 image_url=image_url,
#                 address=address_,
#                 city=city,
#                 state=state,
#                 country='United States',
#                 zipcode=zipcode,
#                 email=email,
#                 website=website,
#                 office_phone_numbers=office_phone_numbers,
#                 agent_phone_numbers=agent_phone_numbers,
#                 social=social,
#                 profile_url=response.url,
#             )
#             yield item

#     """
#     # Errorback to put failed urls back in queue
#     def errback_httpbin(self, failure, url):
#         credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
#         connection = pika.BlockingConnection(pika.ConnectionParameters(
#             credentials=credentials, host=QUEUE_IP, socket_timeout=600))
#         channel = connection.channel()
#         channel.queue_declare(queue=QUEUE_NAME, durable=True)
#         channel.basic_publish(
#             exchange='', routing_key=QUEUE_NAME, body=url)
#         connection.close()
#     """
