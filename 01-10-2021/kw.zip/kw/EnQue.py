import pika
import json
from time import sleep
import datetime
from pymongo import MongoClient






Hosts = ['134.209.174.206', '159.89.47.171', '138.197.109.170','104.248.5.100']

for i in Hosts:
    print(Hosts.index(i), "  ", i)


QUEUE_HOST = Hosts[int(input("Choose Host:"))]
# QUEUE_HOST = '159.89.47.171'  # load balancer

QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'
QUEUE_NAME = input("QUEUE NAME:")

credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
connection = pika.BlockingConnection(pika.ConnectionParameters(
    credentials=credentials, host=QUEUE_HOST, socket_timeout=3000))
channel = connection.channel()

f = open(input("INPUT FILE NAME:"))


URLS = f.readlines()
f.close()


channel.queue_declare(queue=QUEUE_NAME, durable=True)
count = len(URLS)


# print("QUEUE_IP="+QUEUE_HOST+"\n"+"QUEUE_NAME= "+QUEUE_NAME)
# print(QUEUE_HOST+":15672/")
# print("QUEUE Username:"+QUEUE_USER)
# print("QUEUE Password:"+QUEUE_PASS)
# print("Element Count="+str(len(URLS)))
message = "QUEUE_IP="+QUEUE_HOST+"\n"+"QUEUE_NAME= "+QUEUE_NAME+"\n"+QUEUE_HOST+":15672/"+"\nQUEUE Username:" + \
    QUEUE_USER+"\nQUEUE Password:"+QUEUE_PASS+"\nElement Count="+str(count)
print(message)

for x in URLS:
    channel.basic_publish(exchange='', routing_key=QUEUE_NAME, body=x.strip())
    sleep(0.0001)
connection.close()
