import subprocess
from scrapy import cmdline
from bhgre.settings import *
print('spider restarted ++++++++++++++++++')
cmdline.execute("scrapy crawl bhgre".split())