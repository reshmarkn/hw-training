import random
import base64
# from scrapy.conf import settings
# from scrapy import log
import requests
import random
import logging
from requests.auth import HTTPProxyAuth
logger = logging.getLogger(__name__)


def parse_proxy():
    PROXY_LIST = requests.get('http://68.183.58.145/stormproxies?type=3',
                          headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
    # PROXY_LIST = [
    #     '157.230.189.5:5566',
    #     '157.230.190.226:5566'
    # ]
    PROXY = random.choice(PROXY_LIST)
    proxy_url = "http://%s" % PROXY
    proxies = {"http": "http://%s" % PROXY,
               "https": "http://%s" % PROXY}
    logger.debug("Proxy added")
    return {'proxies': proxies, 'proxy_url': proxy_url}
    # # proxy = random.choice(PROXY_LIST)

    # # proxies = {"http": "http://68.183.58.145:5566",
    # #            "https": "http://157.230.189.5:5566"}

    # proxies = {"http": "http://5.79.66.2:13200",
    #            "https": "https://5.79.66.2:13200", }

    # # proxies = {}
    # # log.msg("Proxy added")
    # print('proxy added')
    # return {'proxies': proxies}
