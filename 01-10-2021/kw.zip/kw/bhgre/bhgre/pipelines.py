
import pymongo
from pymongo import MongoClient
from scrapy.exceptions import DropItem
from bhgre.items import *
from pymongo import MongoClient
from slacker import Slacker
from bhgre.settings import *
# from databasenotifier import automation_script


class BhgrePipeline(object):
    def __init__(self, settings):
        # self.mongo_uri = settings.get('MONGO_URI')
        self.mongo_db = settings.get('MONGODB_DB')
        self.mongo_collection = settings.get('MONGO_COLLECTION')
        self.mongo_collection_url = settings.get('MONGO_COLLECTION_URL')
        self.dup_key = settings.get('DUP_KEY')

    @classmethod
    def from_crawler(cls, crawler):
        return cls(
            settings=crawler.settings
        )

    def open_spider(self, spider):
        self.client = MongoClient(
            'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
        try:
            self.client.admin.command("enablesharding", self.mongo_db)
        except:
            pass
        try:
            self.client.admin.command(
                "shardcollection", self.mongo_db + '.' + self.mongo_collection_url, key={'_id': 1})
        except:
            pass
        try:
            self.client.admin.command(
                "shardcollection", self.mongo_db + '.' + self.mongo_collection, key={'profile_url': 1}, unique=True)
        except:
            pass

        self.db = self.client[self.mongo_db]

    # def open_spider(self, spider):
    #     self.client = pymongo.MongoClient(self.mongo_uri)
    #     self.db = self.client[self.mongo_db]
    #     if self.dup_key:
    #         self.db[self.mongo_collection].create_index(
    #             self.dup_key, unique=True)

    def process_item(self, item, spider):
        if isinstance(item, BhgreItem):
            try:
                self.db[self.mongo_collection].insert(dict(item))
            except:
                raise DropItem("Dropping duplicate item")
        if isinstance(item, bhgreUrlItem):
            try:
                self.db[self.mongo_collection_url].insert(dict(item))
            except:
                raise DropItem("Dropping duplicate item")
        return item

    def close_spider(self, spider):
        automation_script.Automation_Spider(
            self.mongo_db, self.mongo_collection)
        self.client.close()
