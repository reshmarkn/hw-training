import scrapy
import string
import re
from scrapy.http import Request, FormRequest
from bhgre.items import BhgreItem
from xml.dom import minidom
from bhgre.settings import *
from pymongo import MongoClient
from scrapy import signals
import subprocess
# from databasenotifier import automation_script
from bhgre.items import *
# import StringIO
import gzip

headers = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
           'accept-encoding': 'gzip, deflate, br',
           'accept-language': 'en-GB,en-US;q=0.8,en;q=0.6',
           'cache-control': 'no-cache',
           'pragma': 'no-cache',
           'upgrade-insecure-requests': '1',
           'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36'}
# db = MongoClient(
#     'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017').automation_test_kw
# dbname = 'automation_test_kw'
# collection_name = 'bhgre_profile_urls'


class Bhgre(scrapy.Spider):
    name = 'bhgre_crawler'
    allowed_domains = ['bhgre.com']
    start_urls = ['https://www.bhgre.com/sitemap_brokers_index.xml']

    def spider_ended(self):
        automation_script.Automation_Spider(MONGODB_DB, MONGO_COLLECTION_URL)
        # subprocess.call("python q_insert.py ", shell=True)

    def parse(self, response):
        urls = re.findall('https.*?xml', response.body_as_unicode())
        for link in urls:
            if 'https' in link:
                link = link.strip('>')
                yield Request(url=link, callback=self.parse_url, headers=headers)

    def parse_url(self, response):
        xmldoc = minidom.parseString(response.body)
        LOCS = xmldoc.getElementsByTagName('loc')
        LOCS.pop(0)
        for loc in LOCS:
            p_url = loc.childNodes[0].data
            if '-office-' not in p_url:
                if '/buying-a-house' in p_url:
                    p_url = p_url.replace('/buying-a-house', '')
                if '/selling-a-house' in p_url:
                    p_url = p_url.replace('/selling-a-house', '')
                # meta = {'url': p_url}
                # db.bhgre_profile_urls.insert(dict(meta))
                item = bhgreUrlItem()
                item['url'] = p_url
                yield item

    @classmethod
    def from_crawler(cls, crawler, *args, **kwargs):
        spider = super(Bhgre, cls).from_crawler(
            crawler, *args, **kwargs)
        crawler.signals.connect(spider.spider_opened, signals.spider_opened)
        crawler.signals.connect(spider.spider_closed, signals.spider_closed)
        return spider

    def spider_opened(self, spider):
        print('Opening {} spider'.format(spider.name))

    def spider_closed(self, spider):
        print('%%%%%%%%%%%%%%%%%%%%%%%%%%')
        self.spider_ended()
        # cmdline.execute("scrapy crawl denver_realestate_parser".split())
        # subprocess.call('')
        print('Closing {} spider'.format(spider.name))
        # f = open('bhgresept1.txt', 'a')
        # f.write(p_url + '\n')
        # f.close()

# remove selling a house and buyinh a house from crawled urls
