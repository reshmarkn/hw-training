import scrapy
import string
import re
from bhgre.settings import *
import json
from pymongo import MongoClient
import requests
import pika
from scrapy import signals
# from databasenotifier import automation_script

# from fake_useragent import UserAgent
from bhgre.proxy import parse_proxy
from scrapy.selector import Selector
from scrapy.shell import inspect_response
from scrapy.http import Request, FormRequest
from bhgre.items import BhgreItem
import logging
# import cloudscraper

# import cloudscraper

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


client = MongoClient('mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
try:
    client.admin.command("enablesharding", MONGODB_DB)
except:
    pass
try:
    client.admin.command(
        "shardcollection", MONGODB_DB + '.' + MONGO_COLLECTION, key={'profile_url': 1}, unique=True)
except:
    pass
db = client[MONGODB_DB]
# print(collection_name,'/////')
# dbname = 'kw_Apr_2020'
# collection_name = 'bhgre1'
# headers = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
#            'accept-encoding': 'gzip, deflate, br',
#            'accept-language': 'en-GB,en-US;q=0.8,en;q=0.6',
#            'upgrade-insecure-requests': '1',
#            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36'}


class Bhgre(scrapy.Spider):
    name = 'bhgre_parser'
    allowed_domains = ['bhgre.com']

    headers = {
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
        "accept-encoding": "gzip, deflate, br",
        "accept-language": "en-GB,en-US;q=0.9,en;q=0.8,ml;q=0.7",
        "cache-control": "max-age=0",
        "upgrade-insecure-requests": "1",
        "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36"
    }
    # headers_1 = {
    #     'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    #     'accept-encoding': 'gzip, deflate, br',
    #     'accept-language': 'en-GB,en-US;q=0.8,en;q=0.6',
    #     'cache-control': 'no-cache',
    #     'pragma': 'no-cache',
    #     'upgrade-insecure-requests': '1',
    #     'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36'
    # }

    def spider_ended(self):
        automation_script.Automation_Spider(MONGO_DB, MONGO_COLLECTION)

    def start_requests(self):
        # ----------------------------------------------------------------
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        while True:
            try:
                channel = connection.channel()
            except:
                connection = pika.BlockingConnection(pika.ConnectionParameters(
                    credentials=credentials, host=QUEUE_IP, socket_timeout=300))
                channel = connection.channel()

            channel.basic_qos(prefetch_count=1)
            method, properties, url = channel.basic_get(queue=QUEUE_NAME)
            if not url:
                break
            url = str(url.strip(), encoding='utf-8')
            channel.basic_ack(delivery_tag=method.delivery_tag)
            if url.strip():
                link = str(url)
                # print(link,'555555555555555555555555')
                res = ''
                proxy = parse_proxy()
                proxies = proxy['proxies']
                try:
                    res = requests.get(
                        url=link, headers=self.headers, proxies=proxies)
                except:
                    try:
                        res = requests.get(
                            url=link, headers=self.headers, proxies=proxies)
                    except:
                        pass
                if res and res.status_code == 200:

                    self.parse_person(res, link)

                    # if item:
                    #     yield item
                else:
                    self.errback_httpbin(link)
                    # item = {'link': link}
                    # print(item,'000000000000000000000')

        connection.close()
        # f = open('missing.txt')
        # for link in f.readlines():
        #     link = link.strip()
        #     res = ''
        #     proxy = parse_proxy()
        #     proxies = proxy['proxies']
        #     try:
        #         res = requests.get(url=link, headers=headers, proxies=proxies)
        #     except:
        #         try:
        #             res = requests.get(
        #                 url=link, headers=headers, proxies=proxies)
        #         except:
        #             pass
        #     if res and res.status_code == 200:
        #         item = self.parse_person(res, link)
        # # yield Request(url='https://api.ipify.org?format=json',
        # # callback=self.parse_person)

    def parse_person(self, res, link):
        # print(res,'111111111111111111111111')
        country = 'United States'
        title = ''
        website = ''
        email = ''

        # inspect_response(response,self)
        sel = Selector(text=res.content)
        NAME_XPATH = '//div[@class="agent-heading"]/h1/text()'
        name = sel.xpath(NAME_XPATH).extract()
        if not name:
            # f = open('no_data.txt','a')
            # f.write(res.request.url + '\n')
            # f.close()
            pass
        else:
            IMAGE_XPATH = '//img[@itemprop="image"]/@src'
            DESCRIPTION_XPATH = '//span[@itemprop="description"]//text()|//div[@id="agent-profile-summary-text"]/span/text()'
            PHONE_NUM_XPATH = '//div[@itemprop="telephone"]/a/text()'
            LANGUAGES_XPATH = '//h2[contains(text(),"I Speak")]/following-sibling::ul/li/text()'
            SOCIAL_XPATH = '//div[@class="agent-social"]//a/@href'

            # profile_url = response.url
            image_url = sel.xpath(IMAGE_XPATH).extract()
            description = sel.xpath(DESCRIPTION_XPATH).extract()
            phone_numbers_ = sel.xpath(PHONE_NUM_XPATH).extract()
            languages = sel.xpath(LANGUAGES_XPATH).extract()
            social_raw = sel.xpath(SOCIAL_XPATH).extract()

            first_name = ''
            middle_name = ''
            last_name = ''
            name = name[0].strip() if name else ''
            if '&' in name:
                first_name = name.strip()
            else:
                agent_name = name.split()
                if len(agent_name) == 1:
                    first_name = agent_name[0]
                    middle_name = ''
                    last_name = ''
                if len(agent_name) == 2:
                    first_name = agent_name[0]
                    middle_name = ''
                    last_name = agent_name[1]
                if len(agent_name) == 3:
                    first_name = agent_name[0]
                    middle_name = agent_name[1]
                    last_name = agent_name[2]
                if len(agent_name) >= 4:
                    first_name = name.strip()
                    middle_name = ''
                    last_name = ''

            image_url = image_url[0].strip() if image_url else ''
            description = ' '.join(
                ' '.join(description).split()) if description else ''
            phone_numbers_ = phone_numbers_[
                0].strip() if phone_numbers_ else ''
            agent_phone_numbers = []
            agent_phone_numbers.append(phone_numbers_)
            # languages = ','.join(languages)

            address = ''
            zipcode = ''
            city = ''
            state = ''
            office_name = ''
            office_phone_numbers = []
            res_body = re.sub(
                b",\n\s*\"description\":\s\"(?:.|\n)*?\"", b"", res.content)
            sel_ = Selector(text=res_body)
            JSON_XPATH = '//script[contains(text(),"ProfilePage")]/text()'
            json_ = sel_.xpath(JSON_XPATH).extract()
            if json_:
                # json_ = ' '.join(' '.join(json_).split()).strip(
                # ).replace(name[0], "") if json_ else ''
                json_ = ' '.join(' '.join(json_).split()).strip(
                ).replace(name, "") if json_ else ''
                try:
                    json_data = json.loads(json_)
                except:
                    with open('json_failed.txt', 'a') as f1:
                        f1.write(res.request.url)
                        return
                    # json_data = json.loads(json_)
                agent_address = json_data.get('about', {}).get(
                    'affiliation', {}).get('address', {})
                address = agent_address.get('streetAddress', '')
                zipcode = agent_address.get('postalCode', '')
                city = agent_address.get('addressLocality', '')
                state = agent_address.get('addressRegion', '')

                office_name = json_data.get('about', {}).get(
                    'affiliation', {}).get('name', '')
                office_phone = json_data.get('about', {}).get(
                    'affiliation', {}).get('telephone', '')
                office_phone_numbers.append(office_phone)

            facebook_url = ''
            twitter_url = ''
            linkedin_url = ''
            other_urls = []
            social = {}

            if social_raw:
                for url_ in social_raw:
                    url_ = url_.strip()
                    if 'http' in url_:
                        if 'facebook.com' in url_.lower():
                            facebook_url = url_
                        elif 'twitter.com' in url_.lower():
                            twitter_url = url_
                        elif 'linkedin.com' in url_.lower():
                            linkedin_url = url_
                        else:
                            other_urls.append(url_)

                social = {
                    'facebook_url': facebook_url,
                    'twitter_url': twitter_url,
                    'linkedin_url': linkedin_url,
                    'other_urls': other_urls if other_urls else [],
                }
            else:
                social = {}

            item = BhgreItem(
                first_name=str(first_name),
                middle_name=str(middle_name),
                last_name=last_name,
                profile_url=str(link),
                address=str(address),
                city=str(city),
                state=str(state),
                social=social,
                title=str(title),
                zipcode=str(zipcode),
                languages=languages,
                office_name=str(office_name),
                image_url=str(image_url),
                description=str(description),
                agent_phone_numbers=agent_phone_numbers,
                office_phone_numbers=office_phone_numbers,
                country=str(country),
                website=str(website),
                email=str(email)
            )
            if first_name:
                # print(item)
                logging.warning(item)
                try:
                    db[MONGO_COLLECTION].insert(dict(item))
                    # return item
                except:
                    pass
            else:
                self.errback_httpbin(link)
                # return dict(item)
                # try:
                # print(item)

                # print(item)
                # except Exception as e:
                # pass
            # else:
            #   print (link,'<<<<<<<<<<<<<<<<<<<<<<')
            #   item = {'link':link}
            #   db.failed_items.insert(dict(item))
    def errback_httpbin(self, url):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=600))
        channel = connection.channel()
        channel.queue_declare(queue=QUEUE_NAME, durable=True)
        channel.basic_publish(exchange='', routing_key=QUEUE_NAME, body=url)
        connection.close()

    @classmethod
    def from_crawler(cls, crawler, *args, **kwargs):
        spider = super(Bhgre, cls).from_crawler(
            crawler, *args, **kwargs)
        crawler.signals.connect(spider.spider_opened, signals.spider_opened)
        crawler.signals.connect(spider.spider_closed, signals.spider_closed)
        return spider

    def spider_opened(self, spider):

        print('Opening {} spider'.format(spider.name))

    def spider_closed(self, spider):
        self.spider_ended()
        print('Closing {} spider'.format(spider.name))
