# -*- coding: utf-8 -*-
import scrapy


class SuttonItem(scrapy.Item):

    first_name = scrapy.Field()
    middle_name = scrapy.Field()
    last_name = scrapy.Field()
    office_name = scrapy.Field()
    title = scrapy.Field()
    description = scrapy.Field()
    languages = scrapy.Field()
    image_url = scrapy.Field()
    address = scrapy.Field()
    city = scrapy.Field()
    state = scrapy.Field()
    country = scrapy.Field()
    zipcode = scrapy.Field()
    office_phone_numbers = scrapy.Field()
    agent_phone_numbers = scrapy.Field()
    email = scrapy.Field()
    website = scrapy.Field()
    social = scrapy.Field()
    profile_url = scrapy.Field()
