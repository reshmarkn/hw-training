# # create a sutton folder in home directory  /home/rijin/Documents/projects/sutton
# # #py3
# # # open scrapy shell

# # a = 'https://www.sutton.com/WebService.svc/Agents?fwdId=59e3f18befda951300fd7faf&model={%22Query%22:%22%22,%22PerPage%22:8000,%22OfficeScope%22:%22%22,%22SortBy%22:%22random%22}'
# # fetch(a)

# # f = open('suttonapi.json','a')
# # f.write(response.body_as_unicode())
# # f.close()

# # import json
# # f = open('suttonapi.json')
# # data = f.read()
# # b = json.loads(data).get('results')
# # f = open('sutton_urlsjan.txt','a')
# # for p in b:
# #     baseurl = 'https://www.sutton.com/Agents/'
# #     rem_url = p.get('officeMetaData',{}).get('address',{}).get('state') + '/' + p.get('officeMetaData',{}).get('address',{}).get('city') + '/' + p.get('fullName').replace(' ','-') + '/' + p.get('id')
# #     url = baseurl + rem_url.lower()
# #     if '*' in url:
# #         url = url.replace('*','')
# #     if ' ' in url:
# #         url = url.replace(' ','%20')
# #     if '-&-' in url:
# #         url = url.replace('-&-','-')
# #     if '--' in url:
# #         url = url.replace('--','-')

# #     try:
# #         f.write(url+'\n')
# #     except:
# #         print (url)
# # f.close()


# # create a sutton folder in home directory  /home/rijin/Documents/projects/sutton
# #py3
# # open scrapy shell
import json
import requests
a = 'https://www.sutton.com/WebService.svc/Agents?fwdId=59e3f18befda951300fd7faf&model={%22Query%22:%22%22,%22PerPage%22:8000,%22OfficeScope%22:%22%22,%22SortBy%22:%22random%22}'
# fetch(a)
response = requests.get(a)  # new line (instead of fetch(a))
f = open('suttonapi.json', 'a')
# f.write(response.body_as_unicode())
f.write(response.text)  # new line ( instead of f.write(response.body_as_unicode()))
f.close()
f = open('suttonapi.json')
data = f.read()
b = json.loads(data).get('results')
f = open('sutton_urlsep.txt', 'a')
for p in b:
    baseurl = 'https://www.sutton.com/Agents/'
    name = p.get('fullName', '').replace(' ', '-')
    address = p.get('officeMetaData', {}).get('address', {}).get('state', '')
    city = p.get('officeMetaData', {}).get('address', {}).get('city', '')
    city = city.replace(' ', '-') if city else ''
    id_ = p.get('id')
    list_ = []
    list_.append(address) if address else ''
    list_.append(city) if city else ''
    list_.append(name) if name else ''
    list_.append(id_) if id_ else ''
    rem_url = '/'.join(list_)
    url = baseurl + rem_url.lower()

    f.write(url + '\n')

#     if name:
#         rem_url = p.get('officeMetaData',{}).get('address',{}).get('state','') + '/' + p.get('officeMetaData',{}).get('address',{}).get('city','') + '/' + str(name) + '/' + p.get('id')
#         if '*' in url:
#             url = url.replace('*','')
#         if ' ' in url:
#             url = url.replace(' ','%20')
#         if '-&-' in url:
#             url = url.replace('-&-','-')
#         if '--' in url:
#             url = url.replace('--','-')
#         try:
#             f.write(url+'\n')
#         except:
#             print (url)
f.close()
