# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
#from dateutil import parser
from w3lib.html import remove_tags
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from sutton.items import *
from sutton.settings import *
from sutton.proxy import parse_proxy

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


class SuttonSpider(Spider):
    name = 'sutton'
    allowed_domains = []

    
    # Queue implementation
    def start_requests(self):
        # Fetching URL from queue until queue is empty
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        channel = connection.channel()
        while True:
            channel.basic_qos(prefetch_count=1)
            method, properties, url = channel.basic_get(queue=QUEUE_NAME)
            if not url.strip():
                break
            channel.basic_ack(delivery_tag=method.delivery_tag)
            url = str(url.strip(), encoding='utf-8')
            if url.strip():
                yield Request(url=url.strip(), callback=self.parse,  errback=lambda x: self.errback_httpbin(x, url.strip()))
        connection.close()
    

    # def start_requests(self):
    #     f = open('sutton_urls.txt')
    #     urls = f.readlines()
    #     for link in urls:
    #         yield Request(url=link.strip(), callback=self.parse)

    def parse(self, response):

        json_data = ''
        data = response.xpath(
            '//*[contains(text(),"Functions.AgentProfile")]/text()').extract_first('')
        data = ''.join(re.findall('Functions.AgentProfile.*?,(.*)\);', data))
        data = data.strip('"HmWerNBrAd6NGtnppyOo"').strip() 
        data = data.strip(',').strip()
        if data:
            try:
                json_data = json.loads(data)
            except:
                f = open('failed.txt', 'a')
                f.write(response.request.url + '\n')
                f.close()
                json_data = {}

        social = {}
        linkedin_url = ''
        facebook_url = ''
        twitter_url = ''
        middle_name = ''
        other_urls = []
        links_ = []
        office_phone = []
        agent_phone = []

        if json_data:
            first_name1 = json_data.get('firstName')
            last_name1 = json_data.get('lastName')
            email = json_data.get('email')
            title = json_data.get('title')
            websites = json_data.get('website')
            office_name = json_data.get('officeMetaData').get('name')
            #address = data.get('officeMetaData').get('address').get('fullAddress')
            address = json_data.get('officeMetaData').get(
                'address').get('address1')
            city = json_data.get('officeMetaData').get('address').get('city')
            state = json_data.get('officeMetaData').get('address').get('state')
            zipcode = json_data.get('officeMetaData').get('address').get('zip')
            country = json_data.get('officeMetaData').get(
                'address').get('country')
            image_url = json_data.get('avatar').get('uri')
            description = json_data.get('profile').get('biography', '')
            languages_ = json_data.get('profile').get('languages')
            languages = [lan['name'] for lan in languages_]
            social_ = json_data.get('profile').get('socialNetworks')
            for soc in social_:
                link = soc.get('link')
                if 'facebook' in link:
                    facebook_url = link
                    social.update({'facebook_url': facebook_url})
                elif 'twitter' in link:
                    twitter_url = link
                    social.update({'twitter_url': twitter_url})
                elif 'linkedin' in link:
                    linkedin_url = link
                    social.update({'linkedin_url': linkedin_url})
                else:
                    other_urls.append(link)
                    social.update({'other_urls': other_urls})

            phone_numbers = json_data.get('profile').get('phoneNumbers')
            for phone in phone_numbers:
                if phone.get('type') == "Work":
                    office_phone = [phone.get('number')]
                elif phone.get('type') == "Mobile":
                    agent_phone = [phone.get('number')]
                # else:
                #     office_phone = []
                #     agent_phone = []

            first_name_ = first_name1.split(' ')
            if len(first_name_) == 2:
                first_name = first_name_[0]
                middle_name = first_name_[1]
            else:
                first_name = first_name1

            last_name_ = last_name1.split('-')
            if len(last_name_) == 2:
                middle_name = last_name_[0]
                last_name = last_name_[1]
            else:
                last_name = last_name1

            if description:
                description = remove_tags(description)
                desc = ' '.join(''.join(description).split())
            else:
                desc = ''
            # description = description.replace('<p>','').replace('<p >','').replace('</p>','').strip() if description else ''
            image_url = image_url if image_url else ''
            websites = websites if websites else ''

            if first_name:
                item = SuttonItem(
                    first_name=first_name,
                    middle_name=middle_name,
                    last_name=last_name,
                    office_name=office_name,
                    title=title,
                    # description = description,
                    description=desc,
                    languages=languages,
                    image_url=image_url,
                    address=address,
                    city=city,
                    state=state,
                    country=country,
                    zipcode=zipcode,
                    office_phone_numbers=office_phone,
                    agent_phone_numbers=agent_phone,
                    email=email,
                    website=websites,
                    social=social,
                    profile_url=response.request.url,
                )
                yield item

    
    # Errorback to put failed urls back in queue
    def errback_httpbin(self, failure, url):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=600))
        channel = connection.channel()
        channel.queue_declare(queue=QUEUE_NAME, durable=True)
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=url)
        connection.close()
    
