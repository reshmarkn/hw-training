# import json
# import requests
# from pymongo import MongoClient
# # from sutton.settings import *


# COLLECTION_NAME = 'sutton_urls'
# MONGO_DB = 'kw_Jun_2020'
# # client = MongoClient('mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')[MONGO_DB]
# # db = client[DB_NAME]
# db = MongoClient(
#     'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017').kw_Jun_2020
# url = 'https://www.sutton.com/WebService.svc/Agents?fwdId=59e3f18befda951300fd7faf&model={%22Query%22:%22%22,%22PerPage%22:8000,%22OfficeScope%22:%22%22,%22SortBy%22:%22random%22}'

# response = requests.get(url)
# response_data = response.text
# json_data = json.loads(response_data)
# results = json_data.get('results')

# # f = open('sutton_urlsapril_v1.txt','a') # for file write code section

# for result in results:
#     baseurl = 'https://www.sutton.com/Agents/'
#     rem_url = result.get('officeMetaData',{}).get('address',{}).get('state') + '/' + result.get('officeMetaData',{}).get('address',{}).get('city') + '/' + result.get('fullName').replace(' ','-') + '/' + result.get('id')
#     url = baseurl + rem_url.lower()
#     if '*' in url:
#         url = url.replace('*','')
#     if ' ' in url:
#         url = url.replace(' ','%20')
#     if '-&-' in url:
#         url = url.replace('-&-','-')
#     if '--' in url:
#         url = url.replace('--','-')

#     items = {'url':url}
#     try:
#     	db[COLLECTION_NAME].insert(dict(items))
#         # f.write(url+'\n') #for file write code section
#     except:
#         print (url)

# # f.close() # For file write code section