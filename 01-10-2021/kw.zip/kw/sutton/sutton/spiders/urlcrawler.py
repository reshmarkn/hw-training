import scrapy
import re
import pika
import json
import logging
#from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from sutton.items import *
from sutton.settings import *
from sutton.proxy import parse_proxy

header = {
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}


class SuttonSpider(Spider):
    name = 'sutton_crawler'
    # start_urls = ['https://www.sutton.com/WebService.svc/Agents?fwdId=59e3f18befda951300fd7faf&model={%22Query%22:%22%22,%22Latitude%22:null,%22Longitude%22:null,%22MaxDistance%22:null,%22PerPage%22:100,%22Page%22:0,%22OfficeScope%22:%22%22,%22SortBy%22:%22random%22}']
    allowed_domains = []

    def start_requests(self):
        for var in range(1, 74):
            link = 'https://www.sutton.com/WebService.svc/Agents?fwdId=59e3f18befda951300fd7faf&model={%22Query%22:%22%22,%22Latitude%22:null,%22Longitude%22:null,%22MaxDistance%22:null,%22PerPage%22:100,%22Page%22:' + str(
                var) + ',%22OfficeScope%22:%22%22,%22SortBy%22:%22random%22}'
            # link = 'https://www.sutton.com/WebService.svc/Agents?fwdId=59e3f18befda951300fd7faf&model={"Query":"","Latitude":null,"Longitude":null,"MaxDistance":null,"PerPage":100,"Page":' + str(var)+'"OfficeScope":"","SortBy":"random"}'
            yield Request(url=link, headers=header, callback=self.parse)

    def parse(self, response):
        json_data = json.loads(response.body_as_unicode())
        if json_data:
            for data in json_data.get('results', ''):
                id_ = data.get('id', '')
                name = data.get('fullName', '')
                city = data.get('officeMetaData', '').get(
                    'address', '').get('city', '')
                state = data.get('officeMetaData', '').get(
                    'address', '').get('state', '')
                newname = name.replace(' ', '-')
                url = 'https://www.sutton.com/Agents/' + \
                    state + '/' + city + '/' + newname + '/' + id_
                profile_url = url.replace(' ', '-')
                # print(profile_url)
                f = open('urls.txt', 'a')
                f.write(profile_url + '\n')
                f.close()
