# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html

from berkshirehathawayhs.settings import *
from berkshirehathawayhs.items import *

class BerkshirehathawayhsPipeline(object):
	def __init__(self, settings):
        self.mongo_db = settings.get('MONGO_DB')
        self.mongo_collection = settings.get('MONGO_COLLECTION')
        self.dup_key = settings.get('DUP_KEY')
        self.mongo_collection_url = settings.get('MONGO_URL_COLLECTION')
	def close_spider(self, spider):
		if self.db[self.mongo_collection].estimated_document_count() < self.db[self.mongo_collection_url].estimated_document_count():
            a = MissingEnqueue(self.mongo_db, self.mongo_collection_url, url_collection_field,
                               self.mongo_db, self.mongo_collection, mongo_collection_field, QUEUE_IP, QUEUE_NAME, slack_id)
            f = open('missing.txt', 'r')
            missing_file_count = f.readlines()
            if int(''.join(missing_file_count)) != int(str(len(a.out))):
                f = open('missing.txt', 'w')
                f.write(str(len(a.out)))
                f.close()
                missing_count = 'missing count' + str(len(a.out))
                logger.info(missing_count)
                subprocess.call("python rerun_script.py ", shell=True)
            else:
                f = open('missing.txt', 'w')
                f.write(str(0))
                f.close()
                logger.info('taking same missing_urls')
                data = {'token': token, 'channel': slack_id,
                        'text': 'taking same missing_urls'}
                requests.post(url='https://slack.com/api/chat.postMessage',
                              data=data)
        else:
            f = open('missing.txt', 'w')
            f.write(str(0))
            f.close()
            logger.info('there is no missing urls')
            data = {'token': token, 'channel': slack_id,
                    'text': 'there is no missing urls'}

            requests.post(
                url='https://slack.com/api/chat.postMessage', data=data)

    def process_item(self, item, spider):
        return item
