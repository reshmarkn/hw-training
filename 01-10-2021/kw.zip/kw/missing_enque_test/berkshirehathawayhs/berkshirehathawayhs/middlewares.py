# -*- coding: utf-8 -*-
import os
import random
# from scrapy.conf import settings
from berkshirehathawayhs.settings import *

# from scrapy import log
import base64
# from berkshirehathawayhs.storm_proxy import parse_proxy
from berkshirehathawayhs.tor_proxy import parse_proxy


class ProxyMiddleware(object):

    def process_request(self, request, spider):
        proxy = parse_proxy()
        request.meta['proxy'] = proxy['proxy_url']
        # log.msg("Proxy added", level=log.DEBUG)


class RandomUserAgentMiddleware(object):

    def process_request(self, request, spider):
        ua = random.choice('USER_AGENT_LIST')
        if ua:
            request.headers.setdefault('User-Agent', ua)
        # log.msg("USER AGENT IS: " + ua, level=log.DEBUG)
