from pymongo import MongoClient
import pika
import json
from scrapy import cmdline
from time import sleep
import datetime
QUEUE_NAME = 'compass'
QUEUE_HOST = '134.209.174.206'
QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'
DB_NAME = 'kw_Mar_2020'
# client = MongoClient()
client = MongoClient('mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')
db = client[DB_NAME]
COLLECTION_NAME = 'compass_url'
FIELD = 'url'
FIELD = FIELD.split(',')
FIELD = [x.strip() for x in FIELD if x.strip()]
searchString = {'_id': 1}
for field in FIELD:
    searchString[field] = 1
# searchString = {'url': 1}
print(searchString)
result = db[COLLECTION_NAME].find({}, searchString)
credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
connection = pika.BlockingConnection(pika.ConnectionParameters(
    credentials=credentials, host=QUEUE_HOST, socket_timeout=3000))
channel = connection.channel()
channel.queue_declare(queue=QUEUE_NAME, durable=True)
for data in result:
    document = dict(data)
    if len(FIELD) == 1:
        document = document[FIELD[0]]
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=document)
        sleep(0.0001)
    else:
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=json.dumps(document))
        sleep(0.0001)
connection.close()
cmdline.execute("scrapy crawl comapss_spider_new".split())
# cmdline.execute("scrapy crawl comapss_spider_new".split())
