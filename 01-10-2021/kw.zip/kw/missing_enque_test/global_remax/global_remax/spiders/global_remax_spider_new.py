# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from global_remax.items import *
from global_remax.settings import *
from global_remax.proxy import parse_proxy
from pymongo import MongoClient
from scrapy import signals
from databasenotifier import automation_script


handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

h = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
}
db = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')[MONGO_DB]
# dbname = 'automation_test_kw'
# collection_name = 'global_remax'
# ==========================
# RemoveOffice_urls ---.remax.com/OfficeProfile.
# check Postalcodes number, lang,(),string,"-","."
# Check name with '-',first_name =re/max,remax
# =============================


class Global_Remax_NewSpider(Spider):
    name = 'global_remax_new'
    # start_urls = ['https://global.remax.com/handlers/officeagentsearch.ashx?mode=list&type=2&regionId=1004&regionRowId=&provinceId=&cityId=&localzoneId=&name=&location=&spokenLanguageCode=&page=1&countryCode=CA&countryEnuName=Canada&countryName=Canada&selmode=residential&officeId=&TargetLng=&TargetLat=']
    # allowed_domains = []
    # def spider_ended(self):
        # automation_script.Automation_Spider(dbname, collection_name)
    def start_requests(self):
        # # Queue implementation
        # if READ_FROM_FILE == False:
        #     credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        #     connection = pika.BlockingConnection(pika.ConnectionParameters(
        #         credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        #     channel = connection.channel()
        #     channel.basic_qos(prefetch_count=1)
        #     while True:
        #         try:
        #             method, properties, body = channel.basic_get(
        #                 queue=QUEUE_NAME)
        #             if not body:
        #                 break
        #             publication_url = body.strip()
        #             publication_url = str(publication_url, encoding="utf-8")
        #             channel.basic_ack(delivery_tag=method.delivery_tag)
        #             connection.close()
        #             if publication_url:
        #                 yield Request(url=publication_url, callback=self.parse, dont_filter=True, headers=h, meta={'request_url': publication_url})
        #         except:
        #             connection = pika.BlockingConnection(pika.ConnectionParameters(
        #                 credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        #             channel = connection.channel()
        #             channel.basic_qos(prefetch_count=1)
        #     connection.close()

        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        channel = connection.channel()
        while True:
            channel.basic_qos(prefetch_count=1)
            method, properties, url = channel.basic_get(queue=QUEUE_NAME)
            if not url.strip():
                break
            channel.basic_ack(delivery_tag=method.delivery_tag)
            url = str(url.strip(), encoding='utf-8')
            if url.strip():
                # yield Request(url=url.strip(), callback=self.parse, headers=headers, errback=lambda x: self.errback_httpbin(x, url.strip()))
                yield Request(url=url.strip(), callback=self.parse, headers=h,meta={'request_url': url.strip()})
        # f = open('missing_urls.txt')
        # for link in f.readlines():
            # publication_url = link.strip()
            # yield Request(url=publication_url, callback=self.parse, dont_filter=True, headers=h, meta={'request_url': publication_url}, errback=lambda x: self.errback_httpbin(x, publication_url))

    def parse(self, response):
        # print('######################')
        # Grab XPATH
        NAME_XPATH = '//li[@class="active"]/span/text()'
        OFFICE_NAME_XPATH = '//span[@itemprop="name"]/text()'
        ADDRESS_XPATH = '//span[@itemprop="streetAddress"]/text()'
        CITY_XPATH = '//span[@itemprop="addressLocality"]/text()'
        STATE_XPATH = '//span[@itemprop="addressRegion"]/text()'
        COUNTRY1 = '//span[@itemprop="addressCountry"]/text()'
        COUNTRY2 = '//title/text()'
        ZIPCODE_XPATH = '//span[@itemprop="postalCode"]/text()'
        IMAGE_URL_XPATH = '//img[@itemprop="image"]/@src'
        # TITLE_XPATH = '//h1/text()'
        # OFFICE_NAME_XPATH = '//h1/text()'
        WEBSITES_XPATH = '//a[@class="url"]/@href'
        OFFICE_PHONE_XPATH = '//span[@id="OfficePhoneSpan"]/text()'
        AGENT_PHONE_XPATH = '//span[@id="PhoneSpan"]/text()|//span[@id="AgentDirectDialSpan"]/text()'
        DESCRIPTION_XPATH = '//div[@class="closer"]//text()'
        LANGUAGES_XPATH = '//div[@class="profile-languages"]/div/@title'
        WHATSAPP_XPATH = '//a[@id="agentprofile_sendmessage_whatsapp_desktop_whatsapp"]/@href'

        # Extract values using above XPATHs
        name = response.xpath(NAME_XPATH).extract()
        office_name = response.xpath(OFFICE_NAME_XPATH).extract()
        address = response.xpath(ADDRESS_XPATH).extract_first('')
        city = response.xpath(CITY_XPATH).extract_first('').strip()
        state = response.xpath(STATE_XPATH).extract_first('').strip()
        country_path1 = response.xpath(COUNTRY1).extract_first('').strip()
        country_path2 = response.xpath(COUNTRY2).extract_first('')
        postalCode = response.xpath(ZIPCODE_XPATH).extract_first('').strip()
        image_url = response.xpath(IMAGE_URL_XPATH).extract_first('')
        # title = response.xpath(TITLE_XPATH).extract_first('')
        websites = response.xpath(WEBSITES_XPATH).extract_first('')
        office_phone = response.xpath(OFFICE_PHONE_XPATH).extract()
        agent_phone = response.xpath(AGENT_PHONE_XPATH).extract()
        description = response.xpath(DESCRIPTION_XPATH).extract()
        languages = response.xpath(LANGUAGES_XPATH).extract()
        whatsapp_url = response.xpath(WHATSAPP_XPATH).extract_first('').strip()

        # Clean Data
        name = name[0].strip() if name else ''
        name = name.split()
        first_name = ''
        middle_name = ''
        last_name = ''
        if len(name) == 1:
            first_name = name[0].strip() if name[0] else ''
            middle_name = ''
            last_name = ''
        if len(name) == 2:
            first_name = name[0].strip() if name[0] else ''
            middle_name = ''
            last_name = name[1].strip() if name[1] else ''
        if len(name) == 3:
            first_name = name[0].strip() if name[0] else ''
            middle_name = name[1].strip() if name[1] else ''
            last_name = name[2].strip() if name[2] else ''
        if len(name) >= 4:
            first_name = ' '.join(name)
            middle_name = ''
            last_name = ''

        if '-' in first_name:
            ll = first_name
            first_name = ll.split('-')[0]
            middle_name = ll.split('-')[1]

        first_name = first_name.capitalize()
        middle_name = middle_name.capitalize()
        last_name = last_name.capitalize()

        office_name = office_name[-1].strip() if office_name else ''
        address = address.replace(',,', ',').strip()
        address = ' '.join(''.join(address).split())
        office_phone_ = []
        for num in office_phone:
            num = ''.join(num).strip()
            office_phone_.append(num)

        agent_phone_ = []
        for num in agent_phone:
            num = ''.join(num).strip()
            agent_phone_.append(num)

        languages = languages if languages else []
        description = ' '.join(' '.join(description).split()
                               ).strip() if description else ''
        if 'default' in image_url:
            image_url = ''
        else:
            image_url = image_url.replace(
                'https://remax.azureedge.net', 'https://global.remax.com',) if image_url else ''

        city = city.split(',')[0]
        state = state.split(',')[0]

        if country_path1:
            country = country_path1
        else:
            if country_path2:
                if '|' in country_path2:
                    country = country_path2.split(
                        '|')[1].strip() if country_path2 else ''
                    if country == 'RE/MAX, LLC.' and country == 'RE/MAX Global':
                        country = ''
            else:
                country = ''

        facebook_url = ''
        linkedin_url = ''
        twitter_url = ''
        other_urls = []
        social = {}
        if linkedin_url:
            social.update({"linkedin_url": linkedin_url})
        if facebook_url:
            social.update({"facebook_url": facebook_url})
        if twitter_url:
            social.update({"twitter_url": twitter_url})
        if whatsapp_url:
            social.update({"other_urls": whatsapp_url})

        if first_name:
            item = Global_RemaxItem(
                first_name=first_name,
                middle_name=middle_name,
                last_name=last_name,
                office_name=office_name,
                address=address,
                city=city,
                state=state,
                country=country,
                zipcode=postalCode,
                image_url=image_url,
                title='',
                email='',
                profile_url=response.url,
                website=websites,
                office_phone_numbers=office_phone_,
                agent_phone_numbers=agent_phone_,
                social=social,
                description=description,
                languages=languages,
            )
            db[MONGO_COLLECTION].insert(dict(item))
            # yield item

    # Errorback to put failed urls back in queue
    # def errback_httpbin(self, failure, url):
        # pass
        # credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        # connection = pika.BlockingConnection(pika.ConnectionParameters(
        #     credentials=credentials, host=QUEUE_IP, socket_timeout=600))
        # channel = connection.channel()
        # channel.queue_declare(queue=QUEUE_NAME, durable=True)
        # channel.basic_publish(
        #     exchange='', routing_key=QUEUE_NAME, body=url)
        # connection.close()
    # @classmethod
    # def from_crawler(cls, crawler, *args, **kwargs):
    #     spider = super(Global_RemaxSpider, cls).from_crawler(
    #         crawler, *args, **kwargs)
    #     crawler.signals.connect(spider.spider_opened, signals.spider_opened)
    #     crawler.signals.connect(spider.spider_closed, signals.spider_closed)
    #     return spider

    # def spider_opened(self, spider):

    #     print('Opening {} spider'.format(spider.name))

    # def spider_closed(self, spider):
    #     self.spider_ended()
    #     print('Closing {} spider'.format(spider.name))

