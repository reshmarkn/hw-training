# -*- coding: utf-8 -*-

BOT_NAME = 'global_remax'

SPIDER_MODULES = ['global_remax.spiders']
NEWSPIDER_MODULE = 'global_remax.spiders'

AUTHOR_EMAIL = 'sreejith@datahut.co'
# Crawl responsibly by identifying yourself (and your website) on the
# user-agent
USER_AGENT = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'

# Duplicate filtering field in item for both mongo and DC
DUP_KEY = 'profile_url'

# Configure QUEUE
QUEUE_NAME = 'ha.remax_global'
QUEUE_IP = '134.209.174.206'
QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'

# Configure MONGODB
# MONGO_URI = 'mongodb://localhost:27017'  # local
MONGO_URI = 'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017'  # shard
MONGO_DB = 'kw_Mar_2020'
MONGO_COLLECTION = 'global_remax_test_24'
MONGO_COLLECTION_URL = 'global_remax_url_test'

DUP_KEY = ''

# Enable or disable downloader middlewares
DOWNLOADER_MIDDLEWARES = {
    # 'global_remax.middlewares.RandomUserAgentMiddleware': 100,
    'global_remax.middlewares.ProxyMiddleware': 110,
    # 'scrapy.contrib.downloadermiddleware.httpproxy.HttpProxyMiddleware': 130,
    # 'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,

}
READ_FROM_FILE = False

# Enable or disable extensions
# EXTENSIONS = {
    # 'general_validator.GeneralValidator': 100,
    # 'sc_mongo.ScrapyMongoExtension': 400,
# }

# # Configure DC
SC_MONGO_EXT_ENABLED = True

# # Configure item pipelines
# ITEM_PIPELINES = {
#     'global_remax.pipelines.Global_RemaxPipeline': 300,
# }


# Obey robots.txt rules
# ROBOTSTXT_OBEY = True

# Configure maximum concurrent requests performed by Scrapy (default: 16)
CONCURRENT_REQUESTS = 1

# Disable cookies (enabled by default)
#COOKIES_ENABLED = False

# Enable and configure the AutoThrottle extension (disabled by default)
#AUTOTHROTTLE_ENABLED = True
