from scrapy.utils.project import get_project_settings
from scrapy.crawler import CrawlerProcess
import subprocess
from scrapy import cmdline
import os
from subprocess import check_output
setting = get_project_settings()
process = CrawlerProcess(setting)
print(process.spiders.list())
spider_list = process.spiders.list()
# spiders = spider_list[:-1]
spiders =['global_remax_new','global_remax_new','global_remax_new']
for spider_name in spiders:
    print ("Running spider %s" % (spider_name))
    process.crawl(spider_name,query='dvh') #query dvh is custom argument used in your scrapy
process.start()

