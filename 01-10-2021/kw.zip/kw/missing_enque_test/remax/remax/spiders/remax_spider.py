# # -*- coding: utf-8 -*-
# import scrapy
# from scrapy.http import Request
# from remax.items import *
# from remax.settings import *
# import json
# #import codecs
# import pika
# import logging

# handler = logging.FileHandler('spider_error.log')
# handler.setLevel('ERROR')
# logging.root.addHandler(handler)
# logger = logging.getLogger('pika')
# logger.propagate = False


# class RemaxSpiderSpider(scrapy.Spider):
#     name = 'remax_spider'
#     allowed_domains = ['http://www.remax.com']
#     #   start_urls = ['http://www.remax.com/api/agents/rnd-SortOrder/1-PageNumber/900-Count/?siteid=null']
#     BASE_URL = 'http://www.remax.com'

#     def start_requests(self):
#         credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
#         connection = pika.BlockingConnection(pika.ConnectionParameters(
#             credentials=credentials, host=QUEUE_IP, socket_timeout=300))
#         channel = connection.channel()
#         while True:
#             channel.basic_qos(prefetch_count=1)
#             method, properties, url = channel.basic_get(queue=QUEUE_NAME)
#             url_ = url.strip() if url else ''
#             if not url_:
#                 break
#             channel.basic_ack(delivery_tag=method.delivery_tag)
#             urls = url.strip()
#             urls = str(urls, encoding="utf-8")
#             if urls.strip():
#                 yield Request(url=urls.strip(), callback=self.parse, errback=lambda x: self.errback_httpbin(x, urls.strip()))
#         connection.close()

#     def parse(self, response):
#         name = response.xpath(
#             '//span[@itemprop="name"]/text()').extract()
#         first_name = ''
#         middle_name = ''
#         last_name = ''
#         # name = name[0].replace('-', ' ').split()
#         if '-' in name[0]:
#             name = name[0].split(',')
#             name = name[0].replace('-', ' ').strip()
#             name = name.split()
#         else:
#             name = name[0].strip()
#             name = name.split(',')
#             name = name[0].split(' ')

#         if len(name) == 1:
#             first_name = name[0].strip() if name[0] else ''
#             middle_name = ''
#             last_name = ''
#         if len(name) == 2:
#             first_name = name[0].strip() if name[0] else ''
#             middle_name = ''
#             last_name = name[1].strip() if name[1] else ''
#         if len(name) == 3:
#             first_name = name[0].strip() if name[0] else ''
#             middle_name = name[1].strip() if name[1] else ''
#             last_name = name[2].strip() if name[2] else ''
#         if len(name) >= 4:
#             first_name = ' '.join(name)
#             middle_name = ''
#             last_name = ''

#         office_name = response.xpath(
#             '//li[@hmsitemprop="OfficeName"]/text()').extract_first('').strip()
#         address = response.xpath(
#             '//span[@itemprop="streetAddress"]/text()').extract_first('').strip()
#         city = response.xpath(
#             '//span[@itemprop="addressLocality"]/text()').extract_first('').strip(',').strip()
#         state = response.xpath(
#             '//span[@itemprop="addressRegion"]/text()').extract_first('').strip(',').strip()
#         zipcode = response.xpath(
#             '//span[@itemprop="postalCode"]/text()').extract_first('').strip(',').strip()
#         image_url = response.xpath(
#             '//img[@title="Agent Photo" ]/@src').extract_first('')
#         #fax = fax
#         title = response.xpath(
#             '//li[@hmsitemprop="Title"]/text()').extract_first('').strip()
#         # emails = response.xpath(
#         # '//@data-agentemail').extract_first('').split('-')[0]
#         emails = response.xpath(
#             '//@data-agentemail').extract_first('')
#         profile_url = response.url
#         websites = response.xpath(
#             '//a[@class="hero-website-link"]/@data-agenturl').extract_first('').strip()
#         # other_phone = other_phone
#         # office_phone_numbers = response.xpath('//div[@itemprop="telephone"][contains(label/text(),"Office")]/a/text()').extract_first('').strip(),
#         # agent_phone_numbers = response.xpath('//div[@itemprop="telephone"][contains(label/text(),"Agent")]/a/text()').extract_first('').strip(),
#         #phone_numbers = phone_numbers,
#         facebook_url = ''.join(response.xpath(
#             '//a[@class="hero-social-icon icon-facebook"]/@href').extract())
#         twitter_url = ''.join(response.xpath(
#             '//a[@class="hero-social-icon icon-twitter"]/@href').extract())
#         linkedin_url = ''.join(response.xpath(
#             '//a[@class="hero-social-icon icon-linkedin"]/@href').extract())
#         pinterest_url = ''.join(response.xpath(
#             '//a[@class="hero-social-icon icon-pinterest"]/@href').extract())
#         googleplus_url = ''.join(response.xpath(
#             '//a[@class="hero-social-icon icon-googleplus"]/@href').extract())
#         youtube_url = ''.join(response.xpath(
#             '//a[@class="hero-social-icon icon-youtube"]/@href').extract())
#         instagram_url = ''.join(response.xpath(
#             '//a[@class="hero-social-icon icon-instagram"]/@href').extract())
#         blog_url = ''.join(response.xpath(
#             '//a[@class="hero-social-icon icon-blog"]/@href').extract())

#         if 'www.facebook.com' in facebook_url:
#             facebook_url = facebook_url.strip()
#         else:
#             facebook_url = ''
#         if 'twitter.com' in twitter_url:
#             twitter_url = twitter_url.strip()
#         else:
#             twitter_url = ''
#         if 'www.linkedin.com' in linkedin_url:
#             linkedin_url = linkedin_url.strip()
#         else:
#             linkedin_url = ''
#         if 'www.pinterest.com' in pinterest_url:
#             pinterest_url = pinterest_url.strip()
#         else:
#             pinterest_url = ''
#         if 'google.com' in googleplus_url:
#             googleplus_url = googleplus_url.strip()
#         else:
#             googleplus_url = ''
#         if 'www.youtube.com' in youtube_url:
#             youtube_url = youtube_url.strip()
#         else:
#             youtube_url = ''
#         if 'www.instagram.com' in instagram_url:
#             instagram_url = instagram_url.strip()
#         else:
#             instagram_url = ''
#         if '/blog/' in blog_url:
#             blog_url = blog_url.strip()
#         else:
#             blog_url = ''

#         other_urls_ = []

#         if pinterest_url:
#             other_urls_.append(pinterest_url)
#         if googleplus_url:
#             other_urls_.append(googleplus_url)
#         if youtube_url:
#             other_urls_.append(youtube_url)
#         if instagram_url:
#             other_urls_.append(instagram_url)
#         if blog_url:
#             other_urls_.append(blog_url)

#         other_urls = []
#         for url in other_urls_:
#             if url:
#                 other_urls.append(url)
#             else:
#                 other_urls = []

#         if facebook_url or twitter_url or linkedin_url or other_urls:
#             social = {'facebook_url': facebook_url,
#                       'twitter_url': twitter_url,
#                       'linkedin_url': linkedin_url,
#                       'other_urls': other_urls,
#                       }
#         else:
#             social = {}

#         description = response.xpath(
#             '//p[@itemprop="description"]/text()').extract()
#         description = ' '.join(
#             ''.join(description).split()) if description else ''
#         if '-Disabled' in emails:
#             emails = emails.replace('-Disabled', '')
#         image_url = response.xpath(
#             '//img[@class="hero-photo"]/@src').extract_first('')

#         agent_phone = []
#         # agent_phone_ = response.xpath('//a[@class="hero-phone-number js-autocall"]/text()').extract()
#         agent_phone_ = response.xpath(
#             '//div[@itemprop="telephone"]/label[contains(text(),"Agent")]/preceding-sibling::a/text()').extract()
#         if len(agent_phone_) > 1:
#             for index, number in enumerate(agent_phone_):
#                 label = str(index + 1)
#                 number = ''.join(number).strip()
#                 phn_dict = {label: number}
#                 agent_phone.append(phn_dict)
#         else:
#             agent_phone_ = ''.join(agent_phone_).strip()
#             agent_phone.append(agent_phone_)

#         office_phone = []
#         # office_phone_ = response.xpath('//a[@class="hero-phone-number js-autocall"]/text()').extract()
#         office_phone_ = response.xpath(
#             '//div[@itemprop="telephone"]/label[contains(text(),"Office")]/preceding-sibling::a/text()').extract()
#         if len(office_phone_) > 1:
#             for index, number in enumerate(office_phone_):
#                 label = str(index + 1)
#                 number = ''.join(number).strip()
#                 phn_dict = {label: number}
#                 office_phone.append(phn_dict)
#         else:
#             office_phone_ = ''.join(office_phone_).strip()
#             office_phone.append(office_phone_)

#         if agent_phone == ['']:
#             agent_phone = []

#         if office_phone == ['']:
#             office_phone = []

#         languages = response.xpath(
#             '//dt[contains(text(),"Languages:")]/following-sibling::dd/text()').extract_first('').strip().split(',')
#         languages_ = []
#         if languages:
#             for i in languages:
#                 languages_.append(i)

#         if languages_ == ['']:
#             languages_ = []
#         else:
#             languages_ = languages_

#         if first_name:
#             item = RemaxItem(
#                 first_name=first_name,
#                 middle_name=middle_name,
#                 last_name=last_name,
#                 office_name=office_name,
#                 address=address,
#                 city=city,
#                 state=state,
#                 zipcode=zipcode,
#                 image_url=image_url,
#                 country='United States',
#                 title=title,
#                 email=emails,
#                 profile_url=profile_url,
#                 website=websites,
#                 #fax = fax,
#                 office_phone_numbers=office_phone,
#                 agent_phone_numbers=agent_phone,
#                 social=social,
#                 description=description,
#                 languages=languages_,

#             )
#             yield item
#             print(item)

#     def errback_httpbin(self, failure, url):
#         credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
#         connection = pika.BlockingConnection(pika.ConnectionParameters(
#             credentials=credentials, host=QUEUE_IP, socket_timeout=600))
#         channel = connection.channel()
#         channel.queue_declare(queue=QUEUE_NAME, durable=True)
#         channel.basic_publish(
#             exchange='', routing_key=QUEUE_NAME, body=url)
#         connection.close()
