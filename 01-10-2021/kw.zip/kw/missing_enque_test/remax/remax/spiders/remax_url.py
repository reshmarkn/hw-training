# import scrapy
# import string
# import json
# from scrapy.http import Request, FormRequest
# from remax.items import *
# from xml.dom import minidom
# # import StringIO
# import gzip
# from pymongo import MongoClient


# headers = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
#            'accept-encoding': 'gzip, deflate, br',
#            'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
#            'upgrade-insecure-requests': '1',
#            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36', }

# class Remax(scrapy.Spider):
#     name = 'remax_urls'
#     allowed_domains = ['remax.com']
#     # db = MongoClient(
#     #     'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017').kw_Apr_2020 

#     def start_requests(self):
#         for i in range(100000000, 200000000):
#             url = 'https://public-api-gateway-prod.kube.remax.booj.io/personnel/agents/' + \
#                 str(i)+'/'
#             yield Request(url=url, callback=self.parse_url, headers=headers)

#     def parse_url(self, response):
#         json_data = json.loads(response.body_as_unicode())
#         active = json_data.get('data').get('status')
#         if active == "ACTIVE":
#             p_url = response.url
#             # meta = {'url': p_url}
#             # self.db.remax_us_url_16.insert(dict(meta))
#             item = RemaxUrlItem()
#             item['url'] = p_url
#             yield item
#         else:
#             pass

