from scrapy.http import Request, FormRequest
import scrapy
import json
import requests
import re
import logging
import pika
from remax.items import *
from remax.settings import *
from pymongo import MongoClient
db = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')[MONGO_DB]
headers = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
    "Upgrade-Insecure-Requests": "1",
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36"
}

import urllib3

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False
urllib3.disable_warnings()

class RemaxSpider_New_Spider(scrapy.Spider):
    name = 'remax_spider_new1'
    # allowed_domains = ['http://www.remax.com']
    BASE_URL = 'http://www.remax.com'

    def start_requests(self):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        channel = connection.channel()
        while True:
            channel.basic_qos(prefetch_count=1)
            method, properties, url = channel.basic_get(queue=QUEUE_NAME)
            url_ = url.strip() if url else ''
            if not url_:
                break
            channel.basic_ack(delivery_tag=method.delivery_tag)
            urls = url.strip()
            urls = str(urls, encoding="utf-8")
            if urls.strip():
                yield Request(url=urls.strip(), callback=self.parse)
        connection.close()
        # urls = [i.strip() for i in open('remax_sept.txt').readlines()]

        # for url in urls:
        #     yield Request(url=url, headers=headers, callback=self.parse)

    def parse(self, response):
        data = json.loads(response.body_as_unicode())
        pro = data.get('data')
        # print(data)
        # print(agents.keys())
        list_ = []
        id_ = pro.get('masterCustomerId', '')
        first_name = pro.get('firstName', '')
        f_name = first_name.replace(' ', '')
        middle_name = pro.get('middleName', '')
        if middle_name == None:
            middle_name = ''
        m_name = middle_name.replace(' ', '') if middle_name else ''
        last_name = pro.get('lastName', '')
        l_name = last_name.replace(' ', '')
        office = pro.get('officeMembership')[0].get(
            'office') if pro.get('officeMembership') else ''
        state = office.get('state', '')
        if state == None:
            state = ''
        if not state:
            state = pro.get('licenses', '')[0].get(
                'state', '') if pro.get('licenses') else ''

        zipcode = office.get('postalCode', '')
        city = office.get('city', '')
        if not city:
            city = pro.get('officeMembershipRolesPrimary')[0].get(
                'office') if pro.get('officeMembershipRolesPrimary') else ''
            city = city.get(
                'office', '') if city else ''

        city_ = city.replace(' ', '')
        state_ = state.replace(' ', '')
        address = office.get('address1', '')
        office_phone_numbers = []
        office_phone_number = office.get('phones')[0].get(
            'phoneNumber') if office.get('phones') else ''
        office_phone_numbers.append(office_phone_number)
        office_name = office.get('officeName', '')
        websites = pro.get('webSites')[0].get(
            'webAddress') if pro.get('webSites') else ''
        emails = pro.get('emails')[0].get(
            'emailAddress') if pro.get('emails') else ''
        agent_phone_numbers = []

        agent_phone = pro.get('phones', '')
        if agent_phone:
            for phone in agent_phone:
                agent_phone_number = phone.get(
                    'phoneNumber') if pro.get('phones') else ''
                if office_phone_number != phone:
                    agent_phone_numbers.append(agent_phone_number)

        description = pro.get('biography')[0].get(
            'biographyText') if pro.get('biography') else ''
        image = pro.get('photos') if pro.get('photos') else ''
        image_url = ''
        for img in image:
            images = img['typeCode']
            if images == 'MainPhoto':
                image_url = img.get('url')
        languages = pro.get('languages') if pro.get('languages') else ''
        languages_ = []
        for i in languages:
            lang = i.get('languageDescr')
            languages_.append(lang)
        social = {}
        title = pro.get('jobTitle', '')
        if title == None:
            title = ''
        list_.append(f_name) if f_name else ''
        list_.append(m_name) if m_name else ''
        list_.append(l_name) if l_name else ''
        list_.append(city_) if city_ else ''
        list_.append(state_) if state_ else ''
        slug = '-'.join(list_)
        profile_url = 'https://www.remax.com/real-estate-agents/' + \
            str(slug) + '/' + str(id_)

        sample_url = response.url
        if first_name:
            item = RemaxItem(
                first_name=first_name,
                middle_name=middle_name,
                last_name=last_name,
                office_name=office_name,
                address=address,
                city=city,
                state=state,
                zipcode=zipcode,
                image_url=image_url,
                country='United States',
                title=title,
                email=emails,
                profile_url=profile_url,
                website=websites,
                # fax = fax,
                office_phone_numbers=office_phone_numbers,
                agent_phone_numbers=agent_phone_numbers,
                social=social,
                description=description,
                languages=languages_,
                sample_url=sample_url
            )
        db[MONGO_COLLECTION].insert(dict(item))
        # yield item
        # print(item)

    # def errback_httpbin(self, failure, url):
    #     credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
    #     connection = pika.BlockingConnection(pika.ConnectionParameters(
    #         credentials=credentials, host=QUEUE_IP, socket_timeout=600))
    #     channel = connection.channel()
    #     channel.queue_declare(queue=QUEUE_NAME, durable=True)
    #     channel.basic_publish(
    #         exchange='', routing_key=QUEUE_NAME, body=url)
    #     connection.close()
