# -*- coding: utf-8 -*-
import scrapy
from pymongo import MongoClient
from scrapy.exceptions import DropItem
from remax.items import *
from remax.settings import *
import requests
from queue_missing.missing_script import MissingEnqueue
import subprocess
import time
from scrapy import cmdline

url_collection_field = 'url'
mongo_collection_field = 'sample_url'
slack_id = 'UQ07UQXCM'
token = 'xoxp-24300212688-816266847429-1001906194901-ea9185ed9081045f47175a604eeaca82'
import logging
handler = logging.FileHandler('script_error.log')
handler.setLevel('INFO')
logging.root.addHandler(handler)
logger = logging.getLogger()

class RemaxPipeline(object):
    print('11111111111111111111111111')

    def __init__(self, settings):
        self.mongo_uri = settings.get('MONGO_URI')
        self.mongo_db = settings.get('MONGO_DB')
        self.mongo_collection = settings.get('MONGO_COLLECTION')
        self.mongo_collection_url = settings.get('MONGO_COLLECTION_URL')
        self.dup_key = settings.get('DUP_KEY')

    @classmethod
    def from_crawler(cls, crawler):
        return cls(
            settings=crawler.settings
        )

    def open_spider(self, spider):
        self.client = MongoClient(self.mongo_uri)
        self.db = self.client[self.mongo_db]
        if self.dup_key:
            self.db[self.mongo_collection].create_index(
                self.dup_key, unique=True)

    # def process_item(self, item, spider):
    #     if isinstance(item, RemaxItem):
    #         try:
    #             self.db[self.mongo_collection].insert(dict(item))
    #         except:
    #             raise DropItem("Dropping duplicate item")
    #     if isinstance(item, RemaxUrlItem):
    #         try:
    #             self.db[self.mongo_collection_url].insert(dict(item))
    #         except:
    #             raise DropItem("Dropping duplicate item")
    #     return item

    def close_spider(self, spider):

        if self.db[self.mongo_collection].estimated_document_count() < self.db[self.mongo_collection_url].estimated_document_count():
            a = MissingEnqueue(self.mongo_db, self.mongo_collection_url, url_collection_field,
                               self.mongo_db, self.mongo_collection, mongo_collection_field, QUEUE_IP, QUEUE_NAME, slack_id)
            f = open('missing.txt', 'r')
            missing_file_count = f.readlines()
            if int(''.join(missing_file_count)) != int(str(len(a.out))):
                f = open('missing.txt', 'w')
                f.write(str(len(a.out)))
                f.close()
                missing_count = 'missing count' + str(len(a.out))
                logging.info(missing_count)
                a =subprocess.run("python3 rerun_script.py", shell=True)
                # print(a.check_returncode,'running deatils')
                if a.returncode == 0:
                    time.sleep(60)
                    print('running compltedley')
                    cmdline.execute("scrapy crawl remax_spider_new".split())
            else:
                f = open('missing.txt', 'w')
                f.write(str(0))
                f.close()
                logging.info('taking same missing_urls')
                data = {'token': token, 'channel': slack_id,
                        'text': 'taking same missing_urls'}
                requests.post(url='https://slack.com/api/chat.postMessage',
                              data=data)
        else:
            f = open('missing.txt', 'w')
            f.write(str(0))
            f.close()
            logging.info('there is no missing urls')
            data = {'token': token, 'channel': slack_id,
                    'text': 'there is no missing urls'}

            requests.post(
                url='https://slack.com/api/chat.postMessage', data=data)
