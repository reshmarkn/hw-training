from scrapy.utils.project import get_project_settings
from scrapy.crawler import CrawlerProcess
from twisted.internet.defer import inlineCallbacks

setting = get_project_settings()
process = CrawlerProcess(setting)
print(process.spiders.list())
spider_list = process.spiders.list()
# spiders = spider_list[:-1]
spiders =['coldwellbankerinternational_new','coldwellbankerinternational_new','coldwellbankerinternational_new','coldwellbankerinternational']

for spider_name in spiders:
    print ("Running spider %s" % (spider_name))
    process.crawl(spider_name,query="dvh") #query dvh is custom argument used in your scrapy
# # process.crawl('comapss_spider_new1')
# # process.crawl('comapss_spider_new1')
# # process.crawl('comapss_spider_new1')
# # process.crawl('comapss_spider_new1')
# # process.crawl('comapss_spider_new')
process.start()
