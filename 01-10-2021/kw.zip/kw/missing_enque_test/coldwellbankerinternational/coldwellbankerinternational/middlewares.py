import logging
import requests
import random
from coldwellbankerinternational.proxy import parse_proxy
#from fake_useragent import UserAgent

logger = logging.getLogger(__name__)


class ProxyMiddleware(object):
    # def __init__(self):
    #     list_proxies = requests.get('http://68.183.58.145/microleaves',
    #                                 headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()

    def process_request(self, request, spider):
        # proxy = random.choise(self.list_proxies)
        # proxy_url = "http://%s" % proxy
        # proxies = {"http": "http://%s" % proxy,
        #            "https": "http://%s" % proxy}
        proxy = parse_proxy()
        request.meta['proxy'] = proxy['proxy_url']


class RandomUserAgentMiddleware(object):

    def process_request(self, request, spider):
        try:
            ua = UserAgent()
            ua = ua.random
        except:
            ua = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'
        if ua:
            request.headers.setdefault('User-Agent', ua)
        logger.debug("USER AGENT IS: " + ua)
