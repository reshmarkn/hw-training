# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
# from dateutil import parser
from scrapy.spiders import Spider
from pymongo import MongoClient
from scrapy.shell import inspect_response
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from coldwellbankerinternational.items import *
from coldwellbankerinternational.settings import *
from coldwellbankerinternational.proxy import parse_proxy
from scrapy import signals
import subprocess
from databasenotifier import automation_script
db = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017').kw_Mar_2020
headers = {
    'accept': 'text/html, */*; q=0.01',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36',
    'x-pjax': 'true',
    'x-pjax-container': '#proxio-card-list-agent-widget',
    'x-requested-with': 'XMLHttpRequest'
}

class ColdwellbankerinternationalSpider(Spider):
    name = 'coldwellbankerinternational_crawler'
    start_urls = ['https://www.coldwellbankerinternational.com/agents/']
    allowed_domains = []


    # def spider_ended(self):
        # automation_script.Automation_Spider(MONGO_DB, MONGO_COLLECTION_URL)
        # subprocess.call("python q_insert.py ", shell=True)

    # def __init__(self):
    #     self.db.coldwellbankerinternational_urlv2.create_index(
    #         'link', unique=True)

    def parse(self, response):
        f = open("country_list.txt")
        for country in f.readlines():
            url = 'https://www.coldwellbankerinternational.com/agents/' + country.strip() + \
                '/page/1/?sort=newest&query_type=all-agents&ExpandQuery=true&_pjax=%23proxio-card-list-agent-widget'
            # url = 'https://www.coldwellbankerinternational.com/agents/ca/page/1/?sort=newest&query_type=all-agents&ExpandQuery=true&_pjax=%23proxio-card-list-agent-widget'
            yield Request(url=url, callback=self.parse_urls, meta={'code': country.strip(), 'page': 1}, headers=headers)
    # url = 'https://www.coldwellbankerinternational.com/agents/ca/'
    # for i in range(1, 207):
    #     url = 'https://www.coldwellbankerinternational.com/agents/ca/page/' + \
    #         str(i) + '/?sort=name&query_type=all-agents&ExpandQuery=true'
    # yield Request(url=url, callback=self.parse_urls, meta={'code': 'ca',
    # 'page': 1}, headers=headers)

    def parse_urls(self, response):
        # inspect_response(response, self)
        

        LINKS = response.xpath(
            '//div[@class="agent-view-listing"]/a/@href').extract()
        country = response.xpath(
            '//input[@placeholder="Select a Country"]/@value').extract_first('')
        NAME_SELECTORS = response.xpath('//a[h1[@itemprop="name"]]')
        # meta = {'country' : country}
        page = response.meta['page']
        code = response.meta['code']
        for name_selector in NAME_SELECTORS:
            name = name_selector.xpath(
                'h1[@itemprop="name"]/text()').extract_first('').strip()
            link = name_selector.xpath('@href').extract_first('')

            if link and name:
                # with open('coldwellbankerinternational_oct_1.csv', 'a') as f:
                #     f.write('"' + link + '","' + name + '","' + code + '"\n')
                # links = {'link': link}
                # db['coldwellbankerinternational_url1'].insert(
                #     dict(links))
                item = ColdwellbankerinternationalUrlItem()
                item['url'] = link
                print(item)
                db[MONGO_COLLECTION_URL].insert(dict(item))

        page += 1

        NEXT_PAGE = response.xpath(
            '//ul[@class="pagination"]/li[@class="next-page"]/a/@href').extract_first('')
        if NEXT_PAGE:
            NEXT_PAGE = NEXT_PAGE.split(
                'sort')[0] + 'sort=newest&' + NEXT_PAGE.split('sort')[-1].split('&', 1)[-1] + '&_pjax=%23proxio-card-list-agent-widget'
            yield Request(url=NEXT_PAGE, callback=self.parse_urls, meta={'code': code, 'page': page}, headers=headers)
    # @classmethod
    # def from_crawler(cls, crawler, *args, **kwargs):
    #     spider = super(ColdwellbankerinternationalSpider, cls).from_crawler(
    #         crawler, *args, **kwargs)
    #     crawler.signals.connect(spider.spider_opened, signals.spider_opened)
    #     crawler.signals.connect(spider.spider_closed, signals.spider_closed)
    #     return spider

    # def spider_opened(self, spider):
    #     print('Opening {} spider'.format(spider.name))

    # def spider_closed(self, spider):
    #     print('%%%%%%%%%%%%%%%%%%%%%%%%%%')
    #     self.spider_ended()
    #     print('Closing {} spider'.format(spider.name))