# -*- coding: utf-8 -*-
from coldwellbankerinternational.proxy import parse_proxy
from coldwellbankerinternational.settings import *
from coldwellbankerinternational.items import *
from scrapy.http import Request, FormRequest
from scrapy.selector import Selector
from scrapy.spiders import Spider
from scrapy import signals
from databasenotifier import automation_script
from pymongo import MongoClient
import scrapy
import re
import pika
import json
import logging
import string
import logging
import time
import urllib

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

# from dateutil import parser
db = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017').kw_Mar_2020
headers = {
    'accept': 'text/html, */*; q=0.01',
    'accept-encoding': 'gzip, deflate, br',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36',
}

class Coldwellbankerinternational_New_Spider(Spider):
    name = 'coldwellbankerinternational_new'
    # start_urls = ['https://www.coldwellbankerinternational.com/agents/']
    allowed_domains = ['www.coldwellbankerinternational.com']
    # handle_httpstatus_list = [301]
    # def spider_ended(self):
        # automation_script.Automation_Spider(MONGO_DB, MONGO_COLLECTION)

    def start_requests(self):

        if READ_FROM_FILE == False:
            credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
            connection = pika.BlockingConnection(pika.ConnectionParameters(
                credentials=credentials, host=QUEUE_IP, socket_timeout=300))
            channel = connection.channel()
            channel.basic_qos(prefetch_count=1)
            while True:
                try:
                    method, properties, body = channel.basic_get(
                        queue=QUEUE_NAME)
                    if not body:
                        break
                    publication_url = body.strip()
                    publication_url = str(publication_url, encoding="utf-8")
                    channel.basic_ack(delivery_tag=method.delivery_tag)
                    connection.close()
                    if publication_url:
                        yield Request(url=publication_url, callback=self.parse_data,headers=headers, meta={'request_url': publication_url})
                except:
                    connection = pika.BlockingConnection(pika.ConnectionParameters(
                        credentials=credentials, host=QUEUE_IP, socket_timeout=300))
                    channel = connection.channel()
                    channel.basic_qos(prefetch_count=1)
            connection.close()

    def parse_data(self, response):
        # print('ffffffffffffffffffffffffffffff')
        countries = {'us': 'USA', 'ar': 'Argentina', 'aw': 'Aruba', 'bm': 'Bermuda', 'vg': 'British Virgin Islands', 'ca': 'Canada', 'ky': 'Cayman Islands', 'cn': 'China', 'co': 'Colombia', 'cr': 'Costa Rica', 'cw': 'Curacao', 'do': 'Dominican Republic', 'eg': 'Egypt', 'fr': 'France', 'de': 'Germany', 'gh': 'Ghana', 'gd': 'Grenada', 'gt': 'Guatemala', 'in': 'India', 'id': 'Indonesia', 'ie': 'Ireland', 'it': 'Italy', 'jm': 'Jamaica',
                     'ke': 'Kenya', 'mt': 'Malta', 'mx': 'Mexico', 'mc': 'Monaco', 'an': 'Netherlands Antilles', 'pa': 'Panama', 'pt': 'Portugal', 'pr': 'Puerto Rico', 'ro': 'Romania', 'kn': 'Saint Kitts and Nevis', 'sg': 'Singapore', 'es': 'Spain', 'th': 'Thailand', 'bs': 'The Bahamas', 'nl': 'The Netherlands', 'tr': 'Turkey', 'tc': 'Turks and Caicos Islands', 'ae': 'United Arab Emirates', 'vi': 'United States Virgin Islands', 'uy': 'Uruguay'}
        country_code = response.xpath(
            '//input[@name="country"]/@value').extract_first('')
        country = countries.get(country_code)

        # Grab XPATH
        NAME_XPATH = '//h1//text()'
        IMAGE_XPATH = '//a[@class="profile-image"]/img/@src'
        TITLE_XPATH = '//span[@class="job-title"]/text()'
        OFFICE_NAME = '//span[@itemprop="address"]/text()'
        DESCRIPTION_XPATH = '//div[@itemprop="description"]//text() | //div[@class="agent-section-list"]/ul/li//text()'
        LANGUAGES_XPATH = '//div[@class="stacked-section-content"]/ul/li//text()'
        ADDRESS_XPATH = '//span[@itemprop="address"]/span/text()'
        AGENT_NUMBERS_XPATH = '//p[contains(text(),"Mobile:")]/span/text()'
        OFFICE_NUMBER_XPATH = '//p[contains(text(),"Office:")]/span/text()|//p[contains(text(),"Phone:")]/span/text()'

        # Extract values using above XPATHs
        name = response.xpath(NAME_XPATH).extract_first('').strip()
        image = response.xpath(IMAGE_XPATH).extract_first('')
        title = response.xpath(TITLE_XPATH).extract_first('').strip()
        office_name = response.xpath(OFFICE_NAME).extract_first('').strip()
        description = response.xpath(DESCRIPTION_XPATH).extract()
        languages = response.xpath(LANGUAGES_XPATH).extract()
        address = response.xpath(ADDRESS_XPATH).extract_first('')
        agent_numbers = response.xpath(AGENT_NUMBERS_XPATH).extract()
        office_numbers = response.xpath(OFFICE_NUMBER_XPATH).extract()

        facebook_url = response.xpath(
            '//div[@class="agent-contacts-actions"]/a[contains(@href,"facebook.com")]/@href').extract_first('')
        linkedin_url = response.xpath(
            '//div[@class="agent-contacts-actions"]/a[contains(@href,"linkedin.com")]/@href').extract_first('')
        instagram_url = response.xpath(
            '//div[@class="agent-contacts-actions"]/a[contains(@href,"instagram.com")]/@href').extract_first('')
        twitter_url = response.xpath(
            '//div[@class="agent-contacts-actions"]/a[contains(@href,"twitter.com")]/@href').extract_first('')
        youtube_url = response.xpath(
            '//div[@class="agent-contacts-actions"]/a[contains(@href,"youtube.com")]/@href').extract_first('')
        googleplus_url = response.xpath(
            '//div[@class="agent-contacts-actions"]/a[contains(@href,"googleplus.com")]/@href').extract_first('')
        pinterest_url = response.xpath(
            '//div[@class="agent-contacts-actions"]/a[contains(@href,"pinterest.com")]/@href').extract_first('')

        # Clean Data
        name = name.split()
        if len(name) == 1:
            first_name = name[0].strip() if name[0] else ''
            middle_name = ''
            last_name = ''
        if len(name) == 2:
            first_name = name[0].strip() if name[0] else ''
            middle_name = ''
            last_name = name[1].strip() if name[1] else ''
        if len(name) == 3:
            first_name = name[0].strip() if name[0] else ''
            middle_name = name[1].strip() if name[1] else ''
            last_name = name[2].strip() if name[2] else ''
        if len(name) >= 4:
            first_name = ' '.join(name)
            middle_name = ''
            last_name = ''
        # image = re.findall('background-image: url\((.*)\)', image)
        image_url = image if image else ''
        if 'user-default' in image_url:
            image_url = ''
        description = ' '.join(' '.join(description).split()
                               ).strip() if description else ''

        lan = []
        for lang in languages:
            language = lang.strip()
            lan.append(language)

        address = address if address else ''

        if 'facebook' in facebook_url:
            facebook_url = facebook_url.strip()
        else:
            facebook_url = ''
        if 'twitter' in twitter_url:
            twitter_url = twitter_url.strip()
        else:
            twitter_url = ''
        if 'linkedin' in linkedin_url:
            linkedin_url = linkedin_url.strip()
        else:
            linkedin_url = ''
        if 'pinterest' in pinterest_url:
            pinterest_url = pinterest_url.strip()
        else:
            pinterest_url = ''
        if 'google' in googleplus_url:
            googleplus_url = googleplus_url.strip()
        else:
            googleplus_url = ''
        if 'www.instagram.com' in instagram_url:
            instagram_url = instagram_url.strip()
        else:
            instagram_url = ''

        other_urls_ = []

        if pinterest_url:
            other_urls_.append(pinterest_url)
        if googleplus_url:
            other_urls_.append(googleplus_url)
        if instagram_url:
            other_urls_.append(instagram_url)

        other_urls = []
        for url in other_urls_:
            if url:
                other_urls.append(url)
            else:
                other_urls = []

        if facebook_url or twitter_url or linkedin_url or other_urls:
            social = {'facebook_url': facebook_url,
                      'twitter_url': twitter_url,
                      'linkedin_url': linkedin_url,
                      'other_urls': other_urls,
                      }
        else:
            social = {}

        agent_numbers = [i.strip() for i in agent_numbers if i.strip()]
        office_numbers = [i.strip() for i in office_numbers if i.strip()]
# ---------------------------------------------------------
        # zipcode = ''
        # zip_1 = ''
        # url = response.url
        # url1 = url.rsplit('/', 2)[-2]
        # zip1 = re.findall(r'\w+$|\d+', url1)
        # if len(zip1) == 0:
        #     zip_1 = ''
        # elif len(zip1) == 1:
        #     zipp__ = ''.join(zip1)
        #     if re.findall(r'^[a-zA-Z]+\d{2}', zipp__):
        #         zip_1 = zip1
        #     elif re.findall(r'^[\d]+', zipp__):
        #         zip_1 = zip1
        #     else:
        #         zip_1 = ''
        # elif len(zip1) == 2:
        #     zip_1 = zip1[0] + '-' + zip1[1]
        # zip_1 = ''.join(zip_1).strip()
        # if zip_1:
        #     if re.search(r'^\d\-', zip_1):
        #         zip_text = response.xpath(
        #             '//span[@itemprop="address"]/span[2]/text()').extract()
        #         zip_text = ''.join(zip_text).strip()
        #         zip_caps = re.findall(r'[A-Z]{2}', zip_text)
        #         zip_caps = ''.join(zip_caps).strip()
        #         zipcode = zip_caps + zip_1
        #     else:
        #         zipcode = zip_1
        # zipcode = ''.join(zipcode).strip()

        # city1 = response.xpath(
        #     '//span[@itemprop="address"]/span[2]/text()').extract()

        # # Canada ZipCode
        # if zipcode == '':
        #     location = ''.join(city1)
        #     postalcode = re.findall(
        #         r'[a-zA-Z]\d[a-zA-Z]\d[a-zA-Z]\d', location)
        #     zipcode = ''.join(postalcode)
# --------------------------------------------------------
        # adress_xpath = response.xpath('//span[@itemprop="address"]/span[2]/text()').extract_first('')
        # if adress_xpath:
        #     pattern = re.findall(r'\d+',adress_xpath)
        #     if pattern:
        #         pattern = pattern[-1]
        #         if pattern in adress_xpath:
        #             zipcode = adress_xpath.split()[-1]
        #             if zipcode:
        #                 zipcode = zipcode
        #     else:
        #         zipcode =''

        #     # zipcode = re.findall(r'[A-Z]+/d+[A-Z]+',''.join(adress_xpath))
        #     # if zipcode:
        #     #     zipcode =  ''.join(zipcode)
        #     # else:
        #     #     zipcode = re.findall(r'[A-Z]+\d+',''.join(adress_xpath))
        #     #     if zipcode:
        #     #         zipcode = ''.join(zipcode)
        #     #     else:
        #     #         zipcode =  re.findall(r'\d+ [A-Z]+',''.join(adress_xpath))
        #     #         if zipcode:
        #     #             zipcode = ''.join(zipcode)
        #     #         else:
        #     #             zipcode = re.findall(r'\d+',''.join(adress_xpath))
        #     #             if zipcode:
        #     #                 zipcode = ''.join(zipcode)
        # city1 = response.xpath('//span[@itemprop="address"]/span[2]/text()').extract()
        # state = ''
        # city = ''
        # if zipcode:

        #     if city1:
        #         if city1[0].replace(zipcode, '').strip().lower().endswith('city'):
        #             citynew = ''.join(city1).split(',')
        #             if len(citynew) == 2:
        #                 city = citynew[0]
        #                 city = ''.join(city)
        #                 state = citynew[1].replace(
        #                     ' city', '').replace('City', '').replace(zipcode, '').strip()
        #                 state = ''.join(state)
        #             elif len(citynew) == 1:
        #                 city = citynew[0].replace(zipcode, '').strip().split(',')
        #                 city = ''.join(city)
        #                 state = ''
        #             else:
        #                 city = ''
        #                 state = ''
        #         else:
        #             citynew = ''.join(city1).split(',')
        #             if len(citynew) == 2:
        #                 city = citynew[0]
        #                 city = ''.join(city)
        #                 state = citynew[1].replace(
        #                     ' city', '').replace(zipcode, '').replace('City', '').strip()
        #                 state = ''.join(state)
        #             elif len(citynew) == 1:
        #                 city = citynew[0].replace(zipcode, '').strip().split(',')
        #                 city = ''.join(city)
        #                 state = ''
        #             else:
        #                 city = ''
        #                 state = ''
        # else:
        #     zipcode = ''
        #     city2 = city1[0].split(',')
        #     if city2:
        #         city3 = city1[0].split(',')[-1]
        #         if city3:
        #             city = city3.strip()
        #         state = city1[0].split(',')[0]
        #         if state:
        #             state = ''.join(state) /////////////////////////// mahesh

        # print(zipcode)

# ------------------------------------------------------------------------------------------------
        zipcode = ''
        zipcode_ = ''
        zip_1 = ''

        url = response.url
        url1 = url.rsplit('/', 2)[-2]
        zip1 = re.findall(r'\w+$|\d+', url1)

        if len(zip1) == 0:
            zip_1 = ''
        elif len(zip1) == 1:
            zipp__ = ''.join(zip1)
            zip__1 = re.findall(r'^[a-zA-Z]+\d{2}', zipp__)
            zip__2 = re.findall(r'^[\d]+', zipp__)
            if zip__1:
                zip_1 = zip1
            elif zip__2:
                if len(zip__2[0]) > 1:

                    zip_1 = zip1
            else:
                zip_1 = ''
        elif len(zip1) == 2:

            zip_1 = zip1[0] + '-' + zip1[1]
            zip_1 = re.sub('-[A-z]+.*', '', zip_1)
        zip_1 = ''.join(zip_1).strip()

        if zip_1:
            if re.search(r'^\d\-', zip_1):
                zip_text = response.xpath(
                    '//span[@itemprop="address"]/span[2]/text()').extract()
                zip_text = ''.join(zip_text).strip()
                zip_caps = re.findall(r'[A-Z]{2}', zip_text)
                zip_caps = ''.join(zip_caps).strip()
                zipcode = zip_caps + zip_1
            else:
                zipcode = zip_1
        zipcode = ''.join(zipcode).strip()

        city1 = response.xpath(
            '//span[@itemprop="address"]/span[2]/text()').extract()

        if zipcode == '':
            location = ''.join(city1)
            postalcode = re.findall(
                r'[a-zA-Z]\d[a-zA-Z]\d[a-zA-Z]\d', location)
            zipcode2 = ''.join(postalcode)
            if zipcode2 == '':
                zipcode3 = re.findall('P.O. Box.*\d+', address)
                if zipcode3:
                    zipcode_ = zipcode3[0].replace('P.O. Box ', '')

            else:
                zipcode_ = zipcode2.strip()
            zipcode = ''.join(zipcode_).strip()
        if len(zip1[0]) > 9:
            zip_text = response.xpath(
                '//span[@itemprop="address"]/span[2]/text()').extract()
            zip_text = zip_text[0].split(' ')
            zipcode = zip_text[-1]
            zipcode = zipcode.strip()

# -------------------------------------------
        state = ''
        city = ''
        if city1:
            if city1[0].replace(zipcode, '').strip().lower().endswith('city'):
                citynew = ''.join(city1).split(',')
                if len(citynew) == 2:
                    city = citynew[0]
                    city = ''.join(city)
                    state = citynew[1].replace(
                        ' city', '').replace('City', '').replace(zipcode, '').strip()
                    state = ''.join(state)
                elif len(citynew) == 1:
                    city = citynew[0].replace(zipcode, '').strip().split(',')
                    city = ''.join(city)
                    state = ''
                else:
                    city = ''
                    state = ''
            else:
                citynew = ''.join(city1).split(',')
                if len(citynew) == 2:
                    city = citynew[0]
                    city = ''.join(city)
                    state = citynew[1].replace(
                        ' city', '').replace(zipcode, '').replace('City', '').strip()
                    state = ''.join(state)
                elif len(citynew) == 1:
                    city = citynew[0].replace(zipcode, '').strip().split(',')
                    city = ''.join(city)
                    state = ''
                else:
                    city = ''
                    state = ''

        email = response.xpath(
            '//a[starts-with(@href,"mailto:")]/@href').extract_first('').replace('mailto:', '')

        if first_name:
            item = ColdwellbankerinternationalItem(
                first_name=first_name,
                middle_name=middle_name,
                last_name=last_name,
                image_url=image_url,
                title=title,
                office_name=office_name,
                description=description,
                languages=lan,
                address=address,
                city=city,
                zipcode=zipcode,
                state=state,
                agent_phone_numbers=agent_numbers,
                office_phone_numbers=office_numbers,
                social=social,
                website='',
                email=email,
                # fax = fax,
                profile_url=response.url,
                country=country,
            )
            print(item)
            db[MONGO_COLLECTION].insert(dict(item))
            # yield item

    # def errback_httpbin(self, failure, url):
    #     pass
    # @classmethod
    # def from_crawler(cls, crawler, *args, **kwargs):
    #     spider = super(ColdwellbankerinternationalSpider, cls).from_crawler(
    #         crawler, *args, **kwargs)
    #     crawler.signals.connect(spider.spider_opened, signals.spider_opened)
    #     crawler.signals.connect(spider.spider_closed, signals.spider_closed)
    #     return spider

    # def spider_opened(self, spider):

    #     print('Opening {} spider'.format(spider.name))

    # def spider_closed(self, spider):
    #     self.spider_ended()
    #     print('Closing {} spider'.format(spider.name))