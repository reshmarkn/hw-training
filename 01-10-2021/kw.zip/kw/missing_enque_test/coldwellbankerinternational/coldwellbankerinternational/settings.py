# -*- coding: utf-8 -*-
from datetime import datetime

now = datetime.now()
day = now.strftime("%D")
month = now.strftime("%b")
year = now.strftime("%Y")
if int(day.split('/')[1]) >= 25:
    cuurent_month = datetime(now.year, now.month + 1, now.day)
    next_month = cuurent_month.strftime("%b")
    dbname = 'kw_' + next_month + '_' + year
else:
    dbname = 'kw_' + month + '_'+year

dbname = 'kw_auto_test1'

BOT_NAME = 'coldwellbankerinternational'

SPIDER_MODULES = ['coldwellbankerinternational.spiders']
NEWSPIDER_MODULE = 'coldwellbankerinternational.spiders'

AUTHOR_EMAIL = ''
# Crawl responsibly by identifying yourself (and your website) on the
# user-agent
USER_AGENT = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'

# Duplicate filtering field in item for both mongo and DC
DUP_KEY = 'profile_url'

DOWNLOAD_DELAY = 2
RETRY_TIMES = 5
RETRY_HTTP_CODES = [500, 502, 503, 504, 400, 403, 408]

# Configure QUEUE
QUEUE_NAME = 'ha.coldwellbankerinternational'
QUEUE_IP = '134.209.174.206'
QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'
# QUEUE_PASS = 'betaqueue123'

# Configure MONGODB
# MONGO_URI = 'mongodb://localhost:27017'  # local
MONGO_URI = 'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017'  # shard
MONGO_DB = 'kw_Mar_2020'
MONGO_COLLECTION = 'coldwellbankerinternational_data_test'
MONGO_COLLECTION_URL = 'coldwellbankerinternational_url_test'

# Enable or disable downloader middlewares
# DOWNLOADER_MIDDLEWARES = {
#     'coldwellbankerinternational.middlewares.RandomUserAgentMiddleware': 100,
#     'coldwellbankerinternational.middlewares.ProxyMiddleware': 110,
#     # 'scrapy.downloadermiddleware.httpproxy.HttpProxyMiddleware': 130,
#     # 'scrapy.downloadermiddleware.httpproxy.HttpProxyMiddleware': 130,
#     # 'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
# }
READ_FROM_FILE = False
# Enable or disable extensions
# EXTENSIONS = {
#     # 'general_validator.GeneralValidator': 100,
#     # 'sc_mongo.ScrapyMongoExtension': 400,
# }

# Configure DC
# SC_MONGO_EXT_ENABLED = True

# Configure item pipelines
# ITEM_PIPELINES = {
#     'coldwellbankerinternational.pipelines.ColdwellbankerinternationalPipeline': 300,
# }

# Obey robots.txt rules
# ROBOTSTXT_OBEY = True

# Configure maximum concurrent requests performed by Scrapy (default: 16)
CONCURRENT_REQUESTS = 20

# Disable cookies (enabled by default)
# COOKIES_ENABLED = False

# Enable and configure the AutoThrottle extension (disabled by default)
# AUTOTHROTTLE_ENABLED = True
