# -*- coding: utf-8 -*-
import pymongo
from scrapy.exceptions import DropItem
from century21global.items import *
from century21global.settings import *
from queue_missing.missing_script import MissingEnqueue
from scrapy import cmdline
import time 

import subprocess
import requests
url_collection_field = 'url'
mongo_collection_field = 'sample_url'
slack_id = 'UQ07UQXCM'
token = 'xoxp-24300212688-816266847429-1001906194901-ea9185ed9081045f47175a604eeaca82'
import logging
handler = logging.FileHandler('script_error.log')
handler.setLevel('INFO')
logging.root.addHandler(handler)
logger = logging.getLogger()

class Century21GlobalPipeline(object):
    print('1111111111111111111111111111111111')

    def __init__(self, settings):
        self.mongo_uri = settings.get('MONGO_URI')
        self.mongo_db = settings.get('MONGO_DB')
        self.mongo_collection = settings.get('MONGO_COLLECTION')
        self.dup_key = settings.get('DUP_KEY')
        self.mongo_collection_url = settings.get('MONGO_URL_COLLECTION')

    @classmethod
    def from_crawler(cls, crawler):
        return cls(
            settings=crawler.settings
        )

    def open_spider(self, spider):
        self.client = pymongo.MongoClient(self.mongo_uri)
        self.db = self.client[self.mongo_db]
        if self.dup_key:
            self.db[self.mongo_collection].create_index(
                self.dup_key, unique=True)

    def close_spider(self, spider):
        if self.db[self.mongo_collection].estimated_document_count() < self.db[self.mongo_collection_url].estimated_document_count():
            a = MissingEnqueue(self.mongo_db, self.mongo_collection_url, url_collection_field,
                               self.mongo_db, self.mongo_collection, mongo_collection_field, QUEUE_IP, QUEUE_NAME, slack_id)
            f = open('missing.txt', 'r')
            missing_file_count = f.readlines()
            if int(''.join(missing_file_count)) != int(str(len(a.out))):
                f = open('missing.txt', 'w')
                f.write(str(len(a.out)))
                f.close()
                missing_count = 'missing count' + str(len(a.out))
                logger.info(missing_count)
                a = subprocess.run("python3 rerun_script.py", shell=True)
                print(a.check_returncode)
                if a.returncode == 0:
                    time.sleep(60)
                    cmdline.execute("scrapy crawl century21global".split())
            else:
                f = open('missing.txt', 'w')
                f.write(str(0))
                f.close()
                logger.info('taking same missing_urls')
                data = {'token': token, 'channel': slack_id,
                        'text': 'taking same missing_urls'}
                requests.post(url='https://slack.com/api/chat.postMessage',
                              data=data)
        else:
            f = open('missing.txt', 'w')
            f.write(str(0))
            f.close()
            logger.info('there is no missing urls')
            data = {'token': token, 'channel': slack_id,
                    'text': 'there is no missing urls'}

            requests.post(
                url='https://slack.com/api/chat.postMessage', data=data)
        # self.client.close()

    def process_item(self, item, spider):
        if isinstance(item, Century21GlobalItem):
            try:
                self.db[self.mongo_collection].insert(dict(item))
            except:
                raise DropItem("Dropping duplicate item")
        return item
        # if isinstance(item, Century21GlobalURLItem):
        #     try:
        #         self.db[self.mongo_collection].insert(dict(item))
        #     except:
        #         raise DropItem("Dropping duplicate item")
        # return item
