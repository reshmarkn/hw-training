# -*- coding: utf-8 -*-
import scrapy


class Century21GlobalItem(scrapy.Item):
    profile_url = scrapy.Field()
    first_name = scrapy.Field()
    middle_name = scrapy.Field()
    last_name = scrapy.Field()
    image_url = scrapy.Field()
    office_name = scrapy.Field()
    address = scrapy.Field()
    description = scrapy.Field()
    languages = scrapy.Field()
    sample_url = scrapy.Field()
    social = scrapy.Field()
    #fax = scrapy.Field()
    city = scrapy.Field()
    zipcode = scrapy.Field()
    state = scrapy.Field()
    agent_phone_numbers = scrapy.Field()
    office_phone_numbers = scrapy.Field()
    country = scrapy.Field()
    email = scrapy.Field()
    title = scrapy.Field()
    website = scrapy.Field()


class Century21GlobalURLItem(scrapy.Item):
    url = scrapy.Field()
