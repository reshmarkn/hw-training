# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
import urllib
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from century21global.items import *
from century21global.settings import *
from century21global.proxy import parse_proxy
from century21global.middlewares import *
from pymongo import MongoClient
from scrapy import signals
import subprocess
# from databasenotifier import automation_script


headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}

db = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@138.197.68.56').kw_Mar_2020

# dbname = 'automation_test_kw'
# collection_name = 'century21global_url'


class Century21GlobalSpider(Spider):
    name = 'century21global_crawler'
    start_urls = ['https://www.century21global.com/real-estate-agents/sitemap']
    allowed_domains = ['www.century21global.com']

    # def spider_ended(self):
        # automation_script.Automation_Spider(dbname, collection_name)
        # subprocess.call("python q_insert.py ", shell=True)

    # def __init__(self):
    #     self.db.century21global_jan_url.create_index(
    #         'url', unique=True)

    def parse(self, response):
        URLS = response.xpath(
            '//ul/li/a[starts-with(@href,"/real-estate-agents/")]/@href').extract()
        for url in URLS:
            url = response.urljoin(url)
            if '/USA' not in url:
                yield Request(url=url, callback=self.parse_urls, headers=headers)

    def parse_urls(self, response):
        urls = response.xpath(
            '//a[@class="search-result-photo result-photo-portrait"]/@href').extract()
        for url in urls:
            url = response.urljoin(url)
            url = {'url': url}
            print(url)
            db[MONGO_URL_COLLECTION].insert(dict(url))
            # f = open('c21url_sept_try5.txt', 'a')
            # f.write(url + '\n')
            # f.close()
            # print(url)

            # item = Century21GlobalURLItem(
            #     url=url
            # )
            # yield item
        next_page = response.xpath(
            '//a[contains(text(),"Next")]/@href').extract_first('')
        if next_page:
            next_ = response.urljoin(next_page)
            yield Request(url=next_, callback=self.parse_urls, headers=headers)

    # @classmethod
    # def from_crawler(cls, crawler, *args, **kwargs):
    #     spider = super(Century21GlobalSpider, cls).from_crawler(
    #         crawler, *args, **kwargs)
    #     crawler.signals.connect(spider.spider_opened, signals.spider_opened)
    #     crawler.signals.connect(spider.spider_closed, signals.spider_closed)
    #     return spider

    # def spider_opened(self, spider):
    #     print('Opening {} spider'.format(spider.name))

    # def spider_closed(self, spider):
    #     print('%%%%%%%%%%%%%%%%%%%%%%%%%%')
    #     self.spider_ended()
    #     # cmdline.execute("scrapy crawl denver_realestate_parser".split())
    #     # subprocess.call('')
    #     print('Closing {} spider'.format(spider.name))
