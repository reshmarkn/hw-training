# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
import urllib
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from century21global.items import *
from century21global.settings import *
from century21global.middlewares import *
from century21global.proxy import parse_proxy
from databasenotifier import automation_script
from scrapy import signals
from pymongo import MongoClient
handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

h = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}
db = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')[MONGO_DB]
# dbname = 'automation_test_kw'
# collection_name = 'century21global'


class Century21GlobalSpider_New(Spider):
    name = 'century21global_new'
    allowed_domains = ['www.century21global.com']

    # def spider_ended(self):
        # automation_script.Automation_Spider(dbname, collection_name)

    def start_requests(self):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        channel = connection.channel()
        while True:
            channel.basic_qos(prefetch_count=1)
            method, properties, url = channel.basic_get(queue=QUEUE_NAME)
            if not url.strip():
                break
            channel.basic_ack(delivery_tag=method.delivery_tag)
            url = str(url.strip(), encoding='utf-8')
            if url.strip():
                # yield Request(url=url.strip(), callback=self.parse, headers=headers, errback=lambda x: self.errback_httpbin(x, url.strip()))
                yield Request(url=url.strip(), callback=self.parse_data, headers=h,meta={'request_url': url.strip(),'sample_url':url.strip()})







        # if READ_FROM_FILE == False:
        #     credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        #     connection = pika.BlockingConnection(pika.ConnectionParameters(
        #         credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        #     channel = connection.channel()
        #     channel.basic_qos(prefetch_count=1)
        #     while True:
        #         try:
        #             method, properties, body = channel.basic_get(
        #                 queue=QUEUE_NAME)
        #             if not body:
        #                 break
        #             publication_url = body.strip()
        #             publication_url = str(publication_url, encoding="utf-8")
        #             channel.basic_ack(delivery_tag=method.delivery_tag)
        #             connection.close()
        #             if publication_url:
        #                 print(publication_url, '****')
        #                 yield Request(url=publication_url, callback=self.parse_data,headers=headers, meta={'request_url': publication_url, 'sample_url': publication_url})

        #         except:
        #             connection = pika.BlockingConnection(pika.ConnectionParameters(
        #                 credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        #             channel = connection.channel()
        #             channel.basic_qos(prefetch_count=1)

    def parse_data(self, response):
        publication_url = response.meta['sample_url']
        NAME_XPATH = '//h2//text()'
        OFFICE_NAME_XPATH = '//h2/a/text()'
        LANGUAGES_XPATH = '//div[@class="detail-data-secondary"]/text()'
        DESCRIPTION_XPATH = '//div[@class="remarksSection"]//text()'
        # PHONE_XPATH = '//div[@class="detail-data-primary"]//text()'
        IMAGE_XPATH = '//img[@class="detail-image-primary"]/@src'
        LOCATION_XPATH = '//div[@class="detail-data-primary"]/text()'

        # Extract values using above XPATHs
        name = response.xpath(NAME_XPATH).extract_first('')
        office_name = response.xpath(OFFICE_NAME_XPATH).extract_first('')
        languages = response.xpath(LANGUAGES_XPATH).extract()
        description = response.xpath(DESCRIPTION_XPATH).extract()
        # phone = response.xpath(PHONE_XPATH).extract()
        image = response.xpath(IMAGE_XPATH).extract_first('')
        location = response.xpath(LOCATION_XPATH).extract()
        state = ''
        # Clea Data
        agent_name = name.replace('-', ' ').split()
        first_name = ''
        middle_name = ''
        last_name = ''
        if '&' in agent_name:
            first_name = name.strip()
        else:
            if len(agent_name) == 1:
                first_name = agent_name[0]
                middle_name = ''
                last_name = ''
            if len(agent_name) == 2:
                first_name = agent_name[0]
                middle_name = ''
                last_name = agent_name[1]
            if len(agent_name) == 3:
                first_name = agent_name[0]
                middle_name = agent_name[1]
                last_name = agent_name[2]
            if len(agent_name) >= 4:
                first_name = name.strip()
                middle_name = ''
                last_name = ''

        languages = ' '.join(''.join(languages).replace(':', '').split())
        language = languages.split(',')
        language_ = []
        for lang in language:
            lang_ = lang.strip()
            language_.append(lang_)

        if language_ == ['']:
            language_ = []

        description = ' '.join(
            ' '.join(description).split()).strip() if description else ''

        PHONE_XPATH = '//div[@class="detail-data-primary"]//text()'
        phone = response.xpath(PHONE_XPATH).extract()
        phone = [phone_text.strip()
                 for phone_text in phone if phone_text.strip()]
        agent_phn = []
        office_phn = []
        for phn in phone:
            if re.findall(r'Cell Phone:\s+?(.*)', phn):
                agent_num = re.findall(
                    r'Cell Phone:\s?(.*)', phn)[0].strip()
                agent_phn.append(agent_num)
            elif re.findall(r'Phone:\s+?(.*)', phn):
                office_num = re.findall(r'Phone:\s?(.*)', phn)[0].strip()
                office_phn.append(office_num)
        if 'https' not in image:
            image = 'https://www.century21global.com'+image

        if 'noPhoto-agent' in image:
            image = ''
        location = ' '.join(' '.join(location).split()
                            ).strip() if location else ''
        country = response.xpath(
            '//span[@class="title"]/following-sibling::a[1]/text()').extract()
        country = ''.join(country).strip()

        states = response.xpath(
            '//span[@class="title"]/following-sibling::a[2]/text()').extract()
        if states:
            states = ''.join(states).strip()
            state = states.replace('city', '').strip()
        else:
            states = response.xpath(
                '//div[@class="detail-data-primary"]//text()').extract()[1]
            states = states.strip()

        city = response.xpath(
            '//span[@class="title"]/following-sibling::a[3]/text()').extract()
        city = ''.join(city).strip()
        if city == '':
            city = state
            state = ''

        # ------------------------------------------------------------------
        # zip_ = re.findall(r'[A-Z]\d[A-Z] *\d[A-Z]\d', location)
        # zipcode = ''.join(zip_).strip()
        # if zipcode == '':
        #     zip_ = re.findall(r'[0-9]{4,7}', location)
        #     for num in zip_:
        #         if re.findall(r'\d{4}', num):
        #             zip_ = num
        #         elif re.findall(r'\d{3]', num):
        #             zip_ = num
        #     zipcode = ''.join(zip_).strip()
            # zip_ = re.findall(r'[A-Z]\d[A-Z] *\d[A-Z]\d', location)
        # ------------------------------------------------------------------
        zipcode = ''
        zip_ = re.findall(r'[A-Z]\d[A-Z] *\d[A-Z]\d', location)
        zipcode = ''.join(zip_).strip()
        zipcode = ''.join(zip_).strip()
        # if zipcode == '':
        #     zip_ = re.findall(r'[0-9]{4,5}', location)
        # if zip_:
        #     zip_ = zip_[0]
        #     zipcode = ''.join(zip_).strip()

        if zipcode == '':
            destination = response.xpath(
                '//div[@class="detail-data-primary"]/text()').extract()
            # print('@@@@@@@@@@@@@@@@@', destination)
            loc = []

            for content in [content.strip() for content in destination if content.strip()]:

                if 'phone' not in content.lower():
                    loc.append(content)
            # print('@@@@@@@@@@@@@@', loc)
            locs = []
            for content in [content.strip() for content in loc if content.strip()]:

                if 'fax' not in content.lower():
                    locs.append(content)
            # locs = ' '.join(loc).strip()
            for num in locs:
                zip_ = re.findall(r'[0-9]{3,7}', num)
                # print(zip_)
                if zip_:
                    zipcode = zip_
            if len(zipcode) == 2:
                zipcode = '-'.join(zipcode).strip()
            else:
                zipcode = ' '.join(zipcode).strip()

            # if ('.') in loc[0]:
            #     zip_ = loc[0]
            #     zipcode = zip_.split(',')[-1]
            # else:
            #     zipcode = loc[1].split()[-1]

            # count = 0
            # print('@@@@@@@@@@', loc)
            # for zips in loc:

            #     if '.' in loc[count]:
            #         zips_ = loc[0].split('.')
            #         zip_ = zips_[-1]
            #         count += 1
            #     if count == 1:
            #         zips_ = loc[1].split(' ')
            #         zip_ = zips_[-1]

            #         # zip_ = re.findall(r'[0-9]{3,8}', zips[count])
            #         break
        # if zip_:
        #     zip_ = zip_[0]
        #     zipcode = ''.join(zip_).strip()
        # zipcode = zipcode[0] if zipcode else ''
        address_ = location.split(city)[0] if city else ''
        address_ = ''.join(address_).strip(', ')
        address = ''
        if address_ == '':
            address = response.xpath(
                '//div[@class="detail-data-primary"]/text()').extract_first('').strip()
        else:
            address = address_

        # Removing Foreign Characters
        url = response.url
        profile_url = urllib.parse.unquote_plus(url)
        office = urllib.parse.unquote_plus(office_name)
        address = urllib.parse.unquote_plus(address)
        sample_url = publication_url
        # yield item
        if first_name:
            item = Century21GlobalItem(
                profile_url=profile_url,
                first_name=first_name,
                middle_name=middle_name,
                last_name=last_name,
                image_url=image,
                office_name=office,
                email='',
                title='',
                website='',
                address=address,
                description=description,
                languages=language_,
                sample_url=sample_url,
                city=city,
                social={},
                zipcode=zipcode,
                state=state,
                agent_phone_numbers=agent_phn,
                office_phone_numbers=office_phn,
                country=country,
            )
            print(item)
            db[MONGO_COLLECTION].insert(dict(item))
    #         yield item
    #         # print(item)

    # def errback_httpbin(self, failure, url):
    #     credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
    #     connection = pika.BlockingConnection(pika.ConnectionParameters(
    #         credentials=credentials, host=QUEUE_IP, socket_timeout=600))
    #     channel = connection.channel()
    #     channel.queue_declare(queue=QUEUE_NAME, durable=True)
    #     channel.basic_publish(exchange='', routing_key=QUEUE_NAME, body=url)
    #     connection.close()

    # @classmethod
    # def from_crawler(cls, crawler, *args, **kwargs):
    #     spider = super(Century21GlobalSpider, cls).from_crawler(
    #         crawler, *args, **kwargs)
    #     crawler.signals.connect(spider.spider_opened, signals.spider_opened)
    #     crawler.signals.connect(spider.spider_closed, signals.spider_closed)
    #     return spider

    # def spider_opened(self, spider):
    #     print('Opening {} spider'.format(spider.name))

    # def spider_closed(self, spider):
    #     print('%%%%%%%%%%%%%%%%%%%%%%%%%%')
    #     self.spider_ended()
    #     # cmdline.execute("scrapy crawl denver_realestate_parser".split())
    #     # subprocess.call('')
    #     print('Closing {} spider'.format(spider.name))
