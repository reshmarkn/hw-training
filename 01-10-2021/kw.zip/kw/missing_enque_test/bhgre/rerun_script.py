# # import subprocess
# # from scrapy import cmdline
# from bhgre.settings import *
# # spider =['bhgre1','bhgre']
# # for i in spider:
# # 	cmdline.execute("scrapy crawl "+''.join(i).split())

# # subprocess.call('for spider in bhgre1 bhgre; do scrapy crawl $spider -L INFO; done', shell=True)
# # cmdline.execute("scrapy crawl bhgre1".split(),shell=True)
# # cmdline.execute("scrapy crawl bhgre".split(),shell=True)
# import scrapy
# from scrapy.crawler import CrawlerProcess

# # from bhgre.bhgre_spiders import *
# # from bhgre.bhrge_new import *

# # process = CrawlerProcess()
# # process.crawl(bhgre1)
# # process.crawl(bhgre)
# # process.start()
# from scrapy.crawler import CrawlerProcess
# from bhgre.spiders import Bhgre_new

# process = CrawlerProcess()
# process.crawl(bhgre1)
# process.start()



from scrapy.utils.project import get_project_settings
from scrapy.crawler import CrawlerProcess

setting = get_project_settings()
process = CrawlerProcess(setting)
print(process.spiders.list())
spider_list = process.spiders.list()
# spiders = spider_list[:-1]
spiders =['bhgre','bhgre','bhgre','bhgre1']

for spider_name in spiders:
    print ("Running spider %s" % (spider_name))
#     if 'bhgre_urls' in spider_name:
    process.crawl(spider_name,query="dvh") #query dvh is custom argument used in your scrapy
process.start()
