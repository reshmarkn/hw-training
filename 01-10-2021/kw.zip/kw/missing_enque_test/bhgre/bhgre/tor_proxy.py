import random
import base64
# from scrapy.conf import settings
# from scrapy import log
import random
from requests.auth import HTTPProxyAuth


def parse_proxy():
    # proxy = random.choice(PROXY_LIST)

    proxies = {"http": "http://68.183.58.145:5566",
               "https": "http://157.230.189.5:5566"}

    # proxies = {"http": "http://5.79.66.2:13200",
    #            "https": "https://5.79.66.2:13200", }

    # proxies = {}
    # log.msg("Proxy added")
    print('proxy added')
    return {'proxies': proxies}
