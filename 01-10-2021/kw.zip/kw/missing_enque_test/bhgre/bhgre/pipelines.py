# import slack
# -*- coding: utf-8 -*-

from pymongo import MongoClient
from bhgre.items import *
from bhgre.settings import *
from queue_missing.missing_script import MissingEnqueue
import subprocess
import requests
import logging
handler = logging.FileHandler('script_error.log')
handler.setLevel('INFO')
logging.root.addHandler(handler)
logger = logging.getLogger()


# MONGO_DB = 'kw_Mar_2020'
# MONGODB_COLLECTION = 'bhgre_test'
# qhost = '134.209.174.206'
# qname = 'ha.bhgre_test'
slack_id = 'UQ07UQXCM'
token = 'xoxp-24300212688-816266847429-1001906194901-ea9185ed9081045f47175a604eeaca82'

class BhgrePipeline(object):
    print('1111111111111111111111111111111111111111111111111')

    def __init__(self, *args, **kwargs):
        # self.client = MongoClient().kw
        self.db = MongoClient(
            'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')[DB_NAME]
        # self.db[MONGODB_COLLECTION].create_index('', unique=True)

    # def process_item(self, item, spider):
    #     if isinstance(item, BhgreItem):
    #         # try:
    #         self.db[MONGODB_COLLECTION].insert(dict(item))

    def close_spider(self, spider):
        print('222222222222222222222222222222222222222')
        url_collection_field = 'url'
        MONGODB_COLLECTION_field = 'profile_url'
        if db[MONGODB_COLLECTION].estimated_document_count() < db[url_collection].estimated_document_count():
            a = MissingEnqueue(DB_NAME, MONGODB_URL_COLLECTION, url_collection_field, DB_NAME,
                               MONGODB_COLLECTION, MONGODB_COLLECTION_field, QUEUE_IP, QUEUE_NAME, slack_id)
            f = open('missing.txt', 'r')
            missing_file_count = f.readlines()
            if int(''.join(missing_file_count)) != int(str(len(a.out))):
                f = open('missing.txt', 'w')
                f.write(str(len(a.out)))
                f.close()
                missing_count = 'missing count' +str(len(a.out)) 
                logging.info(missing_count)
                subprocess.call("python rerun_script.py ", shell=True)
            else:
                f = open('missing.txt', 'w')
                f.write(str(0))
                f.close()
                logging.info('taking same missing_urls')
                data = {'token': token, 'channel': slack_id, 'text':'taking same missing_urls'}
                requests.post(url='https://slack.com/api/chat.postMessage',
                      data=data)
        else:
            f = open('missing.txt', 'w')
            f.write(str(0))
            f.close()
            logging.info('there is no missing urls')
            data = {'token': token, 'channel': slack_id, 'text':'there is no missing urls'}
            
            requests.post(url='https://slack.com/api/chat.postMessage',data=data)
            # client.chat_postMessage(
            #         channel=slack_user, text='no more missing urls')

