import json
import requests

# -*- coding: utf-8 -*-

# Scrapy settings for century21 project
#
# For simplicity, this file contains only settings considered important or
# commonly used. You can find more settings consulting the documentation:
#
#     http://doc.scrapy.org/en/latest/topics/settings.html
#     http://scrapy.readthedocs.org/en/latest/topics/downloader-middleware.html
#     http://scrapy.readthedocs.org/en/latest/topics/spider-middleware.html

BOT_NAME = 'century21'
DUP_KEY = ''

DOWNLOAD_DELAY = 2
RETRY_TIMES = 5
RETRY_HTTP_CODES = [500, 502, 503, 504, 400, 403, 408, 405]

SPIDER_MODULES = ['century21.spiders']
NEWSPIDER_MODULE = 'century21.spiders'

# COLLECTION_NAME = 'century21'
MONGO_USER = "datahut"
MONGO_PASS = "cGFzc21lMTIz"
MONGO_PORT = "27017"
AUTHOR_NAME = 'divya'
AUTHOR_EMAIL = 'divya@datahut.co'

SC_MONGO_EXT_ENABLED = True
EXTENSIONS = {
    # 'sc_mongo.ScrapyMongoExtension': 400,
    # 'general_validator.GeneralValidator': 100,
}
READ_FROM_FILE = False

QUEUE_IP = '134.209.174.206'
QUEUE_NAME = 'ha.century21_test'
QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'
MONGO_DB = 'kw_Mar_2020'
URL_COLLECTION ='century21_us_url_test'
MONGODB_COLLECTION = 'century21_us_test1'
# DOWNLOADER_MIDDLEWARES = {
#     'century21.middlewares.RandomUserAgentMiddleware': 100,
#     'century21.middlewares.ProxyMiddleware': 110,
#     #     'scrapy.contrib.downloadermiddleware.useragent.UserAgentMiddleware': 120,
#     #     'scrapy.contrib.downloadermiddleware.httpproxy.HttpProxyMiddleware': 130,
# }
# ITEM_PIPELINES = {
#     'century21.pipelines.Century21Pipeline': 300,
# }
# EXTENSIONS = {
#     'general_validator.GeneralValidator': 100,
# }
# Crawl responsibly by identifying yourself (and your website) on the user-agent
# USER_AGENT = 'century21 (+http://www.yourdomain.com)'

# Obey robots.txt rules
# ROBOTSTXT_OBEY = True

# Configure maximum concurrent requests performed by Scrapy (default: 16)
CONCURRENT_REQUESTS = 1

# Configure a delay for requests for the same website (default: 0)
# See http://scrapy.readthedocs.org/en/latest/topics/settings.html#download-delay
# See also autothrottle settings and docs
# DOWNLOAD_DELAY = 3
# The download delay setting will honor only one of:
# CONCURRENT_REQUESTS_PER_DOMAIN = 16
# CONCURRENT_REQUESTS_PER_IP = 16

# Disable cookies (enabled by default)
COOKIES_ENABLED = False

# PROXY_LIST = requests.get('http://68.183.58.145/stormproxies?type=3',
#                           headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
# PROXY_LIST = requests.get('http://68.183.58.145/microleavesproxies?type=3',
#                           headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()

# Disable Telnet Console (enabled by default)
# TELNETCONSOLE_ENABLED = False

# Override the default request headers:
# DEFAULT_REQUEST_HEADERS = {
#   'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
#   'Accept-Language': 'en',
# }

# Enable or disable spider middlewares
# See http://scrapy.readthedocs.org/en/latest/topics/spider-middleware.html
# SPIDER_MIDDLEWARES = {
#    'century21.middlewares.Century21SpiderMiddleware': 543,
# }

# Enable or disable downloader middlewares
# See http://scrapy.readthedocs.org/en/latest/topics/downloader-middleware.html
# DOWNLOADER_MIDDLEWARES = {
#    'century21.middlewares.MyCustomDownloaderMiddleware': 543,
# }

# Enable or disable extensions
# See http://scrapy.readthedocs.org/en/latest/topics/extensions.html
# EXTENSIONS = {
#    'scrapy.extensions.telnet.TelnetConsole': None,
# }

# Configure item pipelines
# See http://scrapy.readthedocs.org/en/latest/topics/item-pipeline.html

# Enable and configure the AutoThrottle extension (disabled by default)
# See http://doc.scrapy.org/en/latest/topics/autothrottle.html
# AUTOTHROTTLE_ENABLED = True
# The initial download delay
# AUTOTHROTTLE_START_DELAY = 5
# The maximum download delay to be set in case of high latencies
# AUTOTHROTTLE_MAX_DELAY = 60
# The average number of requests Scrapy should be sending in parallel to
# each remote server
# AUTOTHROTTLE_TARGET_CONCURRENCY = 1.0
# Enable showing throttling stats for every response received:
# AUTOTHROTTLE_DEBUG = False

# Enable and configure HTTP caching (disabled by default)
# See http://scrapy.readthedocs.org/en/latest/topics/downloader-middleware.html#httpcache-middleware-settings
# HTTPCACHE_ENABLED = True
# HTTPCACHE_EXPIRATION_SECS = 0
# HTTPCACHE_DIR = 'httpcache'
# HTTPCACHE_IGNORE_HTTP_CODES = []
# HTTPCACHE_STORAGE = 'scrapy.extensions.httpcache.FilesystemCacheStorage'

# PROXY_LIST = requests.get('http://68.183.58.145/microleaves?',
#                           headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
# PROXY_LIST = requests.get('http://68.183.58.145/torproxies?type=3',
#                           headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
