import scrapy
from scrapy.http import Request
from century21.items import *
from century21.settings import *
from scrapy.selector import Selector
from century21.proxy import *
from pymongo import MongoClient
from scrapy.shell import inspect_response
from scrapy import signals


import string
import re
import json
import logging
import requests
import time
import urllib3
import pika

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False
urllib3.disable_warnings()
db = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')[MONGO_DB]
dbname = 'kw_Apr_2020'
collection_name = 'century21_us'
headers={'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
'accept-encoding':'gzip, deflate',
'accept-language':'en-US,en;q=0.9,ml;q=0.8',
'upgrade-insecure-requests':'1',
'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'}
# headers = {
#     "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
#     "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
#     "cache-control": "no-cache",
#     "upgrade-insecure-requests": "1",
#     "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36"
# }


PROXY_LIST = ['68.183.58.145:5566','157.230.189.5:5566']
PROXY = random.choice(PROXY_LIST)
proxy_url = "http://%s" % PROXY
proxies = {"http": "http://%s" % PROXY,
            "https": "http://%s" % PROXY}


class Century21SpiderSpider_new(scrapy.Spider):
    name = "century21_spider_new1"
    allowed_domains = ["century21.com"]
    start_urls = ['https://www.century21.com/']

    def parse(self, response):
        if READ_FROM_FILE == False:
            credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
            connection = pika.BlockingConnection(pika.ConnectionParameters(
                credentials=credentials, host=QUEUE_IP, socket_timeout=300))
            channel = connection.channel()
            channel.basic_qos(prefetch_count=1)
            while True:
                try:
                    method, properties, body = channel.basic_get(
                        queue=QUEUE_NAME)
                except:
                    credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
                    connection = pika.BlockingConnection(pika.ConnectionParameters(
                        credentials=credentials, host=QUEUE_IP, socket_timeout=300))
                    channel = connection.channel()
                    channel.basic_qos(prefetch_count=1)
                    method, properties, body = channel.basic_get(
                        queue=QUEUE_NAME)
                if not body:
                    break
                publication_url = body.strip()
                publication_url = str(publication_url, encoding="utf-8")
                channel.basic_ack(delivery_tag=method.delivery_tag)
                # proxy = parse_proxy()
                # proxies = proxy['proxies']
                response = ''
                try:
                    response = requests.get(
                        publication_url, headers=headers,  proxies=proxies, verify=False)
                    # print('111111111111', response)
                except:
                    try:
                        response = requests.get(
                            publication_url, headers=headers,  proxies=proxies, verify=False)
                    except:
                        pass
                if response and response.status_code == 200:
                    self.parse_data(response, publication_url)

            connection.close()

    def parse_data(self, response, publication_url):
        # inspect_response(response, self)
        sel = Selector(text=response.content)
        city = ''
        state = ''
        zip_ = ''
        first_name = ''
        middle_name = ''
        last_name = ''
        description_ = ''
        description1 = ''
        description = ''
        image_url = ''
        company_name1 = ''
        ph_num = ''
        number = ''
        location = ''
        citystate = ''
        citystate1 = ''
        state_ = ''
        address_ = ''
        address_office = []
        social = {}

        CO_NAME = '//h1//text()'
        IMAGE_URL = '//img[@itemprop="image"]/@src'
        PHONENUM = '//a[@itemprop="telephone"][1]/text()'
        MOBILENUM = '//a[@itemprop="telephone"][2]/text()'
        LANGUAGES_XAPTH = '//span[@itemprop="availableLanguage"]//text()'
        ADDRESS = '//div[@class="addressBlock"]/text()'
        NAME = '//span[@itemprop="name"]/text()'

        co_name = sel.xpath(CO_NAME).extract()
        image_url = sel.xpath(IMAGE_URL).extract()
        phonenum = sel.xpath(PHONENUM).extract()
        mobilenum = sel.xpath(MOBILENUM).extract()
        languages = sel.xpath(LANGUAGES_XAPTH).extract()
        address = sel.xpath(ADDRESS).extract()
        name = sel.xpath(NAME).extract()
        names1 = ''.join(name).split(' ')
        if len(names1) >= 4:
            first_name = name[0]
        else:
            names = ''.join(name).split(' ')
            if len(names) == 1:
                first_name = names[0].replace(',', '')
                middle_name = ''
                last_name = ''
            if len(names) == 2:
                first_name = names[0].replace(',', '')
                middle_name = ''
                last_name = names[1].replace(',', '')
            if len(names) == 3:
                first_name = names[0].replace(',', '')
                middle_name = names[1].replace(',', '')
                last_name = names[2].replace(',', '')

        co_name = ' '.join(''.join(co_name).strip().split()) if co_name else ''
        if '21' in co_name:
            company_name = co_name.split(' 21 ')
            if 'Affiliated' in company_name:
                ''
            else:
                company_name1 = company_name[1]

        image_url = ''.join(image_url) if image_url else ''

        lan = []
        for lang in languages:
            language = lang.strip()
            lan.append(language)

        mobilenum = [x.strip().replace('Mobile: ', '').replace('tel:', '').replace(
            ' (mobile)', '') for x in mobilenum] if mobilenum else []
        phonenum = [x.strip().replace('Mobile: ', '').replace('tel:', '').replace('Office: ', '')
                    for x in phonenum] if phonenum else []

        if 'png' in image_url:
            image_url = ''
        else:
            if 'no-agent' in image_url:
                image_url = ''
            else:
                image_url = image_url

        address = [x.strip() for x in address] if address else []
        address = [x.strip() for x in address if x] if address else []
        address_office = [x.strip()
                          for x in address_office] if address_office else []
        address_office = [x.strip()
                          for x in address_office if x] if address_office else []
        address_office = ' '.join(
            address_office).strip() if address_office else ''
        if len(address) >= 2:
            address_ = address[0].strip()
            city_state_zip = address[1].strip()
            if ',' in city_state_zip:
                city_state_zip_list = city_state_zip.split(',')
                if len(city_state_zip_list) == 2:
                    city = city_state_zip_list[0].strip()
                    zip_ = re.findall(r'\d+', city_state_zip_list[1])
                    zip_ = zip_[0].strip() if zip_ else ''
                    state = city_state_zip_list[1].strip(
                        zip_).strip() if zip_ else city_state_zip_list[1].strip()
        if len(address) >= 3:
            address_ = address[0].strip()
            city_state_zip = address[2].strip()
            if ',' in city_state_zip:
                city_state_zip_list = city_state_zip.split(',')
                if len(city_state_zip_list) == 2:
                    city = city_state_zip_list[0].strip()
                    zip_ = re.findall(r'\d+', city_state_zip_list[1])
                    zip_ = zip_[0].strip() if zip_ else ''
                    state = city_state_zip_list[1].strip(
                        zip_).strip() if zip_ else city_state_zip_list[1].strip()
        description = sel.xpath(
            '//span[@itemprop="description"]//text()').extract()
        if description:
            description = sel.xpath(
                '//span[@itemprop="description"]//text()').extract()
            description1 = description
            description_ = ' '.join(description1).split()
            description_ = ' '.join(description_)
            description_ = description_ if description_ else ''
        else:
            response1 = ''
            description_url = sel.xpath(
                '//a[@class="agentwebpage"]//@href').extract_first()
            if description_url:

                # try:
                response1 = requests.get(
                    description_url, headers=headers,  proxies=proxies, verify=False)
                # except Exception as e:
                #     pass
                if response1.status_code == 200:
                    # print(response1.content, '9999999999999999999999')
                    sel1 = Selector(text=response1.content)
                    description = sel1.xpath(
                        '//div[@class="col-sm-6 col-md-7 col-lg-8"]//text() | //div[@class="col-sm-6 col-md-7 col-lg-8"]//h2//text() | //div[@class="col-xs-12"]//p//text()').extract()
                    description1 = description
                    description_ = ' '.join(description1).split()
                    description_ = ' '.join(description_)
                    description_ = description_ if description_ else ''
                else:
                    description_ = ''

        items = Century21Item(
            profile_url=response.request.url,
            first_name=first_name,
            middle_name=middle_name,
            last_name=last_name,
            image_url=image_url,
            office_name=company_name1,
            address=address_,
            description=description_,
            languages=lan,
            social={},
            website='',
            email='',
            title='',
            country='Unites States',
            # fax=faxnum,
            city=city,
            zipcode=zip_,
            state=state,
            agent_phone_numbers=mobilenum,
            office_phone_numbers=phonenum,
        )
        # print(items)
        if first_name:
            if 'jsessionid' in response.url.lower():
                pass
                # db.failed_items.insert({'url': response.url})
                # db.failed_items1.insert({'url': response.request.url})
                # db.failed_items2.insert({'url': publication_url})
            else:
                db[MONGODB_COLLECTION].insert(dict(items))

    def errback_httpbin(self, publication_url):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=600))
        channel = connection.channel()
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=publication_url)
        connection.close()

    # @classmethod
    # def from_crawler(cls, crawler, *args, **kwargs):
    #     spider = super(Century21SpiderSpider, cls).from_crawler(
    #         crawler, *args, **kwargs)
    #     crawler.signals.connect(spider.spider_opened, signals.spider_opened)
    #     crawler.signals.connect(spider.spider_closed, signals.spider_closed)
    #     return spider

    # def spider_opened(self, spider):

    #     print('Opening {} spider'.format(spider.name))

    # def spider_closed(self, spider):
    #     self.spider_ended()
    #     print('Closing {} spider'.format(spider.name))
