import scrapy
import string
from io import StringIO
import io
from scrapy.http import Request, FormRequest
from xml.dom import minidom
import gzip
from pymongo import MongoClient
from century21.settings import *
from scrapy import signals
import subprocess
from century21.proxy import *


headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36'}

db = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')[MONGO_DB]
# dbname = '.kw_Apr_2020'
# collection_name = 'century21_us_url_new'


class Century21Url(scrapy.Spider):
    name = 'century21_url'
    start_urls = ['https://www.century21.com/c21sitemaps/sitemapc21agents.xml']

    allowed_domains = ['century21.com']

    a = []


        # subprocess.call("python q_insert.py ", shell=True)

    def parse(self, response):

        xmldoc = minidom.parseString(response.body)
        LOCS = xmldoc.getElementsByTagName('loc')
        for loc in LOCS:
            p_url = loc.childNodes[0].data
            p_url = p_url.strip()
            yield Request(p_url, callback=self.parse_url, headers=headers)

    def parse_url(self, response):

        compressedFile = io.BytesIO()
        compressedFile.write(response.body)
        compressedFile.seek(0)
        decompressedFile = gzip.GzipFile(fileobj=compressedFile, mode='rb')
        sitemap_data = decompressedFile.read()
        xmldoc = minidom.parseString(sitemap_data)
        LOCS = xmldoc.getElementsByTagName('loc')
        # print(LOCS)
        for loc in LOCS:
            p_url = loc.childNodes[0].data
            # print(p_url)
            if 'www.century21.com' in p_url:
                if '/buying-a-house' in p_url:
                    p_url = p_url.replace('/buying-a-house', '')
                if '/selling-a-house' in p_url:
                    p_url = p_url.replace('/selling-a-house', '')
                urls = {'url': p_url}
                db[URL_COLLECTION].insert(dict(urls))

    # @classmethod
    # def from_crawler(cls, crawler, *args, **kwargs):
    #     spider = super(Century21Url, cls).from_crawler(
    #         crawler, *args, **kwargs)
    #     crawler.signals.connect(spider.spider_opened, signals.spider_opened)
    #     crawler.signals.connect(spider.spider_closed, signals.spider_closed)
    #     return spider

    # def spider_opened(self, spider):
    #     print('Opening {} spider'.format(spider.name))

    # def spider_closed(self, spider):
    #     print('%%%%%%%%%%%%%%%%%%%%%%%%%%')
    #     self.spider_ended()
    #     print('Closing {} spider'.format(spider.name))
