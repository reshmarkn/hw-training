from pymongo import MongoClient
from century21.items import *
from century21.settings import *
from queue_missing.missing_script import MissingEnqueue
import subprocess
from century21.settings import *
import time
from scrapy import cmdline
slack_id = 'UQ07UQXCM'
token = 'xoxp-24300212688-816266847429-1001906194901-ea9185ed9081045f47175a604eeaca82'
import logging
handler = logging.FileHandler('script_error.log')
handler.setLevel('INFO')
logging.root.addHandler(handler)
logger = logging.getLogger()
# MONGODB_COLLECTION_EXTRA_URLS = 'sept_data'
URL_COLLECTION_FIELD = 'url'
MONGODB_COLLECTION_FIELD = 'profile_url'

class Century21Pipeline(object):
    print('11111111111111111111111111111111111111111111111111111')

    def __init__(self, *args, **kwargs):
        self.client = MongoClient(
            'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')
        self.db = self.client[MONGO_DB]
        self.db[MONGODB_COLLECTION].create_index('profile_url', unique=True)
        # self.db[MONGODB_COLLECTION_EXTRA_URLS].create_index('not_found_url',unique=True)

    # def process_item(self, item, spider):
    #     if isinstance(item, Century21Item):
    #         # try:
    #         self.db[MONGODB_COLLECTION].insert(
    #             dict(item), check_keys=False)
    #         # except:
    #         #     pass
    #         return item
    def close_spider(self, spider):
        if self.db[MONGODB_COLLECTION].estimated_document_count() < self.db[URL_COLLECTION].estimated_document_count():
            a = MissingEnqueue(MONGO_DB, URL_COLLECTION, URL_COLLECTION_FIELD,MONGO_DB,
                               MONGODB_COLLECTION, MONGODB_COLLECTION_FIELD, QUEUE_IP, QUEUE_NAME, slack_id)
            f = open('missing.txt', 'r')
            missing_file_count = f.readlines()
            if int(''.join(missing_file_count)) != int(str(len(a.out))):
                f = open('missing.txt', 'w')
                f.write(str(len(a.out)))
                f.close()
                missing_count = 'missing count' +str(len(a.out)) 
                logger.info(missing_count)
                a =subprocess.run("python3 rerun_script.py", shell=True)
                # print(a.check_returncode,'running deatils')
                if a.returncode == 0:
                    time.sleep(60)
                    print('running compltedley')
                    cmdline.execute("scrapy crawl century21_spider_new".split())
            else:
                f = open('missing.txt', 'w')
                f.write(str(0))
                f.close()
                logging.info('taking same missing_urls')
                data = {'token': token, 'channel': slack_id, 'text':'taking same missing_urls'}
                requests.post(url='https://slack.com/api/chat.postMessage',
                      data=data)
                # subprocess.call("python q_local_deltion.py -l QUEUE_IP QUEUE_NAME", shell=True)

        else:
            f = open('missing.txt', 'w')
            f.write(str(0))
            f.close()
            logging.info('there is no missing urls')
            data = {'token': token, 'channel': slack_id, 'text':'there is no missing urls'}
            
            requests.post(url='https://slack.com/api/chat.postMessage',data=data)

