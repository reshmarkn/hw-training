import logging
import random
import requests
from century21.settings import *
import json
logger = logging.getLogger(__name__)


def parse_proxy():
	PROXY_LIST = [
			# "5.79.66.2:13200"
			'68.183.58.145:5566',
        '157.230.189.5:5566'
	]
	PROXY = random.choice(PROXY_LIST)
	proxy_url = "http://%s" % PROXY
	proxies = {"http": "http://%s" % PROXY,
					   "https": "http://%s" % PROXY}
	logger.debug("Proxy added")
	return {'proxies': proxies, 'proxy_url': proxy_url}
