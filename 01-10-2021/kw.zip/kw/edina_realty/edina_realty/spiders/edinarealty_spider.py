from scrapy.http import Request, FormRequest
import scrapy
import json
import requests
import re
from edina_realty.proxy import parse_proxy
from scrapy.spiders import Spider
from edina_realty.settings import *
from edina_realty.items import *

headers = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding": "gzip, deflate, br",
    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8,ml;q=0.7",
    "upgrade-insecure-requests": "1",
    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36"}


class Edina_RealtySpider(Spider):
    name = 'edinarealty'

    headers1 = {'Accept': 'application/json, text/plain, */*',
                'Origin': 'https://www.edinarealty.com',
                'Referer': 'https://www.edinarealty.com/find-a-realtor-office',
                'Sec-Fetch-Mode': 'cors',
                'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36', }
    handle_httpstatus_list = [503, 403, 500,404]

    def start_requests(self):
        urls = 'https://www.edinarealty.com/find-a-realtor-office#/'
        yield Request(url=urls, headers=headers, callback=self.parse)

    def parse(self, response):
        res = response.body_as_unicode()
        api = re.findall('apiKey = "(.*?)";', res)
        api = api[0] if api else ''
        time_stamp = re.findall('timestamp = "(.*?)";', res)
        time_stamp = time_stamp[0] if time_stamp else ''
        self.headers1.update({'api-key': api,
                              'timestamp': time_stamp})
        url = 'https://api.edinarealty.com/api/Person/AgentSearch?&SortBy=AgentLegalLastNameAtoZ&pgeNum=1'
        yield Request(url=url, headers=self.headers1, callback=self.parse_api)

    def parse_api(self, response):
        office_phone_numbers = []
        if response.status == 200:
            data = json.loads(response.body_as_unicode())
            if data:
                agents = data.get('agents', [])
                for agent in agents:
                    first_name = agent.get('firstName', '')
                    middle_name = agent.get('middleName')
                    last_name = agent.get('lastName')
                    title = agent.get('title')
                    email = agent.get('emailAddress')
                    image_url = agent.get('portraitUrl')
                    languages_ = agent.get('languages')
                    website = agent.get('websiteUrll')
                    office_name = agent.get('primaryOffice').get('name')
                    office_name = office_name + ' ' + 'office'
                    city = agent.get('primaryOffice').get('city')
                    state = agent.get('primaryOffice').get('state')
                    zipcode = agent.get('primaryOffice').get('postalCode')
                    address = agent.get('primaryOffice').get('addressLine1')
                    phone_numbers = agent.get('agentPhones')
                    for phone in phone_numbers:
                        if phone.get('type') == "Preferred":
                            agent_phone_numbers = [phone.get('number')]
                        elif phone.get('type') == "Text":
                            office_phone_numbers = [phone.get('number')]

                    if agent_phone_numbers == office_phone_numbers:
                        office_phone_numbers = ''
                    social = {}
                    social_ = agent.get('agentSocialUrls', '')
                    for soc in social_:
                        if soc.get('type') == "Facebook":
                            facebook_url = soc.get('url')
                            social.update({'facebook_url': facebook_url})
                        elif soc.get('type') == "LinkedIn":
                            linkedin_url = soc.get('url')
                            social.update({'linkedin_url': linkedin_url})
                        elif soc.get('type') == "Instagram":
                            instagram_url = soc.get('url')
                            social.update({'instagram_url': instagram_url})
                        elif soc.get('type') == "Twitter":
                            twitter_url = soc.get('url')
                            social.update({'twitter_url': twitter_url})
                        else:
                            other_urls = soc.get('url')
                            social.update({'other_urls': other_urls})

                    slug = agent.get('slug', '')
                    profile_url = 'https://www.edinarealty.com/' + slug
                    image_url = image_url if image_url else ''
                    languages = languages if languages_ else []
                    address = address if address else ''
                    state = state if state else ''
                    website = website if website else ''
                    zipcode = zipcode if zipcode else ''
                    city = city if city else ''
                    office_name = office_name if office_name else ''

                    meta = {'item': {'first_name': first_name,
                                     'middle_name': middle_name,
                                     'last_name': last_name,
                                     'office_name': office_name,
                                     'title': title,
                                     'description': "",
                                     'languages': languages,
                                     'image_url': image_url,
                                     'address': address,
                                     'city': city,
                                     'state': state,
                                     'zipcode': zipcode,
                                     'email': email,
                                     'website': website,
                                     'office_phone_numbers': office_phone_numbers,
                                     'agent_phone_numbers': agent_phone_numbers,
                                     'social': social,
                                     'profile_url': profile_url, }}

                    yield Request(url=profile_url, headers=headers, callback=self.description_parser, meta=meta)
                next_ = response.url.split('&pgeNum=')[1]
                next_page_url = 'https://api.edinarealty.com/api/Person/AgentSearch?&SortBy=AgentLegalLastNameAtoZ&pgeNum=' + \
                    str(int(next_) + 1)
                yield Request(url=next_page_url, headers=self.headers1, callback=self.parse_api)

    def description_parser(self, response):
        item = Edina_RealtyItem()
        item.update(response.meta.get('item'))
        description = response.xpath('//p[@class="lead"]/text()').extract()
        item['description'] = ''.join(description).strip()
        item['country'] = 'United States'
        yield item
