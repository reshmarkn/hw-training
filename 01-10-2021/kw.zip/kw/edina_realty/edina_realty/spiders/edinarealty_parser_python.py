# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
import requests
import pymongo
#from dateutil import parser
from pymongo import MongoClient
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from edina_realty.items import *
from edina_realty.settings import *
from edina_realty.proxy import parse_proxy
from scrapy.shell import inspect_response


handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

# db = MongoClient(
#     'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')[MONGO_DB]

# db.edinarealty.create_index(
#     [('profile_url', pymongo.DESCENDING)], unique=True)
client = MongoClient('mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')
try:
    client.admin.command(
        "shardcollection", MONGO_DB + '.' + MONGO_COLLECTION, key={'profile_url': 1}, unique=True)
except:
    pass

db = client[MONGO_DB]

headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}

# headers1 ={
#     'accept': 'application/json, text/plain, */*',
#     'api-key': '2E2589BBD339D85DDBE3ED7412FE70B2B8C687D6133876A572293A21EDE1760B',
#     'referer': 'https://www.edinarealty.com/find-a-realtor-office',
#     'timestamp': '2019-10-28T09:45:07.202Z',
#     'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
#     'origin': 'https://www.edinarealty.com',
# }
headers1 = {

    'accept': 'application/json, text/plain, */*',
    'api-key': '70F2BBC1D4E4E815CC4C1EB0C37969FB5B4E305AD961B533AC35D8886BCC1319',
    'referer': 'https://www.edinarealty.com/find-a-realtor-office',
    'timestamp': '2019-11-29T09:09:12.581Z',
    'origin': 'https://www.edinarealty.com',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
}


class Edina_RealtySpider(Spider):
    name = 'edinarealty_parser_python'
    start_urls = ['http://books.toscrape.com/']

    def parse(self, response):
        req_response = ''
        headers1 = {

            'accept': 'application/json, text/plain, */*',
            'api-key': '70F2BBC1D4E4E815CC4C1EB0C37969FB5B4E305AD961B533AC35D8886BCC1319',
            'referer': 'https://www.edinarealty.com/find-a-realtor-office',
            'timestamp': '2019-11-29T09:09:12.581Z',
            'origin': 'https://www.edinarealty.com',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
        }
        try:
            proxy = parse_proxy()
            proxies = proxy['proxies']
            # for i in range(1,196):
            url = 'https://api.edinarealty.com/api/Person/AgentSearch?&SortBy=AgentLegalLastNameAtoZ&pgeNum=1'
            # url = 'https://api.edinarealty.com/api/Person/AgentSearch?&SortBy=AgentLegalLastNameAtoZ&pgeNum=72'
            req_response = requests.get(
                url, headers=headers1, proxies=proxies, verify=False)
        except:
            try:
                proxy = parse_proxy()
                proxies = proxy['proxies']
                # for i in range(1,194):
                url = 'https://api.edinarealty.com/api/Person/AgentSearch?&SortBy=AgentLegalLastNameAtoZ&pgeNum=1'
                req_response = requests.get(
                    url, headers=headers1, proxies=proxies, verify=False)
            except:
                pass

        if req_response:
            if req_response.status_code == 200:
                item = self.parse_new(req_response, url)
                if item:
                    yield item
            else:
                self.errback_httpbin(url)
        else:
            print('sssssssssssssssssss')
            self.errback_httpbin(url)

    def parse_new(self, response, url):

        social = {}
        other_urls = []
        first_name = ''
        middle_name = ''
        last_name = ''
        city = ''
        state = ''
        zipcode = ''
        image_url = ''
        email = ''
        languages = []
        website = ''
        description = ''
        office_phone_numbers = []
        agent_phone_numbers = []

        data = json.loads(response.text)
        if data:
            agents = data.get('agents', [])
            for agent in agents:
                first_name = agent.get('firstName')
                middle_name = agent.get('middleName')
                last_name = agent.get('lastName')
                title = agent.get('title')
                email = agent.get('emailAddress')
                # image_url = agent.get('coverPhotoUrl')
                image_url = agent.get('portraitUrl')
                languages_ = agent.get('languages')
                website = agent.get('websiteUrll')
                office_name = agent.get('primaryOffice').get('name')
                office_name = office_name + ' ' + 'office'

                city = agent.get('primaryOffice').get('city')
                state = agent.get('primaryOffice').get('state')
                zipcode = agent.get('primaryOffice').get('postalCode')
                address = agent.get('primaryOffice').get('addressLine1')

                firstname_split = first_name.split(' ')
                if len(firstname_split) == 2:
                    first_name = firstname_split[0]
                    middle_name = firstname_split[1]

                phone_numbers = agent.get('agentPhones')
                for phone in phone_numbers:
                    if phone.get('type') == "Preferred":
                        agent_phone_numbers = [phone.get('number')]
                    elif phone.get('type') == "Text":
                        office_phone_numbers = [phone.get('number')]

                if agent_phone_numbers == office_phone_numbers:
                    office_phone_numbers = ''
                social = {}
                social_ = agent.get('agentSocialUrls', '')
                for soc in social_:
                    if soc.get('type') == "Facebook":
                        facebook_url = soc.get('url')
                        social.update({'facebook_url': facebook_url})
                    elif soc.get('type') == "LinkedIn":
                        linkedin_url = soc.get('url')
                        social.update({'linkedin_url': linkedin_url})
                    elif soc.get('type') == "Instagram":
                        instagram_url = soc.get('url')
                        social.update({'instagram_url': instagram_url})
                    elif soc.get('type') == "Twitter":
                        twitter_url = soc.get('url')
                        social.update({'twitter_url': twitter_url})
                    else:
                        other_urls = soc.get('url')
                        social.update({'other_urls': other_urls})

                slug = agent.get('slug')
                if slug:
                    profile_url = 'https://www.edinarealty.com/' + slug
                image_url = image_url if image_url else ''
                languages = [lan for lan in languages_] if languages_ else []
                address = address if address else ''
                state = state if state else ''
                website = website if website else ''
                zipcode = zipcode if zipcode else ''
                city = city if city else ''
                office_name = office_name if office_name else ''

                meta = {'first_name': first_name,
                        'middle_name': middle_name,
                        'last_name': last_name,
                        'office_name': office_name,
                        'title': title,
                        'description': description,
                        'languages': languages,
                        'image_url': image_url,
                        'address': address,
                        'city': city,
                        'state': state,
                        'zipcode': zipcode,
                        'email': email,
                        'website': website,
                        'office_phone_numbers': office_phone_numbers,
                        'agent_phone_numbers': agent_phone_numbers,
                        'social': social,
                        'profile_url': profile_url, }
                try:
                    proxy = parse_proxy()
                    proxies = proxy['proxies']
                    responses = requests.get(
                        url=profile_url, headers=headers, proxies=proxies, verify=False)

                    if responses.status_code == 200:
                        self.parse_des(responses, meta)
                except:
                    try:
                        proxy = parse_proxy()
                        proxies = proxy['proxies']
                        responses = requests.get(
                            url=profile_url, headers=headers, proxies=proxies, verify=False)

                        if responses.status_code == 200:
                            self.parse_des(responses, meta)
                    except:
                        pass
        try:
            theurl = response.url
            next_ = theurl.split('&pgeNum=')[1]
            next_page_url = 'https://api.edinarealty.com/api/Person/AgentSearch?&SortBy=AgentLegalLastNameAtoZ&pgeNum=' + \
                str(int(next_) + 1)

            proxy = parse_proxy()
            proxies = proxy['proxies']
            response = requests.get(
                url=next_page_url, headers=headers1, proxies=proxies, verify=False)

            if response.status_code == 200:
                self.parse_new(response, url)
            else:
                self.errback_httpbin(url)
        except:
            try:
                theurl = response.url
                next_ = theurl.split('&pgeNum=')[1]
                next_page_url = 'https://api.edinarealty.com/api/Person/AgentSearch?&SortBy=AgentLegalLastNameAtoZ&pgeNum=' + \
                    str(int(next_) + 1)

                proxy = parse_proxy()
                proxies = proxy['proxies']
                response = requests.get(
                    url=next_page_url, headers=headers1, proxies=proxies, verify=False)

                if response.status_code == 200:
                    self.parse_new(response, url)
                else:
                    self.errback_httpbin(url)
            except:
                pass

    def parse_des(self, responses, meta):
        sel = Selector(text=responses.content)

        first_name = meta['first_name']
        middle_name = meta['middle_name']
        last_name = meta['last_name']
        office_name = meta['office_name']
        title = meta['title']
        description = meta['description']
        languages = meta['languages']
        image_url = meta['image_url']
        address = meta['address']
        city = meta['city']
        state = meta['state']
        zipcode = meta['zipcode']
        email = meta['email']
        website = meta['website']
        office_phone_numbers = meta['office_phone_numbers']
        agent_phone_numbers = meta['agent_phone_numbers']
        social_ = meta['social']
        profile_url = meta['profile_url']

        description = sel.xpath('//p[@class="lead"]/text()').extract()
        description = ''.join(description).strip()

        item = Edina_RealtyItem(
            first_name=first_name,
            middle_name=middle_name,
            last_name=last_name,
            office_name=office_name,
            title=title,
            description=description,
            languages=languages,
            image_url=image_url,
            address=address,
            city=city,
            state=state,
            country='United States',
            zipcode=zipcode,
            email=email,
            website=website,
            # office_phone_numbers=office_phone_numbers,
            office_phone_numbers=[],
            agent_phone_numbers=agent_phone_numbers,
            social=social_,
            profile_url=profile_url,
        )
        if first_name:
            db[MONGO_COLLECTION].insert(dict(item))
        print(item)

    def errback_httpbin(self, url):
        pass
