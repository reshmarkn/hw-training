# -*- coding: utf-8 -*-
import scrapy
import re
import json
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from edina_realty.proxy import parse_proxy

headers = {
    'Accept': 'application/json, text/plain, */*',
    'api-key': '8B902CC813733F7863DB18B2DEB3AB6F079D3D6D640B3619C6473081DBBF956B',
    'Referer': 'https://www.edinarealty.com/find-a-realtor-office',
    'timestamp': '2019-05-01T03:02:54.739Z',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36'
}


class Edina_RealtyUrlSpider(Spider):
    name = 'edina_realty_crawler'
    # start_urls = ['']
    allowed_domains = []

    def start_requests(self):
        url = 'https://api.edinarealty.com/api/Person/AgentSearch?&SortBy=AgentLegalLastNameAtoZ&pgeNum=1'
        yield Request(url=url, callback=self.parse, headers=headers)

    def parse(self, response):
        data = json.loads(response.body_as_unicode())
        if data:
            agents = data.get('agents', [])
            for agent in agents:
                slug = agent.get('slug')
                if slug:
                    profile_url = 'https://www.edinarealty.com/' + slug
                    f = open('edina_may.txt', 'a')
                    f.write(profile_url + '\n')
                    f.close()

        theurl = response.url
        next_ = theurl.split('&pgeNum=')[1]
        next_page = 'https://api.edinarealty.com/api/Person/AgentSearch?&SortBy=AgentLegalLastNameAtoZ&pgeNum=' + \
            str(int(next_) + 1)
        yield Request(url=next_page, callback=self.parse, headers=headers)
