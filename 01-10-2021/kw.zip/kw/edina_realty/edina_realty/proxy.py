import logging
import random
import requests
import json

logger = logging.getLogger(__name__)


def parse_proxy():
    #     PROXY_LIST = requests.get('http://68.183.58.145/microleaves?',
    #                           headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
    # PROXY_LIST = ["51.15.6.103:2776", "51.15.6.103:2777", "51.15.6.103:2778", "51.15.6.103:2779", "51.15.6.103:2780", "51.15.6.103:2781", "51.15.6.103:2782", "51.15.6.103:2783", "51.15.6.103:2784", "51.15.6.103:2785", "51.15.6.103:2786", "51.15.6.103:2787",
    #               "51.15.6.103:2788", "51.15.6.103:2789", "51.15.6.103:2790", "51.15.6.103:2791", "51.15.6.103:2792", "51.15.6.103:2793", "51.15.6.103:2794", "51.15.6.103:2795", "51.15.6.103:2796", "51.15.6.103:2797", "51.15.6.103:2798", "51.15.6.103:2799", "51.15.6.103:2800"]
    # PROXY_LIST = requests.get('http://68.183.58.145/torproxies?type=3',
    #
                           # headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
    PROXY_LIST = requests.get('http://68.183.58.145/stormproxies',
                              headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
    PROXY = random.choice(PROXY_LIST)
    proxy_url = "http://%s" % PROXY
    proxies = {"http": "http://%s" % PROXY,
               "https": "http://%s" % PROXY}
    logger.debug("Proxy added")
    return {'proxies': proxies, 'proxy_url': proxy_url}
