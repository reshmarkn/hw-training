
import os
import random
import base64
from edina_realty.settings import *
from edina_realty.proxy import parse_proxy


class ProxyMiddleware(object):
    def process_request(self, request, spider):
        proxy = parse_proxy()
        proxies = proxy['proxies']
        request.meta['proxy'] = proxies['http']
