# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from reecenichols.items import *
from reecenichols.settings import *
from reecenichols.proxy import parse_proxy

headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}


class ReecenicholsUrlSpider(Spider):
    name = 'reecenichols_crawler'
    # start_urls = ['']
    allowed_domains = []

    def start_requests(self):
        for var in range(1, 260):
            url = 'https://www.reecenichols.com/AgentSearch/Results.aspx?SearchType=agent&FirstName=&LastName=&OfficeName=&Address=&City=&State=&Country=-32768&Zip=&Languages=&Titles=&Specialties=&Accreditations=&Areas=&rpp=50&page=' + \
                str(var) + '&SortOrder='
            yield Request(url=url, callback=self.parse, headers=headers)

    def parse(self, response):

        profile_url = response.xpath(
            '//div[@class="ao-info-c1"]/h3/a/@href').extract()
        for i in profile_url:
            f = open('urlsaugust.txt', 'a')
            f.write(i + '\n')
            f.close()
