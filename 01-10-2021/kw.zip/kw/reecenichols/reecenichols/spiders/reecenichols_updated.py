# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
import requests
import random
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from reecenichols.items import *
from scrapy.selector import Selector
from reecenichols.settings import *
from reecenichols.proxy import parse_proxy
from time import sleep
from pymongo import MongoClient

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False
req = requests.Session() 
headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, ',
    'Accept-Language': 'en-GB,en;q=0.9',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}
# headers = {"Accept": "*/*",
# "Accept-Encoding": "gzip, deflate, br",
# "Accept-Language": "en-GB,en;q=0.9",
# "Connection": "keep-alive",
# "Sec-Fetch-Dest": "empty",
# "Sec-Fetch-Mode": "cors",
# "Sec-Fetch-Site": "same-origin",
# "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Mobile Safari/537.36",
# "X-Requested-With": "XMLHttpRequest",}

class ReecenicholsSpider(Spider):
    name = 'reecenichols'
    # start_urls = ['']
    allowed_domains = []

    def start_requests(self):
        for var in range(1, 305):
            # url = 'https://www.reecenichols.com/CMS/CmsRoster/RosterSection?layoutID=944&pageSize=10&pageNumber='+str(var)+'&sortBy=firstname-asc'
            # response = req.get(url=url,headers=headers,proxies=proxies)
            # sleep(5)
            # self.parse(response,url)
            url = 'https://www.reecenichols.com/roster/agents/'+str(var)
            yield Request(url=url, callback=self.parse, headers=headers, dont_filter=True)

    def parse(self, response):
        # sel_ = Selector(text=response.content)

        agents_sel = response.xpath('//article')

        for sel in agents_sel:
            profile_url = sel.xpath(
                'a[@class="site-roster-card-image-link"]/@href').extract_first('').strip()
            office_phone = sel.xpath(
                'div[@class="site-roster-card-content"]/ul/li/a/text()').extract_first('').replace('Phone:', '').strip()
            office_name = sel.xpath(
                'div[@class="site-roster-card-content"]/ul/li[4]/text()').extract_first('').strip()
            meta = {
                'office_phone': office_phone,
                'office_name': office_name,
            }
            if profile_url:
                if 'http:' not in profile_url:
                    url = 'https://www.reecenichols.com' + profile_url
                yield Request(url=url, callback=self.parse_next, meta=meta, headers=headers, dont_filter=True)
                # response = req.get(url=url,headers=headers,proxies=proxies)
                # sleep(5)
                # self.parse_next(response,meta)
    def parse_next(self, response):
        profile_url = response.url
        office_name = response.meta['office_name']
        office_phone = response.meta['office_phone']
        # response = Selector(text=response.text)
        first_name = ''
        middle_name = ''
        last_name = ''
        name = response.xpath('//div[@class="rng-bio-account-slider"]/p/text() | //p[@class="rng-agent-profile-contact-name"]/text()').extract_first('').strip()
        agent_name = name.replace('-', ' ').split()
        if '&' in agent_name:
            first_name = name
        else:
            if len(agent_name) == 1:
                first_name = agent_name[0].strip()
                middle_name = ''
                last_name = ''
            if len(agent_name) == 2:
                first_name = agent_name[0].strip()
                middle_name = ''
                last_name = agent_name[1].strip()
            if len(agent_name) == 3:
                first_name = agent_name[0].strip()
                middle_name = agent_name[1].strip()
                last_name = agent_name[2].strip()
            if len(agent_name) >= 4:
                first_name = name.strip()
                middle_name = ''
                last_name = ''
        image_url = ''
        image = response.xpath('//div[@class="rng-bio-account-slider"]/img/@src | //div[@class="rng-bio-account-slider"]/div/img/@src | //img[@class="rng-agent-profile-photo"]/@src').extract_first('').strip()
        image_url = image if image else ''
        if '/AgentNoPhotoAvailable' in image_url:
            image_url = ''
        
        location = response.xpath('//li[@class="rng-agent-profile-contact-address"]//text()').extract()
        location_ =[z.strip() for z in location if z.strip()]                                          
        if len(location_) == 2:
            address = location_[0]
            state_city = location_[1]
            city = state_city.split(',')[0]
            zip_state = state_city.split(',')[1]
            zipcode = zip_state.split(' ')[2]
            state = zip_state.split(' ')[1]
        else:
            address = ''
            city = ''
            zipcode = ''
            state = ''
        agent_phone = response.xpath('//div[@class="rng-bio-account-slider"]/p/a/text() | //li[@class="rng-agent-profile-contact-phone"]/a/@href').extract_first('').replace('tel:','')
        agent_phone_numbers = [agent_phone] if agent_phone else []
        # office_phone_numbers = [office_phone] if office_phone else []
        website = response.xpath('//a[contains(text(),"View My Website")]/@href | //li[@class="rng-agent-profile-contact-website"]/a/@href').extract_first('')
        title = response.xpath('//div[@class="rng-bio-account-slider"]/h4/text() | //span[@class="rng-agent-profile-contact-title"]/text()').extract_first('')
        EMAIL_XPATH = '//p[@id="footer-email"]/a[@id="footer-email-a"]/text() | //li[@class="rng-agent-profile-contact-email"]/a/@href'
        DESCRIPTION_XPATH = '//div[@id="body-text-1-preview-7757"]//p/text() | //div[@id="body-text-1-preview-5500"]/text()'
        email_ = response.xpath(EMAIL_XPATH).extract_first()
        email = 'https://www.reecenichols.com'+email_
        description = response.xpath(DESCRIPTION_XPATH).extract()
        description = ' '.join(''.join(description).split())

        social = {}

        # yield item
        item = ReecenicholsItem(
            title=title,
            office_name=office_name,
            address=address,
            city=city,
            state=state,
            zipcode=zipcode,
            profile_url=profile_url,
            languages=[],
            description=description,
            first_name=first_name,
            middle_name=middle_name,
            last_name=last_name,
            website=website,
            email=email,
            image_url=image_url,
            agent_phone_numbers=agent_phone_numbers,
            office_phone_numbers=[],
            social=social,
            country='United States',
        )
        # print(item)
        # # db[MONGODB_COLLECTION].insert(dict(item))

        yield item
