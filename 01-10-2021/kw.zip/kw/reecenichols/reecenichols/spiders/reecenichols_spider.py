# # -*- coding: utf-8 -*-
# import scrapy
# import re
# import pika
# import json
# import logging
# # from dateutil import parser
# from scrapy.spiders import Spider
# from scrapy.selector import Selector
# from scrapy.http import Request, FormRequest
# from reecenichols.items import *
# from reecenichols.settings import *
# from reecenichols.proxy import parse_proxy

# handler = logging.FileHandler('spider_error.log')
# handler.setLevel('ERROR')
# logging.root.addHandler(handler)
# logger = logging.getLogger('pika')
# logger.propagate = False

# headers = {
#     'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
#     'Accept-Encoding': 'gzip, deflate, ',
#     'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
#     'Upgrade-Insecure-Requests': '1',
#     'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}


# class ReecenicholsSpider(Spider):
#     name = 'reecenichols'
#     # start_urls = ['']
#     allowed_domains = []

#     def start_requests(self):
#         for var in range(1, 55):
#             url = 'https://www.reecenichols.com/AgentSearch/Results.aspx?SearchType=agent&FirstName=&LastName=&OfficeName=&Address=&City=&State=&Country=-32768&Zip=&Languages=&Titles=&Specialties=&Accreditations=&Areas=&rpp=50&page=' + \
#                 str(var) + '&SortOrder='
#             yield Request(url=url, callback=self.parse, headers=headers, dont_filter=True)

#     def parse(self, response):
#         agents_sel = response.xpath('//div[@class="ao-agent-row-item clear"]')

#         for sel in agents_sel:
#             profile_url = sel.xpath(
#                 'div//div[@class="ao-info-c1"]/h3/a/@href').extract_first('').strip()
#             address = sel.xpath(
#                 'div//div[@class="ao-address"]/span/text()').extract_first('').strip()
#             location = sel.xpath(
#                 'div//div[@class="ao-address"]/text()').extract()
#             location = ' '.join(''.join(location).split())
#             address = ' '.join(''.join(address).split())
#             office_phone = sel.xpath(
#                 'div//div[@id="ao-phone"]//text()').extract_first('').replace('Phone:', '').strip()
#             agent_phone = sel.xpath(
#                 'div//div[@id="ao-phone"]//text()').extract_first('').replace('Cell:', '').strip()
#             name = sel.xpath(
#                 'div//div[@class="ao-info-c1"]/h3/a/text()').extract_first('').strip()
#             # image = sel.xpath(
#             #     'div//div/img[@class="ao-search-agent-photo"]/@src|div/a/img[@class="ao-search-agent-photo"]/@src').extract_first('').strip()
#             office_name = sel.xpath(
#                 'div//div[@class="ao-info-c2"]/div[@class="ao-office"]/a/text()').extract_first('')
#             meta = {
#                 'address': address,
#                 'location': location,
#                 'office_phone': office_phone,
#                 'agent_phone': agent_phone,
#                 'name': name,
#                 'office_name': office_name
#             }
#             if profile_url:
#                 if 'http:' not in profile_url:
#                     url = response.urljoin(profile_url)
#                 yield Request(url=url, callback=self.parse_next, meta=meta, headers=headers, dont_filter=True)

#     def parse_next(self, response):
#         profile_url = response.url
#         address = response.meta['address']
#         name = response.meta['name']
#         # image = response.meta['image']
#         location = response.meta['location']
#         agent_phone = response.meta['agent_phone']
#         office_phone = response.meta['office_phone']
#         office_name = response.meta['office_name']

#         first_name = ''
#         middle_name = ''
#         last_name = ''

#         agent_name = name.replace('-', ' ').split()
#         if '&' in agent_name:
#             first_name = name
#         else:
#             if len(agent_name) == 1:
#                 first_name = agent_name[0].strip()
#                 middle_name = ''
#                 last_name = ''
#             if len(agent_name) == 2:
#                 first_name = agent_name[0].strip()
#                 middle_name = ''
#                 last_name = agent_name[1].strip()
#             if len(agent_name) == 3:
#                 first_name = agent_name[0].strip()
#                 middle_name = agent_name[1].strip()
#                 last_name = agent_name[2].strip()
#             if len(agent_name) >= 4:
#                 first_name = name.strip()
#                 middle_name = ''
#                 last_name = ''
#         image_url = ''
#         image = response.xpath('//div[@class="agent-photo  pull-left"]/img/@src').extract_first('').strip()
#         image_url = image if image else ''
#         if '/AgentNoPhotoAvailable' in image_url:
#             image_url = ''

#         if location:
#             city = location.split(', ')[0].strip()
#             postal = location.split(', ')[1].strip()
#             if postal:
#                 state = postal.split(' ')[0].strip()
#                 zipcode = postal.split(' ')[1].strip()

#         agent_phone = agent_phone.replace('Phone:', '')
#         agent_phone_numbers = [agent_phone] if agent_phone else []
#         office_phone_numbers = [office_phone] if office_phone else []

#         EMAIL_XPATH = '//p[@id="footer-email"]/a[@id="footer-email-a"]/text()'
#         DESCRIPTION_XPATH = '//div[@class="intro-text"]//text()'
#         FACEBOOK_XPATH = '//ul[@class="social-collage"]//li[@class="fb"]/a/@href'
#         LINKEDIN_XPATH = '//ul[@class="social-collage"]//li[@class="linkedin"]/a/@href'
#         TWITTER_XPATH = '//ul[@class="social-collage"]//li[@class="twitter"]/a/@href'
#         INSTAGRAM_XPATH = '//ul[@class="social-collage"]//li[@class="instagram"]/a/@href'
#         PINTEREST_XPATH = '//ul[@class="social-collage"]//li[@class="pinterest"]/a/@href'
#         YOUTUBE_XPATH = '//ul[@class="social-collage"]//li[@class="youtube"]/a/@href'
#         GOOGLEPLUS_XPATH = '//ul[@class="social-collage"]//li[@class="google-plus"]/a/@href'

#         email = response.xpath(EMAIL_XPATH).extract_first('').strip()
#         description = response.xpath(DESCRIPTION_XPATH).extract()
#         description = ' '.join(''.join(description).split())

#         facebook_url = response.xpath(FACEBOOK_XPATH).extract_first('').strip()
#         linkedin_url = response.xpath(LINKEDIN_XPATH).extract_first('').strip()
#         twitter_url = response.xpath(TWITTER_XPATH).extract_first('').strip()
#         instagram_url = response.xpath(
#             INSTAGRAM_XPATH).extract_first('').strip()
#         pinterest_url = response.xpath(
#             PINTEREST_XPATH).extract_first('').strip()
#         youtube_url = response.xpath(YOUTUBE_XPATH).extract_first('').strip()
#         googleplus_url = response.xpath(
#             GOOGLEPLUS_XPATH).extract_first('').strip()

#         if 'facebook' in facebook_url:
#             facebook_url = facebook_url.strip()
#         else:
#             facebook_url = ''
#         if 'twitter' in twitter_url:
#             twitter_url = twitter_url.strip()
#         else:
#             twitter_url = ''
#         if 'linkedin' in linkedin_url:
#             linkedin_url = linkedin_url.strip()
#         else:
#             linkedin_url = ''
#         if 'pinterest' in pinterest_url:
#             pinterest_url = pinterest_url.strip()
#         else:
#             pinterest_url = ''
#         if 'google' in googleplus_url:
#             googleplus_url = googleplus_url.strip()
#         else:
#             googleplus_url = ''
#         if 'youtube' in youtube_url:
#             youtube_url = youtube_url.strip()
#         else:
#             youtube_url = ''
#         if 'instagram' in instagram_url:
#             instagram_url = instagram_url.strip()
#         else:
#             instagram_url = ''

#         other_urls_ = []

#         if pinterest_url:
#             other_urls_.append(pinterest_url)
#         if googleplus_url:
#             other_urls_.append(googleplus_url)
#         if youtube_url:
#             other_urls_.append(youtube_url)
#         if instagram_url:
#             other_urls_.append(instagram_url)

#         other_urls = []
#         for url in other_urls_:
#             if url:
#                 other_urls.append(url)
#             else:
#                 other_urls = []

#         if facebook_url or twitter_url or linkedin_url or other_urls:
#             social = {'facebook_url': facebook_url,
#                       'twitter_url': twitter_url,
#                       'linkedin_url': linkedin_url,
#                       'other_urls': other_urls,
#                       }
#         else:
#             social = {}

#         # yield item
#         item = ReecenicholsItem(
#             title='',
#             office_name=office_name,
#             address=address,
#             city=city,
#             state=state,
#             zipcode=zipcode,
#             profile_url=profile_url,
#             languages=[],
#             description=description,
#             first_name=first_name,
#             middle_name=middle_name,
#             last_name=last_name,
#             website='',
#             email='',
#             image_url=image_url,
#             agent_phone_numbers=agent_phone_numbers,
#             office_phone_numbers=office_phone_numbers,
#             social=social,
#             country='United States',
#         )
#         yield item
