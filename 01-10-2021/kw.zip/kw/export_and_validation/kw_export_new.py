# import os
import json
from datetime import datetime
import sys
import subprocess
from slacker import Slacker
import pymongo
from pymongo import MongoClient
import time
import glob

# file size function
Slack = Slacker(
    'xoxp-24300212688-35464554529-262255845088-43b7f5b45d669c16a2fc81caa80fa6e2')
SLACK_USERS = ['@Avinash', '@Sisira']
db = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017').kw_May_2020


def validate(item, position):
    position = position
    data_row = item
    count = 0
    country = []
    zipcode = []
    profile_url = []
    state = []
    office_phone_numbers = []
    email = []
    city = []
    image_url = []
    language = []
    empty_description = []
    empty_lastname = []
    empty_firstname = []
    empty_officename = []
    city_empty = []
    social_empty = []
    image_url = []
    address_empty = []
    title_empty = []
    country_empty = []
    zipcode_empty = []
    zipcode_length = []
    profile_url_empty = []
    language_empty = []
    agent_phone_numbers_empty = []
    number_error = []
    office_phone_numbers_empty = []
    office_number_error = []
    tags_description = []
    email_error = []
    email_empty = []

    if position > 1:
        for key, value in data_row.items():
            if key == 'country':
                country.append(value)
                if value == '':
                    country_empty.append(position)
                    # raise ValueError('country field null at position',position)
            if key == 'zipcode':
                zipcode.append(value)
                if value == '':
                    zipcode_empty.append(position)
                    # raise ValueError('zipcode field null at position',position)
                elif len(value) > 8 or len(value) < 3:
                    zipcode_length.append(position)
                    message = 'error in zipcode at:' + position
                    return message
                    sys.exit()
                    # raise ValueError('check zipcode field at position',position)
            if key == 'profile_url':
                profile_url.append(value)
                if not value:
                    profile_url_empty.append(position)
                    message = 'error no  profile_url at:' + position
                    return message
                    sys.exit()
                    # raise ValueError('no profile_url at position:',position)
            if key == 'languages':
                if value:
                    language.extend(value)
                else:
                    language_empty.append(position)
            if key == 'agent_phone_numbers':
                if value:
                    if len(value) > 1:
                        for numbers in value:
                            number = re.findall(r'\d+', str(numbers))
                            if len(number) > 11:
                                number_error.append(position)
                                # raise ValueError('check agent_phone_numbers',position)
                    else:
                        number = re.findall(r'\d+', str(value))
                        if len(number) > 11:
                            number_error.append(position)
                        # raise ValueError('check agent_phone_numbers',position)
                else:
                    agent_phone_numbers_empty.append(position)
            if key == 'description':
                if value:
                    tags = re.match(r'<.*?>', value)
                    if tags:
                        tags_description.append(position)
                        # raise ValueError('tags in description',position)
                else:
                    empty_description.append(position)

            if key == 'state':
                if state:
                    state.append(value)
            if key == 'office_phone_numbers':
                if value:
                    if len(value) > 1:
                        for numbers in value:
                            number = re.findall(r'\d+', str(numbers))
                            if len(number) > 11:
                                office_number_error.append(position)
                                # raise ValueError('check office_phone_numbers',position)
                    else:
                        number = re.findall(r'\d+', str(value))
                        if len(number) > 11:
                            office_number_error.append(position)
                            # raise ValueError('check office_phone_numbers',position)
                else:
                    office_phone_numbers_empty.append(position)
            if key == 'email':
                if value:
                    # (?# regex=r"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)")
                    check = re.search(
                        r'(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)', value)
                    if not check:
                        email_error.append(position)
                        message = 'error email format is not correct at:' + position
                        return message
                        sys.exit()
                        # raise ValueError('check email at ', position)
                else:
                    email_empty.append(position)
            if key == 'last_name':
                if not value:
                    empty_lastname.append(position)

            if key == 'office_name':
                if not value:
                    empty_officename.append(position)
            if key == 'first_name':
                if not value:
                    empty_firstname.append(position)
                    message = 'error email format is not correct at:' + position
                    return message
                    sys.exit()
                    # raise ValueError('no first name in first name filed at position',position)
            if key == 'city':
                if value:
                    city.append(value)
                else:
                    city_empty.append(position)
            if key == 'social':
                if not value:
                    social_empty.append(position)
            # if key == 'middle_name':
            if key == 'image_url':
                if not value:
                    image_url.append(position)
            if key == 'address':
                if not value:
                    address_empty.append(position)
            # if key == 'website':
            if key == 'title':
                if not value:
                    title_empty.append(position)
    dup_data = len(datas) - len(set(profile_url))
    unique_zipcode = set(zipcode)
    unique_country = set(country)
    unique_city = set(city)
    report = {'site_name': file_name,
              'country_null': country_empty,
              'country_unique': unique_country,
              'zipcode_mull': zipcode_empty,
              'zipcode_length_error_position': zipcode_length,
              'unique_zipcode': unique_zipcode,
              'duplicate_data_count': dup_data,
              'null in profile_url': profile_url_empty,
              'language_null_count': len(language_empty),
              'language_empty_count': len(language_empty),
              'unique_language': set(language),
              'agent_phone_numbers_error': number_error,
              'agent_phone_numbers_empty': agent_phone_numbers_empty,
              'tags_in_description': tags_description,
              'empty_description': len(empty_description),
              'state_unique': set(state),
              'state_null_count': len(datas) - len(state),
              'office_number_error': office_number_error,
              'office_phone_numbers_empty': len(office_phone_numbers_empty),
              'email_error': email_error,
              'email_empty': len(email_empty),
              'last_name_null': len(empty_lastname),
              'office_name_ null': len(empty_officename),
              'first_name_null': len(empty_firstname),
              'city_unique': unique_city,
              'city_null': city_empty,
              'social_null': len(social_empty),
              'image_url_null': len(image_url),
              'address_null': len(address_empty),
              'title_null': len(title_empty)




              }
    # logging.error(str(report))
    return str(report)


def file_size(file_name):
    statinfo = subprocess.check_output(
        ['du', '-b', file_name]).split()[0].decode('utf-8')
    statinfo = float(statinfo) / 1000 / 1000
    statinfo = round(statinfo, 3)
    return str(statinfo) + 'MB'
# file size function completed
# def export(command):
#     subprocess.Popen(command,shell=True)

# def native(command):
#     subprocess.Popen(command_native,shell=True)

# def awk(command):
#     subprocess.Popen(awkcommand,shell=True)
# def zipping(zipped_file_name,clean_data_file):
#     subprocess.call(["zip", "-r", zipped_file_name, clean_data_file])

# date
today = datetime.now().strftime('%Y_%m_%d')
# date

# File names
site_name = 'woodsbros'
raw_filename = site_name + '.json'
native_ascci_file = site_name + '_temp.json'
clean_data_file = site_name + '_' + today + '.json'
zipped_file_name = clean_data_file + '.zip'
meta_file = site_name + '_metadata.txt'
# file name assigning finished

# Export Data
command = 'mongoexport --host 138.197.68.56 --port 27017 --username datahut --password cGFzc21lMTIz -d kw_May_2020 -c woodsbros_data_v1 --out ' + \
    raw_filename + ' --authenticationDatabase admin'
# export(command)
export = subprocess.Popen(command, shell=True)
export = export.communicate()
# Export complete

# Native to Aacii
# time.sleep(120)
command_native = 'native2ascii -encoding UTF-8 -reverse ' + \
    raw_filename + ' ' + native_ascci_file
native = subprocess.Popen(command_native, shell=True)
native = native.communicate()
# native(command_native)
# time.sleep(100)
# Native to Aacii finished
awkcommand = 'awk \'{gsub("\\"_id[^,]*,", "");print}\'' + \
    ' ' + native_ascci_file + ' > ' + clean_data_file
# awk(awkcommand)
# subprocess.Popen(['awk','{gsub("\\"_id[^,]*,", "");print}',native_ascci_file,' > ',clean_data_file])
awk = subprocess.Popen(awkcommand, shell=True)
awk = awk.communicate()
# validate json
exce = False
f = open(clean_data_file)
lines = f.readlines()
no_of_lines = len(lines)
d = []
for i, line in enumerate(lines):
    try:
        # line= ' '.join(line.split())
        # print(line)
        item = json.loads(line)
    except Exception as e:
        exce = True
        d.append(str(e) + 'in line %s' % str(i + 1))
        # print(d)
# f.close()
if exce == True:
    print('Invalid JSON')
    sys.exit()
    # quit()
else:
    data = validate(item, i + 1)
    message = data
    log = site_name
    db.log.insert(dict(json.loads(data)))
    for user in SLACK_USERS:
        Slack.chat.post_message(user, message)
    print('JSON validated...!')
# Json validation finished

# remove _id


# time.sleep(10)
# removed _id


# zip the file

ziping = subprocess.call(["zip", "-r", zipped_file_name, clean_data_file])
# ziping=ziping.communicate()

details = {
    'filename': zipped_file_name,
    'Dropbox path': '',
    'Zipped data size': file_size(zipped_file_name),
    'Total data count': no_of_lines,
    'Data format': 'json.zip',
    'Date transferred': today,
    'json loading failed line number': d

}
# print(details)
# with open("users.txt", "a") as f:
#     f.write('filename : %s' % zipped_file_name + '\n')
#     f.write('Dropbox path : '+'\n')
#     # f.write("Total data size: %s MB" % file_size(clean_data_file) +'\n')
#     f.write("Zipped data size: %s MB" % file_size(zipped_file_name) + '\n')
#     f.write("Total data count: %s" % no_of_lines + '\n')
#     f.write("Data format: json.zip" + '\n')
#     f.write('Date transferred: %s' % today + '\n')
#     f.write(''+'\n')
# created meta file

# remove unwanted files
command_remove = 'rm  ' + raw_filename + ' ' + native_ascci_file
subprocess.Popen(command_remove, shell=True)
# removed unwanted files

message = str(details)
for user in SLACK_USERS:
    Slack.chat.post_message(slack_to, '```DATA STATUS :: \n{}\n```'.format(message), username='Data-Validator',
                            icon_url='http://icons.iconarchive.com/icons/graphicloads/colorful-long-shadow/128/Check-3-icon.png')
    # Slack.chat.post_message(user, message)
