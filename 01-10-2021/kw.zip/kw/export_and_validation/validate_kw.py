import csv
import re
import json
import logging
import sys
from slacker import Slacker

Slack = Slacker(
			'xoxp-24300212688-35464554529-262255845088-43b7f5b45d669c16a2fc81caa80fa6e2')
SLACK_USERS = ['@Avinash']
# file_name = input('Enter CSV file: ')

# file_name = sys.argv[1]
logging.basicConfig(filename="alliebeth.log", level=logging.INFO)


file_name = input('Enter filename: ')
datas=[]
with open(file_name,'r') as data: 
	for items in data:
		datas.append(json.loads(items))
	# READER = csv.reader(csvfile, delimiter=';')
	position = 0
	count = 0
	country = [] 
	zipcode = []
	profile_url = []
	state = []
	office_phone_numbers = []
	email = []
	city = []
	image_url = []
	language=[]
	empty_description = []
	empty_lastname = []
	empty_firstname = []
	empty_officename = []
	city_empty = []
	social_empty = []
	image_url = []
	address_empty = []
	title_empty = []
	country_empty=[]
	zipcode_empty = []
	zipcode_length = []
	profile_url_empty = []
	language_empty = []
	agent_phone_numbers_empty=[]
	number_error=[]
	office_phone_numbers_empty=[]
	office_number_error=[]
	tags_description = []
	email_error = []
	email_empty = []
	for data_row in datas:
		position += 1
		if position > 1:
			for key,value in data_row.items():
				if key == 'country':
					country.append(value)
					if value == '':
						country_empty.append(position)
						# raise ValueError('country field null at position',position)
				if key == 'zipcode':
					zipcode.append(value)
					if value == '':
						zipcode_empty.append(position)
						# raise ValueError('zipcode field null at position',position)
					elif len(value) > 8:
						zipcode_length.append(position)
						# raise ValueError('check zipcode field at position',position)
				if key == 'profile_url':
					profile_url.append(value)
					if value == '':
						profile_url_empty.append(position)
						# raise ValueError('no profile_url at position:',position)
				if key == 'languages':
					if value:
						language.extend(value)
					else:
						language_empty.append(position)
				if key == 'agent_phone_numbers':
					if value:
						if len(value) > 1:
							for numbers in value:
								number = re.findall(r'\d+',str(numbers))
								if len(number) > 11:
									number_error.append(position)
									# raise ValueError('check agent_phone_numbers',position)
						else:
							number = re.findall(r'\d+',str(value))
							if len(number) > 11:
								number_error.append(position)
							# raise ValueError('check agent_phone_numbers',position)
					else:
						agent_phone_numbers_empty.append(position)
				if key == 'description':
					if value:
						tags = re.match(r'<.*?>',value)
						if tags:
							tags_description.append(position)
							# raise ValueError('tags in description',position)
					else:
						empty_description.append(position)

				if key == 'state':
					if state:
						state.append(value)
				if key == 'office_phone_numbers':
					if value:
						if len(value) > 1:
							for numbers in value:
								number = re.findall(r'\d+',str(numbers))
								if len(number) > 11:
									office_number_error.append(position)
									# raise ValueError('check office_phone_numbers',position)
						else:
							number = re.findall(r'\d+',str(value))
							if len(number) > 11:
								office_number_error.append(position)
								# raise ValueError('check office_phone_numbers',position)
					else:
						office_phone_numbers_empty.append(position)				
				if key == 'email':
					if value:
					# (?# regex=r"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)")
						check=re.search(r'(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)',value)
						if not check:
							email_error.append(position)
							# raise ValueError('check email at ', position)
					else:
						email_empty.append(position)
				if key == 'last_name':
					if not value:
						empty_lastname.append(position)
				if key == 'office_name':
					if not value:
						empty_officename.append(position)
				if key == 'first_name':
					if not value:
						empty_firstname.append(position)
						# raise ValueError('no first name in first name filed at position',position)
				if key == 'city':
					if value :
						city.append(value)
					else:
						city_empty.append(position)
				if key == 'social':
					if not value:
						social_empty.append(position)
				# if key == 'middle_name':
				if key == 'image_url':
					if not value:
						image_url.append(position) 
				if key == 'address':
					if not value:
						address_empty.append(position)
				# if key == 'website':
				if key == 'title':
					if not value:
						title_empty.append(position)
	dup_data = len(datas) - len(set(profile_url))    			
	unique_zipcode = set(zipcode) 
	unique_country = set(country)
	unique_city = set(city)
	report = {'country_null': country_empty,
	'country_unique':unique_country,
	'zipcode_mull':zipcode_empty,
	'zipcode_length_error_position':zipcode_length,
	'unique_zipcode':unique_zipcode,
	'duplicate_data_count': dup_data,
	'null in profile_url': profile_url_empty,
	'language_null_count': len(language_empty),
	'language_empty_count': len(language_empty),
	'unique_language': set(language),
	'agent_phone_numbers_error': number_error,
	'agent_phone_numbers_empty': agent_phone_numbers_empty,
	'tags_in_description': tags_description,
	'empty_description': len(empty_description),
	'state_unique': set(state),
	'state_null_count': len(datas)-len(state),
	'office_number_error': office_number_error,
	'office_phone_numbers_empty': len(office_phone_numbers_empty),
	'email_error': email_error,
	'email_empty': len(email_empty),
	'last_name_null': len(empty_lastname),
	'office_name_ null': len(empty_officename),
	'first_name_null': len(empty_firstname),
	'city_unique': unique_city,
	'city_null': city_empty,
	'social_null':len(social_empty),
	'image_url_null':len(image_url),
	'address_null': len(address_empty),
	'title_null': len(title_empty)




	}
	logging.error(str(report))
	message = str(report)
	for user in SLACK_USERS:
		Slack.chat.post_message(user, message)