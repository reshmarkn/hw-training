# import os
import json
from datetime import datetime
# import sys
import subprocess
from slacker import Slacker
import time
import glob

# file size function
Slack = Slacker(
            'xoxp-24300212688-35464554529-262255845088-43b7f5b45d669c16a2fc81caa80fa6e2')
SLACK_USERS = ['@Avinash']

def file_size(file_name):
    statinfo = subprocess.check_output(['du','-b',file_name]).split()[0].decode('utf-8')                                      
    statinfo = float(statinfo)/1000/1000
    statinfo = round(statinfo, 3) 
    return str(statinfo)+'MB'
# file size function completed
# def export(command):
#     subprocess.Popen(command,shell=True)

# def native(command):
#     subprocess.Popen(command_native,shell=True)

# def awk(command):
#     subprocess.Popen(awkcommand,shell=True)
# def zipping(zipped_file_name,clean_data_file):
#     subprocess.call(["zip", "-r", zipped_file_name, clean_data_file])

# date
today = datetime.now().strftime('%Y_%m_%d')
# date

# File names
site_name = 'coldwellbanker_us'
raw_filename = site_name + '.json'
native_ascci_file = site_name + '_temp.json'
clean_data_file = site_name + '_' + today + '.json'
zipped_file_name = clean_data_file + '.zip'
meta_file = site_name + '_metadata.txt'
# file name assigning finished

# Export Data
command='mongoexport --host 138.197.68.56 --port 27017 --username datahut --password cGFzc21lMTIz -d kw_Jul_2020 -c coldwellbanker_unique --out '+raw_filename+' --authenticationDatabase admin'  
# export(command)
export=subprocess.Popen(command,shell=True)
export=export.communicate()
# Export complete

# Native to Aacii
# time.sleep(120)
command_native='native2ascii -encoding UTF-8 -reverse '+raw_filename+' '+native_ascci_file 
native=subprocess.Popen(command_native,shell=True)
native=native.communicate()
# native(command_native)
# time.sleep(100)
# Native to Aacii finished

# validate json
exce = False
f = open(native_ascci_file)
lines = f.readlines()
no_of_lines = len(lines)
for i, line in enumerate(lines):
    try:
        # line= ' '.join(line.split())
        # print(line)
        item = json.loads(line)
    except Exception as e:
        exce = True
        print(str(e) + 'in line %s' % str(i+1))
f.close()
if exce == True:
    print('Invalid JSON')
    quit()
else:
    print('JSON validated...!')
# Json validation finished

# remove _id


awkcommand='awk \'{gsub("\\"_id[^,]*,", "");print}\''+' ' +native_ascci_file+ ' > ' +clean_data_file 
# awk(awkcommand)
# subprocess.Popen(['awk','{gsub("\\"_id[^,]*,", "");print}',native_ascci_file,' > ',clean_data_file])
awk=subprocess.Popen(awkcommand,shell=True)
awk=awk.communicate()
# time.sleep(10)
# removed _id



# zip the file

ziping=subprocess.call(["zip", "-r", zipped_file_name, clean_data_file])
# ziping=ziping.communicate()

details={
    'filename': zipped_file_name,
    'Dropbox path' : '',
    'Zipped data size': file_size(zipped_file_name),
    'Total data count': no_of_lines,
    'Data format': 'json.zip',
    'Date transferred': today 

}
# print(details)
# with open("users.txt", "a") as f:
#     f.write('filename : %s' % zipped_file_name + '\n')
#     f.write('Dropbox path : '+'\n')
#     # f.write("Total data size: %s MB" % file_size(clean_data_file) +'\n')
#     f.write("Zipped data size: %s MB" % file_size(zipped_file_name) + '\n')
#     f.write("Total data count: %s" % no_of_lines + '\n')
#     f.write("Data format: json.zip" + '\n')
#     f.write('Date transferred: %s' % today + '\n')
#     f.write(''+'\n')
# created meta file

# remove unwanted files
command_remove= 'rm  ' +raw_filename+ ' '+native_ascci_file
subprocess.Popen(command_remove,shell=True)
# removed unwanted files

message = str(details)
for user in SLACK_USERS:
    Slack.chat.post_message(user, message)