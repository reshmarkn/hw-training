# -*- coding: utf-8 -*-
import scrapy


class EwmItem(scrapy.Item):
    first_name = scrapy.Field()
    last_name = scrapy.Field()
    middle_name = scrapy.Field()
    title = scrapy.Field()
    office_name = scrapy.Field()
    agent_phone_numbers = scrapy.Field()
    office_phone_numbers = scrapy.Field()
    languages = scrapy.Field()
    description = scrapy.Field()
    address = scrapy.Field()
    country = scrapy.Field()
    zipcode = scrapy.Field()
    city = scrapy.Field()
    state = scrapy.Field()
    website = scrapy.Field()
    image_url = scrapy.Field()
    email = scrapy.Field()
    profile_url = scrapy.Field()
    social = scrapy.Field()

class EwmUrlItem(scrapy.Item):
    url = scrapy.Field()