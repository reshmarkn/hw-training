import scrapy
import re
import pika
import json
import logging
from scrapy import signals
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from xml.dom import minidom
from ewm.items import *
from ewm.settings import *
from ewm.proxy import parse_proxy
from pymongo import MongoClient
from datetime import datetime
# from databasenotifier import automation_script


class EwmSpider(Spider):

    name = 'ewm_url_crawl'
    start_urls = ['https://www.ewm.com/agent.xml']
    allowed_domains = ['www.ewm.com']

    def parse(self, response):
        xmldoc = minidom.parseString(response.body)
        LOCS = xmldoc.getElementsByTagName('loc')
        LOCS.pop(0)
        for loc in LOCS:
            p_url = loc.childNodes[0].data
            p_url = response.urljoin(p_url)
            # meta = {'url': p_url}
            # db.ewm_urls.insert(dict(meta))
            item = EwmUrlItem()
            item['url'] = p_url
            yield item
        # automation_script.Automation_Spider(MONGO_DB, MONGO_COLLECTION_URL)
