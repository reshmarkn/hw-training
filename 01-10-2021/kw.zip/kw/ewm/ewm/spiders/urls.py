# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import string
import gzip
from xml.dom import minidom
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from ewm.proxy import parse_proxy


class EwmSpider(Spider):
    name = 'ewm_urlcrawler'
    allowed_domains = ['ewm.com']
    start_urls = ['https://www.ewm.com/agent.xml']

    def parse(self, response):
        xmldoc = minidom.parseString(response.body)
        LOCS = xmldoc.getElementsByTagName('loc')
        LOCS.pop(0)
        for loc in LOCS:
            p_url = loc.childNodes[0].data
            if '/agents/' in p_url:
                f = open('ewm_urlsept.txt', 'a')
                f.write(p_url + '\n')
                f.close()
