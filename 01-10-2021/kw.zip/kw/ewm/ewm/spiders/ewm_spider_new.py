# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from ewm.items import *
from ewm.settings import *
from ewm.proxy import parse_proxy
from pymongo import MongoClient
from datetime import datetime
# from databasenotifier import automation_script

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.119 Safari/537.36'}


class EwmSpider(Spider):
    name = 'ewm_parser_new'
    # db =MongoClient('mongodb://localhost:27017')[dbname]
    db = MongoClient(
        'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')[MONGO_DB]

    def start_requests(self):

        for item in self.db[MONGO_COLLECTION_URL].find(no_cursor_timeout=True):
            url = item.get('url')
            link = url.strip()
            yield Request(url=link, callback=self.parse, headers=headers)
        # automation_script.Automation_Spider(MONGO_DB, MONGO_COLLECTION)

    def parse(self, response):
        NAME_XPATH = '//h1[@itemprop="name"]/text()'
        LANGUAGES_XPATH = '//div[@class="cell single-sidebar"]/h3/text()'
        DESCRIPTION_XPATH = '//div[@itemprop="description"]//p/text()'
        IMAGE_XPATH = '//img[@class="js-agent-photo"]/@src|//img[@class="agent-card__img"]/@src'
        TITLE_XPATH = '//div[@class="bt-panel uk-panel uk-panel-box"]/div[1]/div[@class="uk-text-muted"]/text()'
        AGENT_PHONE_XPATH = '//div[@itemprop="telephone"]/strong[contains(text(), "M:")]/following-sibling::text()'
        OFFICE_PHONE_XPATH = '//div[@itemprop="telephone"]/strong[contains(text(), "O:")]/following-sibling::text()'
        OFFICE_NAME_XPATH = '//b[@itemprop="name"]/text() | //div[@itemprop="name"]/strong/text()'
        ADRRESS_XPATH = '//span[@itemprop="streetAddress"]/text() | //div[@itemprop="streetAddress"]/text()'
        CITY_XPATH = '//span[@itemprop="addressLocality"]/text()'
        STATE_XPATH = '//span[@itemprop="addressRegion"]/text()'
        ZIPCODE_XPATH = '//span[@itemprop="postalCode"]/text()'

        name = response.xpath(NAME_XPATH).extract_first('').strip()
        languages = response.xpath(LANGUAGES_XPATH).extract_first(
            '').replace('Fluent In: ', '').split(',')
        description = response.xpath(DESCRIPTION_XPATH).extract()
        image_url = response.xpath(IMAGE_XPATH).extract_first('').strip()
        title = response.xpath(TITLE_XPATH).extract_first('').strip()
        agent_phone = response.xpath(
            AGENT_PHONE_XPATH).extract_first('').strip()
        office_phone = response.xpath(
            OFFICE_PHONE_XPATH).extract_first('').strip()
        office_name = response.xpath(
            OFFICE_NAME_XPATH).extract_first('').strip()
        address = response.xpath(ADRRESS_XPATH).extract_first('').strip()
        city = response.xpath(CITY_XPATH).extract_first('').strip()
        state = response.xpath(STATE_XPATH).extract_first('').strip()
        zipcode = response.xpath(ZIPCODE_XPATH).extract_first('').strip()

        if '-' in name:
            name_list = name.split('-')[0]
        else:
            name_list = name

        if name_list:
            agent_name = name_list.split(' ')
            if len(agent_name) > 3:
                first_name = name.strip()
                middle_name = ''
                last_name = ''
            elif len(agent_name) == 3:
                first_name = agent_name[0].strip()
                middle_name = agent_name[1].strip()
                last_name = agent_name[2].strip()
            elif len(agent_name) == 2:
                first_name = agent_name[0].strip()
                middle_name = ''
                last_name = agent_name[1].strip()
            elif len(agent_name) == 1:
                first_name = agent_name[0].strip()
                middle_name = ''
                last_name = ''
            else:
                first_name = ''
                middle_name = ''
                last_name = ''

        languages_ = []
        if languages == ['']:
            languages_ = []
        else:
            for language in languages:
                lang = language.strip()
                languages_.append(lang)

        description = ' '.join(''.join(description).split())
        agent_phone_numbers = [agent_phone] if agent_phone else []
        office_phone_numbers = [office_phone] if office_phone else []

        facebook_url = ''.join(response.xpath(
            '//a[@class="bt-icon__button bt-icon--facebook"]/@href').extract())
        twitter_url = ''.join(response.xpath(
            '//a[@class="bt-icon__button bt-icon--twitter"]/@href').extract())
        linkedin_url = ''.join(response.xpath(
            '//a[@class="bt-icon__button bt-icon--linkedin"]/@href').extract())
        pinterest_url = ''.join(response.xpath(
            '//a[@class="bt-icon__button bt-icon--pinterest"]/@href').extract())
        googleplus_url = ''.join(response.xpath(
            '//a[@class="bt-icon__button bt-icon--googleplus"]/@href').extract())
        youtube_url = ''.join(response.xpath(
            '//a[@class="bt-icon__button bt-icon--youtube"]/@href').extract())
        instagram_url = ''.join(response.xpath(
            '//a[@class="bt-icon__button bt-icon--instagram"]/@href').extract())
        blog_url = ''.join(response.xpath(
            '//a[@class="bt-icon__button bt-icon--blog"]/@href').extract())
        if 'https' not in image_url:
            image_url = ''

        if 'www.facebook.com' in facebook_url:
            facebook_url = facebook_url.strip()
        else:
            facebook_url = ''
        if 'twitter.com' in twitter_url:
            twitter_url = twitter_url.strip()
        else:
            twitter_url = ''
        if 'www.linkedin.com' in linkedin_url:
            linkedin_url = linkedin_url.strip()
        else:
            linkedin_url = ''
        if 'www.pinterest.com' in pinterest_url:
            pinterest_url = pinterest_url.strip()
        else:
            pinterest_url = ''
        if 'google.com' in googleplus_url:
            googleplus_url = googleplus_url.strip()
        else:
            googleplus_url = ''
        if 'www.youtube.com' in youtube_url:
            youtube_url = youtube_url.strip()
        else:
            youtube_url = ''
        if 'www.instagram.com' in instagram_url:
            instagram_url = instagram_url.strip()
        else:
            instagram_url = ''
        if '/blog/' in blog_url:
            blog_url = blog_url.strip()
        else:
            blog_url = ''

        other_urls_ = []

        if pinterest_url:
            other_urls_.append(pinterest_url)
        if googleplus_url:
            other_urls_.append(googleplus_url)
        if youtube_url:
            other_urls_.append(youtube_url)
        if instagram_url:
            other_urls_.append(instagram_url)
        if blog_url:
            other_urls_.append(blog_url)

        other_urls = []
        for url in other_urls_:
            if url:
                other_urls.append(url)
            else:
                other_urls = []

        if facebook_url or twitter_url or linkedin_url or other_urls:
            social = {'facebook_url': facebook_url,
                      'twitter_url': twitter_url,
                      'linkedin_url': linkedin_url,
                      'other_urls': other_urls,
                      }
        else:
            social = {}

        if office_name == 'EWM Realty International':
            address = '201 Alhambra Circle #1060'
            city = 'Coral Gables'
            state = 'FL'
            zipcode = '33134'

        if first_name:
            item = EwmItem(
                first_name=first_name,
                middle_name=middle_name,
                last_name=last_name,
                image_url=image_url,
                title=title,
                office_name=office_name,
                description=description,
                languages=languages_,
                address=address,
                city=city,
                zipcode=zipcode,
                state=state,
                agent_phone_numbers=agent_phone_numbers,
                office_phone_numbers=office_phone_numbers,
                social=social,
                website='',
                email='',
                profile_url=response.request.url,
                country='United States',
            )
            yield item
