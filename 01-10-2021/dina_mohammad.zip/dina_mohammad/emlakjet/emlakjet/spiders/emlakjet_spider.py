# -*- coding: utf-8 -*-
import scrapy
import string
import io
import gzip
import logging
import re
import pika
import json

from time import sleep
from scrapy.http import Request, FormRequest
from xml.dom import minidom
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime
from rmq import RmqHandler

from emlakjet.items import *
from emlakjet.settings import *

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


class EmlakjetSpiderSpider(scrapy.Spider):
    name = "emlakjet_spider"
    allowed_domains = ["emlakjet.com"]
    start_urls = ['https://www.emlakjet.com/satilik-konut/?q=']
    handle_httpstatus_list = [404, 301]

    def start_requests(self):
        # credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        # connection = pika.BlockingConnection(pika.ConnectionParameters(
        #     credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        # channel = connection.channel()
        # while True:
        #     channel.basic_qos(prefetch_count=1)
        #     method, properties, url = channel.basic_get(queue=QUEUE_NAME_NEW)
        #     if not url.strip():
        #         break
        #     channel.basic_ack(delivery_tag=method.delivery_tag)
        #     url = str(url.strip(), encoding='utf-8')
        #     if url.strip():
        rmqh = RmqHandler(QUEUE_NAME, ip=QUEUE_IP,user=QUEUE_USER, pwd=QUEUE_PASS)
        while True:
            count, data = rmqh.get()
            if not data:
                break
            if data:
                url = data
                yield Request(url=url.strip(), callback=self.parse_data, errback=lambda x: self.errback_httpbin(x, url.strip()))
        # connection.close()

    def parse_data(self, response):
        user_id = ''
        if response.status == 404 or response.status == 301:
            logging.warning('XXXX-failed response-XXXX')
            pass
        elif response.status == 200:
            price = ''
            currency = ''
            category_url_new = ''
            url = response.url
            title = response.xpath('//h1[@class="styles_detailTitle__qBXKm"]//text()').extract()
            broker = response.xpath(
                '//div[@class="styles_ownerDetail__2bEhx"]//p[@class="styles_accountName__2Lc3U"]//text()').extract()
            id_ = response.xpath(
                '//div[contains(text(),"İlan Numarası")]/following-sibling::div//text()').extract()
            property_type = response.xpath( 
                '//div[contains(text(),"Türü")]/following-sibling::div//text()').extract()
            description = response.xpath(
                '//div[@class="_3HVir"]/p//text()|//div[@class="_3HVir"]/h3//text()|//div[@id="ilan-aciklamasi"]//p//text()').extract()

            category = response.xpath(
                '//div[@class="styles_breadcrumb__hHF16"]//ul/li/a/text()').extract()
            category_url = response.xpath(
                '//div[@class="styles_breadcrumb__hHF16"]//ul/li/a/@href').extract()

            price = response.xpath(
                '//div[@data-scroll="fiyat-analizi"]/following-sibling::text()').extract()
            currency = response.xpath(
                '//div[@data-scroll="fiyat-analizi"]/following-sibling::div/text()').extract()

            bedrooms = response.xpath(
                '//div[contains(text(),"Oda Sayısı")]/following-sibling::div//text()').extract()
            bathrooms = response.xpath(
                '//div[contains(text(),"Banyo Sayısı")]/following-sibling::div//text()').extract()

            img = response.xpath(
                '//div[@class="styles_thumbnailsContainer__GIU5q"]//img/@src|//div[@class="_2RAKk"]//img/@src|//div[@class="_2YnOw"]//img/@src|//div[@class="styles_thumbnailsContainer__GIU5q"]//img/@data-src').extract()

            area = response.xpath(
                '//div[@class="styles_listingInformationTable__1X9Aq"]//div[contains(text(),"Brüt Metrekare")]/following-sibling::div//text()|//div[@id="ilan-bilgileri"]//div[contains(text(),"Alan")]/following-sibling::div//text()|//div[@id="bilgiler"]//div[contains(text(),"Alan")]/following-sibling::div//text()').extract()
            
            amen = response.xpath(
                '//div[@id="ilan-ozellikleri"]//text()').extract()

            agent = response.xpath(
                '//div[@class="styles_ownerDetail__2bEhx"]/h1/text()').extract()
            user = response.xpath('//div[@class="_3lUSe"]/a/@href').extract()

            phone_script = response.xpath(
                '//script[contains(text(),"VIEW_PHONE_LISTING")]/text()').extract()

            script_data = response.xpath(
                '//script[@type="application/json"]/text()').extract()

            title = ' '.join(''.join(title).strip().split()) if title else ''
            broker = broker[0].strip() if broker else ''
            id_ = id_[0].strip() if id_ else ''
            property_type = property_type[0] if property_type else ''
            description = ' '.join(''.join(description).strip().replace(
                '*', '').split()) if description else ''

            category = [x.strip() for x in category] if category else ''
            category = [x.strip()
                        for x in category if x] if category else ''
            category = ' > '.join(category).strip() if category else ''
            category_ = category.split('> ')

            location = category_[-1] if category_ else ''
            location = location.strip().split('Mahallesi')[
                0].strip() if location else ''

            if category_url and len(category_url) >= 2:
                category_url_new = category_url[1] if category_url else ''
            if category_url_new:
                if 'satilik' in category_url_new:
                    category = 'sale'
                    category_url = category_url_new
                if 'kiralik' in category_url_new:
                    category = 'rent'
                    category_url = category_url_new
                else:
                    category_url = category_url_new
                    category = category
            else:
                category_url = ''
                category = ''

            price = price[0].strip() if price else ''
            currency = currency[0].strip() if currency else ''
            if not price or currency:
                if script_data:
                    json_data = json.loads(script_data[0])
                    data = json_data.get('props').get('initialProps').get(
                        'pageProps').get('pageResponse').get('price')
                    currency = data.get('currency', '') if data else ''
                    currency = 'TL' if currency == 'TRY' else currency
                    price_js = data.get('price_order', '') if data else ''
            price = price if price else price_js

            json_data_ = response.xpath('//script[@id="__NEXT_DATA__"][@type="application/json"]/text()').extract()
            json_data_ = ''.join(json_data_)
            json_dict = json.loads(json_data_)
            published_at = json_dict.get('props','').get('initialProps','').get('pageProps','').get('pageResponse','').get('createdAt').split('T')[0]

            bedrooms = ' '.join(
                ''.join(bedrooms).strip().split()) if bedrooms else ''
            bathrooms = ' '.join(
                ''.join(bathrooms).strip().split()) if bathrooms else ''

            number_of_photos = str(len(list(set(img)))) if img else ''

            area = [x.strip().replace('-', '') for x in [x.strip()
                                                         for x in area] if x]if area else ''
            area = ''.join(area).strip() if area else ''
            amen = [x.strip() for x in [x.strip()
                                        for x in amen] if x]if amen else ''
            amenities = ', '.join(amen).strip().replace(
                '  ', ' ').strip() if amen else ''

            agent_name = ''.join(agent).strip() if agent else ''
            if user:
                user_data = ''.join(user).split('-') if user else ''
                user_id = user_data[-1].replace('/', '') if user_data else ''
            user_id = user_id if user_id else ''

            phone_script = phone_script[0].strip() if phone_script else ''
            phone_sel = re.findall(
                r'<span.*?</span>', phone_script) if phone_script else ''
            sel = Selector(text=phone_sel[0].strip()) if phone_sel else ''
            phone_numbers = sel.xpath('//span/text()').extract() if sel else []
            phone_numbers = ', '.join([x.strip() for x in [x.strip(
            ) for x in phone_numbers] if x]).strip() if phone_numbers else ''

            scraped_ts = (datetime.now()).strftime("%Y-%m-%d")

            now = datetime.now()
            current = datetime(now.year, now.month, 1)
            next_month = datetime(now.year + int(now.month / 12), ((now.month % 12) + 1), 1)
            now_date_int = int(now.strftime("%d"))
            if now_date_int <=31 and now_date_int >=25:
                iteration_month = next_month.strftime("%m")
                iteration_year = next_month.strftime("%Y")
            else:
                iteration_month = now.strftime("%m")
                iteration_year = now.strftime("%Y")
            iteration_number = iteration_year + '_'+ iteration_month


            item = EmlakjetItem(

                reference_number='',
                id=id_,
                url=response.url,
                broker_display_name=broker,
                broker=broker.upper(),
                category=category,
                category_url=category_url,
                title=title,
                property_type=property_type,
                sub_category_1='',
                sub_category_2='',
                depth='',
                description=description,
                location=location,
                price=price,
                currency=currency,
                price_per='',
                bedrooms=bedrooms,
                bathrooms=bathrooms,
                furnished='',
                rera_permit_number='',
                dtcm_licence='',
                scraped_ts=scraped_ts,
                amenities=amenities,
                details=area,
                agent_name=agent_name,
                number_of_photos=number_of_photos,
                user_id=user_id,
                phone_number=phone_numbers,
                date=scraped_ts,
                iteration_number=iteration_number,
                published_at=published_at,


            )
            if title:
                yield item

    def errback_httpbin(self, failure, url):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=600))
        channel = connection.channel()
        channel.queue_declare(queue=QUEUE_NAME_NEW, durable=True)
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME_NEW, body=url)
        connection.close()
