# -*- coding: utf-8 -*-
import scrapy
import string
import io
import gzip
import logging
import re

from time import sleep
from scrapy.http import Request, FormRequest
from xml.dom import minidom
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime

from emlakjet.items import *
from emlakjet.settings import *


class EmlakjetCrawlerSpider(scrapy.Spider):
    name = "emlakjet_crawler"
    allowed_domains = ["emlakjet.com"]
    BASE_URL = 'https://www.emlakjet.com'

    def start_requests(self):
        start_urls = [
            'https://www.emlakjet.com/satilik-konut/',
            'https://www.emlakjet.com/satilik-isyeri/',
            'https://www.emlakjet.com/devren-isyeri/',
            'https://www.emlakjet.com/satilik-arsa/',
            'https://www.emlakjet.com/kat-karsiligi-arsa/',
            'https://www.emlakjet.com/satilik-turistik-tesis/',
            'https://www.emlakjet.com/kiralik-konut/',
            'https://www.emlakjet.com/kiralik-isyeri/',
            'https://www.emlakjet.com/kiralik-arsa/',
            'https://www.emlakjet.com/kiralik-turistik-tesis/',
            'https://www.emlakjet.com/gunluk-kiralik-konut/',
            'https://www.emlakjet.com/satilik-konut/', ]
        for url in start_urls:
            meta= {'start_url':url}
            yield Request(url,callback=self.parse, dont_filter=True,meta=meta)
        # https://www.emlakjet.com/satilik-konut/projeler
        # cities = ['konya']
    def parse(self,response):
        url = response.meta.get('start_url')
        if 'konut' in url:
            sub_category_1 = 'Residential'
        else:
            sub_category_1 = 'Commercial'
        if 'gunluk-kiralik-konut' in url:
            sub_category_2 = 'Daily rental'
        else:
            sub_category_2 = ''

        cities = ['istanbul', 'ankara', 'izmir', 'adana', 'adiyaman', 'afyonkarahisar', 'agri', 'aksaray', 'amasya', 'antalya', 'ardahan', 'artvin', 'aydin', 'balikesir', 'bartin', 'batman', 'bilecik', 'bingol', 'bitlis', 'bolu', 'burdur', 'bursa', 'canakkale', 'cankiri', 'corum', 'denizli', 'diyarbakir', 'duzce', 'edirne', 'elazig', 'erzincan', 'erzurum', 'eskisehir', 'gaziantep', 'giresun', 'gumushane', 'hakkari', 'hatay', 'igdir', 'isparta', 'kahramanmaras', 'karabuk', 'karaman', 'kars', 'kastamonu', 'kayseri', 'kilis', 'kirikkale', 'kirsehir', 'kocaeli', 'konya', 'kutahya', 'malatya', 'manisa', 'mardin', 'mersin', 'mugla', 'mus', 'nevsehir', 'nigde', 'ordu', 'osmaniye', 'rize', 'sakarya', 'samsun', 'sanliurfa', 'siirt', 'sinop', 'sivas', 'sirnak', 'tekirdag', 'tokat', 'trabzon', 'tunceli', 'usak', 'van', 'yalova', 'yozgat', 'zonguldak', 'kktc']

        # cities = ['erzincan','erzurum','ordu','edirne','bolu','kirsehir','kocaeli','corum','malatya','eskisehir','gumushane','sirnak','mugla','tokat','kilis','hakkari','bingol','isparta','balikesir','amasya','diyarbakir','konya','mersin','istanbul','tunceli','van','tekirdag','karaman','karabuk','artvin','aydin','denizli','kayseri','agri','burdur','gaziantep','adiyaman','samsun','izmir','kars','ankara','nigde','kutahya','sinop','sakarya','osmaniye','giresun','kahramanmaras','kirklareli','cankiri','adana','bursa','mus','bitlis','antalya','yozgat','batman','kirikkale','zonguldak','duzce','yalova','canakkale','siirt','bilecik','kastamonu','hatay','sivas','elazig','afyonkarahisar','nevsehir','usak','mardin','trabzon','manisa','rize','aksaray','bayburt','ardahan','sanliurfa','bartin','igdir','kktc']
        for city in cities:
            for room in range(1, 20):
                urls = url + city + '/projeler/?max_fiyat=2000000&min_fiyat=5000&oda_sayisi[]={}'.format(room)
                yield Request(urls, callback=self.parse_url, dont_filter=True, meta={'maximum': 2000000, 'minimum': 5000,'sub_category_1':sub_category_1,'sub_category_2':sub_category_2,'url':url})

    def parse_url(self, response):
        url = response.meta.get('url')
        if response:
            sub_category_1 = response.meta.get('sub_category_1')
            sub_category_2 = response.meta.get('sub_category_2')
            minimum = response.meta.get('minimum')
            maximum = response.meta.get('maximum')
            total_count = response.xpath(
                '//div[@class="_2NcmX"]/span/strong/text() | //div[@class="styles_title__2IT00"]/span/strong/text()').extract()
            if total_count:

                total_count = total_count[0].strip().replace('.', '').replace(',','')
                if int(total_count) > 1500:
                    # minimum = response.meta.get('minimum')
                    # maximum = response.meta.get('maximum')

                    avg_price = round(int(maximum + minimum) / 2)
                    split_prices = [(minimum, avg_price), (avg_price, maximum)]
                    for low_price_new, high_price_new in split_prices:
                        new_url = 'https://www.emlakjet.com/satilik-konut/?max_fiyat=' + \
                            str(high_price_new) + \
                            '&min_fiyat=' + str(low_price_new)
                        yield Request(new_url, callback=self.parse_url, meta={'maximum': high_price_new, 'minimum': low_price_new})

                else:
                    all_data = response.xpath('//div[@class="styles_listingItem__1asTK"]')
                    for data in all_data:
                        links = data.xpath(
                            'a[@data-ej-category="listingpage"][@data-ej-label="link_item"]/@href').extract()
                        link = 'https://www.emlakjet.com'+ links[0]
                        depth = data.xpath('a/div[@class="styles_badges__pmOxL"]//text()').extract()
                        depth_ = ','.join(depth)

                        item = EmlakjetUrlItem(
                            url=link,
                            sub_category_1=sub_category_1,
                            sub_category_2 =sub_category_2,
                            depth = depth_

                        )
                        yield item
                        # print(item)
                    # next_page = response.xpath(
                    #     '//a[@class="pagination-next-button icon-right-arrow pagination-button"]/@href').extract()
                    next_page = response.xpath(
                        '//li[@class="styles_pagingButton__3HGBl styles_lastButton__2Khv2"]//div//a/@href').extract()
                    # print(next_page,'///////////////')
                    # next_page1 = response.xpath(
                    #     '//link[@rel="next"]/@href').extract()
                    if next_page:
                        next_page = response.urljoin(next_page[0].strip())
                        meta = {'sub_category_1': sub_category_1, 'sub_category_2': sub_category_2,'url':url}
                        yield Request(url=next_page, callback=self.parse_url,meta=meta)
