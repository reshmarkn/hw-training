# -*- coding: utf-8 -*-
import scrapy
import string
import io
import gzip
import logging
import re

from time import sleep
from scrapy.http import Request, FormRequest
from xml.dom import minidom
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime

from emlakjet.items import *
from emlakjet.settings import *


class EmlakjetCrawlerSmpSpider(scrapy.Spider):
    name = "emlakjet_crawler_sitemap"
    start_urls = [
                'https://www.emlakjet.com/sitemaps/listing_satilik_desktop_1.xml',
                'https://www.emlakjet.com/sitemaps/listing_satilik_desktop_2.xml',
                'https://www.emlakjet.com/sitemaps/listing_satilik_desktop_3.xml',
                'https://www.emlakjet.com/sitemaps/listing_satilik_desktop_4.xml',
                'https://www.emlakjet.com/sitemaps/listing_satilik_desktop_5.xml',
                'https://www.emlakjet.com/sitemaps/listing_satilik_desktop_6.xml',
                'https://www.emlakjet.com/sitemaps/listing_satilik_desktop_7.xml',
                'https://www.emlakjet.com/sitemaps/listing_satilik_desktop_8.xml',
                'https://www.emlakjet.com/sitemaps/listing_satilik_desktop_9.xml',
                'https://www.emlakjet.com/sitemaps/listing_kiralik_desktop_1.xml',
                'https://www.emlakjet.com/sitemaps/listing_kiralik_desktop_2.xml',
                'https://www.emlakjet.com/sitemaps/listing_kiralik_desktop_3.xml',
                'https://www.emlakjet.com/sitemaps/listing_kiralik_desktop_4.xml',
                'https://www.emlakjet.com/sitemaps/listing_kiralik_desktop_5.xml',
                'https://www.emlakjet.com/sitemaps/listing_kiralik_desktop_6.xml',
                'https://www.emlakjet.com/sitemaps/listing_kiralik_desktop_7.xml',
                'https://www.emlakjet.com/sitemaps/listing_kiralik_desktop_8.xml',
                'https://www.emlakjet.com/sitemaps/listing_kiralik_desktop_9.xml',
                'https://www.emlakjet.com/sitemaps/detail_satilik_desktop_1.xml',
                'https://www.emlakjet.com/sitemaps/detail_satilik_desktop_2.xml',
                'https://www.emlakjet.com/sitemaps/detail_satilik_desktop_3.xml',
                'https://www.emlakjet.com/sitemaps/detail_satilik_desktop_4.xml',
                'https://www.emlakjet.com/sitemaps/detail_satilik_desktop_5.xml',
                'https://www.emlakjet.com/sitemaps/detail_satilik_desktop_6.xml',
                'https://www.emlakjet.com/sitemaps/detail_satilik_desktop_7.xml',
                'https://www.emlakjet.com/sitemaps/detail_kiralik_desktop_1.xml',
                'https://www.emlakjet.com/sitemaps/detail_kiralik_desktop_2.xml'
    ]

    allowed_domains = ['emlakjet.com']

    def parse(self, response):
        xmldoc = minidom.parseString(response.body)
        LOCS = xmldoc.getElementsByTagName('loc')
        for loc in LOCS:
            url_ = loc.childNodes[0].data
            url_ = url_.strip()
            if '/ilan/' in url_:
                item = EmlakjetUrlItem(
                    url=url_.strip(),
                    sub_category_1='',
                    sub_category_2 ='',
                    depth = ''                    
                )
                yield item
