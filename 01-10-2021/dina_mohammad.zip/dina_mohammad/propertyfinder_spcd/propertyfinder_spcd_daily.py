import io
import re
import ast
import json
import data_daily
import gzip
import random
import logging
import requests
from io import StringIO
from xpath import *
from time import sleep
from slacker import Slacker
from xml.dom import minidom
from datetime import datetime
from string import ascii_lowercase
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from proxy import tor_proxy
from proxy import microleaves_proxy
from proxy import storm_proxy
# USERS = ['@priyanka']

logging.basicConfig(filename='script_error.log',
                    format='%(asctime)s - %(message)s', level=logging.INFO)


headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
}
api_headers = {'accept': 'application/json, text/plain, */*',
               'accept-encoding': 'gzip, deflate, br',
               'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', }


Slack = Slacker(
    'xoxp-24300212688-35464554529-262255845088-43b7f5b45d669c16a2fc81caa80fa6e2')
# USERS = ['@sisira','@avinash']
USERS = ['@anu']
proxy_t = tor_proxy()
proxies_t = proxy_t['proxies']

proxy_m = microleaves_proxy()
proxies_m = proxy_m['proxies']

proxy_s = storm_proxy()
proxies_s = proxy_s['proxies']


def message_url(domain):
    message = 'agent links xpath is updated in ' + domain
    logging.info('%s', message)
    for user in USERS:
        Slack.chat.post_message(user, message)


def message_pagination(domain):
    message = 'pagination link xpath updated in ' + domain
    logging.info('%s', message)
    for user in USERS:
        Slack.chat.post_message(user, message)


def aqar_ksa_():
    url = 'https://sa.aqar.fm/'
    response = requests.get(url, headers=headers)
    sel = Selector(text=response.content)
    domain = url.split('.')[1]
    if response.status_code == 200:
        name_link = sel.xpath('//h4/a[@class="listTitle"]/@href').extract()
        links = []
        for n_links in name_link:
            a = 'https://sa.aqar.fm' + n_links
            links.append(a)
            if len(links) > 24:
                break
        if links:
            item = data_daily.aqar_ksa_fun(links)
        else:
            message_url(domain)


def aqarmap_egp_():
    urls = ['https://aqarmap.com.eg/en/for-sale/property-type/', 'https://aqarmap.com.eg/en/for-rent/property-type/']
    for url in urls:
        response = requests.get(url, headers=headers)
    sel = Selector(text=response.content)
    property_urls = sel.xpath('//section[contains(@class,"searchResults")]//a[@itemprop="url"]/@href').extract()
    domain = url.split('.')[1]
    links = []
    for prop in property_urls:
        prop = 'https://aqarmap.com.eg' + prop.strip()
        prop = prop.strip().replace('https://egypt.aqarmap.com/ar/', 'https://egypt.aqarmap.com/en/').strip()
        links.append(prop)
        if len(links) > 24:
            break
    if links:
        item = data_daily.aqarmap_egp_fun(links)
    else:
        message_url(domain)


def bayut_ksa_():
    urls = ['https://www.bayut.sa/en/ksa/properties-for-sale/',
            'https://www.bayut.sa/en/ksa/properties-for-rent/']
    for url in urls:
        response = requests.get(url, headers=headers)
    sel = Selector(text=response.content)
    links_ = sel.xpath(
        '//li[@role="article"]/article/div/a/@href').extract()
    links = []
    for link in links_:
        url = 'https://www.bayut.sa' + link
        links.append(url)
        if len(links) > 24:
            break
    if links:
        item = data_daily.bayut_ksa_fun(links)
    else:
        message_url(domain)
        print(links)


def bayut_uae_():
    urls = ['https://www.bayut.com/for-sale/property/uae/?completion_status=ready',
            'https://www.bayut.com/for-sale/property/uae/?completion_status=off-plan',
            'https://www.bayut.com/to-rent/property/uae/']
    for url in urls:
        meta = {'parent': url}
        response = requests.get(url, headers=headers, proxies=proxy_t)
    sel = Selector(text=response.content)
    property_list = sel.xpath('//li[@role="article"]/article')
    links = []
    for prop in property_list:
        link = prop.xpath(
            'div/a/@href').extract()
        print(link, '999999999999999999999999999')
        listing_label = prop.xpath(
            'div//div[@aria-label="Listing label"]/span/@aria-label').extract()
        link = link[0].strip() if link else ''
        listing_label = listing_label[0].strip() if listing_label else 'no_adv_type'
        if link:
            url = 'https://www.bayut.com' + link.strip()
            links.append(url)
            if len(links) > 24:
                break
    if links:
        item = data_daily.bayut_uae_fun(links)
    else:
        message_url(domain)


def emlakjet_tur_():
    urls = [
        'https://www.emlakjet.com/satilik-konut/',
        'https://www.emlakjet.com/satilik-isyeri/',
        'https://www.emlakjet.com/devren-isyeri/',
        'https://www.emlakjet.com/satilik-arsa/',
        'https://www.emlakjet.com/kat-karsiligi-arsa/',
        'https://www.emlakjet.com/satilik-turistik-tesis/',
        'https://www.emlakjet.com/kiralik-konut/',
        'https://www.emlakjet.com/kiralik-isyeri/',
        'https://www.emlakjet.com/kiralik-arsa/',
        'https://www.emlakjet.com/kiralik-turistik-tesis/',
        'https://www.emlakjet.com/gunluk-kiralik-konut/',
        'https://www.emlakjet.com/satilik-konut/projeler/', ]
    cities = ['istanbul', 'ankara', 'izmir', 'adana', 'adiyaman', 'afyonkarahisar', 'agri', 'aksaray', 'amasya', 'antalya', 'ardahan', 'artvin', 'aydin', 'balikesir', 'bartin', 'batman', 'bilecik', 'bingol', 'bitlis', 'bolu', 'burdur', 'bursa', 'canakkale', 'cankiri', 'corum', 'denizli', 'diyarbakir', 'duzce', 'edirne', 'elazig', 'erzincan', 'erzurum', 'eskisehir', 'gaziantep', 'giresun', 'gumushane', 'hakkari', 'hatay', 'igdir', 'isparta', 'kahramanmaras', 'karabuk', 'karaman', 'kars', 'kastamonu', 'kayseri', 'kilis', 'kirikkale', 'kirsehir', 'kocaeli', 'konya', 'kutahya', 'malatya', 'manisa', 'mardin', 'mersin', 'mugla', 'mus', 'nevsehir', 'nigde', 'ordu', 'osmaniye', 'rize', 'sakarya', 'samsun', 'sanliurfa', 'siirt', 'sinop', 'sivas', 'sirnak', 'tekirdag', 'tokat', 'trabzon', 'tunceli', 'usak', 'van', 'yalova', 'yozgat', 'zonguldak', 'kktc']

    for city in cities:
        for room in range(1, 20):

            for url in urls:
                domain = url.split('.')[1]

                url = url + city + '/?max_fiyat=2000000&min_fiyat=5000&oda_sayisi[]={}'.format(room)

                meta = {'maximum': 2000000, 'minimum': 5000, 'domain': domain}
                response = requests.get(url, headers=headers, proxies=proxies_t)
                data1 = response.content
                k = next_fun_tur(data1, meta)


def next_fun_tur(data1, meta):
    minimum = meta.get('minimum')
    maximum = meta.get('maximum')
    domain = meta.get('domain')
    sel = Selector(text=data1)

    total_count = sel.xpath(
        '//div[@class="_2NcmX"]/span/strong/text()').extract()
    if total_count:

        total_count = total_count[0].replace('.', '')
        if int(total_count) > 1500:
            avg_price = round(int(maximum + minimum) / 2)
            split_prices = [(minimum, avg_price), (avg_price, maximum)]
            for low_price_new, high_price_new in split_prices:
                new_url = 'https://www.emlakjet.com/satilik-konut/?max_fiyat=' + \
                    str(high_price_new) + \
                    '&min_fiyat=' + str(low_price_new)
                requests.get(new_url, meta={'maximum': high_price_new, 'minimum': low_price_new})

        else:

            links_ = sel.xpath(
                '//div[@class="w_bXG"]/a[@data-ej-category="listingpage"]/@href').extract()
            links = []
            for link in links_:
                link = 'https://www.emlakjet.com' + link
                links.append(link)
                if len(links) > 24:
                    break
            if links:
                item = data_daily.emlakjet_tur_fun(links)
            else:
                message_url(domain)


def justproperty_bah():
    url = 'https://www.justproperty.bh/en/sitemap-search-rent.xml'
    domain = url.split('.')[1]
    link_ = []
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        xmldoc = minidom.parseString(response.content)
        LOCS = xmldoc.getElementsByTagName('loc')
        LOCS.pop(0)
        for loc in LOCS:
            p_url = loc.childNodes[0].data
            response = requests.get(p_url, headers=headers)
            data = response.content
            k = next_fun_bah(response, data)


def next_fun_bah(response, data):
    sel = Selector(text=data)
    name_link = sel.xpath(
        '//div[@class="item-middle"]//a/@href').extract()
    links = []
    for link in name_link:
        name_url = 'https://www.justproperty.bh' + link
        links.append(name_url)
        if len(links) > 24:
            break
    if links:
        item = data_daily.justproperty_bah_fun(links)
    else:
        message_url(domain)


def justproperty_qat():
    urls = 'https://www.justproperty.qa/en/sitemap-search-rent.xml'
    domain = urls.split('.')[1]
    response = requests.get(urls, headers=headers)
    if response.status_code == 200:
        xmldoc = minidom.parseString(response.content)
        LOCS = xmldoc.getElementsByTagName('loc')
        for loc in LOCS:
            p_url = loc.childNodes[0].data
            if '.xml.gz' in p_url:
                response = requests.get(p_url, headers=headers)
            elif '.xml' in p_url:
                response = requests.get(p_url, headers=headers)
            else:
                p_url = p_url
                if '/rent/' or '/buy/' in p_url:
                    response = requests.get(p_url, headers=headers)
                    data1 = response.content
                    k = next_fun_qat(response, data1)


def next_fun_qat(response, data1):
    sel = Selector(text=data1)
    url_link = sel.xpath(
        '//a[@class="item-title-link"]/@href').extract()
    links = []
    for url in url_link:
        name_url = 'https://www.justproperty.qa' + url
        links.append(name_url)
        if len(links) > 24:
            break
    if links:
        item = data_daily.justproperty_qat_fun(links)
    else:
        message_url(domain)


def mubawab_qat_():
    url = 'https://www.mubawab.com.qa/en/crp/qatar/qatar/real-estate-for-rent-all:sc:apartments-for-rent,commercial-property-for-rent,houses-for-rent,land-for-rent,riads-for-rent,rooms-for-rent,villas-and-luxury-homes-for-rent'
    response = requests.get(url, headers=headers)
    sel = Selector(text=response.content)
    domain = url.split('.')[1]
    links = sel.xpath('//ul[@class="ulListing"]/li/@linkref').extract()
    if links:
        item = data_daily.mubawab_qat_fun(links)
    else:
        message_url(domain)


def olx_bah_():
    url = 'https://olx.com.bh/en/properties/'
    response = requests.get(url, headers=headers)
    sel = Selector(text=response.content)
    sub_cat_links = sel.xpath(
        '//a[@class="topLink tdnone "]/@href').extract()
    sub_loc_links = sel.xpath(
        '//div[@id="locationLinks"]//a/@href').extract()
    if sub_loc_links:
        for link in sub_loc_links:
            link = link.strip().strip('#')
            if 'http' in link:
                requests.get(link, headers=headers)

    if sub_cat_links:
        for link in sub_cat_links:
            link = link.strip().strip('#')
            if 'http' in link:
                requests.get(link, headers=headers)

    links_ = sel.xpath(
        '//div[@class="ads__item__info"]/a/@href').extract()
    links = []
    for url in links_:
        url = url.strip()
        if '/en/' not in url:
            url = url.replace('/ad/', '/en/ad/').strip()
            links.append(url)
            if len(links) > 24:
                break
    if links:
        item = data_daily.olx_bah_fun(links)
    else:
        message_url(domain)


def olx_():
    url = 'https://olx.com.eg/en/properties/'
    response = requests.get(url, headers=headers, proxies=proxy_t)
    print(response)
    sel = Selector(text=response.content)
    sub_cat_links = sel.xpath(
        '//a[@class="topLink tdnone "]/@href').extract()
    sub_loc_links = sel.xpath(
        '//div[@id="locationLinks"]//a/@href').extract()

    if sub_loc_links:
        for link in sub_loc_links:
            link = link.strip().strip('#')
            if 'http' in link:
                requests.get(link, headers=headers, proxies=proxy_t)
    if sub_cat_links:
        for link in sub_cat_links:
            link = link.strip().strip('#')
            if 'http' in link:
                requests.get(link, headers=headers, proxies=proxy_t)
    links_ = sel.xpath(
        '//div[@class="ads__item__info"]/a/@href').extract()
    print(links_, '////////////////')
    links = []
    for url in links_:
        links.append(url)
        if len(links) > 24:
            break
    if links:
        item = data_daily.olx_fun(links)
    else:
        message_url(domain)

    if sub_loc_links:
        for link in sub_loc_links:
            link = link.strip().strip('#')
            if 'http' in link:
                requests.get(link, headers=headers, proxies=proxy_t)
    if sub_cat_links:
        for link in sub_cat_links:
            link = link.strip().strip('#')
            if 'http' in link:
                requests.get(link, headers=headers, proxies=proxy_t)
    links_ = sel.xpath(
        '//div[@class="ads__item__info"]/a/@href').extract()
    links = []
    for url in links_:
        links.append(url)
        if len(links) > 24:
            break
    if links:
        item = data_daily.olx_fun(links)
    else:
        message_url(domain)


def qatarliving_qat_():
    urls = ['https://www.qatarliving.com/classifieds/properties/sale',
            'https://www.qatarliving.com/classifieds/properties/rent',
            'https://www.qatarliving.com/classifieds/commercial-properties/sale',
            'https://www.qatarliving.com/classifieds/commercial-properties/rent']
    for url in urls:
        response = requests.get(url, headers=headers, proxies=proxies_t)
    sel = Selector(text=response.content)
    parent_url = url.replace(
        'https://www.qatarliving.com', '').strip()
    type_select = sel.xpath(
        '//div[@id="edit-type"]/div/label/text()').extract()
    bedrooms_select = sel.xpath(
        '//select[@id="edit-property-bedroom"]/option/@value').extract()
    location_select = sel.xpath(
        '//select[@id="edit-search-location"]/option/text()').extract()
    location_select = [x.strip().replace(' / ', '-').strip().replace(' ', '-').strip(
    ).strip('-').lower() for x in location_select] if location_select else ''
    type_select = [x.strip().lower().replace(' ', '-')
                   for x in type_select] if type_select else []
    if bedrooms_select:
        for loc in location_select:
            for bed in bedrooms_select:
                for p_type in type_select:
                    url = 'https://www.qatarliving.com/classifieds/properties/%s/in-%s/?price_min=0&price_max=500000&property_bedroom=%s&advertiser=all' % (
                        str(p_type), str(loc), str(bed))
                    meta = {'parent_url': parent_url}
                    requests.get(url, headers=headers)
                    data1 = response.content
                    k = next_fun_qatar(data1, meta)
    else:
        for loc in location_select:
            for p_type in type_select:
                url = 'https://www.qatarliving.com/classifieds/commercial-properties/%s/in-%s/?price_min=0&price_max=500000&advertiser=all' % (
                    str(p_type), str(loc))
                meta = {'parent_url': parent_url}
                requests.get(url, headers=headers)
                data1 = response.content
                k = next_fun_qatar(data1, meta)


def next_fun_qatar(data1, meta):
    parent_url = meta.get('parent_url')
    sel = Selector(text=data1)
    properties_list = sel.xpath(
        '//div[@id="classified_search_results"]/span/@href').extract()
    links = []
    for prop in properties_list:

        # print(properties_list,'+++++++++++++++')
        prop = 'https://www.qatarliving.com' + prop
        print(prop, '--------------')
        links.append(prop)
        if len(links) > 24:
            break
    if links:
        item = data_daily.qatarliving_qat_fun(links)
    else:
        message_url(domain)


def dubizzle_():

    start_urls = [
        'https://dubai.dubizzle.com/sitemaps/sitemaps/classified-dpv-en-1.xml', ]
    links = []
    domain = 'dubizzle'
    for url in start_urls:
        response = requests.get(url)
        if response.status_code == 200:
            xmldoc = minidom.parseString(response.text)
            LOCS = xmldoc.getElementsByTagName('loc')
            for loc in LOCS:
                url_ = loc.childNodes[0].data
                links.append(url_)
    if not links:
        message_url(domain)
    else:
        item = data_daily.dubizzle_fun(links)

# try:
    # aqar_ksa_()
    # aqarmap_egp_()
    # bayut_ksa_()
    # bayut_uae_()
    # emlakjet_tur_()
    # justproperty_bah()
    # justproperty_qat()
    # mubawab_qat_()
    # olx_bah_()
    # olx_()
    # qatarliving_qat_()
# except Exception as e:


def error_fun(e):
    logging.exception(str(e))
    count = len(open('script_error.log').readlines())
    if count > 0:
        f = open('script_error.log')
        l = f.readlines()
        m = re.findall('requests.*ProxyError.*?peer.*', ''.join(l))
        if m:
            for user in USERS:
                message = 'SPCD running stoped due to proxy fail'
                Slack.chat.post_message(user, message)
        else:
            for user in USERS:
                message = 'SPCD running stoped due to an exception is raised'
                Slack.chat.post_message(user, message)

# try:
#     aqar_ksa_()
# except:
#     try:
#         aqar_ksa_()
#     except Exception as e:
#         spider = "aqar_ksa"
#         error_fun(e,spider)

# try:
#     aqarmap_egp_()
# except:
#     try:
#         aqarmap_egp_()
#     except Exception as e:
#         spider = "aqarmap_egp"
#         error_fun(e,spider)

# try:
#     bayut_ksa_()
# except:
#     try:
#         bayut_ksa_()
#     except Exception as e:
#         spider = "bayut_ksa"
#         error_fun(e,spider)

# try:
#     bayut_uae_()
# except:
#     try:
#         bayut_uae_()
#     except Exception as e:
#         spider = "bayut_uae"
#         error_fun(e,spider)

# try:
#     emlakjet_tur_()
# except:
#     try:
#         emlakjet_tur_()
#     except Exception as e:
#         spider = "emlakjet_tur"
#         error_fun(e,spider)

# try:
#     justproperty_bah()
# except:
#     try:
#         justproperty_bah()
#     except Exception as e:
#         spider = "justproperty_bah"
#         error_fun(e,spider)
# try:
#     justproperty_qat()
# except:
#     try:
#         justproperty_qat()
#     except Exception as e:
#         spider = "justproperty_qat"
#         error_fun(e,spider)

# try:
#     mubawab_qat_()
# except:
#     try:
#         mubawab_qat_()
#     except Exception as e:
#         spider = "mubawab_qat"
#         error_fun(e,spider)

# try:
#     olx_bah_()
# except:
#     try:
#         olx_bah_()
#     except Exception as e:
#         spider = "olx_bah"
#         error_fun(e,spider)

# try:
#     olx_()
# except:
#     try:
#         olx_()
#     except Exception as e:
#         spider = " olx"
#         error_fun(e,spider)

# try:
#     qatarliving_qat_()
# except:
#     try:
#         qatarliving_qat_()
#     except Exception as e:
#         spider = "qatarliving_qat"
#         error_fun(e,spider)

# # try:
# #     aqar_ksa_()
# # except:
# #     try:
# #         aqar_ksa_()
# #     except Exception as e:
# #         error_fun(e)

# # try:
# #     aqarmap_egp_()
# # except:
# #     try:
# #         aqarmap_egp_()
# #     except Exception as e:
# #         error_fun(e)

# # try:
# #     bayut_ksa_()
# # except:
# #     try:
# #         bayut_ksa_()
# #     except Exception as e:
# #         error_fun(e)

# # try:
# #     bayut_uae_()
# # except:
# #     try:
# #         bayut_uae_()
# #     except Exception as e:
# #         error_fun(e)

# # try:
# #     emlakjet_tur_()
# # except:
# #     try:
# #         emlakjet_tur_()
# #     except Exception as e:
# #         error_fun(e)

# # try:
# #     justproperty_bah()
# # except:
# #     try:
# #         justproperty_bah()
# #     except Exception as e:
# #         error_fun(e)
# # try:
# #     justproperty_qat()
# # except:
# #     try:
# #         justproperty_qat()
# #     except Exception as e:
# #         error_fun(e)

# # try:
# #     mubawab_qat_()
# # except:
# #     try:
# #         mubawab_qat_()
# #     except Exception as e:
# #         error_fun(e)

# # try:
# #     olx_bah_()
# # except:
# #     try:
# #         olx_bah_()
# #     except Exception as e:
# #         error_fun(e)

# # try:
# #     olx_()
# # except:
# #     try:
# #         olx_()
# #     except Exception as e:
# #         error_fun(e)

# # try:
# #     qatarliving_qat_()
# # except:
# #     try:
# #         qatarliving_qat_()
# #     except Exception as e:
# #         error_fun(e)


try:
    dubizzle_()
except:
    try:
        dubizzle_()
    except Exception as e:
        error_fun(e)
