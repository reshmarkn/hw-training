import logging
from slacker import Slacker
Slack = Slacker(
    'xoxp-24300212688-35464554529-262255845088-43b7f5b45d669c16a2fc81caa80fa6e2')
USERS = ['@Mahesh']
# USERS = ['@sisira', '@ramesh']


def slack_note(message, domain):
    if message:
        message = message
    else:
        message = 'no issues in ' + domain
        logging.info('%s', message)
    # f = open('slack_message.txt', 'a')
    # f.write(str(message) + '\n')
    # f.close()

    for user in USERS:
        Slack.chat.post_message(user, str(message))
