import io
import re
import ast
import json
import data
import gzip
import random
# import logging
import requests
from io import StringIO
from xpath import *
from log_file import *
from time import sleep
from slacker import Slacker
from xml.dom import minidom
from datetime import datetime
from string import ascii_lowercase
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from proxy import tor_proxy
from proxy import microleaves_proxy
from proxy import storm_proxy

logging.basicConfig(filename='script_error.log',
                    format='%(asctime)s - %(message)s', level=logging.INFO)
Slack = Slacker(
    'xoxp-24300212688-35464554529-262255845088-43b7f5b45d669c16a2fc81caa80fa6e2')
USERS = ['@anu']


headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
}
api_headers = {'accept': 'application/json, text/plain, */*',
               'accept-encoding': 'gzip, deflate, br',
               'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', }


proxy_t = tor_proxy()
proxies_t = proxy_t['proxies']

proxy_m = microleaves_proxy()
proxies_m = proxy_m['proxies']

proxy_s = storm_proxy()
proxies_s = proxy_s['proxies']


def message_url(domain):
    message = 'agent links xpath is updated in ' + domain
    slack_note(message, domain)


def message_pagination(domain):
    message = 'pagination link xpath updated in ' + domain
    slack_note(message, domain)


def aqar_ksa_():
    url = 'https://sa.aqar.fm/'
    response = requests.get(url, headers=headers)
    sel = Selector(text=response.content)
    domain = url.split('.')[1]
    name_link = sel.xpath('//h4/a[@class="listTitle"]/@href').extract()
    links = []
    for n_links in name_link:
        a = 'https://sa.aqar.fm' + n_links
        links.append(a)
        if len(links) > 24:
            break
    if links:
        item = data.aqar_ksa_fun(links)
    else:
        message_url(domain)


def aqarmap_egp_():
    urls = ['https://aqarmap.com.eg/en/for-sale/property-type/',
            'https://aqarmap.com.eg/en/for-rent/property-type/']
    for url in urls:
        response = requests.get(url, headers=headers)
    sel = Selector(text=response.content)
    property_urls = sel.xpath(
        '//section[contains(@class,"searchResults")]//a[@itemprop="url"]/@href').extract()
    domain = url.split('.')[1]
    links = []
    for prop in property_urls:
        prop = 'https://aqarmap.com.eg' + prop.strip()
        prop = prop.strip().replace('https://egypt.aqarmap.com/ar/',
                                    'https://egypt.aqarmap.com/en/').strip()
        links.append(prop)
        if len(links) > 24:
            break
    if links:
        item = data.aqarmap_egp_fun(links)
    else:
        message_url(domain)


def bayut_ksa_():
    urls = ['https://www.bayut.sa/en/ksa/properties-for-sale/',
            'https://www.bayut.sa/en/ksa/properties-for-rent/']
    for url in urls:
        response = requests.get(url, headers=headers)
    sel = Selector(text=response.content)
    # print(sel,'22222222222222222')
    links_ = sel.xpath(
        '//li[@role="article"]/article/div/a/@href').extract()
    links = []
    for link in links_:
        # print(link,'pppppppppppppppppppppp')
        url = 'https://www.bayut.sa' + link
        links.append(url)
        if len(links) > 24:
            break
    if links:
        item = data.bayut_ksa_fun(links)
    else:
        message_url(domain)


def bayut_uae_():
    domain = 'bayut_uae_'
    urls = ['https://www.bayut.com/for-sale/property/uae/?completion_status=ready']
    for url in urls:
        meta = {'parent': url}
        response = requests.get(url, headers=headers, proxies=proxy_t)
    sel = Selector(text=response.content)
    property_list = sel.xpath('//li[@role="article"]/article')
    links = []
    for prop in property_list:
        link = prop.xpath(
            'div/a/@href').extract()
        link = link[0].strip() if link else ''
        if link:
            url = 'https://www.bayut.com' + link.strip()
            links.append(url)
            if len(links) > 24:
                break
    if links:
        item = data.bayut_uae_fun(links)
    else:
        message_url(domain)


def isqaan():
    domain = 'isqan'
    links = []
    url = 'https://www.isqan.com/api/properties/published?availability=sale&page=1&pageSize=25'
    response = requests.get(url, headers=headers, proxies=proxy_t)
    data = json.loads(response.text)
    name_link = data.get('data').get('properties').get('results')
    for n_links in name_link:
        product_url = 'https://www.isqan.com/en/properties/'+str(p_id)
        links.append(product_url)
        if len(links) > 24:
            break
    if links:
        item = data.isqan(links)
    else:
        message_url(domain)


# def emlakjet_tur_():
#     urls = [
#         'https://www.emlakjet.com/satilik-konut/',
#         'https://www.emlakjet.com/satilik-isyeri/',
#         'https://www.emlakjet.com/devren-isyeri/',
#         'https://www.emlakjet.com/satilik-arsa/',
#         'https://www.emlakjet.com/kat-karsiligi-arsa/',
#         'https://www.emlakjet.com/satilik-turistik-tesis/',
#         'https://www.emlakjet.com/kiralik-konut/',
#         'https://www.emlakjet.com/kiralik-isyeri/',
#         'https://www.emlakjet.com/kiralik-arsa/',
#         'https://www.emlakjet.com/kiralik-turistik-tesis/',
#         'https://www.emlakjet.com/gunluk-kiralik-konut/',
#         'https://www.emlakjet.com/satilik-konut/projeler/', ]
#     cities = ['istanbul', 'ankara', 'izmir', 'adana', 'adiyaman', 'afyonkarahisar', 'agri', 'aksaray', 'amasya', 'antalya', 'ardahan', 'artvin', 'aydin', 'balikesir', 'bartin', 'batman', 'bilecik', 'bingol', 'bitlis', 'bolu', 'burdur', 'bursa', 'canakkale', 'cankiri', 'corum', 'denizli', 'diyarbakir', 'duzce', 'edirne', 'elazig', 'erzincan', 'erzurum', 'eskisehir', 'gaziantep', 'giresun', 'gumushane', 'hakkari', 'hatay', 'igdir', 'isparta', 'kahramanmaras', 'karabuk', 'karaman', 'kars', 'kastamonu', 'kayseri', 'kilis', 'kirikkale', 'kirsehir', 'kocaeli', 'konya', 'kutahya', 'malatya', 'manisa', 'mardin', 'mersin', 'mugla', 'mus', 'nevsehir', 'nigde', 'ordu', 'osmaniye', 'rize', 'sakarya', 'samsun', 'sanliurfa', 'siirt', 'sinop', 'sivas', 'sirnak', 'tekirdag', 'tokat', 'trabzon', 'tunceli', 'usak', 'van', 'yalova', 'yozgat', 'zonguldak', 'kktc']

#     for city in cities:
#         for room in range(1, 20):

#             for url in urls:
#                 domain = url.split('.')[1]

#                 url = url + city + '/?max_fiyat=2000000&min_fiyat=5000&oda_sayisi[]={}'.format(room)

#                 meta = {'maximum': 2000000, 'minimum': 5000}
#                 response = requests.get(url, headers=headers, proxies=proxies_t)
#                 data1 = response.content
#                 k = next_fun_tur(data1, meta)


# def next_fun_tur(data1, meta):
#     # print(meta,'++++++++++++++++++++')
#     minimum = meta.get('minimum')
#     maximum = meta.get('maximum')

#     sel = Selector(text=data1)

#     total_count = sel.xpath(
#         '//div[@class="_2NcmX"]/span/strong/text()').extract()
#     if total_count:

#         total_count = total_count[0].replace('.', '')
#         if int(total_count) > 1500:
#             avg_price = round(int(maximum + minimum) / 2)
#             split_prices = [(minimum, avg_price), (avg_price, maximum)]
#             for low_price_new, high_price_new in split_prices:
#                 new_url = 'https://www.emlakjet.com/satilik-konut/?max_fiyat=' + \
#                     str(high_price_new) + \
#                     '&min_fiyat=' + str(low_price_new)
#                 requests.get(new_url, meta={'maximum': high_price_new, 'minimum': low_price_new})

#         else:

#             links_ = sel.xpath(
#                 '//div[@class="w_bXG"]/a[@data-ej-category="listingpage"]/@href').extract()
#             links = []
#             for link in links_:
#                 # print(link,'33333333333333333')
#                 link = 'https://www.emlakjet.com' + link
#                 links.append(link)
#                 if len(links) > 24:
#                     break
#             if links:
#                 item = data.emlakjet_tur_fun(links)
#             else:
#                 domain = "emlakjet_tur"
#                 message_url(domain)


def olx_bah_():
    url = 'https://olx.com.bh/en/properties/'
    response = requests.get(url, headers=headers)
    sel = Selector(text=response.content)

    links_ = sel.xpath(
        '//div[@class="ads__item__info"]/a/@href').extract()
    links = []
    for url in links_:
        url = url.strip()
        if '/en/' not in url:
            url = url.replace('/ad/', '/en/ad/').strip()
            links.append(url)
            if len(links) > 24:
                break
    if links:
        item = data.olx_bah_fun(links)
    else:
        message_url(domain)


def olx_():
    url = 'https://olx.com.eg/en/properties/'
    response = requests.get(url, headers=headers)
    # print(response)
    sel = Selector(text=response.content)
    links_ = sel.xpath(
        '//div[@class="ads__item__info"]/a/@href').extract()
    links = []
    for url in links_:
        links.append(url)
        if len(links) > 24:
            break
    if links:
        item = data.olx_fun(links)
    else:
        message_url(domain)


# def qatarliving_qat_():
#     urls = ['https://www.qatarliving.com/classifieds/properties/sale',
#             'https://www.qatarliving.com/classifieds/properties/rent',
#             'https://www.qatarliving.com/classifieds/commercial-properties/sale',
#             'https://www.qatarliving.com/classifieds/commercial-properties/rent']
#     for url in urls:
#         response = requests.get(url, headers=headers, proxies=proxies_t)
#         # print(response,'/////////////')
#         # print(response.text)
#     sel = Selector(text=response.content)
#     # print(sel,'999999999')
#     parent_url = url.replace(
#         'https://www.qatarliving.com', '').strip()
#     # print(parent_url,']]]]]]]]]]]]]]')
#     type_select = sel.xpath(
#         '//div[@id="edit-type"]/div/label/text()').extract()
#     bedrooms_select = sel.xpath(
#         '//select[@id="edit-property-bedroom"]/option/@value').extract()
#     location_select = sel.xpath(
#         '//select[@id="edit-search-location"]/option/text()').extract()
#     location_select = [x.strip().replace(' / ', '-').strip().replace(' ', '-').strip(
#     ).strip('-').lower() for x in location_select] if location_select else ''
#     type_select = [x.strip().lower().replace(' ', '-')
#                    for x in type_select] if type_select else []
#     if bedrooms_select:
#         for loc in location_select:
#             for bed in bedrooms_select:
#                 for p_type in type_select:
#                     url = 'https://www.qatarliving.com/classifieds/properties/%s/in-%s/?price_min=0&price_max=500000&property_bedroom=%s&advertiser=all' % (
#                         str(p_type), str(loc), str(bed))
#                     meta = {'parent_url': parent_url}
#                     requests.get(url, headers=headers)
#                     data1 = response.content
#                     k = next_fun_qatar(data1, meta)
#     else:
#         for loc in location_select:
#             for p_type in type_select:
#                 url = 'https://www.qatarliving.com/classifieds/commercial-properties/%s/in-%s/?price_min=0&price_max=500000&advertiser=all' % (
#                     str(p_type), str(loc))
#                 meta = {'parent_url': parent_url}
#                 requests.get(url, headers=headers)
#                 data1 = response.content
#                 k = next_fun_qatar(data1, meta)


# def next_fun_qatar(data1, meta):
#     parent_url = meta.get('parent_url')
#     sel = Selector(text=data1)
#     properties_list = sel.xpath(
#         '//div[@id="classified_search_results"]/span/@href').extract()
#     links = []
#     for prop in properties_list:
#         prop = 'https://www.qatarliving.com' + prop
#         links.append(prop)
#         if len(links) > 24:
#             break
#     if links:
#         item = data.qatarliving_qat_fun(links)
#     else:
#         message_url(domain)

def error_fun(e, spider):
    logging.exception(str(e))
    count = len(open('script_error.log').readlines())
    if count > 0:
        f = open('script_error.log')
        l = f.readlines()
        m = re.findall('requests.*ProxyError.*?peer.*', ''.join(l))
        if m:
            for user in USERS:
                message = 'SPCD running stoped due to proxy fail' + str(spider)
                Slack.chat.post_message(user, message)
        else:
            for user in USERS:
                message = 'SPCD running stoped due to an exception is raised' + \
                    str(spider)
                Slack.chat.post_message(user, message)


try:
    aqar_ksa_()
except:
    spider = "aqar_ksa"
    error_fun(e, spider)

try:
    aqarmap_egp_()
except:
    spider = "aqarmap_egp"
    error_fun(e, spider)

try:
    bayut_ksa_()
except:
    spider = "bayut_ksa"
    error_fun(e, spider)

try:
    bayut_uae_()
except:
    e = 'exception'
    spider = "bayut_uae"
    error_fun(e, spider)

# try:
#     emlakjet_tur_()
# except:
#     e='exception'
#     domain = "emlakjet_tur"
#     error_fun(e, domain)


try:
    olx_bah_()
except:
    spider = "olx_bah"
    error_fun(e, spider)

try:
    olx_()
except:
    spider = " olx"
    error_fun(e, spider)

# try:
#     qatarliving_qat_()
# except:
#     spider = "qatarliving_qat"
#     error_fun(e, spider)
