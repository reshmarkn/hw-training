import re
import csv
import json
import random
import requests
import logging
import urllib

import comparison
from xpath import *
from log_file import *
from slacker import Slacker
from datetime import datetime
from pymongo import MongoClient
from scrapy.selector import Selector
from proxy import tor_proxy
from proxy import microleaves_proxy
from proxy import storm_proxy

# from sample_generate import * 

today = datetime.now().strftime('%Y_%m_%d')
# PROXY_LIST = [
#     '68.183.58.145:5566',
#     '157.230.189.5:5566'
# ]
# PROXY = random.choice(PROXY_LIST)
# proxy_url = "http://%s" % PROXY
# proxies = {"http": "http://%s" % PROXY,
#            "https": "http://%s" % PROXY}

proxy_t = tor_proxy()
proxies_t = proxy_t['proxies']

proxy_m = microleaves_proxy()
proxies_m = proxy_m['proxies']

proxy_s = storm_proxy()
proxies_s = proxy_s['proxies']
logging.basicConfig(filename='script_error.log',
                    format='%(asctime)s - %(message)s', level=logging.INFO)

headers = {

    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    # 'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
}

def aqar_ksa_fun(links):
    print('aqar_ksa')
    domain = 'aqar_ksa_2020_05'
    reference_number_=[]
    id__=[]
    url_=[]
    broker_display_name_=[]
    bedroom_ = []
    broker_=[]
    category_=[]
    category_url_=[]
    title_=[]
    description_=[]
    price_=[]
    currency_=[]
    price_text_ = []
    price_per_=[]
    bathrooms_=[]
    furnished_=[]
    rera_permit_number_=[]
    dtcm_licence_=[]
    amenities_=[]
    details_=[]
    agent_name_=[]
    number_of_photos_=[]
    user_id_=[]
    phone_number_=[]
    latitude_=[]
    longitude_=[]
    message = []
    location_=[]
    area_ = []
    bedroom1_ = []
    bathrooms1_ = []
    name_ = []
    message = []
    user_=[]
    agent_ = []
    image_ =[]
    address_ = []
    photo_ = []
    broker_id_ =[]
    area_f_=[]
    area_p_=[]
    image1_ = []
    image2_ =[]
    price_raw_=[]
    row_data = []
    user_id_ =[]
    phone_numbers_=[]
    latitude_=[]
    longitude_=[]

    img_=[]
    for link in links:
        response = requests.get(link, headers=headers)
        sel = Selector(text=response.content)
        link = response.url
        # print(link)
        if response.status_code == 200:
            name = sel.xpath(aqar_ksa.NAME_XPATH).extract_first('')
            category = sel.xpath(aqar_ksa.CATEGORY_XPATH).extract_first()
            description = sel.xpath(aqar_ksa.DESCRIPTION_XPATH).extract()
            id_ = sel.xpath(aqar_ksa.ID_XPATH).extract_first()
            bedroom = sel.xpath(aqar_ksa.BEDROOM_XPATH).extract_first()
            bathroom = sel.xpath(aqar_ksa.BATHROOM_XPATH).extract_first()
            furnished = sel.xpath(aqar_ksa.FURNISHED_XPATH).extract_first()
            price_text = sel.xpath(aqar_ksa.PRICE_XPATH).extract_first()
            category_url = sel.xpath(aqar_ksa.CATEGORY_URL_XPATH).extract_first()
            broker = sel.xpath(aqar_ksa.BROKER_XPATH).extract_first()

            title_.append(name) if name else ''
            category_.append(category) if category else ''
            description_.append(description_) if description else ''
            id__.append(id_) if id_ else ''
            bedroom_.append(bedroom) if bedroom else ''
            bathrooms_.append(bathroom) if bathroom else ''
            furnished_.append(furnished) if furnished else ''
            price_text_.append(price_text) if price_text else ''
            category_url_.append(category_url) if category_url else ''
            broker_.append(broker) if broker else ''
            user = sel.xpath(aqar_ksa.USER_XPATH).extract()[0]
            phone_script = sel.xpath(aqar_ksa.PHONE_XPATH).extract()
            phone_numbers = re.findall(
                r'{"usersInfo.*?\"phone\":\d+,', phone_script[0].strip()) if phone_script else ''
            phone_numbers = phone_numbers[0].strip() if phone_numbers else ''
            phone_numbers = re.findall(
                r'\"phone\":\d+,', phone_numbers.strip()) if phone_script else ''
            phone_numbers = phone_numbers[0].strip().strip(
                '\"phone\":').strip(',') if phone_numbers else ''
            phone_numbers_.append(phone_numbers)
            if user:
                data = user.replace(u'window.__store__ = ', '')if user else ''
                user_data = json.loads(data) if data else ''
                user_id = user_data.get('listingReducer').get(
                    'selectedListing').get('user_id')if user_data else ''
            user_id = user_id if user_id else ''
            user_id_.append(user_id)
            images_json=re.findall('imgs":.*?]',str(response.content))
            if images_json:
                image1 = images_json[0].replace('imgs":[','').replace(']','').split(',') 
                number_of_photos = len(image1)
            else:
                number_of_photos=''
            img_.append(number_of_photos)
            lat_long = sel.xpath('*').re_first('"location":(\{.*?\})')
            lat_long = lat_long.strip() if lat_long else ''
            lat_long = re.findall(r'\"premium\":\d+,\"location\":{\"lat\":.*?,\"lng\":.*?},\"links\"', lat_long) if lat_long else ''
            latitude = re.findall(r'\"lat\":.*?,', lat_long) if lat_long else ''
            latitude = latitude[0].strip().strip(
                '"lat":').strip(',').strip() if latitude else ''
            longitude = re.findall(r'\"lng\":.*?}', lat_long) if lat_long else ''
            longitude = longitude[0].strip().strip('"lng":').strip(
                ',').strip('}').strip() if longitude else ''
            latitude_.append(latitude)
            longitude_.append(longitude)
            id_list =[]
            id_ = link.split('-')[-1].strip()
            id_list.append(id_)
    if id_list==[]:
        msg ='id empty in aqar_ksa'
        message.append(msg)              
    if longitude_==[]:
        msg ='longitude empty in aqar_ksa'
        message.append(msg)   
    if latitude_ ==[]:
        msg ='latitude  empty in aqar_ksa'
        message.append(msg)          
    if img_ ==[]:
        msg ='No of photos empty in aqar_ksa'
        message.append(msg)       
    if phone_numbers_ ==[]:
        msg ='Phone is empty in aqar_ksa'
        message.append(msg)
    if user_id_ ==[]:
        msg ='User id is empty in aqar_ksa'
        message.append(msg)
    if title_ == []:
        msg = 'title field is empty in aqar_ksa'
        print(msg)
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in aqar_ksa'
        print(msg)
        message.append(msg) 
    if category_ == []:
        msg = 'category field is empty in aqar_ksa'
        print(msg)
        message.append(msg)    
    if id__ == []:
        msg = 'id_ field is empty in aqar_ksa'
        print(msg)
        message.append(msg)
    if broker_ == []:
        msg = 'broker field is empty in aqar_ksa'
        print(msg)
        message.append(msg)
    if bathrooms_ == []:
        msg = 'bathroom field is empty in aqar_ksa'
        print(msg)
        message.append(msg)
    if bedroom_ == []:
        msg = 'bedroom field is empty in aqar_ksa'
        print(msg)
        message.append(msg)
    if category_url_ == []:
        msg = 'category_url field is empty in aqar_ksa'
        print(msg)
        message.append(msg)
    if price_text_ == []:
        msg = 'price_text field is empty in aqar_ksa'
        print(msg)
        message.append(msg)
    if furnished_ == []:
        msg = 'furnished field is empty in aqar_ksa'
        print(msg)
        message.append(msg)
    slack_note(message,domain)

def aqarmap_egp_fun(links):
    print('aqarmap_egp_')
    domain = 'aqarmap_egp'
    reference_number_=[]
    id__=[]
    url_=[]
    broker_display_name_=[]
    bedroom_ = []
    broker_=[]
    category_=[]
    category_url_=[]
    title_=[]
    description_=[]
    price_=[]
    currency_=[]
    price_text_ = []
    price_per_=[]
    bathrooms_=[]
    furnished_=[]
    rera_permit_number_=[]
    dtcm_licence_=[]
    amenities_=[]
    details_=[]
    agent_name_=[]
    number_of_photos_=[]
    user_id_=[]
    phone_number_=[]
    latitude_=[]
    longitude_=[]
    message = []
    location_=[]
    area_ = []
    bedroom1_ = []
    bathrooms1_ = []
    name_ = []
    message = []
    user_=[]
    agent_ = []
    image_ =[]
    address_ = []
    photo_ = []
    broker_id_ =[]
    area_f_=[]
    area_p_=[]
    image1_ = []
    image2_ =[]
    price_raw_=[]
    row_data = []
    location_ =[]
    img_ =[]
    for link in links:
        response = requests.get(link, headers=headers)
        sel = Selector(text=response.content)
        link = response.url
        if response.status_code == 200:
            title = sel.xpath(aqarmap_egp.TITLE_XPATH).extract_first()
            category = sel.xpath(aqarmap_egp.CATEGORY_XPATH).extract_first()
            category_url = sel.xpath(aqarmap_egp.CATEGORY_URL_XPATH).extract_first()
            description = sel.xpath(aqarmap_egp.DESCRIPTION_XPATH).extract()
            id_url = sel.xpath(aqarmap_egp.ID_XPATH).extract_first()
            location = sel.xpath(aqarmap_egp.LOCATION_XPATH).extract_first()
            price = sel.xpath(aqarmap_egp.PRICE_XPATH).extract_first()
            bedrooms_text = sel.xpath(aqarmap_egp.BEDROOM_XPATH).extract_first()
            bathrooms_text = sel.xpath(aqarmap_egp.BATHROOM_XPATH).extract_first()
            broker_display_name = sel.xpath(aqarmap_egp.BROKER_XPATH).extract_first()
            area = sel.xpath(aqarmap_egp.AREA_XPATH).extract_first()
            name = sel.xpath(aqarmap_egp.NAME_XPATH).extract_first()
            img = sel.xpath(aqarmap_egp.IMAGE_XPATH).extract()
            property_text = sel.xpath(aqarmap_egp.PROPERTY_XPATH).extract()
            phone_number = sel.xpath(aqarmap_egp.PHONE_NUMBER_XPATH).extract()
            latitude_=[]
            latitude = sel.xpath(aqarmap_egp.LATITUDE_XPATH).extract()
            longitude_=[]
            longitude = sel.xpath(aqarmap_egp.LONGITUDE_XPATH).extract()
            longitude_.append(longitude_)
            latitude_.append(latitude)

            phone_numbers_ =[]
            phone_number = ",".join([urllib.parse.unquote(x).strip() for x in phone_number]) if phone_number else ''
            phone_numbers_.append(phone_number)
            img_.append(img)
            title_.append(title) if title else ''
            category_.append(category) if category else ''
            description_.append(description) if description else ''
            id__.append(id_url) if id_url else ''
            bedroom_.append(bedrooms_text) if bedrooms_text else ''
            bathrooms_.append(bathrooms_text) if bathrooms_text else ''
            category_url_.append(category_url) if category_url else ''
            broker_.append(broker_display_name) if broker_display_name else ''
            area_.append(area) if area else ''
            price_.append(price) if price else ''
            name_.append(name) if name else ''
            location_.append(location)
            property_text = [x.strip() for x in property_text if x.strip() != '']
            property_type = property_text[0].strip() if property_text else ''
            property_type_=[]
            property_type_.append(property_type)
    if longitude_ ==[]:
        msg ='longitude is empty in aqarmap_egp'
    if latitude_ ==[]:
        msg ='latitude is empty in aqarmap_egp'
    if phone_numbers_ ==[]:
        msg ='phone_numbers is empty in aqarmap_egp'
        message.append(msg)

    if property_type_ ==[]:
        msg = 'property type is empty in aqarmap_egp'
        message.append(msg)

    if img_ ==[]:
        msg = 'image field is empty in aqarmap_egp'
        message.append(msg)
    if location_ ==[]:
        msg ='location field is empty in aqarmap_egp'
        message.append(msg)
    if title_ == []:
        msg = 'title field is empty in aqarmap_egp'
        print(msg)
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in aqarmap_egp'
        print(msg)
        message.append(msg) 
    if category_ == []:
        msg = 'category field is empty in aqarmap_egp'
        print(msg)
        message.append(msg)    
    if id__ == []:
        msg = 'id_ field is empty in aqarmap_egp'
        print(msg)
        message.append(msg)
    if broker_ == []:
        msg = 'broker field is empty in aqarmap_egp'
        print(msg)
        message.append(msg)
    if bathrooms_ == []:
        msg = 'bathroom field is empty in aqarmap_egp'
        print(msg)
        message.append(msg)
    if bedroom_ == []:
        msg = 'bedroom field is empty in aqarmap_egp'
        print(msg)
        message.append(msg)
    if category_url_ == []:
        msg = 'category_url field is empty in aqarmap_egp'
        print(msg)
        message.append(msg)
    if name_ == []:
        msg = 'name field is empty in aqarmap_egp'
        print(msg)
        message.append(msg)
    if area_ == []:
        msg = 'area field is empty in aqarmap_egp'
        print(msg)
        message.append(msg)
    if price_ == []:
        msg = 'price field is empty in aqarmap_egp'
        print(msg)
        message.append(msg)
    slack_note(message,domain)
def bayut_ksa_fun(links):
    print('bayut_ksa_')
    domain = 'bayut_ksa'
    reference_number_=[]
    id__=[]
    url_=[]
    broker_display_name_=[]
    bedroom_ = []
    broker_=[]
    category_=[]
    category_url_=[]
    title_=[]
    description_=[]
    price_=[]
    currency_=[]
    price_text_ = []
    price_per_=[]
    bathrooms_=[]
    furnished_=[]
    rera_permit_number_=[]
    dtcm_licence_=[]
    amenities_=[]
    details_=[]
    agent_name_=[]
    number_of_photos_=[]
    user_id_=[]
    phone_number_=[]
    latitude_=[]
    longitude_=[]
    message = []
    location_=[]
    area_ = []
    bedroom1_ = []
    bathrooms1_ = []
    name_ = []
    message = []
    user_=[]
    agent_ = []
    image_ =[]
    address_ = []
    photo_ = []
    broker_id_ =[]
    area_f_=[]
    area_p_=[]
    image1_ = []
    image2_ =[]
    price_raw_=[]
    row_data = []
    for link in links:
        response = requests.get(link, headers=headers)
        sel = Selector(text=response.content)
        link = response.url
        if response.status_code == 200:
            title = sel.xpath(bayut_ksa.TITLE_XPATH).extract_first()
            location = sel.xpath(bayut_ksa.LOCATION_XPATH).extract_first()
            description = sel.xpath(bayut_ksa.DESCRIPTION_XPATH).extract()
            bedrooms1 = sel.xpath(bayut_ksa.BEDROOMS_XPATH1).extract_first()
            bathrooms1 = sel.xpath(bayut_ksa.BATHROOMS_XPATH1).extract_first()
            bedrooms2 = sel.xpath(bayut_ksa.BEDROOMS_XPATH2).extract_first()
            bathrooms2 = sel.xpath(bayut_ksa.BATHROOMS_XPATH2).extract_first()
            broker_display_name = sel.xpath(
                bayut_ksa.BROKER_DISPLAY_NAME_XPATH).extract_first()
            id_ = sel.xpath(bayut_ksa.ID__XPATH).extract_first()
            category = sel.xpath(bayut_ksa.CATEGORY_XPATH).extract_first()
            category_url = sel.xpath(bayut_ksa.CATEGORY_URL_XPATH).extract_first()
            rera_permit_number = sel.xpath(bayut_ksa.RERA_PERMIT_NUMBER).extract_first()
            price_per = sel.xpath(bayut_ksa.PRICE_PER_XPATH).extract_first()
            price = sel.xpath(bayut_ksa.PRICE_XPATH).extract_first()
            reference_nub = sel.xpath(bayut_ksa.REFER_NUB_XPATH).extract_first()
            phone_script = sel.xpath(bayut_ksa.PHONE_SCRIPT_XPATH).extract()
            # print(phone_script)
            try:
                phone_script = re.findall(r'\"phoneNumber\":\{.*?\},', phone_script[0].strip()) if phone_script else ''
                phone_script = json.loads(phone_script[0].strip().strip('"phoneNumber":').strip(',').replace('[', '').replace(']', '').replace(':,', ':null,')).values() if phone_script else ''
                phone_numbers = list(phone_script) if phone_script else ''
                phone_numbers = [x.strip() for x in phone_numbers if x] if phone_numbers else ''
                phone_numbers = [x.strip() for x in phone_numbers] if phone_numbers else ''
                phone_numbers = [x.strip() for x in phone_numbers if x] if phone_numbers else ''
                phone_numbers = ', '.join(phone_numbers) if phone_numbers else ''
            except:
                phone_numbers =''
            phone_numbers_=[]
            phone_numbers_.append(phone_numbers)

            data = sel.xpath(bayut_ksa.DATA_XPATH)
            amenities_str = ''
            if data:
                for amt in data:
                    key = amt.xpath('span[@class="_3af7fa95"]/text()').extract()
                    value = amt.xpath('span[@class="_812aa185"]/text()').extract()
                    keys = ' '.join(''.join(key).strip().strip().strip(
                        ':').split()) if key else ''
                    values = ' '.join(
                        ''.join(value).strip().split()) if value else ''
                    if key:
                        amenities_str = amenities_str + keys + ':' + values + ', '
            amenities_str = amenities_str.strip(
                ', ').strip() if amenities_str else ''
            amenities_str = amenities_str.strip(
                ', ').strip() if amenities_str else ''
            amenities_=[]
            amenities_.append(amenities_str)
            user = sel.xpath(bayut_ksa.USER_XPATH).extract()
            user = ''.join(user) if user else ''
            if '-' in user:
                user_data = user.split('-') if user else ''
                user_id = user_data[-1] if user_data else ''
            user_id = user_id.replace('/', '') if user_id else ''

            user_id_=[]
            user_id_.append(user_id)
            title_.append(title) if title else ''
            location_.append(location) if location else ''
            description_.append(description) if description else ''
            bedroom_.append(bedrooms1) if bedrooms1 else ''
            bathrooms_.append(bathrooms1) if bathrooms1 else ''
            bedroom1_.append(bedrooms2) if bedrooms2 else ''
            bathrooms1_.append(bathrooms2) if bathrooms2 else ''
            broker_display_name_.append(broker_display_name) if broker_display_name else ''
            id__.append(id_) if id_ else ''
            category_.append(category) if category else ''
            category_url_.append(category_url_) if category_url else ''
            price_per_.append(price_per) if price_per else ''
            price_.append(price) if price else ''
            reference_number_.append(reference_nub) if reference_nub else ''
            rera_permit_number_.append(rera_permit_number) if rera_permit_number else ''

    #         row = [reference_number_,id__,url_,broker_display_name_,bedroom_ ,broker_,category_,category_url_,title_,description_,price_,currency_,price_text_ ,price_per_,bathrooms_,furnished_,rera_permit_number_,dtcm_licence_,amenities_,details_,agent_name_,number_of_photos_,user_id_,phone_number_,latitude_,longitude_,message ,location_,area_ ,bedroom1_ ,bathrooms1_ ,name_ ,message ,user_,agent_ ,image_ ,address_ ,photo_ ,broker_id_ ,area_f_,area_p_,image1_ ,image2_ ,price_raw_]
    #         row_data.append(row)

    # Sample_Genaration(domain,row_data)
    if phone_numbers_ ==[]:
        msg ='phone number is empty in bayut_ksa'
        message.append(msg)
    if amenities_ ==[]:
        msg ='amenities field is empty in bayut_ksa'
        message.append(msg)
    if user_id_ ==[]:
        msg ='user id is empty in bayut_ksa'
        message.append(msg)

    if title_ == []:
        msg = 'title field is empty in bayut_ksa'
        print(msg)
        message.append(msg)
    if location_ == []:
        msg = 'location field is empty in bayut_ksa'
        print(msg)
        message.append(msg)        
    if description_ == []:
        msg = 'description field is empty in bayut_ksa'
        print(msg)
        message.append(msg) 
    if category_ == []:
        msg = 'category field is empty in bayut_ksa'
        print(msg)
        message.append(msg)    
    if id__ == []:
        msg = 'id_ field is empty in bayut_ksa'
        print(msg)
        message.append(msg)
    if broker_display_name_ == []:
        msg = 'broker_display_name field is empty in bayut_ksa'
        print(msg)
        message.append(msg)
    if bathrooms_ == []:
        msg = 'bathroom1 field is empty in bayut_ksa'
        print(msg)
        message.append(msg)
    if bathrooms1_ == []:
        msg = 'bathroom2 field is empty in bayut_ksa'
        print(msg)
        message.append(msg)
    if bedroom_ == []:
        msg = 'bedroom1 field is empty in bayut_ksa'
        print(msg)
        message.append(msg)
    if bedroom1_ == []:
        msg = 'bedroom2 field is empty in bayut_ksa'
        print(msg)
        message.append(msg)

    if category_url_ == []:
        msg = 'category_url field is empty in bayut_ksa'
        print(msg)
        message.append(msg)
    if price_text_ == []:
        msg = 'price_text field is empty in bayut_ksa'
        print(msg)
        message.append(msg)
    if price_per_ == []:
        msg = 'price_per field is empty in bayut_ksa'
        print(msg)
        message.append(msg)
    if price_ == []:
        msg = 'price field is empty in bayut_ksa'
        print(msg)
        message.append(msg)
    if reference_number_ == []:
        msg = 'reference_number field is empty in bayut_ksa'
        print(msg)
        message.append(msg)
    if rera_permit_number_ ==[]:
        msg = 'rera_permit_number_ field is empty in bayut_ksa'
        message.append(msg)

    slack_note(message,domain)
def bayut_uae_fun(links):
    print('bayut_uae_')
    domain = 'bayut_uae'
    reference_number_=[]
    id__=[]
    url_=[]
    broker_display_name_=[]
    bedroom_ = []
    broker_=[]
    category_=[]
    category_url_=[]
    title_=[]
    description_=[]
    price_=[]
    currency_=[]
    price_text_ = []
    price_per_=[]
    bathrooms_=[]
    furnished_=[]
    rera_permit_number_=[]
    dtcm_licence_=[]
    amenities_=[]
    details_=[]
    agent_name_=[]
    number_of_photos_=[]
    user_id_=[]
    phone_number_=[]
    latitude_=[]
    longitude_=[]
    message = []
    location_=[]
    area_ = []
    bedroom1_ = []
    bathrooms1_ = []
    name_ = []
    message = []
    user_=[]
    agent_ = []
    image_ =[]
    address_ = []
    photo_ = []
    broker_id_ =[]
    area_f_=[]
    area_p_=[]
    image1_ = []
    image2_ =[]
    price_raw_=[]
    listing_id_ =[]
    row_data = []
    ded_ =[]
    package_type_=[]
    verified_list=[]
    locality_ =[]
    object_id_ =[]
    furunished_list=[]
    for link in links:
        response = requests.get(link, headers=headers,proxies=proxy_s)
        sel = Selector(text=response.content)
        # print(sel)
        link = response.url
        # print(link,'00000000000000000000')
        if response.status_code == 200:
            title = sel.xpath(bayut_uae.TITLE_XPATH).extract_first()
            location = sel.xpath(bayut_uae.LOCATION_XPATH).extract_first()
            description = sel.xpath(bayut_uae.DESCRIPTION_XPATH).extract()
            bedrooms1 = sel.xpath(bayut_uae.BEDROOMS_XPATH1).extract_first()
            bathrooms1 = sel.xpath(bayut_uae.BATHROOMS_XPATH1).extract_first()
            bedrooms2 = sel.xpath(bayut_uae.BEDROOMS_XPATH2).extract_first()
            bathrooms2 = sel.xpath(bayut_uae.BATHROOMS_XPATH2).extract_first()
            broker_display_name = sel.xpath(
                bayut_uae.BROKER_DISPLAY_NAME_XPATH).extract_first()
            id_ = sel.xpath(bayut_uae.ID__XPATH).extract_first()
            category = sel.xpath(bayut_uae.CATEGORY_XPATH).extract_first()
            category_url = sel.xpath(bayut_uae.CATEGORY_URL_XPATH).extract_first()
            rera_permit_number = sel.xpath(bayut_uae.RERA_PERMIT_NUMBER).extract_first()
            price_per = sel.xpath(bayut_uae.PRICE_PER_XPATH).extract_first()
            price = sel.xpath(bayut_uae.PRICE_XPATH).extract_first()
            reference_nub = sel.xpath(bayut_uae.REFER_NUB_XPATH).extract_first()
            rera_permit_number = sel.xpath(bayut_uae.RERA_PERMIT_NUMBER).extract_first()
            verified = sel.xpath(bayut_uae.VERIFIED_XPATH).extract_first()
            currency = sel.xpath(bayut_uae.CURRENCY_XPATH).extract_first()
            amenities = sel.xpath(bayut_uae.AMENITIES_XPATH).extract()
            details = sel.xpath(bayut_uae.DETAILS_XPATH).extract()
            image = sel.xpath(bayut_uae.IMG_XPATH).extract()
            phone = sel.xpath(bayut_uae.PHONE_XPATH).extract()
            ded =sel.xpath(bayut_uae.DED_XPATH).extract()
            longitude = sel.xpath(bayut_uae.LONGITUDE_XPATH).extract()
            latitude = sel.xpath(bayut_uae.LATITUDE_XPATH).extract()
            listing_id = sel.xpath(bayut_uae.LISTING_XPATH).extract()
            package_type = sel.xpath(bayut_uae.PAKAGE).extract()
            locality = sel.xpath(bayut_uae.LOCALITY_XPATH).extract()
            object_id = sel.xpath(bayut_uae.OBJECT_ID_XPATH).extract()
            furunished = sel.xpath(bayut_uae.FURNISHED_XPATH).extract() 
            furunished_list.append(furunished)
            object_id_.append(object_id_)
            locality_.append(locality)
            package_type_.append(package_type)
            listing_id_.append(listing_id)
            latitude_.append(latitude)
            longitude_.append(longitude)
            ded_.append(ded)
            phone_number_.append(phone_number_)  
            image_.append(image)
            details_.append(details)
            amenities_.append(amenities)
            currency_.append(currency)
            title_.append(title) if title else ''
            location_.append(location) if location else ''
            description_.append(description) if description else ''
            bedroom_.append(bedrooms1) if bedrooms1 else ''
            bathrooms_.append(bathrooms1) if bathrooms1 else ''
            bedroom1_.append(bedrooms2) if bedrooms2 else ''
            bathrooms1_.append(bathrooms2) if bathrooms2 else ''
            broker_display_name_.append(broker_display_name) if broker_display_name else ''
            id__.append(id_) if id_ else ''
            category_.append(category) if category else ''
            category_url_.append(category_url_) if category_url else ''
            price_per_.append(price_per) if price_per else ''
            price_.append(price) if price else ''
            reference_number_.append(reference_nub) if reference_nub else ''
            rera_permit_number_.append(rera_permit_number) if rera_permit_number else ''
            verified_list.append(verified) if verified else ''
 
    #         row = [reference_number_,id__,url_,broker_display_name_,bedroom_ ,broker_,category_,category_url_,title_,description_,price_,currency_,price_text_ ,price_per_,bathrooms_,furnished_,rera_permit_number_,dtcm_licence_,amenities_,details_,agent_name_,number_of_photos_,user_id_,phone_number_,latitude_,longitude_,message ,location_,area_ ,bedroom1_ ,bathrooms1_ ,name_ ,message ,user_,agent_ ,image_ ,address_ ,photo_ ,broker_id_ ,area_f_,area_p_,image1_ ,image2_ ,price_raw_]
    #         row_data.append(row)

    # Sample_Genaration(domain,row_data)
    if object_id_ ==[]:
        msg = 'object id is updated in bayut_uae'
        message.append(msg)
    if furunished_list ==[]:
        msg='Furnished filed is empty in bayut_uae'
        message.append(msg)
        
    if locality_ ==[]:
        msg = 'locality is updated in bayut_uae'
    if package_type_ ==[]:
        msg = 'package_type is updated in bayut_uae'
        message.append(msg)

    if listing_id_ ==[]:
        msg ='listing id is updated in bayut_uae'
        message.append(msg)
    if latitude_ ==[]:
        msg = 'latitude is updated in bayut_uae'
        message.append(msg)
    if longitude_ ==[]:
        msg = 'longitude_ is updated in bayut_uae'
        message.append(msg)
    if ded_ ==[]:
        msg = 'ded is updated in bayut_uae'
        message.append(msg)
    if phone_number_ ==[]:
        msg = 'phone number xpath is updated in bayut_uae'
        message.append(msg)

    if image_ ==[]:
        msg = 'image xpath is empty in bayut_uae'
        message.append(msg)

    if details_ ==[]:
        msg = 'details is empty in bayut_uae'
        message.append(msg)

    if amenities_ == []:
        msg = 'amenities is empty in bayut_uae'
        message.append(msg)

    if rera_permit_number_ ==[]:
        msg = 'permit number is empty in bayut_uae'
        message.append(msg)
    if currency == []:
        msg = 'currency field is empty in bayut_uae'
        message.append(msg)
    if title_ == []:
        msg = 'title field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    if location_ == []:
        msg = 'location field is empty in bayut_uae'
        print(msg)
        message.append(msg)        
    if description_ == []:
        msg = 'description  field is empty in bayut_uae'
        print(msg)
        message.append(msg) 
    if category_ == []:
        msg = 'category field is empty in bayut_uae'
        print(msg)
        message.append(msg)    
    if id__ == []:
        msg = 'id_ field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    if broker_display_name_ == []:
        msg = 'broker_display_name field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    if bathrooms_ == []:
        msg = 'bathroom1 field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    if bathrooms1_ == []:
        msg = 'bathroom2 field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    if bedroom_ == []:
        msg = 'bedroom1 field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    if bedroom1_ == []:
        msg = 'bedroom2 field is empty in bayut_ksa'
        print(msg)
        message.append(msg)

    if category_url_ == []:
        msg = 'category_url field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    if price_text_ == []:
        msg = 'price_text field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    if price_per_ == []:
        msg = 'price_per field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    if price_ == []:
        msg = 'price field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    if reference_number_ == []:
        msg = 'reference_number field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    if verified_list == []:
        msg = 'verified list empty'
        message.append(msg)
    slack_note(message,domain)
def emlakjet_tur_fun(links):
    print('emlakjet_tur_')
    domain = 'emlakjet_tur'
    reference_number_=[]
    id__=[]
    url_=[]
    broker_display_name_=[]
    bedroom_ = []
    broker_=[]
    category_=[]
    category_url_=[]
    title_=[]
    description_=[]
    price_=[]
    currency_=[]
    price_text_ = []
    price_per_=[]
    bathrooms_=[]
    furnished_=[]
    rera_permit_number_=[]
    dtcm_licence_=[]
    amenities_=[]
    details_=[]
    agent_name_=[]
    number_of_photos_=[]
    user_id_=[]
    phone_number_=[]
    latitude_=[]
    longitude_=[]
    message = []
    location_=[]
    area_ = []
    bedroom1_ = []
    bathrooms1_ = []
    name_ = []
    message = []
    user_=[]
    agent_ = []
    image_ =[]
    address_ = []
    photo_ = []
    broker_id_ =[]
    area_f_=[]
    area_p_=[]
    image1_ = []
    image2_ =[]
    price_raw_=[]
    row_data = []
    for link in links:
        response = requests.get(link, headers=headers)
        sel = Selector(text=response.content)
        # print(sel)
        link = response.url
        # print(link,'00000000000000000000')
        if response.status_code == 404 or response.status_code == 301:
            pass
        elif response.status_code == 200:
            title = sel.xpath(emlakjet_tur.TITLE_XPATH).extract_first()
            description = sel.xpath(emlakjet_tur.DESCRIPTION_XPATH).extract()
            bedrooms = sel.xpath(emlakjet_tur.BEDROOMS_XPATH).extract_first()
            bathrooms = sel.xpath(emlakjet_tur.BATHROOMS_XPATH).extract_first()
            id_ = sel.xpath(emlakjet_tur.ID_XPATH).extract_first()
            category = sel.xpath(emlakjet_tur.CATEGORY_XPATH).extract_first()
            category_url = sel.xpath(emlakjet_tur.CATEGORY_URL_XPATH).extract_first()
            price = sel.xpath(emlakjet_tur.PRICE_XPATH).extract_first()
            broker = sel.xpath(emlakjet_tur.BROKER_XPATH).extract_first()            
            user = sel.xpath(emlakjet_tur.USER_XPATH).extract_first()
            amenities = sel.xpath(emlakjet_tur.AMENITIES_XPATH).extract_first()
            agent = sel.xpath(emlakjet_tur.AGENT_XPATH).extract_first()
            phone_number = sel.xpath(emlakjet_tur.PHONE_XPATH).extract_first()
            image = sel.xpath(emlakjet_tur.IMAGE_XPATH).extract_first()
            area = sel.xpath(emlakjet_tur.AREA_XPATH).extract_first()
            
            title_.append(title) if title else ''
            description_.append(description) if description else ''
            bedroom_.append(bedrooms) if bedrooms else ''
            bathrooms_.append(bathrooms) if bathrooms else ''
            id__.append(id_) if id_ else ''
            category_.append(category) if category else ''
            category_url_.append(category_url_) if category_url else ''
            price_.append(price) if price else ''
            broker_.append(broker) if broker else ''
            user_.append(user) if user else ''
            amenities_.append(amenities) if amenities else ''
            agent_.append(agent) if agent else ''
            phone_number_.append(phone_number) if phone_number else ''
            image_.append(image) if image else ''
            area_.append(area) if area else ''
    #         row = [reference_number_,id__,url_,broker_display_name_,bedroom_ ,broker_,category_,category_url_,title_,description_,price_,currency_,price_text_ ,price_per_,bathrooms_,furnished_,rera_permit_number_,dtcm_licence_,amenities_,details_,agent_name_,number_of_photos_,user_id_,phone_number_,latitude_,longitude_,message ,location_,area_ ,bedroom1_ ,bathrooms1_ ,name_ ,message ,user_,agent_ ,image_ ,address_ ,photo_ ,broker_id_ ,area_f_,area_p_,image1_ ,image2_ ,price_raw_]
    #         row_data.append(row)

    # Sample_Genaration(domain,row_data)

    if title_ == []:
        msg = 'title field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in emlakjet_tur'
        print(msg)
        message.append(msg) 
    if category_ == []:
        msg = 'category field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)    
    if id__ == []:
        msg = 'id_ field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if bathrooms_ == []:
        msg = 'bathroom1 field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if bedroom_ == []:
        msg = 'bedroom1 field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)

    if category_url_ == []:
        msg = 'category_url field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if price_ == []:
        msg = 'price field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if broker_ == []:
        msg = 'broker field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if agent_ == []:
        msg = 'agent field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if user_ == []:
        msg = 'user field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if image_ == []:
        msg = 'image field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if area_ == []:
        msg = 'area field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if phone_number_ == []:
        msg = 'phone_number field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if amenities_ == []:
        msg = 'amenities field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    slack_note(message,domain)
def justproperty_bah_fun(link):
    print('justproperty_bah_')
    domain = 'justproperty_bah'
    reference_number_=[]
    id__=[]
    url_=[]
    broker_display_name_=[]
    bedroom_ = []
    broker_=[]
    category_=[]
    category_url_=[]
    title_=[]
    description_=[]
    price_=[]
    currency_=[]
    price_text_ = []
    price_per_=[]
    bathrooms_=[]
    furnished_=[]
    rera_permit_number_=[]
    dtcm_licence_=[]
    amenities_=[]
    details_=[]
    agent_name_=[]
    number_of_photos_=[]
    user_id_=[]
    phone_number_=[]
    latitude_=[]
    longitude_=[]
    message = []
    location_=[]
    area_ = []
    bedroom1_ = []
    bathrooms1_ = []
    name_ = []
    message = []
    user_=[]
    agent_ = []
    image_ =[]
    address_ = []
    photo_ = []
    broker_id_ =[]
    area_f_=[]
    area_p_=[]
    image1_ = []
    image2_ =[]
    price_raw_=[]
    row_data = []
    # for link in links:
    # print(link)
    response = requests.get(link, headers=headers)
    # sel = Selector(text=response.content)
    # print(sel)
    link = response.url
    # print(link,'00000000000000000000')
    if response.status_code == 200:
        title = sel.xpath(justproperty_bah.TITLE_XPATH).extract_first()
        description = sel.xpath(justproperty_bah.DESCRIPTION_XPATH).extract()
        bedrooms = sel.xpath(justproperty_bah.BEDROOMS_XPATH).extract_first()
        bathrooms = sel.xpath(justproperty_bah.BATHROOMS_XPATH).extract_first()
        id_ = sel.xpath(justproperty_bah.ID_XPATH).extract_first()
        category = sel.xpath(justproperty_bah.CATEGORY_XPATH).extract_first()
        category_url = sel.xpath(justproperty_bah.CATEGORY_URL_XPATH).extract()
        price = sel.xpath(justproperty_bah.PRICE_XPATH).extract_first()
        broker = sel.xpath(justproperty_bah.BROKER_XPATH).extract_first()            
        amenities = sel.xpath(justproperty_bah.AMENITIES_XPATH).extract_first()
        agent = sel.xpath(justproperty_bah.AGENT_XPATH).extract_first()
        phone_number = sel.xpath(justproperty_bah.PHONE_XPATH).extract_first()
        image = sel.xpath(justproperty_bah.IMAGE_XPATH).extract_first()
        area = sel.xpath(justproperty_bah.DETAILS_XPATH).extract_first()
        price_per = sel.xpath(justproperty_bah.PRICE_PER_XPATH).extract_first()
        address = sel.xpath(justproperty_bah.ADDRESS_XPATH).extract_first()
        location = sel.xpath(justproperty_bah.LOCATION_XPATH).extract_first()
        furnished = sel.xpath(justproperty_bah.FURNISHED_XPATH).extract_first()
        photo = sel.xpath(justproperty_bah.PHOTO_XPATH).extract_first()
        reference_nub = sel.xpath(justproperty_bah.REFER_NUB_XPATH).extract_first()
        
        title_.append(title) if title else ''
        description_.append(description) if description else ''
        bedroom_.append(bedrooms) if bedrooms else ''
        bathrooms_.append(bathrooms) if bathrooms else ''
        id__.append(id_) if id_ else ''
        category_.append(category) if category else ''
        category_url_.append(category_url_) if category_url else ''
        price_.append(price) if price else ''
        broker_.append(broker) if broker else ''
        amenities_.append(amenities) if amenities else ''
        agent_.append(agent) if agent else ''
        phone_number_.append(phone_number) if phone_number else ''
        image_.append(image) if image else ''
        area_.append(area) if area else ''
        reference_number_.append(reference_nub) if reference_nub else ''
        photo_.append(photo) if photo else ''
        furnished_.append(furnished) if furnished else ''
        location_.append(location) if location else ''
        price_per_.append(price_per) if price_per else ''
        address_.append(address) if address else ''
#         row = [reference_number_,id__,url_,broker_display_name_,bedroom_ ,broker_,category_,category_url_,title_,description_,price_,currency_,price_text_ ,price_per_,bathrooms_,furnished_,rera_permit_number_,dtcm_licence_,amenities_,details_,agent_name_,number_of_photos_,user_id_,phone_number_,latitude_,longitude_,message ,location_,area_ ,bedroom1_ ,bathrooms1_ ,name_ ,message ,user_,agent_ ,image_ ,address_ ,photo_ ,broker_id_ ,area_f_,area_p_,image1_ ,image2_ ,price_raw_]
#         row_data.append(row)

# Sample_Genaration(domain,row_data)

    if title_ == []:
        msg = 'title field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in justproperty_bah'
        print(msg)
        message.append(msg) 
    if category_ == []:
        msg = 'category field is empty in justproperty_bah'
        print(msg)
        message.append(msg)    
    if id__ == []:
        msg = 'id_ field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if bathrooms_ == []:
        msg = 'bathroom1 field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if bedroom_ == []:
        msg = 'bedroom1 field is empty in justproperty_bah'
        print(msg)
        message.append(msg)

    if category_url_ == []:
        msg = 'category_url field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if price_ == []:
        msg = 'price field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if broker_ == []:
        msg = 'broker field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if agent_ == []:
        msg = 'agent field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if user_ == []:
        msg = 'user field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if image_ == []:
        msg = 'image field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if area_ == []:
        msg = 'area field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if phone_number_ == []:
        msg = 'phone_number field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if amenities_ == []:
        msg = 'amenities field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    slack_note(message,domain)

def justproperty_qat_fun(links):
    print('justproperty_qat_')
    domain = 'justproperty_qat'
    reference_number_=[]
    id__=[]
    url_=[]
    broker_display_name_=[]
    bedroom_ = []
    broker_=[]
    category_=[]
    category_url_=[]
    title_=[]
    description_=[]
    price_=[]
    currency_=[]
    price_text_ = []
    price_per_=[]
    bathrooms_=[]
    furnished_=[]
    rera_permit_number_=[]
    dtcm_licence_=[]
    amenities_=[]
    details_=[]
    agent_name_=[]
    number_of_photos_=[]
    user_id_=[]
    phone_number_=[]
    latitude_=[]
    longitude_=[]
    message = []
    location_=[]
    area_ = []
    bedroom1_ = []
    bathrooms1_ = []
    name_ = []
    message = []
    user_=[]
    agent_ = []
    image_ =[]
    address_ = []
    photo_ = []
    broker_id_ =[]
    area_f_=[]
    area_p_=[]
    image1_ = []
    image2_ =[]
    price_raw_=[]
    row_data = []
    for link in links:
        response = requests.get(link, headers=headers)
        sel = Selector(text=response.content)
        # print(sel)
        link = response.url
        # print(link,'00000000000000000000')
        if response.status_code == 200:
            title = sel.xpath(justproperty_qat.TITLE_XPATH).extract_first()
            agent = sel.xpath(justproperty_qat.AGENT_XPATH).extract_first()
            bedrooms = sel.xpath(justproperty_qat.BEDROOMS_XPATH).extract_first()
            bathrooms = sel.xpath(justproperty_qat.BATHROOMS_XPATH).extract_first()
            description = sel.xpath(justproperty_qat.DESCRIPTION_XPATH).extract()
            price = sel.xpath(justproperty_qat.PRICE_XPATH).extract_first()
            address = sel.xpath(justproperty_qat.ADDRESS_XPATH).extract_first()
            broker_id = sel.xpath(justproperty_qat.BROKER_ID).extract_first()
            id_ = sel.xpath(justproperty_qat.ID_XPATH).extract_first()
            category = sel.xpath(justproperty_qat.CATEGORY_XPATH).extract_first()
            category_url = sel.xpath(justproperty_qat.CATEGORY_URL_XPATH).extract()
            broker = sel.xpath(justproperty_qat.BROKER_XPATH).extract_first()            
            furnished = sel.xpath(justproperty_qat.FURNISHED_XPATH).extract_first()
            price_per = sel.xpath(justproperty_qat.PRICE_PER_XPATH).extract_first()
            location = sel.xpath(justproperty_qat.LOCATION_XPATH).extract_first()
            amenities = sel.xpath(justproperty_qat.AMENITIES_XPATH).extract_first()
            reference_nub = sel.xpath(justproperty_qat.REFER_NUB_XPATH).extract_first()
            phone_number = sel.xpath(justproperty_qat.PHONE_XPATH).extract_first()
            image = sel.xpath(justproperty_qat.IMAGE_XPATH).extract_first()
            area_f = sel.xpath(justproperty_qat.AREA_XPATH_F).extract_first()
            area_p = sel.xpath(justproperty_qat.AREA_XPATH_P).extract_first()            
            
            title_.append(title) if title else ''
            description_.append(description) if description else ''
            bedroom_.append(bedrooms) if bedrooms else ''
            bathrooms_.append(bathrooms) if bathrooms else ''
            id__.append(id_) if id_ else ''
            category_.append(category) if category else ''
            category_url_.append(category_url_) if category_url else ''
            price_.append(price) if price else ''
            broker_.append(broker) if broker else ''
            amenities_.append(amenities) if amenities else ''
            agent_.append(agent) if agent else ''
            phone_number_.append(phone_number) if phone_number else ''
            image_.append(image) if image else ''
            reference_number_.append(reference_nub) if reference_nub else ''
            furnished_.append(furnished) if furnished else ''
            location_.append(location) if location else ''
            price_per_.append(price_per) if price_per else ''
            address_.append(address) if address else ''
            broker_id_.append(broker_id) if broker_id else ''
            area_f_.append(area_f) if area_f else ''
            area_p_.append(area_p) if area_p else '' 
            # print(title_)
            # print(category_)
            # print(area_p_)
            # print(image_)
    #         row = [reference_number_,id__,url_,broker_display_name_,bedroom_ ,broker_,category_,category_url_,title_,description_,price_,currency_,price_text_ ,price_per_,bathrooms_,furnished_,rera_permit_number_,dtcm_licence_,amenities_,details_,agent_name_,number_of_photos_,user_id_,phone_number_,latitude_,longitude_,message ,location_,area_ ,bedroom1_ ,bathrooms1_ ,name_ ,message ,user_,agent_ ,image_ ,address_ ,photo_ ,broker_id_ ,area_f_,area_p_,image1_ ,image2_ ,price_raw_]
    #         row_data.append(row)

    # Sample_Genaration(domain,row_data)

    if title_ == []:
        msg = 'title field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in justproperty_qat'
        print(msg)
        message.append(msg) 
    if category_ == []:
        msg = 'category field is empty in justproperty_qat'
        print(msg)
        message.append(msg)    
    if id__ == []:
        msg = 'id_ field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if bathrooms_ == []:
        msg = 'bathroom1 field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if bedroom_ == []:
        msg = 'bedroom1 field is empty in justproperty_qat'
        print(msg)
        message.append(msg)

    if category_url_ == []:
        msg = 'category_url field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if price_ == []:
        msg = 'price field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if broker_ == []:
        msg = 'broker field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if agent_ == []:
        msg = 'agent field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if image_ == []:
        msg = 'image field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if area_f_ == []:
        msg = 'area_f field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if area_p_ == []:
        msg = 'area_p field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if phone_number_ == []:
        msg = 'phone_number field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if amenities_ == []:
        msg = 'amenities field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if reference_number_ == []:
        msg = 'reference_number field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if broker_id_ == []:
        msg = 'broker_id field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if address_ == []:
        msg = 'address field is empty in justproperty_qat'
        print(msg)
        message.append(msg)    
    if price_per_ == []:
        msg = 'price_per field is empty in justproperty_qat'
        print(msg)
        message.append(msg)  
    if location_ == []:
        msg = 'location field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if furnished_ == []:
        msg = 'furnished field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    slack_note(message,domain)
def mubawab_qat_fun(links):
    print('mubawab_qat_')
    domain = 'mubawab_qat'
    reference_number_=[]
    id__=[]
    url_=[]
    broker_display_name_=[]
    bedroom_ = []
    broker_=[]
    category_=[]
    category_url_=[]
    title_=[]
    description_=[]
    price_=[]
    currency_=[]
    price_text_ = []
    price_per_=[]
    bathrooms_=[]
    furnished_=[]
    rera_permit_number_=[]
    dtcm_licence_=[]
    amenities_=[]
    details_=[]
    agent_name_=[]
    number_of_photos_=[]
    user_id_=[]
    phone_number_=[]
    latitude_=[]
    longitude_=[]
    message = []
    location_=[]
    area_ = []
    bedroom1_ = []
    bathrooms1_ = []
    name_ = []
    message = []
    user_=[]
    agent_ = []
    image_ =[]
    address_ = []
    photo_ = []
    broker_id_ =[]
    area_f_=[]
    area_p_=[]
    image1_ = []
    image2_ =[]
    price_raw_=[]
    row_data = []
    for link in links:
        response = requests.get(link, headers=headers)
        sel = Selector(text=response.content)
        # print(sel)
        link = response.url
        # print(link,'00000000000000000000')
        if response.status_code == 200:
            title = sel.xpath(mubawab_qat.TITLE_XPATH).extract_first()
            description = sel.xpath(mubawab_qat.DESCRIPTION_XPATH).extract()
            bedrooms = sel.xpath(mubawab_qat.BEDROOMS_XPATH).extract_first()
            bathrooms = sel.xpath(mubawab_qat.BATHROOMS_XPATH).extract_first()
            id_ = sel.xpath(mubawab_qat.ID_XPATH).extract_first()
            category = sel.xpath(mubawab_qat.CATEGORY_XPATH).extract_first()
            category_url = sel.xpath(mubawab_qat.CATEGORY_URL_XPATH).extract_first()
            price = sel.xpath(mubawab_qat.PRICE_XPATH).extract_first()
            phone_number = sel.xpath(mubawab_qat.PHONE_XPATH).extract_first()
            image = sel.xpath(mubawab_qat.IMAGE_XPATH).extract_first()
            amenities = sel.xpath(mubawab_qat.AMENITIES_XPATH).extract_first()
            area = sel.xpath(mubawab_qat.AREA_XPATH).extract_first()
            location = sel.xpath(mubawab_qat.LOCATION_XPATH).extract_first()            
            broker_display_name = sel.xpath(mubawab_qat.BROKER_DISPLAY_NAME_XPATH).extract_first()
            
            title_.append(title) if title else ''
            description_.append(description) if description else ''
            bedroom_.append(bedrooms) if bedrooms else ''
            bathrooms_.append(bathrooms) if bathrooms else ''
            id__.append(id_) if id_ else ''
            category_.append(category) if category else ''
            category_url_.append(category_url_) if category_url else ''
            price_.append(price) if price else ''
            amenities_.append(amenities) if amenities else ''
            phone_number_.append(phone_number) if phone_number else ''
            image_.append(image) if image else ''
            area_.append(area) if area else ''
            location_.append(location) if location else ''
            broker_display_name_.append(broker_display_name) if broker_display_name else ''
    #         row = [reference_number_,id__,url_,broker_display_name_,bedroom_ ,broker_,category_,category_url_,title_,description_,price_,currency_,price_text_ ,price_per_,bathrooms_,furnished_,rera_permit_number_,dtcm_licence_,amenities_,details_,agent_name_,number_of_photos_,user_id_,phone_number_,latitude_,longitude_,message ,location_,area_ ,bedroom1_ ,bathrooms1_ ,name_ ,message ,user_,agent_ ,image_ ,address_ ,photo_ ,broker_id_ ,area_f_,area_p_,image1_ ,image2_ ,price_raw_]
    #         row_data.append(row)

    # Sample_Genaration(domain,row_data)
   
    if title_ == []:
        msg = 'title field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in mubawab_qat'
        print(msg)
        message.append(msg) 
    if category_ == []:
        msg = 'category field is empty in mubawab_qat'
        print(msg)
        message.append(msg)    
    if id__ == []:
        msg = 'id_ field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    if bathrooms_ == []:
        msg = 'bathroom1 field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    if bedroom_ == []:
        msg = 'bedroom1 field is empty in mubawab_qat'
        print(msg)
        message.append(msg)

    if category_url_ == []:
        msg = 'category_url field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    if price_ == []:
        msg = 'price field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    if image_ == []:
        msg = 'image field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    if area_ == []:
        msg = 'area field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    if phone_number_ == []:
        msg = 'phone_number field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    if amenities_ == []:
        msg = 'amenities field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    if location_ == []:
        msg = 'location field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    if broker_display_name_ == []:
        msg = 'broker_display_name field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    slack_note(message,domain)
def olx_bah_fun(links):
    print('olx_bah_')
    domain = 'olx_bah'
    reference_number_=[]
    id__=[]
    url_=[]
    broker_display_name_=[]
    bedroom_ = []
    broker_=[]
    category_=[]
    category_url_=[]
    title_=[]
    description_=[]
    price_=[]
    currency_=[]
    price_text_ = []
    price_per_=[]
    bathrooms_=[]
    furnished_=[]
    rera_permit_number_=[]
    dtcm_licence_=[]
    amenities_=[]
    details_=[]
    agent_name_=[]
    number_of_photos_=[]
    user_id_=[]
    phone_number_=[]
    latitude_=[]
    longitude_=[]
    message = []
    location_=[]
    area_ = []
    bedroom1_ = []
    bathrooms1_ = []
    name_ = []
    message = []
    user_=[]
    agent_ = []
    image_ =[]
    address_ = []
    photo_ = []
    broker_id_ =[]
    area_f_=[]
    area_p_=[]
    image1_ = []
    image2_ =[]
    price_raw_=[]
    row_data = []
    for link in links:
        response = requests.get(link, headers=headers,proxies=proxy_t)
        sel = Selector(text=response.content)
        # print(sel)
        link = response.url
        # print(link,'00000000000000000000')
        if response.status_code == 200:
            title = sel.xpath(olx_bah.TITLE_XPATH).extract_first()
            description = sel.xpath(olx_bah.DESCRIPTION_XPATH).extract()
            bedrooms = sel.xpath(olx_bah.BEDROOMS_XPATH).extract_first()
            bathrooms = sel.xpath(olx_bah.BATHROOMS_XPATH).extract_first()
            phone_number = sel.xpath(olx_bah.PHONE_XPATH).extract_first()
            id_ = sel.xpath(olx_bah.ID_XPATH).extract_first()
            category = sel.xpath(olx_bah.CATEGORY_XPATH).extract_first()
            category_url = sel.xpath(olx_bah.CATEGORY_URL_XPATH).extract_first()
            area = sel.xpath(olx_bah.AREA_XPATH).extract_first()
            location = sel.xpath(olx_bah.LOCATION_XPATH).extract_first()            
            price_raw = sel.xpath(olx_bah.PRICE_RAW_XPATH).extract_first()
            amenities = sel.xpath(olx_bah.AMENITIES_XPATH).extract_first()
            broker = sel.xpath(olx_bah.BROKER_XPATH).extract_first()
            furnished = sel.xpath(olx_bah.FURNISHED_XPATH).extract_first()
            image1 = sel.xpath(olx_bah.IMAGE_XPATH1).extract_first()
            image2 = sel.xpath(olx_bah.IMAGE_XPATH2).extract_first()
            
            title_.append(title) if title else ''
            description_.append(description) if description else ''
            bedroom_.append(bedrooms) if bedrooms else ''
            bathrooms_.append(bathrooms) if bathrooms else ''
            id__.append(id_) if id_ else ''
            price_raw_.append(price_raw) if price_raw else ''
            category_.append(category) if category else ''
            category_url_.append(category_url_) if category_url else ''
            amenities_.append(amenities) if amenities else ''
            phone_number_.append(phone_number) if phone_number else ''
            area_.append(area) if area else ''
            location_.append(location) if location else ''
            furnished_.append(furnished) if furnished else ''
            broker_.append(broker) if broker else ''
            image1_.append(image1) if image1 else ''
            image2_.append(image2) if image2 else ''
    #         row = [reference_number_,id__,url_,broker_display_name_,bedroom_ ,broker_,category_,category_url_,title_,description_,price_,currency_,price_text_ ,price_per_,bathrooms_,furnished_,rera_permit_number_,dtcm_licence_,amenities_,details_,agent_name_,number_of_photos_,user_id_,phone_number_,latitude_,longitude_,message ,location_,area_ ,bedroom1_ ,bathrooms1_ ,name_ ,message ,user_,agent_ ,image_ ,address_ ,photo_ ,broker_id_ ,area_f_,area_p_,image1_ ,image2_ ,price_raw_]
    #         row_data.append(row)

    # Sample_Genaration(domain,row_data)

    if title_ == []:
        msg = 'title field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in olx_bah'
        print(msg)
        message.append(msg) 
    if category_ == []:
        msg = 'category field is empty in olx_bah'
        print(msg)
        message.append(msg)    
    if id__ == []:
        msg = 'id_ field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if bathrooms_ == []:
        msg = 'bathroom1 field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if bedroom_ == []:
        msg = 'bedroom1 field is empty in olx_bah'
        print(msg)
        message.append(msg)

    if category_url_ == []:
        msg = 'category_url field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if price_raw_ == []:
        msg = 'price_raw field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if image1_ == []:
        msg = 'image1 field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if image2_ == []:
        msg = 'image2 field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if area_ == []:
        msg = 'area field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if phone_number_ == []:
        msg = 'phone_number field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if amenities_ == []:
        msg = 'amenities field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if location_ == []:
        msg = 'location field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if broker_ == []:
        msg = 'broker field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if furnished_ == []:
        msg = 'furnished field is empty in olx_bah'
        print(msg)
        message.append(msg)
    slack_note(message,domain)

def olx_fun(links):
    print('olx_')
    domain = 'olx'
    reference_number_=[]
    id__=[]
    url_=[]
    broker_display_name_=[]
    bedroom_ = []
    broker_=[]
    category_=[]
    category_url_=[]
    title_=[]
    description_=[]
    price_=[]
    currency_=[]
    price_text_ = []
    price_per_=[]
    bathrooms_=[]
    furnished_=[]
    rera_permit_number_=[]
    dtcm_licence_=[]
    amenities_=[]
    details_=[]
    agent_name_=[]
    number_of_photos_=[]
    user_id_=[]
    phone_number_=[]
    latitude_=[]
    longitude_=[]
    message = []
    location_=[]
    area_ = []
    bedroom1_ = []
    bathrooms1_ = []
    name_ = []
    message = []
    user_=[]
    agent_ = []
    image_ =[]
    address_ = []
    photo_ = []
    broker_id_ =[]
    area_f_=[]
    area_p_=[]
    image1_ = []
    image2_ =[]
    price_raw_=[]
    row_data = []
    for link in links:
        response = requests.get(link, headers=headers)
        sel = Selector(text=response.content)
        # print(sel)
        link = response.url
        # print(link,'000000000000')
        if response.status_code == 200:
            title = sel.xpath(olx.TITLE_XPATH).extract_first()
            description = sel.xpath(olx.DESCRIPTION_XPATH).extract()
            bedrooms = sel.xpath(olx.BEDROOMS_XPATH).extract_first()
            bathrooms = sel.xpath(olx.BATHROOMS_XPATH).extract_first()
            phone_number = sel.xpath(olx.PHONE_XPATH).extract_first()
            id_ = sel.xpath(olx.ID_XPATH).extract()
            category = sel.xpath(olx.CATEGORY_XPATH).extract_first()
            category_url = sel.xpath(olx.CATEGORY_URL_XPATH).extract()
            area = sel.xpath(olx.AREA_XPATH).extract_first()
            location = sel.xpath(olx.LOCATION_XPATH).extract_first()            
            price_raw = sel.xpath(olx.PRICE_RAW_XPATH).extract_first()
            amenities = sel.xpath(olx.AMENITIES_XPATH).extract_first()
            broker = sel.xpath(olx.BROKER_XPATH).extract_first()
            furnished = sel.xpath(olx.FURNISHED_XPATH).extract_first()
            image1 = sel.xpath(olx.IMAGE_XPATH1).extract_first()
            image2 = sel.xpath(olx.IMAGE_XPATH2).extract_first()
            
            title_.append(title) if title else ''
            description_.append(description) if description else ''
            bedroom_.append(bedrooms) if bedrooms else ''
            bathrooms_.append(bathrooms) if bathrooms else ''
            id__.append(id_) if id_ else ''
            price_raw_.append(price_raw) if price_raw else ''
            category_.append(category) if category else ''
            category_url_.append(category_url_) if category_url else ''
            amenities_.append(amenities) if amenities else ''
            phone_number_.append(phone_number) if phone_number else ''
            area_.append(area) if area else ''
            location_.append(location) if location else ''
            furnished_.append(furnished) if furnished else ''
            broker_.append(broker) if broker else ''
            image1_.append(image1) if image1 else ''
            image2_.append(image2) if image2 else ''
    #         row = [reference_number_,id__,url_,broker_display_name_,bedroom_ ,broker_,category_,category_url_,title_,description_,price_,currency_,price_text_ ,price_per_,bathrooms_,furnished_,rera_permit_number_,dtcm_licence_,amenities_,details_,agent_name_,number_of_photos_,user_id_,phone_number_,latitude_,longitude_,message ,location_,area_ ,bedroom1_ ,bathrooms1_ ,name_ ,message ,user_,agent_ ,image_ ,address_ ,photo_ ,broker_id_ ,area_f_,area_p_,image1_ ,image2_ ,price_raw_]
    #         row_data.append(row)

    # Sample_Genaration(domain,row_data)
    if title_ == []:
        msg = 'title field is empty in olx'
        print(msg)
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in olx'
        print(msg)
        message.append(msg) 
    if category_ == []:
        msg = 'category field is empty in olx'
        print(msg)
        message.append(msg)    
    if id__ == []:
        msg = 'id_ field is empty in olx'
        print(msg)
        message.append(msg)
    if bathrooms_ == []:
        msg = 'bathroom1 field is empty in olx'
        print(msg)
        message.append(msg)
    if bedroom_ == []:
        msg = 'bedroom1 field is empty in olx'
        print(msg)
        message.append(msg)

    if category_url_ == []:
        msg = 'category_url field is empty in olx'
        print(msg)
        message.append(msg)
    if price_raw_ == []:
        msg = 'price_raw field is empty in olx'
        print(msg)
        message.append(msg)
    if image1_ == []:
        msg = 'image1 field is empty in olx'
        print(msg)
        message.append(msg)
    if image2_ == []:
        msg = 'image2 field is empty in olx'
        print(msg)
        message.append(msg)
    if area_ == []:
        msg = 'area field is empty in olx'
        print(msg)
        message.append(msg)
    if phone_number_ == []:
        msg = 'phone_number field is empty in olx'
        print(msg)
        message.append(msg)
    if amenities_ == []:
        msg = 'amenities field is empty in olx'
        print(msg)
        message.append(msg)
    if location_ == []:
        msg = 'location field is empty in olx'
        print(msg)
        message.append(msg)
    if broker_ == []:
        msg = 'broker field is empty in olx'
        print(msg)
        message.append(msg)
    if furnished_ == []:
        msg = 'furnished field is empty in olx'
        print(msg)
        message.append(msg)
    slack_note(message,domain)

def qatarliving_qat_fun(links):
    print('qatarliving_qat_')
    domain = 'qatarliving_qat'
    reference_number_=[]
    id__=[]
    url_=[]
    broker_display_name_=[]
    bedroom_ = []
    broker_=[]
    category_=[]
    category_url_=[]
    title_=[]
    description_=[]
    price_=[]
    currency_=[]
    price_text_ = []
    price_per_=[]
    bathrooms_=[]
    furnished_=[]
    rera_permit_number_=[]
    dtcm_licence_=[]
    amenities_=[]
    details_=[]
    agent_name_=[]
    number_of_photos_=[]
    user_id_=[]
    phone_number_=[]
    latitude_=[]
    longitude_=[]
    message = []
    location_=[]
    area_ = []
    bedroom1_ = []
    bathrooms1_ = []
    name_ = []
    message = []
    user_=[]
    agent_ = []
    image_ =[]
    address_ = []
    photo_ = []
    broker_id_ =[]
    area_f_=[]
    area_p_=[]
    image1_ = []
    image2_ =[]
    price_raw_=[]
    row_data = []
    for link in links:
        response = requests.get(link, headers=headers)
        sel = Selector(text=response.content)
        # print(sel)
        link = response.url
        # print(link,'000000000000')
        if response.status_code == 200:
            title = sel.xpath(qatarliving_qat.TITLE_XPATH).extract_first()
            # print(title,';;;;;;;;;;;;')
            description = sel.xpath(qatarliving_qat.DESCRIPTION_XPATH).extract()
            bedrooms = sel.xpath(qatarliving_qat.BEDROOMS_XPATH).extract_first()
            bathrooms = sel.xpath(qatarliving_qat.BATHROOMS_XPATH).extract_first()
            id_ = sel.xpath(qatarliving_qat.PROPERTY_ID_XPATH).extract_first()
            category = sel.xpath(qatarliving_qat.CATEGORY_XPATH).extract_first()
            category_url = sel.xpath(qatarliving_qat.CATEGORY_URL_XPATH).extract_first()
            price = sel.xpath(qatarliving_qat.PRICE_XPATH).extract_first()
            phone_number = sel.xpath(qatarliving_qat.PHONE_XPATH).extract_first()
            image = sel.xpath(qatarliving_qat.IMAGE_XPATH).extract_first()
            amenities = sel.xpath(qatarliving_qat.AMENITIES_XPATH).extract_first()
            furnished = sel.xpath(qatarliving_qat.FURNISHED_XPATH).extract_first()            
            
            title_.append(title) if title else ''
            description_.append(description) if description else ''
            bedroom_.append(bedrooms) if bedrooms else ''
            bathrooms_.append(bathrooms) if bathrooms else ''
            id__.append(id_) if id_ else ''
            category_.append(category) if category else ''
            category_url_.append(category_url_) if category_url else ''
            price_.append(price) if price else ''
            amenities_.append(amenities) if amenities else ''
            phone_number_.append(phone_number) if phone_number else ''
            image_.append(image) if image else ''
            furnished_.append(furnished_) if furnished else ''

            # print(title_,'////////////')
    #         row = [reference_number_,id__,url_,broker_display_name_,bedroom_ ,broker_,category_,category_url_,title_,description_,price_,currency_,price_text_ ,price_per_,bathrooms_,furnished_,rera_permit_number_,dtcm_licence_,amenities_,details_,agent_name_,number_of_photos_,user_id_,phone_number_,latitude_,longitude_,message ,location_,area_ ,bedroom1_ ,bathrooms1_ ,name_ ,message ,user_,agent_ ,image_ ,address_ ,photo_ ,broker_id_ ,area_f_,area_p_,image1_ ,image2_ ,price_raw_]
    #         row_data.append(row)

    # Sample_Genaration(domain,row_data)
    
    if title_ == []:
        msg = 'title field is empty in qatarliving_qat'
        print(msg)
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in qatarliving_qat'
        print(msg)
        message.append(msg) 
    if category_ == []:
        msg = 'category field is empty in qatarliving_qat'
        print(msg)
        message.append(msg)    
    if id__ == []:
        msg = 'id_ field is empty in qatarliving_qat'
        print(msg)
        message.append(msg)
    if bathrooms_ == []:
        msg = 'bathroom1 field is empty in qatarliving_qat'
        print(msg)
        message.append(msg)
    if bedroom_ == []:
        msg = 'bedroom1 field is empty in qatarliving_qat'
        print(msg)
        message.append(msg)

    if category_url_ == []:
        msg = 'category_url field is empty in qatarliving_qat'
        print(msg)
        message.append(msg)
    if price_ == []:
        msg = 'price field is empty in qatarliving_qat'
        print(msg)
        message.append(msg)
    if image_ == []:
        msg = 'image field is empty in qatarliving_qat'
        print(msg)
        message.append(msg)
    if phone_number_ == []:
        msg = 'phone_number field is empty in qatarliving_qat'
        print(msg)
        message.append(msg)
    if amenities_ == []:
        msg = 'amenities field is empty in qatarliving_qat'
        print(msg)
        message.append(msg)
    if furnished_ == []:
        msg = 'furnished field is empty in qatarliving_qat'
        print(msg)
        message.append(msg)
    slack_note(message,domain)
def dubizzle_fun(links):
    reference_number_list = []
    id_list = []
    broker_display_name_list = []
    broker_list = []
    category_list = []
    category_url_list = []
    title_list = []
    description_list = []
    location_list = []
    price_list = []
    currency_list = []
    price_per_list = []
    bedrooms_list = []
    bathrooms_list = []
    furnished_list = []
    rera_permit_number_list = []
    rera_registration_number_list = []
    amenities_list = []
    details_list = []
    number_of_photos_list = []
    user_id_list = []
    phone_number_list = []
    latitude_list = []
    longitude_list = []
    package_type_list = []
    domain = 'dubizzle'
    message = []
    PROXY_LIST = requests.get('http://68.183.58.145/torproxies',
                              headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
    count = 0
    links = ['https://dubai.dubizzle.com/classified/collectibles/other/2020/8/23/10-pounds-gold-coin-21-karat-52grams-2/?back=L2NsYXNzaWZpZWQvY29sbGVjdGlibGVzL290aGVyLw%3D%3D&pos=0&highlighted_ads=1']
    for url in links:
        url = url.strip().replace('/ar/', '/')
        j = 0
        final_response = ''
        while True:
            if j <= 3:
                try:
                    j = j + 1
                    pr = random.choice(PROXY_LIST)
                    proxy = 'https://' + pr
                    proxies = {'https': proxy, 'http': proxy}
                    logging.warning("Proxy Changed to %s" % proxy)
                    cat_url = 'https://alain.dubizzle.com/en/property-for-rent/residential/'
                    cat_url = cat_url.replace(re.findall(
                        '//(.*?)\.', cat_url)[0], re.findall('//(.*?)\.', url)[0])
                    cat_response = requests.get(cat_url, proxies=proxies)

                    correlationid = re.findall(
                        r'correlationId.*?":.*?"(.*?)[\\]+",', str(cat_response.content))[0].strip()
                    h = {'accept': 'application/json',
                         'accept-encoding': 'gzip, deflate, br',
                         'accept-language': 'en',
                         'content-length': '0',
                         'content-type': 'application/json; charset=utf-8',
                         # 'origin': 'https://dubai.dubizzle.com',
                         # 'referer': 'https://dubai.dubizzle.com/en/property-for-rent/residential/apartmentflat/?filters=(agent.name.en:%22Appello%20Real%20Estate%20Brokers%20(L%20L%20C)%22)',
                         # 'sec-fetch-mode': 'cors',
                         # 'sec-fetch-site': 'same-origin',
                         'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.75.14 (KHTML, like Gecko) Version/7.0.3 Safari/7046A194A',
                         'x-access-token': 'null',
                         'x-request-id': correlationid, }
                    loginurl = 'https://dubai.dubizzle.com/en/auth/login/'
                    loginurl = loginurl.replace(re.findall(
                        '//(.*?)\.', loginurl)[0], re.findall('//(.*?)\.', url)[0])
                    login_response = requests.post(
                        url=loginurl, headers=h, proxies=proxies)

                    access_token = login_response.json().get('access_token').strip()
                    h = {'accept': 'application/json',
                         'accept-encoding': 'gzip, deflate, br',
                         'accept-language': 'en',
                         'content-type': 'application/json; charset=utf-8',
                         'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.75.14 (KHTML, like Gecko) Version/7.0.3 Safari/7046A194A',
                         'x-access-token': access_token,
                         'x-request-id': correlationid, }
                    url_slug = url.split('.com')[-1].strip()
                    product_url = 'https://alain.dubizzle.com/en/property-for-sale/dpv/svc/api/v1/listing'
                    product_url = product_url.replace(re.findall(
                        '//(.*?)\.', product_url)[0], re.findall('//(.*?)\.', url)[0])
                    product_url = product_url + url_slug
                    final_response = requests.get(
                        url=product_url, headers=h, proxies=proxies)
                    if final_response and final_response.status_code == 200:
                        msg = 'status:' + url + ':' + str(final_response.status_code)
                        # logging.warning(msg)
                        # break
                        if final_response:
                            package_type = ''
                            final_json = final_response.json()
                            final_raw = final_json.get('data', {})
                            if final_raw:
                                name = str(final_raw.get('name_en', ''))
                                title = name
                                reference_number = str(final_raw.get(
                                    'company_item_id', ''))
                                id_ = str(final_raw.get('id', ''))
                                url = url.replace(
                                    '/en/property-for-sale/dpv/svc/api/v1/listing', '/')

                                broker_display_name = final_raw.get('agent_name', '')
                                broker = broker_display_name.upper() if broker_display_name else ''

                                if '/property-for-sale/' in url:
                                    category = 'sale'
                                    category_url = '/property-for-sale/home/'
                                elif '/property-for-rent/' in url:
                                    category = 'rent'
                                    category_url = '/property-for-rent/home/'
                                else:
                                    category = ''
                                    category_url = ''

                                description_text = final_raw.get('description_en', '')
                                des_sel = lxml.html.fromstring(
                                    description_text) if description_text else ''
                                description = ' '.join(des_sel.xpath(
                                    '//text()')) if description_text else ''

                                location_path = final_raw.get('location_path', '')
                                location_path = location_path.get('en') if location_path else ''
                                location = ', '.join(
                                    [x.strip() for x in location_path]) if location_path else ''

                                price = str(final_raw.get('price', ''))
                                currency = 'AED'
                                price_per = final_raw.get('rent_is_paid_display_en', '')

                                bedrooms = str(final_raw.get('bedrooms', ''))
                                bathrooms = str(final_raw.get('bathrooms', ''))
                                furnished = "Yes" if final_raw.get('furnished', '') else ''

                                rera_permit_number = str(final_raw.get('rera_permit_number', ''))
                                rera_registration_number = str(final_raw.get(
                                    'rera_registration_number', ''))
                                dtcm_licence = ''

                                amenities = ''
                                agent_name = ''
                                user_id = ''
                                details = str(final_raw.get('size', ''))
                                details = 'Area:' + details if details else ''
                                number_of_photos = str(final_raw.get('photos_count', ''))
                                phone_number = str(final_raw.get('phone_number', ''))

                                longitude = final_raw.get('location_get_x', '')
                                latitude = final_raw.get('location_get_y', '')

                                promoted = 'promoted' if final_raw.get('promoted') else ''
                                featured_listing = 'featured' if final_raw.get('featured_listing') else ''
                                package_type = promoted + ', ' + featured_listing
                                package_type = package_type.strip().strip(',').strip()

                                scraped_ts = (datetime.now()).strftime("%Y-%m-%d")
                                date = scraped_ts

                                # iteration_number
                                now = datetime.now()
                                current = datetime(now.year, now.month, 1)
                                next_month = datetime(now.year + int(now.month / 12), ((now.month % 12) + 1), 1)
                                now_date_int = int(now.strftime("%d"))
                                if now_date_int <= 31 and now_date_int >= 25:
                                    iteration_month = next_month.strftime("%m")
                                    iteration_year = next_month.strftime("%Y")
                                else:
                                    iteration_month = now.strftime("%m")
                                    iteration_year = now.strftime("%Y")
                                iteration_number = iteration_year + '_' + iteration_month
                        count = count + 1
                        if count > 5:
                            break
                        reference_number_list.append(reference_number) if reference_number else ''
                        id_list.append(id_) if id_ else ''
                        broker_display_name_list.append(broker_display_name) if broker_display_name else ''
                        broker_list.append(broker) if broker else ''
                        category_list.append(category) if category else ''
                        category_url_list.append(category_url) if category_url else ''
                        title_list.append(title) if title else ''
                        description_list.append(description) if description else ''
                        location_list.append(location) if location else ''
                        price_list.append(price) if price else ''
                        currency_list.append(currency) if currency else ''
                        price_per_list.append(price_per) if price_per else ''
                        bedrooms_list.append(bedrooms) if bedrooms else ''
                        bathrooms_list.append(bathrooms) if bathrooms else ''
                        furnished_list.append(furnished) if furnished else ''
                        rera_permit_number_list.append(rera_permit_number) if rera_permit_number else ''
                        rera_registration_number_list.append(rera_registration_number) if rera_registration_number else ''
                        amenities_list.append(amenities) if amenities else ''
                        details_list.append(details) if details else ''
                        number_of_photos_list.append(number_of_photos) if number_of_photos else ''
                        user_id_list.append(user_id) if user_id else ''
                        phone_number_list.append(phone_number) if phone_number else ''
                        latitude_list.append(latitude) if latitude else ''
                        longitude_list .append(longitude) if longitude else ''
                        package_type_list.append(package_type) if package_type else ''
                    elif final_response.status_code == 404:
                        msg = 'status: ' + url + ': ' + str(final_response.status_code)
                        logging.warning(msg)
                        final_response = ''
                        not_found = {'url': url}
                        break
                except:
                    pass
            else:
                msg = 'failed: ' + url
                logging.warning(msg)
                failed = {'url': url}
                break

    if not reference_number_list:
        msg = 'reference_number field empty in dubizzle'
        message.append(msg)
    if not id_list:
        msg = 'id field empty in dubizzle'
        message.append(msg)
    if not broker_display_name_list:
        msg = 'broker_display_name field empty in dubizzle'
        message.append(msg)
    if not broker_list:
        msg = 'broker field empty in dubizzle'
        message.append(msg)
    if not category_list:
        msg = 'category field empty in dubizzle'
        message.append(msg)
    if not category_url_list:
        msg = 'category_url field empty in dubizzle'
        message.append(msg)
    if not title_list:
        msg = 'title field empty in dubizzle'
        message.append(msg)
    if not description_list:
        msg = 'description field empty in dubizzle'
        message.append(msg)
    if not location_list:
        msg = 'location field empty in dubizzle'
        message.append(msg)
    if not price_list:
        msg = 'price field empty in dubizzle'
        message.append(msg)
    if not currency_list:
        msg = 'currency field empty in dubizzle'
        message.append(msg)
    if not price_per_list:
        msg = 'price_per field empty in dubizzle'
        message.append(msg)
    if not bedrooms_list:
        msg = 'bedrooms field empty in dubizzle'
        message.append(msg)
    if not bathrooms_list:
        msg = 'bathrooms field empty in dubizzle'
        message.append(msg)
    if not furnished_list:
        msg = 'furnished field empty in dubizzle'
        message.append(msg)
    if not rera_permit_number_list:
        msg = 'rera_permit_number field empty in dubizzle'
        message.append(msg)
    if not rera_registration_number_list:
        msg = 'rera_registration_number field empty in dubizzle'
        message.append(msg)
    if not amenities_list:
        msg = 'amenities field empty in dubizzle'
        message.append(msg)
    if not details_list:
        msg = 'details field empty in dubizzle'
        message.append(msg)
    if not number_of_photos_list:
        msg = 'number_of_photos field empty in dubizzle'
        message.append(msg)
    if not user_id_list:
        msg = 'user_id field empty in dubizzle'
        message.append(msg)
    if not phone_number_list:
        msg = 'phone_number field empty in dubizzle'
        message.append(msg)
    if not latitude_list:
        msg = 'latitude field empty in dubizzle'
        message.append(msg)
    if not longitude_list:
        msg = 'longitude field empty in dubizzle'
        message.append(msg)
    if not package_type_list:
        msg = 'package_type field empty in dubizzle'
        message.append(msg)
    slack_note(message, domain)
