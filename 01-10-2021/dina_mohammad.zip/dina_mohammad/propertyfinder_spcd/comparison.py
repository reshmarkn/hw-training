import csv
import json
import data
import random
import requests

# from xpath import *
from slacker import Slacker
from datetime import datetime
from pymongo import MongoClient
from scrapy.selector import Selector
from log_file import *



headers = {

    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
}
db = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017').dina_mohammad
def CollectDb(reference_number, id_, link,broker, category, category_url, name, description, location,bedrooms, bathroom,domain):
    for item in db[domain].find(no_cursor_timeout=True):
        message_ = []
        if link == item.get('url'):
            json_data = item
            print(json_data,'00000000000000')
            if json_data.get('reference_number') in reference_number:
                msg = 'reference_number success ' + domain
                message_.append(msg)
            else:
                msg = 'reference_number failed ' + domain
                message_.append('msg')
            if json_data.get('id_') in id_:
                msg = 'id success ' + domain
                message_.append(msg)
            else:
                msg = 'id failed ' + domain
                message_.append('msg')
            if json_data.get('broker') in broker:
                msg = 'broker success ' + domain
                message_.append(msg)
            else:
                msg = 'broker failed ' + domain
                message_.append('msg')
            if json_data.get('category') in category:
                msg = 'category success ' + domain
                message_.append(msg)
            else:
                msg = 'category failed ' + domain
                message_.append('msg')
            if json_data.get('category_url') in category_url:
                msg = 'category_url success ' + domain
                message_.append(msg)
            else:
                msg = 'category_url failed ' + domain
                message_.append('msg')
            
            if json_data.get('name') in name:
                msg = 'name success ' + domain
                message_.append(msg)
            else:
                msg = 'name failed ' + domain
                message_.append('msg')
            if json_data.get('description') in description:
                msg = 'description success ' + domain
                message_.append(msg)
            else:
                msg = 'description failed ' + domain
                message_.append('msg')
            if json_data.get('location') in location:
                msg = 'location success ' + domain
                message_.append(msg)
            else:
                msg = 'location failed ' + domain
                message_.append('msg')
            if json_data.get('bedrooms') in bedrooms:
                msg = 'bedrooms success ' + domain
                message_.append(msg)
            else:
                msg = 'bedrooms failed ' + domain
                message_.append('msg')
            if json_data.get('bathroom') in bathroom:
                msg = 'bathroom success ' + domain
                message_.append(msg)
            else:
                msg = 'bathroom failed ' + domain
                message_.append('msg')




            if message_:
                # comparison_log(message_)
                f = open('comparison_log.txt', 'a')
                f.write(str(message_) + '\n')
                f.close()
