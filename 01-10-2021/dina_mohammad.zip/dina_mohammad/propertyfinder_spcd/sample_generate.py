import csv
from datetime import datetime

today = datetime.now().strftime('%Y_%m_%d')

def Sample_Genaration(domain,row):
    fields = ['reference_number','id','url','broker_display_name','broker','category','category_url','title','description','location','price','currency','price_per','bedrooms','bathrooms','furnished','rera_permit_number','dtcm_licence','scraped_ts','amenities','details','agent_name','number_of_photos','user_id','phone_number','date','iteration_number','latitude','longitude']
    # fields = ['reference_number','id','url','broker_display_name','bedroom' ,'broker','category','category_url','title','description','price','currency','price_text' ,'price_per','bathrooms','furnished','rera_permit_number','dtcm_licence','amenities','details','agent_name','number_of_photos','user_id','phone_number','latitude','longitude','message' ,'location','area' ,'name' ,'message','user','agent' ,'image' ,'address' ,'photo' ,'broker_id' ,'area_f','area_p','price_raw']
    file_name = domain + '_' + today + '.csv'
    with open(file_name, 'w') as csvfile:
        csvwriter = csv.writer(csvfile)
        csvwriter.writerow(fields)
        csvwriter.writerows(row)
def Sample_Genaration1(domain,row):
    fields = ['reference_number', 'id_', 'link', 'broker', 'broker_display_name', 'category', 'category_url', 'name', 'description', 'location', 'currency', 'price_per_', 'bedrooms', 'bathrooms', 'furnished',
                'rera_permit_number', 'dtcm_licence', 'scraped_ts', 'amenities', 'area', 'agent_name', 'number_of_photos', 'user_id', 'phone_number', 'scraped_ts', 'iteration_number', 'latitude', 'longitude']
    # fields = ['reference_number','id_','link','broker_display_name','broker','category','category_url','title','description','location','price','currency','price_per','bedrooms','bathrooms','dtcm_licence','rera_permit_number','furnished','scraped_ts','amenities','details','agent_name','number_of_photos','user_id','phone_numbers','scraped_ts','rera_registration_number','ded_license_number','rera_length','latitude','longitude','listing_id','package_type','locality','object_id','verified','iteration_number']
    file_name = domain + '_' + today + '.csv'
    with open(file_name, 'w') as csvfile:
        csvwriter = csv.writer(csvfile)
        csvwriter.writerow(fields)
        csvwriter.writerows(row)
def Sample_Genaration2(domain,row):
    fields = ['reference_number','id_','link','broker_display_name','category','category_url','title','description','location','price','currency','price_per','bedrooms','bathrooms','dtcm_licence','rera_permit_number','furnished','scraped_ts','amenities','details','agent_name','number_of_photos','user_id','phone_numbers','scraped_ts','iteration_number']
    # fields = ['reference_number','id','url','broker_display_name','bedroom' ,'broker','category','category_url','title','description','price','currency','price_text' ,'price_per','bathrooms','furnished','rera_permit_number','dtcm_licence','amenities','details','agent_name','number_of_photos','user_id','phone_number','latitude','longitude','message' ,'location','area' ,'name' ,'message','user','agent' ,'image' ,'address' ,'photo' ,'broker_id' ,'area_f','area_p','price_raw']
    file_name = domain + '_' + today + '.csv'
    with open(file_name, 'w') as csvfile:
        csvwriter = csv.writer(csvfile)
        csvwriter.writerow(fields)
        csvwriter.writerows(row)

def Sample_Genaration3(domain,row):
    fields = ['reference_number','id_','link','broker_display_name','category','category_url','title','description','location','price','currency','price_per','bedrooms','bathrooms','dtcm_licence','rera_permit_number','furnished','scraped_ts','amenities','details','agent_name','number_of_photos','user_id','phone_numbers','scraped_ts','rera_registration_number','ded_license_number','rera_length','latitude','longitude','listing_id','package_type','locality','object_id','verified','iteration_number']
    # fields = [reference_number,id_,link,broker,broker.upper(),category,category_url,title,description,location,price_final,currency,price_per,bedrooms,bathrooms,furnished,rera_permit_number,dtcm_licence,scraped_ts,amenities,area,agent_name,number_of_photos,user_id,phone_numbers,scraped_ts,iteration_number]]
    file_name = domain + '_' + today + '.csv'
    with open(file_name, 'w') as csvfile:
        csvwriter = csv.writer(csvfile)
        csvwriter.writerow(fields)
        csvwriter.writerows(row)

def Sample_Genaration4(domain,row):
    fields = ['reference_number','id_','link','broker_display_name','broker','category','category_url','title','description','location','price','currency','price_per','bedrooms','bathrooms','dtcm_licence','rera_permit_number','furnished','scraped_ts','amenities','details','agent_name','number_of_photos','user_id','phone_numbers','scraped_ts','rera_registration_number','ded_license_number','rera_length','latitude','longitude','listing_id','package_type','locality','object_id','verified','iteration_number']
    file_name = domain + '_' + today + '.csv'
    with open(file_name, 'w') as csvfile:
        csvwriter = csv.writer(csvfile)
        csvwriter.writerow(fields)
        csvwriter.writerows(row)
def Sample_Genaration5(domain,row):
    fields = ['reference_number','id_','link','broker','broker_display_name','category','category_url','title','description','location','price_final','currency','price_per','bedrooms','bathrooms','furnished','rera_permit_number','dtcm_licence','scraped_ts','amenities','area','agent_name','number_of_photos','user_id','phone_numbers','scraped_ts','iteration_number']
    file_name = domain + '_' + today + '.csv'
    with open(file_name, 'w') as csvfile:
        csvwriter = csv.writer(csvfile)
        csvwriter.writerow(fields)
        csvwriter.writerows(row)
def Sample_Genaration6(domain,row):
    fields = ['id_','link','broker','broker_display_name','category','category_url','location','bedrooms','bathrooms','price','title','currency','description','price_per','furnished','rera_permit_number','dtcm_licence','scraped_ts','aminity','details','number_of_photos','agent_name','referencenum','user_id','phone_numbers','scraped_ts','iteration_number']
    file_name = domain + '_' + today + '.csv'
    with open(file_name, 'w') as csvfile:
        csvwriter = csv.writer(csvfile)
        csvwriter.writerow(fields)
        csvwriter.writerows(row)
def Sample_Genaration7(domain,row):
    fields = ['id_','link','broker','broker_display_name','category','category_url','location','bedrooms','bathrooms','price','title','currency','description','price_per','furnished','rera_permit_number','dtcm_licence','scraped_ts','area','reference_number','amenity','number_of_photos','agent_name','user_id','phone_numbers','scraped_ts','iteration_number']
    file_name = domain + '_' + today + '.csv'
    with open(file_name, 'w') as csvfile:
        csvwriter = csv.writer(csvfile)
        csvwriter.writerow(fields)
        csvwriter.writerows(row)
def Sample_Genaration7(domain,row):
    fields = ['id_','link','broker','broker_display_name','category','category_url','title','description','location','price','currency','furnished','bedrooms','bathrooms','price_per','rera_permit_number','dtcm_licence','scraped_ts','amenities','details','agent_name','number_of_photos','user_id','phone_number','scraped_ts','iteration_number']
    file_name = domain + '_' + today + '.csv'
    with open(file_name, 'w') as csvfile:
        csvwriter = csv.writer(csvfile)
        csvwriter.writerow(fields)
        csvwriter.writerows(row)