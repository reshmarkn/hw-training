import re
import csv
import json
import random
import requests
import logging
import string
import comparison
from xpath import *
from slacker import Slacker
from datetime import datetime
from pymongo import MongoClient
from scrapy.selector import Selector
from proxy import tor_proxy
from log_file import *
from proxy import microleaves_proxy
from proxy import storm_proxy
from sample_generate import *

Slack = Slacker(
    'xoxp-24300212688-35464554529-262255845088-43b7f5b45d669c16a2fc81caa80fa6e2')
# SLACK_USERS = ['@sisira','@avinash']
SLACK_USERS = ['@Ramesh', '@Mahesh', '@sisira']
today = datetime.now().strftime('%Y_%m_%d')
# db = MongoClient(
#     'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017').kw_feb_20
logging.basicConfig(filename='script_error.log',
                    format='%(asctime)s - %(message)s', level=logging.INFO)
proxy_t = tor_proxy()
proxies_t = proxy_t['proxies']

proxy_m = microleaves_proxy()
proxies_m = proxy_m['proxies']

proxy_s = storm_proxy()
proxies_s = proxy_s['proxies']

headers = {

    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
}


def aqar_ksa_fun(links):
    print('aqar_ksa')
    domain = 'aqar_ksa_2020_05'
    reference_number = ''
    id_list = []
    url_list = []
    broker_display_name_list = []
    broker_list = []
    category_list = []
    category_url_list = []
    title_list = []
    description_list = []
    location = ''
    price_list = []
    currency_list = []
    price_per_list = []
    bedrooms_list = []
    bathrooms_list = []
    furnished = ''
    rera_permit_number = ''
    dtcm_licence = ''
    scraped_ts_list = []
    amenitie_list = []
    details_list = []
    agent_name = ''
    number_of_photos_list = []
    user_id_list = []
    phone_number_list = []
    date_list = []
    iteration_number = '2020_05',
    latitude_list = []
    longitude_list = []
    row_data = []
    message = []
    for link in links:
        response = requests.get(link, headers=headers)
        sel = Selector(text=response.content)
        link = response.url
        print(link)
        if response.status_code == 200:
            user_id = ''
            price_per = ''
            price_per_ = ''
            price_value = ''
            currency = ''
            latitude = ''
            longitude = ''
            name = sel.xpath(aqar_ksa.NAME_XPATH).extract()
            category = sel.xpath(aqar_ksa.CATEGORY_XPATH).extract()
            description = sel.xpath(aqar_ksa.DESCRIPTION_XPATH).extract()
            id_ = sel.xpath(aqar_ksa.ID_XPATH).extract()
            bedroom = sel.xpath(aqar_ksa.BEDROOM_XPATH).extract()
            bathroom = sel.xpath(aqar_ksa.BATHROOM_XPATH).extract()
            furnished = sel.xpath(aqar_ksa.FURNISHED_XPATH).extract()
            price_text = sel.xpath(aqar_ksa.PRICE_XPATH).extract()
            category_url = sel.xpath(aqar_ksa.CATEGORY_URL_XPATH).extract()
            broker = sel.xpath(aqar_ksa.BROKER_XPATH).extract()

            user = sel.xpath(aqar_ksa.USER_XPATH).extract()[0]
            phone_script = sel.xpath(aqar_ksa.PHONE_XPATH).extract()
            lat_long = sel.xpath('*').re_first('"location":(\{.*?\})')

            # Clear Data
            name = ' '.join(''.join(name).strip().split()) if name else ''
            description = ' '.join(
                ''.join(description).strip().split()) if description else ''
            id_ = ' '.join(''.join(id_).strip().split()).strip(
                '#').strip() if id_ else ''
            if not id_:
                id_ = re.findall(r'-\d+', response.url)
                id_ = id_[0].strip('-').strip() if id_ else ''

            bedroom = ' '.join(
                ''.join(bedroom).strip().split()) if bedroom else ''
            bathroom = ' '.join(
                ''.join(bathroom).strip().split()) if bathroom else ''
            furnished = ' '.join(
                ''.join(furnished).strip().split()) if furnished else ''
            # category = [x.strip() for x in category] if category else ''
            # category = [x.strip()
            #           for x in category if x] if category else ''
            # category = ' > '.join(category).strip() if category else ''
            category = category[0] if category else ''
            category_url = category_url[0] if category_url else ''
            # category_url = category_url[-1] if category_url else ''
            broker = ' '.join(''.join(broker).strip().split()
                              ) if broker else ''
            price_text = ' '.join(
                ''.join(price_text).strip().split()) if price_text else ''
            price_value = re.findall(r'\d+', price_text) if price_text else []
            price_value = ''.join(price_value).strip() if price_value else ''

            if '/' in price_text:
                price_text_1 = price_text.split('/')
                price_per = price_text_1[-1] if price_text_1 else ''
                price_per_ = price_per.replace(',', '') if price_per else ''
                price_per_ = price_per_.replace(
                    price_value, '').strip() if price_per_ else ''
                price_text = price_text.replace(
                    price_per, '').replace('/', '').strip()
                price_text_ = price_text.split(' ')
                currency1 = price_text_[1] if price_text_ else ''
                currency2 = price_text_[-1] if price_text_ else ''
                currency = currency1 + ' ' + currency2
                if currency1 and currency2:
                    currency = currency1 + ' ' + currency2
                else:
                    currency = ''

            elif ' ' in price_text:
                price_text_ = price_text.split(' ')
                currency1 = price_text_[1] if price_text_ else ''
                currency2 = price_text_[-1] if price_text_ else ''
                currency = currency1 + ' ' + currency2
                if currency1 and currency2:
                    currency = currency1 + ' ' + currency2
                else:
                    currency = ''

            price_per_ = ' '.join(
                ''.join(price_per_).strip().split()) if price_per_ else ''
            currency = ' '.join(
                ''.join(currency).strip().split()) if currency else ''
            price_value = ' '.join(
                ''.join(price_value).strip().split()) if price_value else ''
            bedrooms = re.findall(r'\d+', bedroom)
            bedrooms = ' '.join(
                ''.join(bedrooms).strip().split()) if bedrooms else ''

            bathroom = re.findall(r'\d+', bathroom)
            bathroom = ' '.join(
                ''.join(bathroom).strip().split()) if bathroom else ''

            img = sel.xpath(aqar_ksa.IMAGE_XPATH).extract()
            number_of_photos = str(len(img))
            area = sel.xpath(aqar_ksa.AREA_XPATH).extract()
            area = ''.join(area) if area else ''
            amenities = sel.xpath(aqar_ksa.AMENITIES_XPATH).extract()
            amenities = [x.strip() for x in amenities] if amenities else ''
            amenities = [x.strip()
                         for x in amenities if x] if amenities else ''
            amenities = ' , '.join(amenities).strip() if amenities else ''

            if user:
                data = user.replace(u'window.__store__ = ', '')if user else ''
                user_data = json.loads(data) if data else ''
                user_id = user_data.get('listingReducer').get(
                    'selectedListing').get('user_id')if user_data else ''
            user_id = user_id if user_id else ''

            phone_numbers = re.findall(
                r'{"usersInfo.*?\"phone\":\d+,', phone_script[0].strip()) if phone_script else ''

            phone_numbers = phone_numbers[0].strip() if phone_numbers else ''
            phone_numbers = re.findall(
                r'\"phone\":\d+,', phone_numbers.strip()) if phone_script else ''
            phone_numbers = phone_numbers[0].strip().strip(
                '\"phone\":').strip(',') if phone_numbers else ''

            lat_long = lat_long.strip() if lat_long else ''
            # lat_long = re.findall(r'\"premium\":\d+,\"location\":{\"lat\":.*?,\"lng\":.*?},\"links\"', lat_long) if lat_long else ''
            latitude = re.findall(
                r'\"lat\":.*?,', lat_long) if lat_long else ''
            latitude = latitude[0].strip().strip(
                '"lat":').strip(',').strip() if latitude else ''
            longitude = re.findall(
                r'\"lng\":.*?}', lat_long) if lat_long else ''
            longitude = longitude[0].strip().strip('"lng":').strip(
                ',').strip('}').strip() if longitude else ''

            scraped_ts = (datetime.now()).strftime("%Y-%m-%d")
            id_list.append(id_) if id_ else ''
            url_list.append(link)
            broker_display_name_list.append(broker) if broker else ''
            broker_list.append(broker.upper()) if broker.upper() else ''
            category_list.append(category) if category else ''
            category_url_list.append(category_url) if category_url else ''
            title_list.append(name) if name else ''
            description_list.append(description) if description else ''
            price_list.append(price_value) if price_value else ''
            currency_list.append(currency) if currency else ''
            price_per_list.append(price_per_) if price_per_ else ''
            bedrooms_list.append(bedrooms) if bedrooms else ''
            bathrooms_list.append(bathroom) if bathroom else ''
            scraped_ts_list.append(scraped_ts) if scraped_ts else ''
            amenitie_list.append(amenities) if amenities else ''
            details_list.append(area) if area else ''
            number_of_photos_list.append(number_of_photos) if number_of_photos else ''
            user_id_list.append(user_id) if user_id else ''
            phone_number_list.append(phone_numbers) if phone_numbers else ''
            date_list.append(scraped_ts) if scraped_ts else ''
            latitude_list.append(latitude) if latitude else ''
            longitude_list.append(longitude) if longitude else ''

            row = [reference_number, id_, link, broker, broker.upper(), category, category_url, name, description, location, price_value, currency, price_per_, bedrooms, bathroom, furnished,
                   rera_permit_number, dtcm_licence, scraped_ts, amenities, area, agent_name, number_of_photos, user_id, phone_numbers, scraped_ts, iteration_number, latitude, longitude]
            row_data.append(row)

            # comparison.CollectDb(reference_number, id_, link,broker, category, category_url, name, description, location,bedrooms, bathroom,domain)
    Sample_Genaration(domain, row_data)

    if id_list == []:
        msg = 'id field is empty in aqar_ksa'
        message.append(msg)
    if url_list == []:
        msg = 'url is field empty in aqar_ksa'
        message.append(msg)
    if broker_display_name_list == []:
        msg = 'broker_display_name is field empty in aqar_ksa'
        message.append(msg)
    if broker_list == []:
        msg = 'broker is field empty in aqar_ksa'
        message.append(msg)
    if category_list == []:
        msg = 'category is field empty in aqar_ksa'
        message.append(msg)
    if category_url_list == []:
        msg = 'category_url is field empty in aqar_ksa'
        message.append(msg)
    if title_list == []:
        msg = 'title is field empty in aqar_ksa'
        message.append(msg)
    if price_list == []:
        msg = 'price is field empty in aqar_ksa'
        message.append(msg)
    if currency_list == []:
        msg = 'currency is field empty in aqar_ksa'
        message.append(msg)
    if price_per_list == []:
        msg = 'price_per is field empty in aqar_ksa'
        message.append(msg)
    if bedrooms_list == []:
        msg = 'bedrooms is field empty in aqar_ksa'
        message.append(msg)
    if bathrooms_list == []:
        msg = 'bathrooms is field empty in aqar_ksa'
        message.append(msg)
    if scraped_ts_list == []:
        msg = 'scraped_ts is field empty in aqar_ksa'
        message.append(msg)
    if amenitie_list == []:
        msg = 'amenitie is field empty in aqar_ksa'
        message.append(msg)
    if details_list == []:
        msg = 'details is field empty in aqar_ksa'
        message.append(msg)
    if number_of_photos_list == []:
        msg = 'number_of_photos is field empty in aqar_ksa'
        message.append(msg)
    if user_id_list == []:
        msg = 'user_id is field empty in aqar_ksa'
        message.append(msg)
    if phone_number_list == []:
        msg = 'phone_number is field empty in aqar_ksa'
        message.append(msg)
    if date_list == []:
        msg = 'date is field empty in aqar_ksa'
        message.append(msg)
    if latitude_list == []:
        msg = 'latitude is field empty in aqar_ksa'
        message.append(msg)
    if longitude_list == []:
        msg = 'longitude is field empty in aqar_ksa'
        message.append(msg)

    slack_note(message, domain)


def aqarmap_egp_fun(links):
    print('aqarmap_egp_')
    domain = 'aqarmap_egp'
    reference_number = ''
    id_list = []
    url_list = []
    broker_display_name_list = []
    broker_list = []
    category_list = []
    category_url_list = []
    title_list = []
    description_list = []
    location = ''
    price_list = []
    currency = 'EGP'
    price_per_ = ''
    bedrooms_list = []
    bathrooms_list = []
    furnished = ''
    rera_permit_number = ''
    dtcm_licence = ''
    scraped_ts_list = []
    amenitie_list = ''
    details_list = []
    agent_name = ''
    number_of_photos_list = []
    user_id_list = []
    phone_number_list = []
    date_list = []
    iteration_number = '2020_05',
    latitude_list = []
    longitude_list = []
    name_list = []
    row_data = []
    message = []
    for link in links:
        response = requests.get(link, headers=headers)
        sel = Selector(text=response.content)
        link = response.url
        if response.status_code == 200:
            user_id = ''
            ament_str = ''
            amenities = ''
            title = sel.xpath(aqarmap_egp.TITLE_XPATH).extract()
            category = sel.xpath(aqarmap_egp.CATEGORY_XPATH).extract()
            category_url = sel.xpath(aqarmap_egp.CATEGORY_URL_XPATH).extract()
            description = sel.xpath(aqarmap_egp.DESCRIPTION_XPATH).extract()
            id_url = sel.xpath(aqarmap_egp.ID_XPATH).extract()
            location = sel.xpath(aqarmap_egp.LOCATION_XPATH).extract()
            price = sel.xpath(aqarmap_egp.PRICE_XPATH).extract()
            bedrooms_text = sel.xpath(aqarmap_egp.BEDROOM_XPATH).extract()
            bathrooms_text = sel.xpath(aqarmap_egp.BATHROOM_XPATH).extract()
            broker_display_name = sel.xpath(aqarmap_egp.BROKER_XPATH).extract()
            area = sel.xpath(aqarmap_egp.AREA_XPATH).extract()
            name = sel.xpath(aqarmap_egp.NAME_XPATH).extract_first('')
            phone_number = sel.xpath(aqarmap_egp.PHONE_XPATH).extract()

            latitude = sel.xpath(
                aqarmap_egp.LATITUDE_XPATH).extract()
            longitude = sel.xpath(
                aqarmap_egp.LONGITUDE_XPATH).extract()

            # Clear Data
            title = [x.strip() for x in title] if title else ''
            title = [x.strip() for x in title if x] if title else ''
            title = ' '.join(title).strip().replace('Listing title', '').replace(
                'Find your property for sale and for rent', '').strip() if title else ''
            category = [x.strip() for x in category] if category else ''
            category = [x.strip()
                        for x in category if x] if category else ''
            # category = ' > '.join(category).strip() if category else ''
            if category and len(category) >= 2:
                category = category[1]
            else:
                category = ''
            category_url = category_url[1].strip() if category_url else ''

            if '/for-rent/' in category_url:
                category = 'rent'
                category_url = '/en/for-rent/property-type/'
            elif '/for-sale/' in category_url:
                category = 'sale'
                category_url = '/en/for-sale/property-type/'
            else:
                category_url = category_url
                category = category

            description = [x.strip() for x in description] if description else ''
            description = [x.strip()
                           for x in description if x] if description else ''
            description = ' '.join(description).strip().replace(
                'Listing Description', '').strip() if description else ''
            id_ = id_url[0].strip().strip(
                'https://egypt.aqarmap.com/').strip() if id_url else ''
            location = [x.strip() for x in location] if location else ''
            location = [x.strip()
                        for x in location if x] if location else ''
            location = ' '.join(location).strip() if location else ''
            price = price[0].strip() if price else ''
            bedrooms_text = bedrooms_text[-1] if bedrooms_text else ''
            bedrooms = re.findall(r'\d+', bedrooms_text) if bedrooms_text else ''
            bedrooms = bedrooms[0].strip() if bedrooms else ''
            bathrooms_text = bathrooms_text[-1] if bathrooms_text else ''
            bathrooms = re.findall(
                r'\d+', bathrooms_text) if bathrooms_text else ''
            bathrooms = bathrooms[0].strip() if bathrooms else ''
            broker_display_name = broker_display_name[
                0].strip() if broker_display_name else ''
            img = sel.xpath(aqarmap_egp.IMAGE_XPATH).extract()
            number_of_photos = len(set(img))
            area = ' '.join(''.join(area).split()) if area else ''
            name = name.strip() if name else ''
            user = sel.xpath(aqarmap_egp.USER_XPATH).extract()
            if user:
                user = user[0]
                if 'user' in user:
                    user_data = user.split('user/') if user else ''
                    user_id = user_data[-1] if user_data else ''
            user_id = user_id if user_id else ''
            phone_number = urllib.parse.unquote(
                phone_number[0]).strip() if phone_number else ''

            scraped_ts = (datetime.now()).strftime("%Y-%m-%d")
            latitude = latitude[0].strip() if latitude else ''
            longitude = longitude[0].strip() if longitude else ''

            url_list.append(link)
            title_list.append(title) if title else ''
            category_list.append(category) if category else ''
            description_list.append(description) if description else ''
            id_list.append(id_) if id_ else ''
            bedrooms_list.append(bedrooms) if bedrooms else ''
            bathrooms_list.append(bathrooms) if bathrooms else ''
            category_url_list.append(category_url) if category_url else ''
            broker_display_name_list.append(broker_display_name) if broker_display_name else ''
            details_list.append(area) if area else ''
            price_list.append(price) if price else ''
            name_list.append(name) if name else ''
            scraped_ts_list.append(scraped_ts) if scraped_ts else ''
            details_list.append(area) if area else ''
            number_of_photos_list.append(number_of_photos) if number_of_photos else ''
            user_id_list.append(user_id) if user_id else ''
            phone_number_list.append(phone_number) if phone_number else ''
            date_list.append(scraped_ts) if scraped_ts else ''
            latitude_list.append(latitude) if latitude else ''
            longitude_list.append(longitude) if longitude else ''

            row = [reference_number, id_, link, broker_display_name, broker_display_name.upper(), category, category_url, name, description, location, currency, price_per_, bedrooms, bathrooms, furnished,
                   rera_permit_number, dtcm_licence, scraped_ts, amenities, area, agent_name, number_of_photos, user_id, phone_number, scraped_ts, iteration_number, latitude, longitude]
            row_data.append(row)

    Sample_Genaration1(domain, row_data)

    if id_list == []:
        msg = 'id field is empty in aqarmap_egp'
        message.append(msg)
    if url_list == []:
        msg = 'url is field empty in aqarmap_egp'
        message.append(msg)
    if broker_display_name_list == []:
        msg = 'broker_display_name is field empty in aqarmap_egp'
        message.append(msg)
    if name_list == []:
        msg = 'name is field empty in aqarmap_egp'
        message.append(msg)
    if category_list == []:
        msg = 'category is field empty in aqarmap_egp'
        message.append(msg)
    if category_url_list == []:
        msg = 'category_url is field empty in aqarmap_egp'
        message.append(msg)
    if title_list == []:
        msg = 'title is field empty in aqarmap_egp'
        message.append(msg)
    if price_list == []:
        msg = 'price is field empty in aqarmap_egp'
        message.append(msg)
    if bedrooms_list == []:
        msg = 'bedrooms is field empty in aqarmap_egp'
        message.append(msg)
    if bathrooms_list == []:
        msg = 'bathrooms is field empty in aqarmap_egp'
        message.append(msg)
    if scraped_ts_list == []:
        msg = 'scraped_ts is field empty in aqarmap_egp'
        message.append(msg)
    if details_list == []:
        msg = 'details is field empty in aqarmap_egp'
        message.append(msg)
    if number_of_photos_list == []:
        msg = 'number_of_photos is field empty in aqarmap_egp'
        message.append(msg)
    if user_id_list == []:
        msg = 'user_id is field empty in aqarmap_egp'
        message.append(msg)
    if phone_number_list == []:
        msg = 'phone_number is field empty in aqarmap_egp'
        message.append(msg)
    if date_list == []:
        msg = 'date is field empty in aqarmap_egp'
        message.append(msg)
    if latitude_list == []:
        msg = 'latitude is field empty in aqarmap_egp'
        message.append(msg)
    if longitude_list == []:
        msg = 'longitude is field empty in aqarmap_egp'
        message.append(msg)
    slack_note(message, domain)


def bayut_ksa_fun(links):
    print('bayut_ksa_')
    domain = 'bayut_ksa'
    reference_number_list = []
    id_list = []
    url_list = []
    broker_display_name_list = []
    broker_list = []
    category_list = []
    category_url_list = []
    title_list = []
    description_list = []
    location_list = []
    price_list = []
    currency_list = []
    price_per_list = []
    bedrooms_list = []
    bathrooms_list = []
    furnished = ''
    rera_permit_number = []
    dtcm_licence = ''
    scraped_ts_list = []
    amenitie_list = []
    details_list = []
    agent_name = []
    number_of_photos_list = []
    user_id_list = []
    phone_number_list = []
    date_list = []
    iteration_number = '2020_05',
    name_list = []
    row_data = []
    message = []

    for link in links:
        response = requests.get(link, headers=headers)
        sel = Selector(text=response.content)
        link = response.url
        if response.status_code == 200:
            amenities = []
            user_id = ''
            agent_name = ''
            title = sel.xpath(bayut_ksa.TITLE_XPATH).extract()
            location = sel.xpath(bayut_ksa.LOCATION_XPATH).extract()
            description = sel.xpath(bayut_ksa.DESCRIPTION_XPATH).extract()
            bedrooms1 = sel.xpath(bayut_ksa.BEDROOMS_XPATH1).extract()
            bathrooms1 = sel.xpath(bayut_ksa.BATHROOMS_XPATH1).extract()
            bedrooms2 = sel.xpath(bayut_ksa.BEDROOMS_XPATH2).extract()
            bathrooms2 = sel.xpath(bayut_ksa.BATHROOMS_XPATH2).extract()
            broker_display_name = sel.xpath(
                bayut_ksa.BROKER_DISPLAY_NAME_XPATH).extract()
            id_ = sel.xpath(bayut_ksa.ID__XPATH).extract()
            category = sel.xpath(bayut_ksa.CATEGORY_XPATH).extract()
            category_url = sel.xpath(
                bayut_ksa.CATEGORY_URL_XPATH).extract()
            rera_permit_number = sel.xpath(
                bayut_ksa.RERA_PERMIT_NUMBER).extract()
            price_per = sel.xpath(bayut_ksa.PRICE_PER_XPATH).extract()
            price = sel.xpath(bayut_ksa.PRICE_XPATH).extract()
            reference_nub = sel.xpath(
                bayut_ksa.REFER_NUB_XPATH).extract()

            details = sel.xpath(bayut_ksa.AREA_XPATH).extract()
            reference_number = sel.xpath(
                bayut_ksa.REFER_NUB_XPATH).extract()
            agent = sel.xpath(
                '//span[contains(text(),"Agent")]/following-sibling::span/text()').extract()

            img = sel.xpath(
                '//div[@class="image-gallery-thumbnails-container"]//picture/img/@src').extract()
            number_of_photos = str(len(img))
            amen = sel.xpath('//ul[@class="e475b606"]//text()').extract()
            amenities = ', '.join(amen).strip().replace('  ', ' ') if amen else ''
            data = sel.xpath(
                '//h3[contains(text(),"Details")]/following-sibling::div/ul/li')
            phone_script = sel.xpath(
                '//script[contains(text(),"phoneNumber")]').extract()
            rera_registration_number = sel.xpath(
                '//div[@aria-label="Agency info"]//span[contains(text(),"RERA#")]/text()|//span[contains(text(),"RERA#")]/text()').extract()
            ded_license_number = sel.xpath(
                '//div[@aria-label="Agency info"]//span[contains(text(),"DED#")]/text()|//span[contains(text(),"DED#")]/text()').extract()
            currency = sel.xpath(
                '//span[@aria-label="Currency"]/text()').extract()

            # Extract values using above XPATHs
            currency = currency[0].strip() if currency else ''
            if not price:
                price = sel.xpath(
                    '//span[@aria-label="Price"]/text()').extract()
            price = price[0].strip() if price else ''

            if not price_per:
                price_per = sel.xpath(
                    '//span[@aria-label="Frequency"]/text()').extract()
            price_per = price_per[0].strip() if price_per else ''

            if 'per' in price_per:
                price_per = price_per.replace('per', '')
            title = title[0].strip() if title else ''
            location = ''.join(location)
            location = location.strip() if location else ''
            description = ' '.join(' '.join(description).strip().split())
            bedrooms2 = bedrooms2 if bedrooms2 else []
            bedrooms = bedrooms1 if bedrooms1 else bedrooms2
            bedrooms = bedrooms[0].strip() if bedrooms else ''
            bedrooms = bedrooms.replace('Beds', '').strip() if bedrooms else ''
            bedrooms = bedrooms.replace('Bed', '').strip() if bedrooms else ''
            bathrooms2 = bathrooms2 if bathrooms2 else []
            bathrooms = bathrooms1 if bathrooms1 else bathrooms2
            bathrooms = bathrooms[0].strip() if bathrooms else ''
            bathrooms = bathrooms.replace('Baths', '').strip() if bathrooms else ''
            bathrooms = bathrooms.replace('Bath', '').strip() if bathrooms else ''
            broker_display_name = broker_display_name[
                0].strip() if broker_display_name else ''
            # category = ' > '.join(category).strip()
            category_url = category_url[-1].strip() if category_url else ''

            if 'for-rent' in category_url:
                category = 'rent'
                category_url = '/en/ksa/properties-for-rent/'
            elif 'for-sale' in category_url:
                category = 'sale'
                category_url = '/en/ksa/properties-for-sale/'

            # rera_permit_number = ' '.join(rera_permit_number).replace(
            #   'Permit', '').replace('#','').replace(
            #   ',', '').strip() if rera_permit_number else ''
            id_ = id_[0].strip() if id_ else ''
            id_ = re.findall('ad_id":(.*),"object_id"', id_)[0]

            if agent:
                agent_ = ','.join(agent).split(',')
                agent_name = agent_[0] if agent_ else ''

            amenities_str = ''
            if data:
                for amt in data:
                    key = amt.xpath('span[@class="_3af7fa95"]/text()').extract()
                    value = amt.xpath('span[@class="_812aa185"]/text()').extract()
                    keys = ' '.join(''.join(key).strip().strip().strip(
                        ':').split()) if key else ''
                    values = ' '.join(
                        ''.join(value).strip().split()) if value else ''
                    if key:
                        amenities_str = amenities_str + keys + ':' + values + ', '
            amenities_str = amenities_str.strip(
                ', ').strip() if amenities_str else ''
            amenities_str = amenities_str.strip(
                ', ').strip() if amenities_str else ''
            reference_number = ' '.join(
                ''.join(reference_number).strip().split()) if reference_number else ''
            details = ' '.join(''.join(details).strip().split()) if details else ''
            details = 'Area :' + details if details else ''

            reference_number = ''.join(
                reference_number) if reference_number else ''

            user = sel.xpath(
                '//div[@aria-label="Agency info"]//a/@href').extract()
            user = ''.join(user) if user else ''
            if '-' in user:
                user_data = user.split('-') if user else ''
                user_id = user_data[-1] if user_data else ''
            user_id = user_id.replace('/', '') if user_id else ''

            phone_script = re.findall(
                r'\"phoneNumber\":\{.*?\},', phone_script[0].strip()) if phone_script else ''
            phone_script = json.loads(phone_script[0].strip().strip(
                '"phoneNumber":').strip(',').replace('[', '').replace(']', '').replace(':,', ':null,')).values() if phone_script else ''
            phone_numbers = list(phone_script) if phone_script else ''
            phone_numbers = [x.strip()
                             for x in phone_numbers if x] if phone_numbers else ''
            phone_numbers = [x.strip()
                             for x in phone_numbers] if phone_numbers else ''
            phone_numbers = [x.strip()
                             for x in phone_numbers if x] if phone_numbers else ''
            phone_numbers = ', '.join(phone_numbers) if phone_numbers else ''

            rera_permit_number_script = sel.xpath(
                '//script[contains(text(),"permitNumber")]/text()').extract()
            rera_permit_number_script = re.findall(
                r'\"permitNumber\":\"\d+"', rera_permit_number_script[0].strip()) if rera_permit_number_script else []
            rera_permit_number = rera_permit_number_script[0].strip().replace(
                '\"permitNumber\":', '').replace('"', '').strip() if rera_permit_number_script else ''

            rera_registration_number_script = sel.xpath(
                '//script[contains(text(),"RERA") and contains(text(),"authority")]/text()').extract()
            rera_registration_number_script = re.findall(
                r'\{\"number\":\"\d+\",\"authority\":\"RERA\"\}', rera_registration_number_script[0].strip()) if rera_registration_number_script else []
            rera_registration_number_script = re.findall(
                r'\d+', rera_registration_number_script[0].strip()) if rera_registration_number_script else []
            rera_registration_number = rera_registration_number_script[0].strip(
            ) if rera_registration_number_script else ''

            ded_license_number_script = sel.xpath(
                '//script[contains(text(),"DED") and contains(text(),"authority")]/text()').extract()
            ded_license_number_script = re.findall(
                r'\{\"number\":\"\d+\",\"authority\":\"DED\"\}', ded_license_number_script[0].strip()) if ded_license_number_script else []
            ded_license_number_script = re.findall(
                r'\d+', ded_license_number_script[0].strip()) if ded_license_number_script else []
            ded_license_number = ded_license_number_script[0].strip(
            ) if ded_license_number_script else ''

            rera_pn_len = len(str(rera_permit_number))
            rera_length = True if rera_pn_len == 10 else False
            scraped_ts = (datetime.now()).strftime("%Y-%m-%d")

            title_list.append(title) if title else ''
            location_list.append(location) if location else ''
            description_list.append(description) if description else ''
            bedrooms_list.append(bedrooms1) if bedrooms1 else ''
            bathrooms_list.append(bathrooms1) if bathrooms1 else ''
            bedrooms_list.append(bedrooms2) if bedrooms2 else ''
            bathrooms_list.append(bathrooms2) if bathrooms2 else ''
            broker_display_name_list.append(
                broker_display_name) if broker_display_name else ''
            id_list.append(id_) if id_ else ''
            category_list.append(category) if category else ''
            category_url_list.append(category_url) if category_url else ''
            price_per_list.append(price_per) if price_per else ''
            price_list.append(price) if price else ''
            reference_number_list.append(reference_nub) if reference_nub else ''
            rera_permit_number_list.append(rera_permit_number) if rera_permit_number else ''
            details_list.append(details) if details else ''
            # reference_number_list.append(reference_number) if reference_number else ''

            row = [reference_number, id_, link, broker_display_name, category, category_url, title, description, location, price, currency, price_per, bedrooms, bathrooms, dtcm_licence, rera_permit_number, furnished, scraped_ts, amenities, details, agent_name, number_of_photos, user_id, phone_numbers, scraped_ts, iteration_number]
            row_data.append(row)

    Sample_Genaration2(domain, row_data)

    if title_list == []:
        msg = 'title field is empty in bayut_ksa'
        print(msg)
        message.append(msg)
    if location_list == []:
        msg = 'location field is empty in bayut_ksa'
        print(msg)
        message.append(msg)
    if description_list == []:
        msg = 'description field is empty in bayut_ksa'
        print(msg)
        message.append(msg)
    if category_list == []:
        msg = 'category field is empty in bayut_ksa'
        print(msg)
        message.append(msg)
    if id_list == []:
        msg = 'id_ field is empty in bayut_ksa'
        print(msg)
        message.append(msg)
    if broker_display_name_list == []:
        msg = 'broker_display_name field is empty in bayut_ksa'
        print(msg)
        message.append(msg)
    if bathrooms_list == []:
        msg = 'bathroom1 field is empty in bayut_ksa'
        print(msg)
        message.append(msg)
    if bedrooms_list == []:
        msg = 'bedroom1 field is empty in bayut_ksa'
        print(msg)
        message.append(msg)
    if category_url_list == []:
        msg = 'category_url field is empty in bayut_ksa'
        print(msg)
        message.append(msg)
    if price_per_list == []:
        msg = 'price_per field is empty in bayut_ksa'
        print(msg)
        message.append(msg)
    if price_list == []:
        msg = 'price field is empty in bayut_ksa'
        print(msg)
        message.append(msg)
    if reference_number_list == []:
        msg = 'reference_number field is empty in bayut_ksa'
        print(msg)
        message.append(msg)
    slack_note(message, domain)


def bayut_uae_fun(links):
    print('bayut_uae_')
    domain = 'bayut_uae'
    reference_number_list = []
    id_list = []
    url_list = []
    broker_display_name_list = []
    broker_list = []
    category_list = []
    category_url_list = []
    title_list = []
    description_list = []
    location_list = []
    price_list = []
    currency_list = []
    price_per_list = []
    bedrooms_list = []
    bathrooms_list = []
    furnished = ''
    rera_permit_number = []
    dtcm_licence = ''
    scraped_ts_list = []
    amenitie_list = []
    details_list = []
    agent_name = []
    number_of_photos_list = []
    user_id_list = []
    phone_number_list = []
    date_list = []
    iteration_number = '2020_05',
    name_list = []
    rera_registration_number_list = []
    ded_license_number_list = []
    rera_length_list = []
    latitude_list = []
    longitude_list = []
    rera_permit_number_list = []
    listing_id_list = []
    package_type_list = []
    locality_list = []
    object_id_list = []
    verified_list = []
    row_data = []
    message = []
    for link in links:
        response = requests.get(link, headers=headers, proxies=proxy_s)
        sel = Selector(text=response.content)
        # print(sel)
        link = response.url
        print(link, '00000000000000000000')
        if response.status_code == 200:

            title = sel.xpath(bayut_uae.TITLE_XPATH).extract_first()
            location = sel.xpath(bayut_uae.LOCATION_XPATH).extract_first()
            description = sel.xpath(bayut_uae.DESCRIPTION_XPATH).extract()
            bedrooms1 = sel.xpath(bayut_uae.BEDROOMS_XPATH1).extract_first()
            bathrooms1 = sel.xpath(bayut_uae.BATHROOMS_XPATH1).extract_first()
            bedrooms2 = sel.xpath(bayut_uae.BEDROOMS_XPATH2).extract_first()
            bathrooms2 = sel.xpath(bayut_uae.BATHROOMS_XPATH2).extract_first()
            broker_display_name = sel.xpath(
                bayut_uae.BROKER_DISPLAY_NAME_XPATH).extract_first()
            id_ = sel.xpath(bayut_uae.ID__XPATH).extract_first()
            category = sel.xpath(bayut_uae.CATEGORY_XPATH).extract_first()
            category_url = sel.xpath(
                bayut_uae.CATEGORY_URL_XPATH).extract_first()
            rera_permit_number = sel.xpath(
                bayut_uae.RERA_PERMIT_NUMBER).extract_first()
            price_per = sel.xpath(bayut_uae.PRICE_PER_XPATH).extract_first()
            price = sel.xpath(bayut_uae.PRICE_XPATH).extract_first()
            reference_nub = sel.xpath(
                bayut_uae.REFER_NUB_XPATH).extract_first()
            rera_permit_number = sel.xpath(
                bayut_uae.RERA_PERMIT_NUMBER).extract_first()

            amenities = []
            user_id = ''
            agent_name = ''

            details = sel.xpath(
                '//span[@aria-label="Area"]/span/text()|//span[contains(text(),"Area")]/following-sibling::span[@aria-label="Value"]/span/text()').extract()
            reference_number = sel.xpath(
                '//span[contains(text(),"Ref. No:")]/following-sibling::span/text()').extract()
            agent = sel.xpath(
                '//span[contains(text(),"Agent")]/following-sibling::span/text()').extract()

            img = sel.xpath(
                '//div[@class="image-gallery-thumbnails-container"]//picture/img/@src').extract()
            number_of_photos = str(len(img))
            amen = sel.xpath('//ul[@class="e475b606"]//text()').extract()
            amenities = ', '.join(amen).strip().replace('  ', ' ') if amen else ''
            data = sel.xpath(
                '//h3[contains(text(),"Details")]/following-sibling::div/ul/li')
            phone_script = sel.xpath(
                '//script[contains(text(),"primaryPhoneNumber")]').extract()
            rera_registration_number = sel.xpath(
                '//div[@aria-label="Agency info"]//span[contains(text(),"RERA#")]/text()|//span[contains(text(),"RERA#")]/text()').extract()
            ded_license_number = sel.xpath(
                '//div[@aria-label="Agency info"]//span[contains(text(),"DED#")]/text()|//span[contains(text(),"DED#")]/text()').extract()
            currency = sel.xpath(
                '//span[@aria-label="Currency"]/text()').extract()
            verified = sel.xpath(
                '//div[@class="_37beb648 _94229082"]//text()').extract()

            # Extract values using above XPATHs

            currency = currency[0].strip() if currency else ''
            if not price:
                price = sel.xpath(
                    '//span[@aria-label="Price"]/text()').extract()
            price = price[0].strip() if price else ''

            if not price_per:
                price_per = sel.xpath(
                    '//span[@aria-label="Frequency"]/text()').extract()
            price_per = price_per[0].strip() if price_per else ''

            if 'per' in price_per:
                price_per = price_per.replace('per', '')
            title = title[0].strip() if title else ''
            location = ''.join(location)
            location = location.strip() if location else ''
            description = ' '.join(' '.join(description).strip().split())
            bedrooms2 = bedrooms2 if bedrooms2 else []
            bedrooms = bedrooms1 if bedrooms1 else bedrooms2
            bedrooms = bedrooms[0].strip() if bedrooms else ''
            bedrooms = bedrooms.replace('Beds', '').strip() if bedrooms else ''
            bedrooms = bedrooms.replace('Bed', '').strip() if bedrooms else ''
            bathrooms2 = bathrooms2 if bathrooms2 else []
            bathrooms = bathrooms1 if bathrooms1 else bathrooms2
            bathrooms = bathrooms[0].strip() if bathrooms else ''
            bathrooms = bathrooms.replace('Baths', '').strip() if bathrooms else ''
            bathrooms = bathrooms.replace('Bath', '').strip() if bathrooms else ''
            broker_display_name = broker_display_name[
                0].strip() if broker_display_name else ''
            # category = ' > '.join(category).strip()
            category_url = category_url[-1].strip() if category_url else ''
            if '/to-rent/' in category_url:
                category = 'rent'
                category_url = '/to-rent/property/uae/'
            elif '/for-sale/' in category_url:
                category = 'sale'
                category_url = '/for-sale/property/uae/'
            id_ = id_[0].strip() if id_ else ''

            # if id_:
            #     id_ = re.findall('ad_id":(.*),"object_id"', id_)[0]
            # else:
            #     id_=''
            if agent:
                agent_ = ','.join(agent).split(',')
                agent_name = agent_[0] if agent_ else ''

            amenities_str = ''
            if data:
                for amt in data:
                    key = amt.xpath('span[@class="_3af7fa95"]/text()').extract()
                    value = amt.xpath('span[@class="_812aa185"]/text()').extract()
                    keys = ' '.join(''.join(key).strip().strip().strip(
                        ':').split()) if key else ''
                    values = ' '.join(
                        ''.join(value).strip().split()) if value else ''
                    if key:
                        amenities_str = amenities_str + keys + ':' + values + ', '
            amenities_str = amenities_str.strip(
                ', ').strip() if amenities_str else ''
            amenities_str = amenities_str.strip(
                ', ').strip() if amenities_str else ''
            reference_number = ' '.join(
                ''.join(reference_number).strip().split()) if reference_number else ''
            details = ' '.join(''.join(details).strip().split()) if details else ''
            details = 'Area :' + details if details else ''

            reference_number = ''.join(
                reference_number) if reference_number else ''

            user = sel.xpath(
                '//div[@aria-label="Agency info"]//a/@href').extract()
            user = ''.join(user) if user else ''
            if '-' in user:
                user_data = user.split('-') if user else ''
                user_id = user_data[-1] if user_data else ''
            user_id = user_id.replace('/', '') if user_id else ''

            phone_number = re.findall(
                r'\"primaryPhoneNumber\":\".*?\",', phone_script[0].strip()) if phone_script else ''
            phone_numbers = phone_number[0].strip().replace(
                '"primaryPhoneNumber":', '').replace(',', '').replace('\"', '')
            rera_permit_number_script = sel.xpath(
                '//script[contains(text(),"permitNumber")]/text()').extract()
            rera_permit_number_script = re.findall(
                r'\"permitNumber\":\"\d+"', rera_permit_number_script[0].strip()) if rera_permit_number_script else []
            rera_permit_number = rera_permit_number_script[0].strip().replace(
                '\"permitNumber\":', '').replace('"', '').strip() if rera_permit_number_script else ''

            rera_registration_number_script = sel.xpath(
                '//script[contains(text(),"RERA") and contains(text(),"authority")]/text()').extract()
            rera_registration_number_script = re.findall(
                r'\{\"number\":\"\d+\",\"authority\":\"RERA\"\}', rera_registration_number_script[0].strip()) if rera_registration_number_script else []
            rera_registration_number_script = re.findall(
                r'\d+', rera_registration_number_script[0].strip()) if rera_registration_number_script else []
            rera_registration_number = rera_registration_number_script[0].strip(
            ) if rera_registration_number_script else ''

            ded_license_number_script = sel.xpath(
                '//script[contains(text(),"DED") and contains(text(),"authority")]/text()').extract()
            ded_license_number_script = re.findall(
                r'\{\"number\":\"\d+\",\"authority\":\"DED\"\}', ded_license_number_script[0].strip()) if ded_license_number_script else []
            ded_license_number_script = re.findall(
                r'\d+', ded_license_number_script[0].strip()) if ded_license_number_script else []
            ded_license_number = ded_license_number_script[0].strip(
            ) if ded_license_number_script else ''

            rera_pn_len = len(str(rera_permit_number))

            rera_length = True if rera_pn_len == 10 else False

            lat_script = sel.xpath(
                '//script[contains(text(),"latitude")]/text()').extract()

            long_script = sel.xpath(
                '//script[contains(text(),"longitude")]/text()').extract()

            obid_script = sel.xpath(
                '//script[contains(text(),"objectID")]/text()').extract()

            listid_script = sel.xpath(
                '//script[contains(text(),"listingid")]/text()').extract()
            pakage_script = sel.xpath(
                '//script[contains(text(),"package_type")]/text()').extract()
            locality_script = sel.xpath(
                '//script[contains(text(),"locality")]/text()').extract()

            latitude = re.findall(
                'latitude":.*?,', lat_script[0].strip()) if lat_script else []
            latitude = latitude[0].strip().replace(
                'latitude":', '').strip(',').strip() if latitude else ''

            longitude = re.findall(
                'longitude":.*?,', long_script[0].strip()) if long_script else []
            longitude = longitude[0].strip().replace(
                'longitude":', '').strip(',').strip() if longitude else ''

            listing_id = re.findall(
                'listingid":.*?,', listid_script[0].strip()) if listid_script else []
            listing_id = listing_id[0].strip().replace(
                'listingid":', '').strip(',').strip() if listing_id else ''

            package_type = re.findall(
                'package_type":.*?,', pakage_script[0].strip()) if pakage_script else []
            package_type = package_type[0].strip().replace(
                'package_type":', '').strip(',').strip('"').strip() if package_type else ''

            locality = re.findall(
                'locality":.*?,', locality_script[0].strip()) if locality_script else []
            locality = locality[0].strip().replace(
                'locality":', '').strip(',').strip('"').strip() if locality else ''

            object_id = re.findall(
                'objectID":.*?,', obid_script[0].strip()) if obid_script else []
            object_id = object_id[-1].strip().replace(
                'objectID":', '').strip(',').strip('"').strip() if object_id else ''

            verified = ''.join([x.strip() for x in [x.strip()
                                                    for x in verified] if x]) if verified else ''

            scraped_ts = (datetime.now()).strftime("%Y-%m-%d")

            title_list.append(title) if title else ''
            location_list.append(location) if location else ''
            description_list.append(description) if description else ''
            bedrooms_list.append(bedrooms1) if bedrooms1 else ''
            bathrooms_list.append(bathrooms1) if bathrooms1 else ''
            bedrooms_list.append(bedrooms2) if bedrooms2 else ''
            bathrooms_list.append(bathrooms2) if bathrooms2 else ''
            broker_display_name_list.append(
                broker_display_name) if broker_display_name else ''
            id_list.append(id_) if id_ else ''
            category_list.append(category) if category else ''
            category_url_list.append(category_url) if category_url else ''
            price_per_list.append(price_per) if price_per else ''
            price_list.append(price) if price else ''
            reference_number_list.append(reference_nub) if reference_nub else ''
            rera_permit_number_list.append(
                rera_permit_number) if rera_permit_number else ''
            row = [reference_number, id_, link, broker_display_name, broker_display_name.upper(), category, category_url, title, description, location, price, currency, price_per, bedrooms, bathrooms, dtcm_licence, rera_permit_number, furnished, scraped_ts, amenities, details, agent_name, number_of_photos, user_id, phone_numbers, scraped_ts, rera_registration_number, ded_license_number, rera_length, latitude, longitude, listing_id, package_type, locality, object_id, verified, iteration_number]
            row_data.append(row)

    Sample_Genaration4(domain, row_data)

    if title_list == []:
        msg = 'title field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    if location_list == []:
        msg = 'location field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    if description_list == []:
        msg = 'description field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    if category_list == []:
        msg = 'category field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    if id_list == []:
        msg = 'id_ field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    if broker_display_name_list == []:
        msg = 'broker_display_name field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    if bathrooms_list == []:
        msg = 'bathroom field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    if bedrooms_list == []:
        msg = 'bedroom field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    if category_url_list == []:
        msg = 'category_url field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    if price_text_list == []:
        msg = 'price_text field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    if price_per_list == []:
        msg = 'price_per field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    if price_list == []:
        msg = 'price field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    if reference_number_list == []:
        msg = 'reference_number field is empty in bayut_uae'
        print(msg)
        message.append(msg)
    slack_note(message, domain)


def emlakjet_tur_fun(links):
    print('emlakjet_tur_')
    domain = 'emlakjet_tur'
    reference_number = ''
    id_list = []
    url_list = []
    broker_display_name_list = []
    broker_list = []
    category_list = []
    category_url_list = []
    title_list = []
    description_list = []
    location_list = []
    price_list = []
    currency_list = []
    price_per = ''
    bedrooms_list = []
    bathrooms_list = []
    furnished = ''
    agent_name_list = []
    rera_permit_number = []
    dtcm_licence = ''
    scraped_ts_list = []
    amenities_list = []
    details_list = []
    number_of_photos_list = []
    user_id_list = []
    phone_number_list = []
    date_list = []
    iteration_number = '2020_05',
    rera_permit_number = ''
    row_data = []
    message = []
    for link in links:
        response = requests.get(link, headers=headers)
        sel = Selector(text=response.content)
        # print(sel)
        link = response.url
        print(link, '00000000000000000000')
        user_id = ''
        if response.status_code == 404 or response.status_code == 301:
            pass
        elif response.status_code == 200:
            price_final = ''
            currency = ''
            category_url_new = ''
            title = sel.xpath(emlakjet_tur.TITLE_XPATH).extract()
            description = sel.xpath(emlakjet_tur.DESCRIPTION_XPATH).extract()
            bedrooms = sel.xpath(emlakjet_tur.BEDROOMS_XPATH).extract()
            bathrooms = sel.xpath(emlakjet_tur.BATHROOMS_XPATH).extract()
            id_ = sel.xpath(emlakjet_tur.ID_XPATH).extract()
            category = sel.xpath(emlakjet_tur.CATEGORY_XPATH).extract()
            category_url = sel.xpath(
                emlakjet_tur.CATEGORY_URL_XPATH).extract()
            price = sel.xpath(emlakjet_tur.PRICE_XPATH).extract()
            broker = sel.xpath(emlakjet_tur.BROKER_XPATH).extract()
            user = sel.xpath(emlakjet_tur.USER_XPATH).extract()
            amen = sel.xpath(emlakjet_tur.AMENITIES_XPATH).extract()
            agent = sel.xpath(emlakjet_tur.AGENT_XPATH).extract()
            phone_script = sel.xpath(emlakjet_tur.PHONE_XPATH).extract()
            img = sel.xpath(emlakjet_tur.IMAGE_XPATH).extract()
            area = sel.xpath(emlakjet_tur.AREA_XPATH).extract()

            title = ' '.join(''.join(title).strip().split()) if title else ''
            bedrooms = ' '.join(
                ''.join(bedrooms).strip().split()) if bedrooms else ''
            bathrooms = ' '.join(
                ''.join(bathrooms).strip().split()) if bathrooms else ''
            description = ' '.join(''.join(description).strip().replace(
                '*', '').split()) if description else ''
            category = [x.strip() for x in category] if category else ''
            category = [x.strip()
                        for x in category if x] if category else ''
            category = ' > '.join(category).strip() if category else ''
            category_ = category.split('> ')
            location = category_[-1] if category_ else ''

            if category_url and len(category_url) >= 2:
                category_url_new = category_url[1] if category_url else ''
            if category_url_new:
                if 'satilik' in category_url_new:
                    category = 'sale'
                    category_url = category_url_new
                if 'kiralik' in category_url_new:
                    category = 'rent'
                    category_url = category_url_new
                else:
                    category_url = category_url_new
                    category = category
            else:
                category_url = ''
                category = ''

            if price:
                price1 = price[0] if price else ''
                if ' ' in price1:
                    price_1 = price1.split(' ')
                    price_final = price_1[0]
                    currency = price_1[1]
            id_ = ' '.join(''.join(id_).strip().split()) if id_ else ''
            broker = ' '.join(''.join(broker).strip().split()
                              ) if broker else ''
            price_final = price_final if price_final else ''
            currency = currency if currency else ''
            location = location.strip().split('Mahallesi')[
                0].strip() if location else ''

            number_of_photos = str(len(list(set(img)))) if img else ''

            area = [x.strip().replace('-', '') for x in [x.strip()
                                                         for x in area] if x]if area else ''
            area = ''.join(area).strip() if area else ''
            amen = [x.strip() for x in [x.strip()
                                        for x in amen] if x]if amen else ''
            amenities = ', '.join(amen).strip().replace(
                '  ', ' ').strip() if amen else ''
            agent_name = ''.join(agent).strip() if agent else ''

            if user:
                user_data = ''.join(user).split('-') if user else ''
                user_id = user_data[-1].replace('/', '') if user_data else ''
            user_id = user_id if user_id else ''
            phone_script = phone_script[0].strip() if phone_script else ''
            phone_sel = re.findall(
                r'<span.*?</span>', phone_script) if phone_script else ''
            sel = Selector(text=phone_sel[0].strip()) if phone_sel else ''
            phone_numbers = sel.xpath('//span/text()').extract() if sel else []
            phone_numbers = ', '.join([x.strip() for x in [x.strip(
            ) for x in phone_numbers] if x]).strip() if phone_numbers else ''

            # scraped_ts = (datetime.now()).strftime("%Y-%m-%d")
            scraped_ts = (datetime.now()).strftime("%Y-%m-%d")

            title_list.append(title) if title else ''
            print(title_list, '////////')
            description_list.append(description) if description else ''
            bedrooms_list.append(bedrooms) if bedrooms else ''
            bathrooms_list.append(bathrooms) if bathrooms else ''
            id_list.append(id_) if id_ else ''
            category_list.append(category) if category else ''
            category_url_list.append(category_url) if category_url else ''
            price_list.append(price_final) if price_final else ''
            broker_list.append(broker) if broker else ''
            amenities_list.append(amenities) if amenities else ''
            agent_name_list.append(agent_name) if agent_name else ''
            phone_number_list.append(phone_numbers) if phone_numbers else ''
            number_of_photos_list.append(number_of_photos) if number_of_photos else ''
            details_list.append(area) if area else ''
            user_id_list.append(user_id) if user_id else ''
            row = [reference_number, id_, link, broker, broker.upper(), category, category_url, title, description, location, price_final, currency, price_per, bedrooms, bathrooms, furnished, rera_permit_number, dtcm_licence, scraped_ts, amenities, area, agent_name, number_of_photos, user_id, phone_numbers, scraped_ts, iteration_number]
            row_data.append(row)

    Sample_Genaration5(domain, row_data)

    if title_list == []:
        msg = 'title field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if description_list == []:
        msg = 'description field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if category_list == []:
        msg = 'category field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if id_list == []:
        msg = 'id_ field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if bathrooms_list == []:
        msg = 'bathroom1 field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if bedrooms_list == []:
        msg = 'bedroom field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)

    if category_url_list == []:
        msg = 'category_url field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if price_list == []:
        msg = 'price field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if broker_list == []:
        msg = 'broker field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if agent_name_list == []:
        msg = 'agent field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if user_list == []:
        msg = 'user field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if number_of_photos_list == []:
        msg = 'image field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if details_list == []:
        msg = 'area field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if phone_number_list == []:
        msg = 'phone_number field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    if amenities_list == []:
        msg = 'amenities field is empty in emlakjet_tur'
        print(msg)
        message.append(msg)
    slack_note(message, domain)


def justproperty_bah_fun(links):
    print('justproperty_bah_')
    domain = 'justproperty_bah'
    reference_number_list = []
    id_list = []
    url_list = []
    broker_display_name_list = []
    broker_list = []
    category_list = []
    category_url_list = []
    title_list = []
    description_list = []
    location_list = []
    price_list = []
    currency_list = []
    price_per_list = []
    bedrooms_list = []
    bathrooms_list = []
    furnished_list = []
    rera_permit_number = ''
    dtcm_licence = ''
    scraped_ts_list = []
    amenities_list = []
    details_list = []
    agent_name = ''
    number_of_photos_list = []
    user_id = ''
    phone_number_list = []
    date_list = []
    iteration_number = '2020_05',
    row_data = []
    message = []
    for link in links:
        response = requests.get(link, headers=headers)
        sel = Selector(text=response.content)
        print(sel)
        link = response.url
        print(link, '00000000000000000000')
        if response.status_code == 200:
            title = sel.xpath(justproperty_bah.TITLE_XPATH).extract_first()
            description = sel.xpath(
                justproperty_bah.DESCRIPTION_XPATH).extract()
            bedrooms = sel.xpath(
                justproperty_bah.BEDROOMS_XPATH).extract_first()
            bathrooms = sel.xpath(
                justproperty_bah.BATHROOMS_XPATH).extract_first()
            id_ = sel.xpath(justproperty_bah.ID_XPATH).extract_first()
            category = sel.xpath(
                justproperty_bah.CATEGORY_XPATH).extract_first()
            category_url = sel.xpath(
                justproperty_bah.CATEGORY_URL_XPATH).extract()
            price = sel.xpath(justproperty_bah.PRICE_XPATH).extract_first()
            broker = sel.xpath(justproperty_bah.BROKER_XPATH).extract_first()
            aminity = sel.xpath(
                justproperty_bah.AMENITIES_XPATH).extract_first()
            phone_numbers = sel.xpath(
                justproperty_bah.PHONE_XPATH).extract_first()
            img = sel.xpath(justproperty_bah.IMAGE_XPATH).extract_first()
            details = sel.xpath(justproperty_bah.DETAILS_XPATH).extract_first()
            price_per = sel.xpath(
                justproperty_bah.PRICE_PER_XPATH).extract_first()
            address = sel.xpath(justproperty_bah.ADDRESS_XPATH).extract_first()
            location = sel.xpath(
                justproperty_bah.LOCATION_XPATH).extract_first()
            furnished = sel.xpath(
                justproperty_bah.FURNISHED_XPATH).extract_first()
            photo = sel.xpath(justproperty_bah.PHOTO_XPATH).extract_first()
            referencenum = sel.xpath(
                justproperty_bah.REFER_NUB_XPATH).extract_first()

            title = ' '.join(''.join(title).strip().split()) if title else ''
            agent_name = ' '.join(
                ''.join(agent_name).strip().split()) if agent_name else ''
            bedrooms = ' '.join(
                ''.join(bedrooms).strip().split()) if bedrooms else ''
            bathrooms = ' '.join(
                ''.join(bathrooms).strip().split()) if bathrooms else ''
            category = ''
            category_url = category_url[-1] if category_url else ''
            if '/rent/' in category_url:
                category = 'rent'
                category_url = '/en/rent/bahrain/properties-for-rent/'
            elif '/buy/' in category_url:
                category = 'sale'
                category_url = '/en/buy/bahrain/properties-for-sale/'

            id_ = id_[0] if id_ else ''
            id_ = ' '.join(''.join(id_).strip().split()) if id_ else ''
            furnished = ' '.join(
                ''.join(furnished).strip().split()) if furnished else ''

            description = ' '.join(
                ''.join(description).strip().split()) if description else ''
            price_per = ' '.join(
                ''.join(price_per).strip().split()) if price_per else ''
            price = ' '.join(''.join(price).strip().replace(
                'BHD', '').split()) if price else ''
            broker = ' '.join(''.join(broker).strip().split()) if broker else ''
            location = ' '.join(
                ''.join(location).strip().split()) if location else ''
            # aminity = ', '.join([i.strip() for i in aminity if i.strip()])
            details = ' '.join(''.join(details).strip().split()) if details else ''
            number_of_photos = str(len(img))
            referencenum = ' '.join(
                ''.join(referencenum).strip().split()) if referencenum else ''

            currency = 'BHD'
            phone_numbers = phone_numbers[0].strip() if phone_numbers else ''
            scraped_ts = (datetime.now()).strftime("%Y-%m-%d")

            title_list.append(title) if title else ''
            description_list.append(description) if description else ''
            bedrooms_list.append(bedrooms) if bedrooms else ''
            bathrooms_list.append(bathrooms) if bathrooms else ''
            id_list.append(id_) if id_ else ''
            category_list.append(category) if category else ''
            category_url_list.append(category_url) if category_url else ''
            price_list.append(price) if price else ''
            broker_list.append(broker) if broker else ''
            amenities_list.append(aminity) if aminity else ''
            phone_number_list.append(phone_numbers) if phone_numbers else ''
            number_of_photos_list.append(number_of_photos) if number_of_photos else ''
            details_list.append(details) if details else ''
            reference_number_list.append(referencenum) if referencenum else ''
            furnished_list.append(furnished) if furnished else ''
            location_list.append(location) if location else ''
            price_per_list.append(price_per) if price_per else ''
            row = [id_, link, broker.upper(), broker, category, category_url, location, bedrooms, bathrooms, price, title, currency, description, price_per, furnished, rera_permit_number, dtcm_licence, scraped_ts, aminity, details, number_of_photos, agent_name, referencenum, user_id, phone_numbers, scraped_ts, iteration_number]
            row_data.append(row)

    Sample_Genaration6(domain, row_data)

    if title_list == []:
        msg = 'title field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if description_list == []:
        msg = 'description field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if category_list == []:
        msg = 'category field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if id_list == []:
        msg = 'id_ field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if bathrooms_ == []:
        msg = 'bathroom1 field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if bedroom_list == []:
        msg = 'bedroom field is empty in justproperty_bah'
        print(msg)
        message.append(msg)

    if category_url_list == []:
        msg = 'category_url field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if price_list == []:
        msg = 'price field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if broker_list == []:
        msg = 'broker field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if user_list == []:
        msg = 'user field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if number_of_photos_list == []:
        msg = 'image field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if details_list == []:
        msg = 'area field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if phone_number_list == []:
        msg = 'phone_number field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if amenities_list == []:
        msg = 'amenities field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    slack_note(message, domain)


def justproperty_qat_fun(links):
    print('justproperty_qat_')
    domain = 'justproperty_qat'
    reference_number_list = []
    id_list = []
    url_list = []
    broker_display_name_list = []
    broker_list = []
    category_list = []
    category_url_list = []
    title_list = []
    description_list = []
    location_list = []
    price_list = []
    currency_list = []
    price_per_list = []
    bedrooms_list = []
    bathrooms_list = []
    furnished_list = []
    rera_permit_number = ''
    dtcm_licence = ''
    scraped_ts_list = []
    amenities_list = []
    details_list = []
    agent_name_list = []
    number_of_photos_list = []
    user_id_list = []
    phone_number_list = []
    date_list = []
    iteration_number = '2020_05',
    row_data = []
    message = []
    for link in links:
        response = requests.get(link, headers=headers)
        sel = Selector(text=response.content)
        print(sel)
        link = response.url
        print(link, '00000000000000000000')
        if response.status_code == 200:
            location = ''
            user_id = ''
            area = ''
            agent_name = ''
            reference_number = ''
            amenity = ''
            phone_numbers = ''
            title = sel.xpath(justproperty_qat.TITLE_XPATH).extract()
            agent = sel.xpath(justproperty_qat.AGENT_XPATH).extract()
            bedrooms = sel.xpath(
                justproperty_qat.BEDROOMS_XPATH).extract()
            bathrooms = sel.xpath(
                justproperty_qat.BATHROOMS_XPATH).extract()
            description = sel.xpath(
                justproperty_qat.DESCRIPTION_XPATH).extract()
            price = sel.xpath(justproperty_qat.PRICE_XPATH).extract()
            address = sel.xpath(justproperty_qat.ADDRESS_XPATH).extract()
            broker_id = sel.xpath(justproperty_qat.BROKER_ID).extract()
            id_ = sel.xpath(justproperty_qat.ID_XPATH).extract()
            category = sel.xpath(
                justproperty_qat.CATEGORY_XPATH).extract()
            category_url = sel.xpath(
                justproperty_qat.CATEGORY_URL_XPATH).extract()
            broker = sel.xpath(justproperty_qat.BROKER_XPATH).extract()
            furnished = sel.xpath(
                justproperty_qat.FURNISHED_XPATH).extract()
            price_per = sel.xpath(
                justproperty_qat.PRICE_PER_XPATH).extract()
            location = sel.xpath(
                justproperty_qat.LOCATION_XPATH).extract()
            amenities = sel.xpath(
                justproperty_qat.AMENITIES_XPATH).extract()
            reference_nub = sel.xpath(
                justproperty_qat.REFER_NUB_XPATH).extract()
            phone_number = sel.xpath(
                justproperty_qat.PHONE_XPATH).extract()
            img = sel.xpath(justproperty_qat.IMAGE_XPATH).extract()
            area_f = sel.xpath(justproperty_qat.AREA_XPATH_F).extract()
            area_p = sel.xpath(justproperty_qat.AREA_XPATH_P).extract()

            title = ' '.join(''.join(title).strip().split()) if title else ''
            agent_name = ' '.join(
                ''.join(agent_name).strip().split()) if agent_name else ''
            bedrooms = ' '.join(
                ''.join(bedrooms).strip().split()) if bedrooms else ''
            bathrooms = ' '.join(
                ''.join(bathrooms).strip().split()) if bathrooms else ''
            price = ' '.join(''.join(price).strip().replace(
                'QAR', '').split()) if price else ''
            description = ' '.join(''.join(description).strip().replace(
                '*', '').split()) if description else ''
            id_ = ' '.join(''.join(id_).strip().split()) if id_ else ''

            category = ''
            category_url = category_url[-1] if category_url else ''
            if '/rent/' in category_url:
                category = 'rent'
                category_url = '/en/rent/qatar/properties-for-rent/'
            elif '/buy/' in category_url:
                category = 'sale'
                category_url = '/en/buy/qatar/properties-for-sale/'

            furnished = ' '.join(
                ''.join(furnished).strip().split()) if furnished else ''
            category = category if category else ''

            broker = ' '.join(''.join(broker).strip().split()) if broker else ''
            price_per = ' '.join(
                ''.join(price_per).strip().split()) if price_per else ''
            location = ' '.join(
                ''.join(location).strip().split()) if location else ''

            area_f = ' '.join(''.join(area_f).strip().split()) if area_f else ''
            area_p = ' '.join(''.join(area_p).strip().split()) if area_p else ''
            reference_number = ' '.join(
                ''.join(reference_number).strip().split()) if reference_number else ''
            amenity = ', '.join([i.strip() for i in amenity if i.strip()])
            number_of_photos = str(len(img))
            if area_f and area_p:
                area = 'Floor Area : ' + area_f + ', ' + 'Plot area : ' + area_p
            elif area_p:
                area = 'Plot area : ' + area_p
            elif area_f:
                area = 'Floor Area : ' + area_f
            currency = 'QAR'
            user = sel.xpath(
                '//div[@class="details-contact-info-links"]/a/@href').extract()

            if user:
                user = user[0] if user else ''
                userdata = user.split('-') if user else ''
                user_id = userdata[-1] if userdata else ''
                user_id = user_id.replace('/', '') if user_id else ''

            phone_numbers = phone_numbers[0].strip() if phone_numbers else ''

            # scraped_ts = (datetime.now()).date()
            scraped_ts = (datetime.now()).strftime("%Y-%m-%d")

            title_list.append(title) if title else ''
            description_list.append(description) if description else ''
            bedrooms_list.append(bedrooms) if bedrooms else ''
            bathrooms_list.append(bathrooms) if bathrooms else ''
            id_list.append(id_) if id_ else ''
            category_list.append(category) if category else ''
            category_url_list.append(category_url) if category_url else ''
            price_list.append(price) if price else ''
            broker_list.append(broker) if broker else ''
            amenities_list.append(amenity) if amenity else ''
            agent_name_list.append(agent) if agent else ''
            phone_number_list.append(phone_number) if phone_number else ''
            number_of_photos_list.append(number_of_photos) if number_of_photos else ''
            reference_number_list.append(reference_nub) if reference_nub else ''
            furnished_list.append(furnished) if furnished else ''
            location_list.append(location) if location else ''
            price_per_list.append(price_per) if price_per else ''
            user_id_list.append(broker_id) if broker_id else ''
            details_list.append(area) if area else ''
            row = [id_, link, broker.upper(), broker, category, category_url, location, bedrooms, bathrooms, price, title, currency, description, price_per, furnished, rera_permit_number, dtcm_licence, scraped_ts, area, reference_number, amenity, number_of_photos, agent_name, user_id, phone_numbers, scraped_ts, iteration_number]
            row_data.append(row)

    Sample_Genaration7(domain, row_data)

    if title_list == []:
        msg = 'title field is empty in justproperty_bah'
        print(msg)
        message.append(msg)
    if description_list == []:
        msg = 'description field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if category_list == []:
        msg = 'category field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if id_list == []:
        msg = 'id_ field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if bathrooms_list == []:
        msg = 'bathroom1 field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if bedrooms_list == []:
        msg = 'bedroom1 field is empty in justproperty_qat'
        print(msg)
        message.append(msg)

    if category_url_list == []:
        msg = 'category_url field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if price_list == []:
        msg = 'price field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if broker_list == []:
        msg = 'broker field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if agent_name_list == []:
        msg = 'agent field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if number_of_photos_list == []:
        msg = 'image field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if details_list == []:
        msg = 'area_f field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if phone_number_list == []:
        msg = 'phone_number field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if amenities_list == []:
        msg = 'amenities field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if reference_number_list == []:
        msg = 'reference_number field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if user_id_list == []:
        msg = 'broker_id field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if price_per_list == []:
        msg = 'price_per field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if location_list == []:
        msg = 'location field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    if furnished_list == []:
        msg = 'furnished field is empty in justproperty_qat'
        print(msg)
        message.append(msg)
    slack_note(message, domain)


def mubawab_qat_fun(links):
    print('mubawab_qat_')
    domain = 'mubawab_qat'
    reference_number = ''
    id_list = []
    url_list = []
    broker_display_name_list = []
    broker_list = []
    category_list = []
    category_url_list = []
    title_list = []
    description_list = []
    location_list = []
    price_list = []
    currency_list = []
    price_per = ''
    bedrooms_list = []
    bathrooms_list = []
    furnished = ''
    rera_permit_number = ''
    dtcm_licence = ''
    scraped_ts_list = []
    amenities_list = []
    details_list = []
    agent_name = ''
    number_of_photos_list = []
    user_id_list = []
    phone_number_list = []
    date_list = []
    iteration_number = '2020_05',
    row_data = []
    message = []
    for link in links:
        response = requests.get(link, headers=headers)
        sel = Selector(text=response.content)
        print(sel)
        link = response.url
        print(link, '00000000000000000000')

        if response.status_code == 200:
            user_id = ''
            id_final_ = ''
            currency = ''
            price = ''
            price_ = ''
            title = sel.xpath(mubawab_qat.TITLE_XPATH).extract_first()
            description = sel.xpath(mubawab_qat.DESCRIPTION_XPATH).extract()
            bedrooms = sel.xpath(mubawab_qat.BEDROOMS_XPATH).extract_first()
            bathrooms = sel.xpath(mubawab_qat.BATHROOMS_XPATH).extract_first()
            id_ = sel.xpath(mubawab_qat.ID_XPATH).extract_first()
            category = sel.xpath(mubawab_qat.CATEGORY_XPATH).extract_first()
            category_url = sel.xpath(
                mubawab_qat.CATEGORY_URL_XPATH).extract_first()
            price = sel.xpath(mubawab_qat.PRICE_XPATH).extract_first()
            phone_number = sel.xpath(mubawab_qat.PHONE_XPATH).extract_first()
            image = sel.xpath(mubawab_qat.IMAGE_XPATH).extract_first()
            amenities = sel.xpath(mubawab_qat.AMENITIES_XPATH).extract_first()
            area = sel.xpath(mubawab_qat.AREA_XPATH).extract_first()
            location = sel.xpath(mubawab_qat.LOCATION_XPATH).extract_first()
            broker_display_name = sel.xpath(
                mubawab_qat.BROKER_DISPLAY_NAME_XPATH).extract_first()
            id_ = id_[0].strip() if id_ else ''
            price_ = ''.join(price_).replace("Price on request", "").replace(
                ",", '').strip() if price_ else ''
            price_ = ' '.join(''.join(price_).split()) if price_ else ''
            price_ = price_.split(' ')
            if len(price_) >= 2:
                currency = price_[0].strip()
                price = price_[1].strip()
            elif len(price_) == 1:
                price_join = price_[0]
                currency = re.sub('[0-9]+', '', price_join)
                price = price_join.strip().replace(currency, '')
            else:
                currency = ''
                price = ''
            location = ' '.join(''.join(location).split()) if location else ''
            title = ''.join(title).strip() if title else ''
            bathrooms = bathrooms[0].strip().replace('Bathrooms', '').replace(
                'Bathroom', '').strip() if bathrooms else ''
            bedrooms = bedrooms[0].strip().replace('Rooms', '').replace(
                'Room', '').strip() if bedrooms else ''
            description = ' '.join(
                ' '.join(description).split()) if description else ''
            category_url = category_url[-1].strip() if category_url else ''
            category_url = category_url.replace('https://www.mubawab.com.qa', '')

            if 'sale' in category_url:
                category = 'sale'
                category_url = '/en/crp/qatar/qatar/real-estate-for-sale-all:sc:apartments-for-sale,commercial-property-for-sale,houses-for-sale,land-for-sale,villas-and-luxury-homes-for-sale'
            elif 'rent' in category_url:
                category = 'rent'
                category_url = '/en/crp/qatar/qatar/real-estate-for-rent-all:sc:apartments-for-rent,commercial-property-for-rent,houses-for-rent,land-for-rent,riads-for-rent,rooms-for-rent,villas-and-luxury-homes-for-rent'

            else:
                category = [x.strip() for x in category if x] if category else ''
                category = ' > '.join(category).strip() if category else ''

            broker_display_name = ''.join(
                broker_display_name).strip() if broker_display_name else ''

            amen = sel.xpath(
                '//ul[@class="features-list inBlock w100"]/li/i/following-sibling::text()').extract()
            area = sel.xpath(
                '//span[@class="tagProp"][contains(text(),"m²")]/text()').extract()
            img = sel.xpath(
                '//div[@class="thumbSldrProp"]//img/@src').extract()
            amen = [x.strip() for x in [x.strip()
                                        for x in amen] if x]if amen else ''
            amenities = ', '.join(amen).strip().replace(
                '  ', ' ').strip() if amen else ''
            number_of_photos = str(len(img))
            area = area[0].strip() if area else ''
            details = ' '.join([x.strip() for x in area.split()]) if area else ''
            user = sel.xpath('//div[@class="agency-info"]//a/@href').extract()

            if user:
                user = ''.join(user).split('/')if user else ''
                user_data = user[-2]if user else ''
                user_id = user_data.split('/') if user_data else ''
                user_id = user_id[0] if user_id else ''

            scraped_ts = (datetime.now()).strftime("%Y-%m-%d")

            phone_input = sel.xpath(
                '//div[@class="hide-phone-number-box"]/@onclick').extract()
            phone_data = re.findall(
                r'\'.*?\'', phone_input[0].strip()) if phone_input else ''

            title_list.append(title) if title else ''
            description_list.append(description) if description else ''
            bedrooms_list.append(bedrooms) if bedrooms else ''
            bathrooms_list.append(bathrooms) if bathrooms else ''
            id_list.append(id_) if id_ else ''
            category_list.append(category) if category else ''
            category_url_list.append(category_url) if category_url else ''
            price_list.append(price) if price else ''
            amenities_list.append(amenities) if amenities else ''
            phone_number_list.append(phone_data) if phone_data else ''
            number_of_photos_list.append(number_of_photos) if number_of_photos else ''
            details_list.append(area) if area else ''
            location_list.append(location) if location else ''
            broker_display_name_list.append(
                broker_display_name) if broker_display_name else ''
            row = [id_, link, broker_display_name, broker_display_name.upper(), category, category_url, title, description, location, price, currency, furnished, bedrooms, bathrooms, price_per, rera_permit_number, dtcm_licence, scraped_ts, amenities, details, agent_name, number_of_photos, user_id, phone_number, scraped_ts, iteration_number]
            row_data.append(row)

    Sample_Genaration7(domain, row_data)

    if title_list == []:
        msg = 'title field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    if description_list == []:
        msg = 'description field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    if category_list == []:
        msg = 'category field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    if id_list == []:
        msg = 'id_ field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    if bathrooms_list == []:
        msg = 'bathroom1 field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    if bedrooms_list == []:
        msg = 'bedroom1 field is empty in mubawab_qat'
        print(msg)
        message.append(msg)

    if category_url_list == []:
        msg = 'category_url field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    if price_list == []:
        msg = 'price field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    if number_of_photos_list == []:
        msg = 'image field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    if details_list == []:
        msg = 'area field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    if phone_number_list == []:
        msg = 'phone_number field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    if amenities_list == []:
        msg = 'amenities field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    if location_list == []:
        msg = 'location field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    if broker_display_name_list == []:
        msg = 'broker_display_name field is empty in mubawab_qat'
        print(msg)
        message.append(msg)
    slack_note(message, domain)


def olx_bah_fun(links):
    print('olx_bah_')
    domain = 'olx_bah'
    reference_number_ = []
    id__ = []
    url_ = []
    broker_display_name_ = []
    bedroom_ = []
    broker_ = []
    category_ = []
    category_url_ = []
    title_ = []
    description_ = []
    price_ = []
    currency_ = []
    price_text_ = []
    price_per_ = []
    bathrooms_ = []
    furnished_ = []
    rera_permit_number_ = []
    dtcm_licence_ = []
    amenities_ = []
    details_ = []
    agent_name_ = []
    number_of_photos_ = []
    user_id_ = []
    phone_number_ = []
    latitude_ = []
    longitude_ = []
    message = []
    location_ = []
    area_ = []
    name_ = []
    message = []
    user_ = []
    agent_ = []
    image_ = []
    address_ = []
    photo_ = []
    broker_id_ = []
    area_f_ = []
    area_p_ = []
    price_raw_ = []
    row_data = []
    for link in links:
        response = requests.get(link, headers=headers, proxies=proxy_t)
        sel = Selector(text=response.content)
        print(sel)
        link = response.url
        print(link, '00000000000000000000')
        if response.status_code == 200:
            img = ''
            phone_number = ''
            title = sel.xpath(olx_bah.TITLE_XPATH).extract_first()
            description = sel.xpath(olx_bah.DESCRIPTION_XPATH).extract()
            bedrooms = sel.xpath(olx_bah.BEDROOMS_XPATH).extract_first()
            bathrooms = sel.xpath(olx_bah.BATHROOMS_XPATH).extract_first()
            phone_number = sel.xpath(olx_bah.PHONE_XPATH).extract_first()
            id_ = sel.xpath(olx_bah.ID_XPATH).extract_first()
            category = sel.xpath(olx_bah.CATEGORY_XPATH).extract_first()
            category_url = sel.xpath(
                olx_bah.CATEGORY_URL_XPATH).extract_first()
            area = sel.xpath(olx_bah.AREA_XPATH).extract_first()
            location = sel.xpath(olx_bah.LOCATION_XPATH).extract_first()
            price_raw = sel.xpath(olx_bah.PRICE_RAW_XPATH).extract_first()
            amenities = sel.xpath(olx_bah.AMENITIES_XPATH).extract_first()
            broker = sel.xpath(olx_bah.BROKER_XPATH).extract_first()
            furnished = sel.xpath(olx_bah.FURNISHED_XPATH).extract_first()
            image1 = sel.xpath(olx_bah.IMAGE_XPATH1).extract_first()
            image2 = sel.xpath(olx_bah.IMAGE_XPATH2).extract_first()

            id_ = id_[0].strip() if id_ else ''
            broker_display_name = broker_display_name[0].replace("agent", "").replace(
                "The Marketer", "").replace("Real Estate Agent", "").strip() if broker_display_name else ''
            category = ' > '.join(category).strip() if category else ''
            category_url = category_url[-1].strip() if category_url else ''
            category_url = category_url.replace('https://olx.com.bh/', '').strip()
            if '/properties-for-rent/' in category_url:
                category = 'rent'
                category_url = '/en/properties/properties-for-rent/'
            elif '/buy/' in category_url:
                category = 'sale'
                category_url = '/en/properties/properties-for-sale/'

            title = ''.join(title).strip() if title else ''
            description = ' '.join(
                ' '.join(description).split()) if description else ''
            location = loc[0].strip() if loc else ''
            price_per = ''
            price_raw_ = ''.join(price_raw_).replace("d. B", "").replace("BHD", "").replace(
                u'\u062f. \u0628', '').replace('BHD', '').strip() if price_raw_ else ''
            bedrooms = bedrooms[0].strip() if bedrooms else ''
            bathrooms = bathrooms[0].strip() if bathrooms else ''
            furnished = furnished[0].strip() if furnished else ''
            rera_permit_number = ''
            dtcm_licence = ''

            if bathrooms:
                bathrooms = bathrooms.split('-')
                bathrooms = bathrooms[0].strip()

            if furnished:
                furnished = furnished.split('-')
                furnished = furnished[0].strip()

            if bedrooms:
                bedrooms = bedrooms.split('-')
                bedrooms = bedrooms[0].strip()

            area = response.xpath(
                '//tr/th[contains(text(),"المساحة (م٢)")]/following-sibling::td/strong/text()|//tr/th[contains(text(),"Area (m²)")]/following-sibling::td/strong/text()').extract()
            area = [x.strip().replace('-', '') for x in [x.strip()
                                                         for x in area] if x]if area else ''
            details = ''.join(area).strip() if area else ''
            details = details + "m2" if details else ''
            img1 = response.xpath(
                '//div[@class="tcenter img-item"]/div/img/@src').extract()
            img2 = response.xpath(
                '//div[@class="photo-handler rel inlblk"]/img/@src').extract()
            if img1 and img2:
                img = img1 + img2
            elif img1:
                img = img1
            elif img2:
                img = img2
            img = img if img else ''
            number_of_photos = str(len(img))
            if number_of_photos == '0':
                number_of_photos = ''
            number_of_photos = number_of_photos if number_of_photos else ''

            amen = response.xpath(
                '//tr/th[contains(text(),"Amenities")]/following-sibling::td/strong/a/text()').extract()
            amen = [x.strip() for x in [x.strip()
                                        for x in amen] if x]if amen else ''
            amenities = ', '.join(amen).strip().replace(
                '\t', '').replace('\n', '') if amen else ''

            is_phone = response.xpath(
                '//span[@class="link spoiler small nowrap"][contains(text(),"Show phone")]')
            if is_phone:
                ad_id = response.url.split('ID')
                if len(ad_id) == 2:
                    ad_id = ad_id[1].replace('.html', '')
                    phone_url = 'https://olx.com.bh/en/ajax/misc/contact/phone/' + ad_id + '/'

            title_.append(title) if title else ''
            description_.append(description) if description else ''
            bedroom_.append(bedrooms) if bedrooms else ''
            bathrooms_.append(bathrooms) if bathrooms else ''
            id__.append(id_) if id_ else ''
            price_raw_.append(price_raw) if price_raw else ''
            category_.append(category) if category else ''
            category_url_.append(category_url_) if category_url else ''
            amenities_.append(amenities) if amenities else ''
            phone_number_.append(phone_number) if phone_number else ''
            area_.append(area) if area else ''
            location_.append(location) if location else ''
            furnished_.append(furnished) if furnished else ''
            broker_.append(broker) if broker else ''
            image_.append(image1) if image1 else ''
            image_.append(image2) if image2 else ''
            row = [reference_number_, id_, link, broker_display_name_, bedroom_, broker, category, category_url, name, description, price_, currency_, price_text, price_per_, bathroom, furnished, rera_permit_number_, dtcm_licence_, amenities_, details_,
                   agent_name_, number_of_photos_, user_id_, phone_number_, latitude_, longitude_, location_, area_, bathrooms_, name_, message, user_, agent_, image_, address_, photo_, broker_id_, area_f_, area_p_, price_raw_]
            row_data.append(row)

    Sample_Genaration(domain, row_data)

    if title_ == []:
        msg = 'title field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if category_ == []:
        msg = 'category field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if id__ == []:
        msg = 'id_ field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if bathrooms_ == []:
        msg = 'bathroom1 field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if bedroom_ == []:
        msg = 'bedroom field is empty in olx_bah'
        print(msg)
        message.append(msg)

    if category_url_ == []:
        msg = 'category_url field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if price_raw_ == []:
        msg = 'price_raw field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if image_ == []:
        msg = 'image field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if area_ == []:
        msg = 'area field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if phone_number_ == []:
        msg = 'phone_number field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if amenities_ == []:
        msg = 'amenities field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if location_ == []:
        msg = 'location field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if broker_ == []:
        msg = 'broker field is empty in olx_bah'
        print(msg)
        message.append(msg)
    if furnished_ == []:
        msg = 'furnished field is empty in olx_bah'
        print(msg)
        message.append(msg)
    slack_note(message, domain)


def olx_fun(links):
    print('olx_')
    domain = 'olx'
    reference_number_ = []
    id__ = []
    url_ = []
    broker_display_name_ = []
    bedroom_ = []
    broker_ = []
    category_ = []
    category_url_ = []
    title_ = []
    description_ = []
    price_ = []
    currency_ = []
    price_text_ = []
    price_per_ = []
    bathrooms_ = []
    furnished_ = []
    rera_permit_number_ = []
    dtcm_licence_ = []
    amenities_ = []
    details_ = []
    agent_name_ = []
    number_of_photos_ = []
    user_id_ = []
    phone_number_ = []
    latitude_ = []
    longitude_ = []
    message = []
    location_ = []
    area_ = []
    name_ = []
    message = []
    user_ = []
    agent_ = []
    image_ = []
    address_ = []
    photo_ = []
    broker_id_ = []
    area_f_ = []
    area_p_ = []
    price_raw_ = []
    row_data = []
    for link in links:
        response = requests.get(link, headers=headers)
        sel = Selector(text=response.content)
        print(sel)
        link = response.url
        print(link, '000000000000')
        if response.status_code == 200:
            title = sel.xpath(olx.TITLE_XPATH).extract_first()
            description = sel.xpath(olx.DESCRIPTION_XPATH).extract()
            bedrooms = sel.xpath(olx.BEDROOMS_XPATH).extract_first()
            bathrooms = sel.xpath(olx.BATHROOMS_XPATH).extract_first()
            phone_number = sel.xpath(olx.PHONE_XPATH).extract_first()
            id_ = sel.xpath(olx.ID_XPATH).extract()
            category = sel.xpath(olx.CATEGORY_XPATH).extract_first()
            category_url = sel.xpath(olx.CATEGORY_URL_XPATH).extract()
            area = sel.xpath(olx.AREA_XPATH).extract_first()
            location = sel.xpath(olx.LOCATION_XPATH).extract_first()
            price_raw = sel.xpath(olx.PRICE_RAW_XPATH).extract_first()
            amenities = sel.xpath(olx.AMENITIES_XPATH).extract_first()
            broker = sel.xpath(olx.BROKER_XPATH).extract_first()
            furnished = sel.xpath(olx.FURNISHED_XPATH).extract_first()
            image1 = sel.xpath(olx.IMAGE_XPATH1).extract_first()
            image2 = sel.xpath(olx.IMAGE_XPATH2).extract_first()

            title_.append(title) if title else ''
            description_.append(description) if description else ''
            bedroom_.append(bedrooms) if bedrooms else ''
            bathrooms_.append(bathrooms) if bathrooms else ''
            id__.append(id_) if id_ else ''
            price_raw_.append(price_raw) if price_raw else ''
            category_.append(category) if category else ''
            category_url_.append(category_url_) if category_url else ''
            amenities_.append(amenities) if amenities else ''
            phone_number_.append(phone_number) if phone_number else ''
            area_.append(area) if area else ''
            location_.append(location) if location else ''
            furnished_.append(furnished) if furnished else ''
            broker_.append(broker) if broker else ''
            image_.append(image1) if image1 else ''
            image_.append(image2) if image2 else ''
            row = [reference_number_, id_, link, broker_display_name_, bedroom_, broker, category, category_url, name, description, price_, currency_, price_text, price_per_, bathroom, furnished, rera_permit_number_, dtcm_licence_, amenities_, details_,
                   agent_name_, number_of_photos_, user_id_, phone_number_, latitude_, longitude_, location_, area_, bathrooms_, name_, message, user_, agent_, image_, address_, photo_, broker_id_, area_f_, area_p_, price_raw_]
            row_data.append(row)

    Sample_Genaration(domain, row_data)

    if title_ == []:
        msg = 'title field is empty in olx'
        print(msg)
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in olx'
        print(msg)
        message.append(msg)
    if category_ == []:
        msg = 'category field is empty in olx'
        print(msg)
        message.append(msg)
    if id__ == []:
        msg = 'id_ field is empty in olx'
        print(msg)
        message.append(msg)
    if bathrooms_ == []:
        msg = 'bathroom1 field is empty in olx'
        print(msg)
        message.append(msg)
    if bedroom_ == []:
        msg = 'bedroom field is empty in olx'
        print(msg)
        message.append(msg)

    if category_url_ == []:
        msg = 'category_url field is empty in olx'
        print(msg)
        message.append(msg)
    if price_raw_ == []:
        msg = 'price_raw field is empty in olx'
        print(msg)
        message.append(msg)
    if image_ == []:
        msg = 'image field is empty in olx'
        print(msg)
        message.append(msg)
    if area_ == []:
        msg = 'area field is empty in olx'
        print(msg)
        message.append(msg)
    if phone_number_ == []:
        msg = 'phone_number field is empty in olx'
        print(msg)
        message.append(msg)
    if amenities_ == []:
        msg = 'amenities field is empty in olx'
        print(msg)
        message.append(msg)
    if location_ == []:
        msg = 'location field is empty in olx'
        print(msg)
        message.append(msg)
    if broker_ == []:
        msg = 'broker field is empty in olx'
        print(msg)
        message.append(msg)
    if furnished_ == []:
        msg = 'furnished field is empty in olx'
        print(msg)
        message.append(msg)
    slack_note(message, domain)


def qatarliving_qat_fun(links):
    print('qatarliving_qat_')
    domain = 'qatarliving_qat'
    reference_number_ = []
    id__ = []
    url_ = []
    broker_display_name_ = []
    bedroom_ = []
    broker_ = []
    category_ = []
    category_url_ = []
    title_ = []
    description_ = []
    price_ = []
    currency_ = []
    price_text_ = []
    price_per_ = []
    bathrooms_ = []
    furnished_ = []
    rera_permit_number_ = []
    dtcm_licence_ = []
    amenities_ = []
    details_ = []
    agent_name_ = []
    number_of_photos_ = []
    user_id_ = []
    phone_number_ = []
    latitude_ = []
    longitude_ = []
    message = []
    location_ = []
    area_ = []
    name_ = []
    message = []
    user_ = []
    agent_ = []
    image_ = []
    address_ = []
    photo_ = []
    broker_id_ = []
    area_f_ = []
    area_p_ = []
    price_raw_ = []
    row_data = []
    for link in links:
        response = requests.get(link, headers=headers)
        sel = Selector(text=response.content)
        print(sel)
        link = response.url
        print(link, '000000000000')
        if response.status_code == 200:
            title = sel.xpath(qatarliving_qat.TITLE_XPATH).extract_first()
            print(title, ';;;;;;;;;;;;')
            description = sel.xpath(
                qatarliving_qat.DESCRIPTION_XPATH).extract()
            bedrooms = sel.xpath(
                qatarliving_qat.BEDROOMS_XPATH).extract_first()
            bathrooms = sel.xpath(
                qatarliving_qat.BATHROOMS_XPATH).extract_first()
            id_ = sel.xpath(qatarliving_qat.PROPERTY_ID_XPATH).extract_first()
            category = sel.xpath(
                qatarliving_qat.CATEGORY_XPATH).extract_first()
            category_url = sel.xpath(
                qatarliving_qat.CATEGORY_URL_XPATH).extract_first()
            price = sel.xpath(qatarliving_qat.PRICE_XPATH).extract_first()
            phone_number = sel.xpath(
                qatarliving_qat.PHONE_XPATH).extract_first()
            image = sel.xpath(qatarliving_qat.IMAGE_XPATH).extract_first()
            amenities = sel.xpath(
                qatarliving_qat.AMENITIES_XPATH).extract_first()
            furnished = sel.xpath(
                qatarliving_qat.FURNISHED_XPATH).extract_first()

            title_.append(title) if title else ''
            description_.append(description) if description else ''
            bedroom_.append(bedrooms) if bedrooms else ''
            bathrooms_.append(bathrooms) if bathrooms else ''
            id__.append(id_) if id_ else ''
            category_.append(category) if category else ''
            category_url_.append(category_url_) if category_url else ''
            price_.append(price) if price else ''
            amenities_.append(amenities) if amenities else ''
            phone_number_.append(phone_number) if phone_number else ''
            image_.append(image) if image else ''
            furnished_.append(furnished_) if furnished else ''

            # print(title_,'////////////')
            row = [reference_number_, id_, link, broker_display_name_, bedroom_, broker, category, category_url, name, description, price_, currency_, price_text, price_per_, bathroom, furnished, rera_permit_number_, dtcm_licence_, amenities_, details_,
                   agent_name_, number_of_photos_, user_id_, phone_number_, latitude_, longitude_, location_, area_, bathrooms_, name_, message, user_, agent_, image_, address_, photo_, broker_id_, area_f_, area_p_, price_raw_]
            row_data.append(row)

    Sample_Genaration(domain, row_data)

    if title_ == []:
        msg = 'title field is empty in qatarliving_qat'
        print(msg)
        message.append(msg)
    if description_ == []:
        msg = 'description field is empty in qatarliving_qat'
        print(msg)
        message.append(msg)
    if category_ == []:
        msg = 'category field is empty in qatarliving_qat'
        print(msg)
        message.append(msg)
    if id__ == []:
        msg = 'id_ field is empty in qatarliving_qat'
        print(msg)
        message.append(msg)
    if bathrooms_ == []:
        msg = 'bathroom1 field is empty in qatarliving_qat'
        print(msg)
        message.append(msg)
    if bedroom_ == []:
        msg = 'bedroom field is empty in qatarliving_qat'
        print(msg)
        message.append(msg)

    if category_url_ == []:
        msg = 'category_url field is empty in qatarliving_qat'
        print(msg)
        message.append(msg)
    if price_ == []:
        msg = 'price field is empty in qatarliving_qat'
        print(msg)
        message.append(msg)
    if image_ == []:
        msg = 'image field is empty in qatarliving_qat'
        print(msg)
        message.append(msg)
    if phone_number_ == []:
        msg = 'phone_number field is empty in qatarliving_qat'
        print(msg)
        message.append(msg)
    if amenities_ == []:
        msg = 'amenities field is empty in qatarliving_qat'
        print(msg)
        message.append(msg)
    if furnished_ == []:
        msg = 'furnished field is empty in qatarliving_qat'
        print(msg)
        message.append(msg)
    slack_note(message, domain)


def dubizzle_fun(links):
    reference_number_list = []
    id_list = []
    broker_display_name_list = []
    broker_list = []
    category_list = []
    category_url_list = []
    title_list = []
    description_list = []
    location_list = []
    price_list = []
    currency_list = []
    price_per_list = []
    bedrooms_list = []
    bathrooms_list = []
    furnished_list = []
    rera_permit_number_list = []
    rera_registration_number_list = []
    amenities_list = []
    details_list = []
    number_of_photos_list = []
    user_id_list = []
    phone_number_list = []
    latitude_list = []
    longitude_list = []
    package_type_list = []
    domain = 'dubizzle'
    message = []
    PROXY_LIST = requests.get('http://68.183.58.145/torproxies',
                              headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
    count = 0
    links = ['https://dubai.dubizzle.com/classified/collectibles/other/2020/8/23/10-pounds-gold-coin-21-karat-52grams-2/?back=L2NsYXNzaWZpZWQvY29sbGVjdGlibGVzL290aGVyLw%3D%3D&pos=0&highlighted_ads=1']
    for url in links:
        url = url.strip().replace('/ar/', '/')
        j = 0
        final_response = ''
        while True:
            if j <= 3:
                try:
                    j = j + 1
                    pr = random.choice(PROXY_LIST)
                    proxy = 'https://' + pr
                    proxies = {'https': proxy, 'http': proxy}
                    logging.warning("Proxy Changed to %s" % proxy)
                    cat_url = 'https://alain.dubizzle.com/en/property-for-rent/residential/'
                    cat_url = cat_url.replace(re.findall(
                        '//(.*?)\.', cat_url)[0], re.findall('//(.*?)\.', url)[0])
                    cat_response = requests.get(cat_url, proxies=proxies)

                    correlationid = re.findall(
                        r'correlationId.*?":.*?"(.*?)[\\]+",', str(cat_response.content))[0].strip()
                    h = {'accept': 'application/json',
                         'accept-encoding': 'gzip, deflate, br',
                         'accept-language': 'en',
                         'content-length': '0',
                         'content-type': 'application/json; charset=utf-8',
                         # 'origin': 'https://dubai.dubizzle.com',
                         # 'referer': 'https://dubai.dubizzle.com/en/property-for-rent/residential/apartmentflat/?filters=(agent.name.en:%22Appello%20Real%20Estate%20Brokers%20(L%20L%20C)%22)',
                         # 'sec-fetch-mode': 'cors',
                         # 'sec-fetch-site': 'same-origin',
                         'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.75.14 (KHTML, like Gecko) Version/7.0.3 Safari/7046A194A',
                         'x-access-token': 'null',
                         'x-request-id': correlationid, }
                    loginurl = 'https://dubai.dubizzle.com/en/auth/login/'
                    loginurl = loginurl.replace(re.findall(
                        '//(.*?)\.', loginurl)[0], re.findall('//(.*?)\.', url)[0])
                    login_response = requests.post(
                        url=loginurl, headers=h, proxies=proxies)

                    access_token = login_response.json().get('access_token').strip()
                    h = {'accept': 'application/json',
                         'accept-encoding': 'gzip, deflate, br',
                         'accept-language': 'en',
                         'content-type': 'application/json; charset=utf-8',
                         'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.75.14 (KHTML, like Gecko) Version/7.0.3 Safari/7046A194A',
                         'x-access-token': access_token,
                         'x-request-id': correlationid, }
                    url_slug = url.split('.com')[-1].strip()
                    product_url = 'https://alain.dubizzle.com/en/property-for-sale/dpv/svc/api/v1/listing'
                    product_url = product_url.replace(re.findall(
                        '//(.*?)\.', product_url)[0], re.findall('//(.*?)\.', url)[0])
                    product_url = product_url + url_slug
                    final_response = requests.get(
                        url=product_url, headers=h, proxies=proxies)
                    print(final_response, '1111111111111111111111111111')
                    if final_response and final_response.status_code == 200:
                        msg = 'status:' + url + ':' + str(final_response.status_code)
                        # logging.warning(msg)
                        # break
                        if final_response:
                            package_type = ''
                            final_json = final_response.json()
                            print(final_json)
                            final_raw = final_json.get('data', {})
                            if final_raw:
                                name = str(final_raw.get('name_en', ''))
                                title = name
                                reference_number = str(final_raw.get(
                                    'company_item_id', ''))
                                id_ = str(final_raw.get('id', ''))
                                url = url.replace(
                                    '/en/property-for-sale/dpv/svc/api/v1/listing', '/')

                                broker_display_name = final_raw.get('agent_name', '')
                                broker = broker_display_name.upper() if broker_display_name else ''

                                if '/property-for-sale/' in url:
                                    category = 'sale'
                                    category_url = '/property-for-sale/home/'
                                elif '/property-for-rent/' in url:
                                    category = 'rent'
                                    category_url = '/property-for-rent/home/'
                                else:
                                    category = ''
                                    category_url = ''

                                description_text = final_raw.get('description_en', '')
                                des_sel = lxml.html.fromstring(
                                    description_text) if description_text else ''
                                description = ' '.join(des_sel.xpath(
                                    '//text()')) if description_text else ''

                                location_path = final_raw.get('location_path', '')
                                location_path = location_path.get('en') if location_path else ''
                                location = ', '.join(
                                    [x.strip() for x in location_path]) if location_path else ''

                                price = str(final_raw.get('price', ''))
                                currency = 'AED'
                                price_per = final_raw.get('rent_is_paid_display_en', '')

                                bedrooms = str(final_raw.get('bedrooms', ''))
                                bathrooms = str(final_raw.get('bathrooms', ''))
                                furnished = "Yes" if final_raw.get('furnished', '') else ''

                                rera_permit_number = str(final_raw.get('rera_permit_number', ''))
                                rera_registration_number = str(final_raw.get(
                                    'rera_registration_number', ''))
                                dtcm_licence = ''

                                amenities = ''
                                agent_name = ''
                                user_id = ''
                                details = str(final_raw.get('size', ''))
                                details = 'Area:' + details if details else ''
                                number_of_photos = str(final_raw.get('photos_count', ''))
                                phone_number = str(final_raw.get('phone_number', ''))

                                longitude = final_raw.get('location_get_x', '')
                                latitude = final_raw.get('location_get_y', '')

                                promoted = 'promoted' if final_raw.get('promoted') else ''
                                featured_listing = 'featured' if final_raw.get('featured_listing') else ''
                                package_type = promoted + ', ' + featured_listing
                                package_type = package_type.strip().strip(',').strip()

                                scraped_ts = (datetime.now()).strftime("%Y-%m-%d")
                                date = scraped_ts

                                # iteration_number
                                now = datetime.now()
                                current = datetime(now.year, now.month, 1)
                                next_month = datetime(now.year + int(now.month / 12), ((now.month % 12) + 1), 1)
                                now_date_int = int(now.strftime("%d"))
                                if now_date_int <= 31 and now_date_int >= 25:
                                    iteration_month = next_month.strftime("%m")
                                    iteration_year = next_month.strftime("%Y")
                                else:
                                    iteration_month = now.strftime("%m")
                                    iteration_year = now.strftime("%Y")
                                iteration_number = iteration_year + '_' + iteration_month
                        count = count + 1
                        if count > 5:
                            break
                        reference_number_list.append(reference_number) if reference_number else ''
                        id_list.append(id_) if id_ else ''
                        broker_display_name_list.append(broker_display_name) if broker_display_name else ''
                        broker_list.append(broker) if broker else ''
                        category_list.append(category) if category else ''
                        category_url_list.append(category_url) if category_url else ''
                        title_list.append(title) if title else ''
                        description_list.append(description) if description else ''
                        location_list.append(location) if location else ''
                        price_list.append(price) if price else ''
                        currency_list.append(currency) if currency else ''
                        price_per_list.append(price_per) if price_per else ''
                        bedrooms_list.append(bedrooms) if bedrooms else ''
                        bathrooms_list.append(bathrooms) if bathrooms else ''
                        furnished_list.append(furnished) if furnished else ''
                        rera_permit_number_list.append(rera_permit_number) if rera_permit_number else ''
                        rera_registration_number_list.append(rera_registration_number) if rera_registration_number else ''
                        amenities_list.append(amenities) if amenities else ''
                        details_list.append(details) if details else ''
                        number_of_photos_list.append(number_of_photos) if number_of_photos else ''
                        user_id_list.append(user_id) if user_id else ''
                        phone_number_list.append(phone_number) if phone_number else ''
                        latitude_list.append(latitude) if latitude else ''
                        longitude_list .append(longitude) if longitude else ''
                        package_type_list.append(package_type) if package_type else ''
                    elif final_response.status_code == 404:
                        msg = 'status: ' + url + ': ' + str(final_response.status_code)
                        logging.warning(msg)
                        final_response = ''
                        not_found = {'url': url}
                        break
                except:
                    pass
            else:
                msg = 'failed: ' + url
                logging.warning(msg)
                failed = {'url': url}
                break

    if not reference_number_list:
        msg = 'reference_number field empty in dubizzle'
        message.append(msg)
    if not id_list:
        msg = 'id field empty in dubizzle'
        message.append(msg)
    if not broker_display_name_list:
        msg = 'broker_display_name field empty in dubizzle'
        message.append(msg)
    if not broker_list:
        msg = 'broker field empty in dubizzle'
        message.append(msg)
    if not category_list:
        msg = 'category field empty in dubizzle'
        message.append(msg)
    if not category_url_list:
        msg = 'category_url field empty in dubizzle'
        message.append(msg)
    if not title_list:
        msg = 'title field empty in dubizzle'
        message.append(msg)
    if not description_list:
        msg = 'description field empty in dubizzle'
        message.append(msg)
    if not location_list:
        msg = 'location field empty in dubizzle'
        message.append(msg)
    if not price_list:
        msg = 'price field empty in dubizzle'
        message.append(msg)
    if not currency_list:
        msg = 'currency field empty in dubizzle'
        message.append(msg)
    if not price_per_list:
        msg = 'price_per field empty in dubizzle'
        message.append(msg)
    if not bedrooms_list:
        msg = 'bedrooms field empty in dubizzle'
        message.append(msg)
    if not bathrooms_list:
        msg = 'bathrooms field empty in dubizzle'
        message.append(msg)
    if not furnished_list:
        msg = 'furnished field empty in dubizzle'
        message.append(msg)
    if not rera_permit_number_list:
        msg = 'rera_permit_number field empty in dubizzle'
        message.append(msg)
    if not rera_registration_number_list:
        msg = 'rera_registration_number field empty in dubizzle'
        message.append(msg)
    if not amenities_list:
        msg = 'amenities field empty in dubizzle'
        message.append(msg)
    if not details_list:
        msg = 'details field empty in dubizzle'
        message.append(msg)
    if not number_of_photos_list:
        msg = 'number_of_photos field empty in dubizzle'
        message.append(msg)
    if not user_id_list:
        msg = 'user_id field empty in dubizzle'
        message.append(msg)
    if not phone_number_list:
        msg = 'phone_number field empty in dubizzle'
        message.append(msg)
    if not latitude_list:
        msg = 'latitude field empty in dubizzle'
        message.append(msg)
    if not longitude_list:
        msg = 'longitude field empty in dubizzle'
        message.append(msg)
    if not package_type_list:
        msg = 'package_type field empty in dubizzle'
        message.append(msg)
    slack_note(message, domain)
