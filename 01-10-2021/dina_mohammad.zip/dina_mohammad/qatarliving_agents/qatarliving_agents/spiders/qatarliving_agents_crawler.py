# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
import re
import io
import gzip

from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime
from scrapy.shell import inspect_response
from xml.dom import minidom

from qatarliving_agents.items import *
from qatarliving_agents.settings import *


class QatarlivingAgentsSpiderSpider(scrapy.Spider):
    name = "qatarliving_agents_crawler"
    allowed_domains = ["qatarliving.com"]
    start_urls = ['https://www.qatarliving.com/classifieds/properties',
                  'https://www.qatarliving.com/classifieds/commercial-properties',
                  'https://www.qatarliving.com/classifieds/properties/apartment',
                  'https://www.qatarliving.com/classifieds/properties/shared-accomodation',
                  'https://www.qatarliving.com/classifieds/properties/villa',
                  ]

    def parse(self, response):
        link = response.xpath(
            '//a[@class="b-card--el-agency-title"]/@href|//div[@class="b-card--el-agency promoted-ads"]/@data-link').extract()

        for i in link:
            url = 'https://www.qatarliving.com' + i
            item = QatarlivingAgentsUrlItem(
                url=url,

            )
            yield item

        next_ = response.xpath('//a[contains(text(),"›")]/@href').extract()
        if next_:
            next_ = ''.join(next_) if next_ else ''
            next_ = 'https://www.qatarliving.com' + next_
            next_url = next_ if next_ else ''
            yield Request(next_url, callback=self.parse,)
