import scrapy
import re
import pika
import json
import logging
import re
import io
import gzip
import requests

from scrapy.shell import inspect_response
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime
from scrapy.shell import inspect_response
from xml.dom import minidom
from scrapy.http import Request

from xml.dom import minidom
from qatarliving_agents.items import *
from qatarliving_agents.settings import *


class QatarlivingAgentsSpiderSpider(scrapy.Spider):
    name = "qatarliving_agents_spider"
    allowed_domains = ["qatarliving.com"]

    start_urls = ['https://www.qatarliving.com/classifieds/properties',
                  'https://www.qatarliving.com/classifieds/commercial-properties',
                  'https://www.qatarliving.com/classifieds/properties/apartment',
                  'https://www.qatarliving.com/classifieds/properties/shared-accomodation',
                  'https://www.qatarliving.com/classifieds/properties/villa',
                  ]

    def start_requests(self):

        f = open('urls.txt')
        for url in f.readlines():
            url = url.strip()
            yield Request(url=url, callback=self.parse_data,)

    def parse_data(self, response):
        phone_number = ''
        ads = []
        first_ad = ''
        ad_url = ''
        num = ''
        agent_name = response.xpath(
            '//h1[@class="b-profile-head--el-name"]/text()').extract()
        agent_name = ' '.join(
            ''.join(agent_name).strip().split()) if agent_name else ''

        data = response.xpath('//span[@data-entity-bundle="classified"][contains(@href,"/properties/") or contains(@href,"/commercial-properties/")]')
        if data:
            first_ad = data[0].xpath('@href').extract()
            first_ad = ''.join(first_ad) if first_ad else ''
            first_ad = 'https://www.qatarliving.com' + first_ad
        for info in data:
            add1 = info.xpath('@href').extract()
            add1 = ''.join(add1) if add1 else ''
            ad_url = 'https://www.qatarliving.com' + add1
            price = info.xpath(
                'div[@class="b-card--el-header"]/div[@class="b-card--el-price-conditions "]//text()').extract()
            if price:
                price = [x.strip() for x in price]
                price = [x.strip() for x in price if x]
                price = ' '.join(price).strip() if price else ''
                if '/properties/' or '/commercial-properties/' in ad_url:
                    ads.append({'ad_url': ad_url, 'price': price})
        number_of_ads = len(ads)
        if first_ad:
            try:
                ad_url_content = requests.get(
                    first_ad).content
            except:
                try:
                    ad_url_content = requests.get(
                        first_ad).content
                except:
                    ad_url_content = ''
            if ad_url_content:
                sel = Selector(text=ad_url_content)
                num = sel.xpath(
                    '//p[contains(text(),"Phone")]/following-sibling::a')
            else:
                num = ''

            if num:
                for phone in num:
                    phone_number = phone.xpath('@href').extract()
            phone_number = ''.join(phone_number).replace(
                'tel:', '') if phone_number else ''
            
        item = QatarlivingAgentsItem(
            agent_name=agent_name,
            ads=ads,
            number_of_ads=number_of_ads,
            url=response.url,
            phone_number=phone_number,

        )
        yield item
