import scrapy
import json
from scrapy.http import Request, FormRequest
from datetime import datetime
import ast
import pika
from gourban.items import *
from gourban.settings import *


amen_feature_list = ['seaView', 'commissionFree', 'sharedPool', 'sharedGym', 'walkinCloset', 'privateJacuzzi', 'security', 'conciergeService', 'childrenPlayArea', 'childrenPool', 'barbecueArea', 'viewOfLandmark', 'viewOfWater', 'saunaRoom', 'steamRoom', 'privatePool', 'privateGarden', 'balcony', 'builtinkitchenApp', 'builtinWardrobe', 'maidsRoom', 'tiledFloor', 'storageRoom', 'studyRoom', 'laundryRoom', 'petsAllowed', 'businessCenter', 'centralAC', 'smartHomeSystem', 'coveredParking', 'carCharging',
                     'basketBallCourt', 'tennisCourt', 'sharedGameRoom', 'sharedRooftop', 'terrace', 'greenCommunity', 'sharedMovieTheater', 'closeToMetro', 'kidsPlayground', 'closeToTram', 'greenery', 'familyFriendly', 'walkFriendly', 'gatedCommunity', 'superMarkets', 'restaurants', 'closeToBeach', 'closeToMall', 'hospital']


amen_feature_dict = {'balcony': 'Balcony',
                     'barbecueArea': 'Barbecue area',
                     'basketBallCourt': 'Shared basketball court',
                     'builtinWardrobe': 'Built-in wardrobe',
                     'builtinkitchenApp': 'Built-in appliances',
                     'businessCenter': 'Business center',
                     'carCharging': 'Electric car charging',
                     'centralAC': 'Central AC',
                     'childrenPlayArea': "Children's play area",
                     'childrenPool': "Children's pool",
                     'chillerFree': 'Chiller free',
                     'commissionFree': 'No service fee',
                     'conciergeService': 'Concierge service',
                     'coveredParking': 'Covered parking',
                     'dhaPromotion': 'For healthworkers',
                     'flexiOne': 'Flexible contract',
                     'flexiTwo': 'Free moving',
                     'freeTVPackage': 'Free TV package',
                     'freeWifi': 'Free WiFi',
                     'greenCommunity': 'Eco-friendly community',
                     'laundryRoom': 'Laundry room',
                     'maidsRoom': 'Maid’s room',
                     'oneMonthFree': '1 month free',
                     'petsAllowed': 'Pet-friendly',
                     'privateGarden': 'Private garden',
                     'privateGym': 'Private gym',
                     'privateJacuzzi': 'Private hot tub',
                     'privatePool': 'Private pool',
                     'saunaRoom': 'Sauna room',
                     'seaView': 'Sea view',
                     'security': 'Security',
                     'sharedGameRoom': 'Shared games room',
                     'sharedGym': 'Shared gym',
                     'sharedMovieTheater': 'Shared movie theater',
                     'sharedPool': 'Shared pool',
                     'sharedRooftop': 'Shared rooftop deck',
                     'smartHomeSystem': 'Smart home system',
                     'steamRoom': 'Steam room',
                     'storageRoom': 'Storage room',
                     'studyRoom': 'Study',
                     'tennisCourt': 'Shared tennis court',
                     'terrace': 'Terrace',
                     'threeMonthFree': '3 months free',
                     'tiledFloor': 'Tile floor',
                     'twoMonthFree': '2 months free',
                     'utilitiesIncluded': 'Utilities included',
                     'viewOfLandmark': 'Landmark view',
                     'viewOfWater': 'Water view',
                     'walkinCloset': 'Walk-in closet',
                     'zeroHousingFees': 'Zero housing fee',
                     'closeToBeach': 'Close to beach',
                     'closeToMall': 'Close to mall',
                     'closeToMetro': 'Close to metro',
                     'closeToTram': 'Close to tram',
                     'familyFriendly': 'Family friendly',
                     'gatedCommunity': 'Gated community',
                     'greenery': 'Green spaces',
                     'hospital': 'Close to hospital',
                     'kidsPlayground': 'Children’s playground',
                     'restaurants': 'Restaurants',
                     'superMarkets': 'Supermarkets',
                     'walkFriendly': 'Pedestrian friendly'}

header = {'accept': 'text/html, application/xhtml+xml, application/xmlq = 0.9, image/webp, image/apng, */*q = 0.8, application/signed-exchangev = b3',
          'accept-encoding': 'gzip, deflate, br',
          'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
          'cache-control': 'no-cache',
          'pragma': 'no-cache',
          'upgrade-insecure-requests': '1',
          'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', }

QUEUE_HOST = '159.89.47.171'
QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'
QUEUE_NAME = 'ha.ha.gourban_url'


class GourbanCrawlerSpider(scrapy.Spider):
    name = 'gourban_parser'

    def start_requests(self):

        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        while True:
            connection = pika.BlockingConnection(pika.ConnectionParameters(
                credentials=credentials, host=QUEUE_HOST, socket_timeout=300))
            channel = connection.channel()
            channel.basic_qos(prefetch_count=1)
            method, properties, url = channel.basic_get(queue=QUEUE_NAME)
            if not url:
                logging.warning('Queue completed.')
                break
            url = str(url.strip(), encoding='utf-8')
            channel.basic_ack(delivery_tag=method.delivery_tag)
            if url:
                url = url.strip()
                yield Request(url, headers=header, callback=self.parse)
        connection.close()
        #url = 'https://api.gourban.com/homescreen-service/api/v1/homescreen/property/1592748322'

        # yield Request(url=url, headers=header, callback=self.parse)

    def parse(self, response):
        data = json.loads(response.body_as_unicode())
        id_ = data.get('result').get('property').get('id')
        id_ = id_ if id_ else ''
        broker_display_name = data.get('result').get(
            'property').get('agentCompName')
        broker_display_name = broker_display_name if broker_display_name else ''
        user_id = data.get('result').get('property').get('brokerId')
        user_id = user_id if user_id else ''
        title = data.get('result').get('property').get('name')
        title = title.replace('\t', '') if title else ''
        descript = data.get('result').get('property').get('description')
        description = descript.replace('\t\t\r\n\r\n', '').replace(
            '\r\n\r\n•\t', ' ').replace('\r\n•\t', ' ').replace('\r\n', ' ').replace('\t \t\t', ' ').replace('\t', '')
        description = description if description else ''
        address = data.get('result').get('property').get('address')
        address = address if address else ''
        price_per_month = data.get('result').get(
            'property').get('twelveMonthPrice')
        price_per = price_per_month/12
        price = round(price_per)
        price = price if price else ''
        bedrooms = data.get('result').get('property').get('bedrooms')
        bedrooms = bedrooms if bedrooms else ''
        bathrooms = data.get('result').get('property').get('bathrooms')
        bathrooms = bathrooms if bathrooms else ''
        furnisned_type = data.get('result').get('property').get('furnishType')
        if furnisned_type == 1:
            furnished = 'Yes'
        else:
            furnished = 'No'
        amen_list = []
        amen_list.clear()
        for a in amen_feature_list:
            value = data.get('result').get('property').get(a)
            if value == True:
                amen_list.append(a)
        amenities = ",".join([amen_feature_dict.get(x) for x in amen_list])
        amenities = amenities if amenities else ''
        details_data = data.get('result').get('property').get('areaSize')
        details = str(details_data)+' sqft'
        details = details if details else ''
        agent_name = data.get('result').get('property').get('agentName')
        agent_name = agent_name if agent_name else ''
        images = data.get('result').get('property').get('images')
        number_of_photos = ast.literal_eval(images)
        number_of_photos = number_of_photos if number_of_photos else ''

        trakheesiNumber = data.get('result').get(
            'property').get('trakheesiNumber')
        trakheesiNumber = trakheesiNumber if trakheesiNumber else ''
        trn = data.get('result').get('property').get('trn')
        latitude = data.get('result').get('property').get('latitude')
        latitude = latitude if latitude else ''
        longitude = data.get('result').get('property').get('longitude')
        longitude = longitude if longitude else ''
        reference_number = data.get('result').get(
            'property').get('referenceIdNum')
        reference_number = reference_number if reference_number else ''

        scraped_ts = (datetime.now()).strftime("%Y-%m-%d")

        if title:

            item = GourbanItem(
                reference_number=str(reference_number),
                id=str(id_),
                url=response.url,
                broker_display_name=broker_display_name,
                broker=broker_display_name.upper(),
                category='RENT',
                category_url='',
                title=title,
                description=description,
                location=address,
                price=str(price),
                currency='AED',
                price_per='Monthly',
                bedrooms=str(bedrooms),
                bathrooms=str(bathrooms),
                furnished=furnished,
                rera_permit_number=str(trakheesiNumber),
                dtcm_licence='',
                scraped_ts=scraped_ts,
                amenities=amenities,
                details=details,
                agent_name=agent_name,
                number_of_photos=str(len(number_of_photos)),
                user_id=str(user_id),
                phone_number='',
                date=scraped_ts,
                iteration_number='2020_08',
                latitude=latitude,
                longitude=longitude
            )
            yield item

        else:
            miss_url = GourbanMissItem()
            miss_url['url'] = response.url
            yield miss_url
