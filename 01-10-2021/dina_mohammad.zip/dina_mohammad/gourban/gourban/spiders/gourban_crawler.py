import scrapy
import re
import pika
import json
import logging
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime
from gourban.items import *
from gourban.settings import *
handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

# count = 0
# page = 0


class GourbanCrawlerSpider(Spider):
    name = 'gourban_crawler'

    header = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
              'accept-encoding': 'gzip, deflate, br',
              'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
              'cache-control': 'no-cache',
              'pragma': 'no-cache',
              'upgrade-insecure-requests': '1',
              'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', }

    def start_requests(self):

        urls = ['https://api.gourban.com/homescreen-service/api/v1/carousel/screen/1',
                'https://api.gourban.com/homescreen-service/api/v1/carousel/screen/2']
        for url in urls:
            yield Request(url=url, headers=self.header, callback=self.parse)

    def parse(self, response):

        data = json.loads(response.body_as_unicode())
        details = data.get('result', '')
        for url_id in details:
            ids = url_id.get('id', '')
            url = 'https://api.gourban.com/homescreen-service/api/v1/carousel/' + \
                str(ids)+'?page=0&size=1000&by=rank&order=asc'
            if url_id.get('type') != "STATIC":
                if url_id.get('type') == "PROPERTY":
                    yield Request(url=url, headers=self.header, callback=self.parse_property_listing)
                else:
                    if url_id.get('type') == "BUILDING":
                        yield Request(url=url, headers=self.header, callback=self.building_listing)

    def building_listing(self, response):
        json_data = json.loads(response.body_as_unicode())
        properties = json_data.get("result").get('content').get('buildings')
        print(len(properties))

        for property_ in properties:
            id_ = property_.get("id")
            url = 'https://api.gourban.com/homescreen-service/api/v1/listing/property?building=' + \
                str(id_)+'&page=0&size=1000&by=rank&order=asc'

            yield Request(url=url, headers=self.header, callback=self.parse_building_listing)

    def parse_building_listing(self, response):
        json_data = json.loads(response.body_as_unicode())
        properties = json_data.get("result").get('properties')

        for property_ in properties:
            id_ = property_.get("id")
            url = 'https://api.gourban.com/homescreen-service/api/v1/homescreen/property/' + \
                str(id_)

            url_item = GourbanUrlItem()
            url_item['url'] = url
            yield url_item
            logging.warning('////////////////////////////////////')

    def parse_property_listing(self, response):

        # global count
        # global page

        # res_url = response.url
        # ids = res_url.split('?')[0].split('/')[-1]

        json_data = json.loads(response.body_as_unicode())
        properties = json_data.get("result").get('content').get('properties')

        for property_ in properties:
            id_ = property_.get("id")
            url = 'https://api.gourban.com/homescreen-service/api/v1/homescreen/property/' + \
                str(id_)

            url_item = GourbanUrlItem()
            url_item['url'] = url
            yield url_item
            logging.warning('????????????????????????????????????')

        # length = len(properties)
        # total_count = json_data.get("result").get('content').get('totalCount')
        # count = count+length

        # if count != total_count:
        #     page += 1
        #     url = 'https://api.gourban.com/homescreen-service/api/v1/carousel/' + \
        #         str(ids)+'?page='+str(page)+'&size=300&by=rank&order=asc'

        #     yield Request(url=url, headers=self.header, callback=self.parse_property_listing)
