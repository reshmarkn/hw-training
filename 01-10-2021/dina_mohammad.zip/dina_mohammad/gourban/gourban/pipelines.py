import pymongo
from pymongo import MongoClient
from scrapy.exceptions import DropItem
from gourban.items import *
from gourban.settings import *

MONGO_URI = 'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017'  # shard
MONGODB_DB = 'dina_mohammad_07_07_2020'
MONGODB_COLLECTION_AGENT = 'gourban_uae_2020_08_07'
MONGODB_COLLECTION_AGENT_URL = 'gourban_uae_url_2020_08_07'
MONGODB_COLLECTION_AGENT_MISS_URL = 'gourban_uae_miss_url_2020_08_07'


class GourbanPipeline(object):
    def __init__(self, *args, **kwargs):
        self.client = MongoClient(
            'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')
        self.db = self.client[MONGODB_DB]
        self.db[MONGODB_COLLECTION_AGENT_URL].create_index('url', unique=True)

    def process_item(self, item, spider):
        if isinstance(item, GourbanItem):
            try:
                self.db[MONGODB_COLLECTION_AGENT].insert(dict(item))
            except Exception:
                raise DropItem("Dropping duplicate item")

        if isinstance(item, GourbanUrlItem):
            try:
                self.db[MONGODB_COLLECTION_AGENT_URL].insert(dict(item))
            except Exception:
                raise DropItem("Dropping duplicate item")

        if isinstance(item, GourbanMissItem):
            try:
                self.db[MONGODB_COLLECTION_AGENT_MISS_URL].insert(dict(item))
            except Exception:
                raise DropItem("Dropping duplicate item")

        return item
