import scrapy
import re
import pika
import json
import logging
import re
import io
import gzip
import requests
import time

from scrapy.shell import inspect_response
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime
from scrapy.shell import inspect_response
from xml.dom import minidom
from scrapy.http import Request
from xml.dom import minidom
from yellowpages.items import *
from yellowpages.settings import *
from time import sleep


class YellowpagesSpiderSpider(scrapy.Spider):
    name = "yellowpages_crawler"
    # allowed_domains = ["yellowpages.com"]
    start_urls = [
        'https://www.yellowpages.com.eg/en/condensed-category/real-estate']

    # def start_requests(self):
    #     for page in range(0, 332):
    #         page_url = 'https://www.yellowpages.com.eg/en/condensed-category/real-estate/p' + \
    #             str(page)
    #         yield Request(page_url, callback=self.parse,)

    def parse(self, response):
        name_link = response.xpath(
            '//a/@href').extract()
        time.sleep(1)
        for link in name_link:
            if 'en/profile' in link:
                url = link.rstrip('//').lstrip('//') if link else ''
                url = 'https://' + url
                if '?position' in url:
                    url = url.split('?position') if url else ''
                    page_url = url[0] if url else ''
                    item = YellowpagesCrawlerItem(
                        url=page_url,
                    )
                    yield item

        next_ = response.xpath('//a[@aria-label="Next"]/@href').extract()
        if next_:
            next_page = ''.join(next_)if next_ else ''
            next_url = 'https://www.yellowpages.com.eg' + next_page if next_page else ''
            yield Request(next_url, callback=self.parse, dont_filter=True)
