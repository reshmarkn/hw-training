# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
import re
import io
import gzip
import requests
import time

from scrapy.shell import inspect_response
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime
from xml.dom import minidom
from scrapy.http import Request

from xml.dom import minidom
from yellowpages.items import *
from yellowpages.settings import *


class YellowpagesSpiderSpider(scrapy.Spider):
    name = "yellowpages_spider"
    # allowed_domains = ["yellowpages.com"]
    # start_urls = [
    #     'https://www.yellowpages.com.eg/en/condensed-category/real-estate']

    # def start_requests(self):
    #     for page in range(20, 30):
    #         page_url = 'https://www.yellowpages.com.eg/en/condensed-category/real-estate/p' + \
    #             str(page)
    #         yield Request(page_url, callback=self.parse,)

    def start_requests(self):
        f = open('urls.txt')
        for url in f.readlines():
            url = url.strip()
            yield Request(url=url, callback=self.parse_data,)

    # def parse(self, response):
    #     name_link = response.xpath(
    #         '//a/@href').extract()
    #     for link in name_link:
    #         if 'en/profile' in link:
    #             url = link.rstrip('//').lstrip('//') if link else ''
    #             url = 'https://' + url
    #             if '?position' in url:
    #                 url = url.split('?position') if url else ''
    #                 page_url = url[0] if url else ''
    # yield Request(page_url, callback=self.parse_data, dont_filter=True)

    # next_ = response.xpath('//a[@aria-label="Next"]/@href').extract()
    # if next_:
    #     next_page = ''.join(next_)if next_ else ''
    #     next_url = 'https://www.yellowpages.com.eg' + next_page if next_page else ''
    #     yield Request(next_url, callback=self.parse, dont_filter=True)

    def parse_data(self, response):
        latitude = ''
        longitude = ''
        street = ''
        website = response.xpath('//a[@class="openWebsite"]/@href').extract()
        website = ''.join(website) if website else ''
        address = response.xpath(
            '//div[@class="col-xs-12 address"]//text()|//p[@class="des-address address"]/text()').extract()
        address_ = ' '.join(''.join(address).strip().split())if address else ''
        item = response.xpath(
            '//script[@type="application/ld+json"]/text()').extract()
        for info in item:
            data = json.loads(info)
            name = data.get('name')
            phone_number = data.get('telephone')
            geo = data.get('geo')
            # address = data.get('address')
            # if address:
            #     street = address.get('streetAddress')
            if geo:
                latitude = geo.get('latitude')
                longitude = geo.get('longitude')
            name = ' '.join(''.join(name).strip().split()) if name else ''
            street = ' '.join(''.join(street).strip().split()
                              ) if street else ''
            phone_number = ' '.join(
                ''.join(phone_number).strip().split()) if phone_number else ''
            website = ' '.join(
                ''.join(website).strip().split()) if website else ''
            latitude = ' '.join(
                ''.join(latitude).strip().split()) if latitude else ''
            longitude = ' '.join(
                ''.join(longitude).strip().split()) if longitude else ''

            item = YellowpagesItem(
                name=name,
                address=address_,
                phone_number=phone_number,
                website=website,
                latitude=latitude,
                longitude=longitude,
                url=response.url,

            )
            if name:
                yield item
