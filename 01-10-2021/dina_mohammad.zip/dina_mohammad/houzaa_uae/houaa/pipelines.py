# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
from pymongo import MongoClient
from scrapy.exceptions import DropItem
from houaa.items import *
from datetime import datetime

now = datetime.now()
current = datetime(now.year, now.month, 1)
next_month = datetime(now.year + int(now.month / 12), ((now.month % 12) + 1), 1)
now_date_int = int(now.strftime("%d"))
if now_date_int <=31 and now_date_int >=25:
    iteration_month = next_month.strftime("%m")
    iteration_year = next_month.strftime("%Y")
else:
    iteration_month = now.strftime("%m")
    iteration_year = now.strftime("%Y")
iteration_number = iteration_year + '_'+ iteration_month

MONGODB_DB = 'dina_mohammad_monthly_' + iteration_number
MONGO_DATA_COLLECTION = 'houza_uae_' + iteration_number
MONGO_LINK_COLLECTION = 'houza_uae_url_new_' + iteration_number
class HouaaPipeline(object):
    def __init__(self, *args, **kwargs):
        self.client = MongoClient(
            'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
        # self.client = MongoClient('mongodb://localhost:27017')
        try:
            self.client.admin.command("enablesharding", MONGODB_DB)
            self.client.admin.command("shardcollection", MONGODB_DB + '.' + MONGO_LINK_COLLECTION,
                                      key={'url': 1}, unique=True)
        except Exception:
            pass
        try:
            self.client.admin.command(
                "shardcollection", MONGODB_DB + "." + MONGO_LINK_COLLECTION, key={'url': 1}, unique=True)
        except Exception:
            pass
        try:
            self.client.admin.command(
                "shardcollection", MONGODB_DB + "." + MONGO_DATA_COLLECTION, key={'url': 1}, unique=True)
        except Exception:
            pass



        # self.client = MongoClient(
        #     'mongodb://datahut:cGFzc21lMTIz@64.225.9.179:27017')
        self.db = self.client[MONGODB_DB]
        # self.db[MONGO_LINK_COLLECTION].create_index('property_url',unique=True)
        # self.db[MONGO_DATA_COLLECTION].create_index('url', unique=True)

    def process_item(self, item, spider):
        if isinstance(item, Houaa_url_item):
            try:
                self.db[MONGO_LINK_COLLECTION].insert(dict(item))
            except:
                raise DropItem("Dropping duplicate item")
        if isinstance(item, Houaa_data_item):
            try:
                self.db[MONGO_DATA_COLLECTION].insert(dict(item))
            except:
                raise DropItem("Dropping duplicate item")
        return item
