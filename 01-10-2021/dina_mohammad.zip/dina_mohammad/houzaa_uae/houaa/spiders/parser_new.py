import scrapy
import json
import pika
from scrapy.http import *
from scrapy.spiders import Spider
from datetime import datetime
from pymongo import MongoClient
from houaa.settings import *
from houaa.items import *
import logging
from rmq import RmqHandler
import requests
import random
from scrapy.selector import Selector

logger = logging.getLogger('pika')
logger.propagate = False
h = {"accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
     "accept-encoding": "gzip, deflate",
     "accept-language": "en-GB,en-US;q=0.9,en;q=0.8,ml;q=0.7",
     "cache-control": "max-age=0",
     "upgrade-insecure-requests": "1",
     "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36"
     }
db =MongoClient('mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false').dina_mohammad_houza
PROXY_LIST = requests.get('http://68.183.58.145/torproxies', headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
PROXY = random.choice(PROXY_LIST)
proxy_url = "http://%s" % PROXY
proxies = {"http": "http://%s" % PROXY,
           "https": "http://%s" % PROXY}
class Houaa_parse_spider(scrapy.Spider):
    name = 'houza_parser'

    def start_requests(self):
        rmqh = RmqHandler(QUEUE_NAME, ip=QUEUE_IP,user=QUEUE_USER, pwd=QUEUE_PASS)
        while True:
            count, data = rmqh.get()
            if not data:
                break
            # js= json.loads(data)
            # url=js.get('url')
            url = str(data.strip())
            api_id = url.split('-')[-1]
            api_url = 'https://api.houza.com/api/v1/properties/short/' + str(api_id)
            meta = {'url': url}
            yield Request(api_url, headers=h, callback=self.parse1, meta=meta)
        # url='https://houza.com/en/buy/dubai/apartments-for-sale-dubai-marina-marina-quays-marina-quay-north/one-bed-plus-study-marina-view-vacant-RWLPAZAKfM'
        # meta = {'url': url}
        # yield Request(url, headers=h, callback=self.parse1, meta=meta)    

    def parse1(self, response):
        if response.status == 200:
            
            json_data = str(response.body, encoding='utf8')
            try:
                json_dict = json.loads(json_data)
            except:
                self.reque(response.meta.get('url'))
            price = json_dict.get('price')
            property_price = price if price else ''
                
            category_name = json_dict.get('listingType','')
            category_name = category_name.lower()
            if 'sale' in category_name:
                category_link = '/en/buy/properties-for-sale'
            if 'rent' in category_name:
                category_link = '/en/rent/properties-for-rent'

            permit_number = json_dict.get('permitNumber','')
            permit_number = permit_number if permit_number else ''

            no_of_photos = json_dict.get('photos','')
            img_no = len(no_of_photos) if no_of_photos else ''

            reference_number = json_dict.get('reference','')
            reference_number = reference_number if reference_number else ''

            rera = json_dict.get('reraId')
            rera_registration_number = rera if rera else ''

            
            description = json_dict.get('description','')
            description = description.replace('\n',' ') if description else ''

            short_id = json_dict.get('shortId', '')
            broker_details = json_dict.get('agency').get('name', '')
            baathrooms = json_dict.get('bathrooms', '')
            bedrooms = json_dict.get('bedrooms', '')
            # furnished_type = json_dict.get('furnishedType','')
            aminties_list = json_dict.get('amenities', '')
            area_details = json_dict.get('sizeSQFT', '')
            agent_names = json_dict.get('agent', '').get('name', '')
            agent_phone_no = json_dict.get('agent', '').get('phone')
            property_title = json_dict.get('title', '')
            geopoint = json_dict.get('geoPoint').get('coordinates', '') 
            price_per = json_dict.get('rentalLength' '')
            try:
                if 'YEARLY' in price_per:
                    price_per = 'year'
                elif 'MONTHLY' in price_per:
                    price_per = 'month'
                elif 'DAILY' in price_per:
                    price_per = 'day'
                elif 'WEEKLY' in price_per:
                    price_per = 'week'
                else:
                    price_per = ''
            except :
                pass

            locations = []
            for k,v in json_dict.items():
                if 'location' in k:
                    try:
                        locations.append(json_dict.get(k).get('name',''))
                    except :
                        pass
            location = ' ,'.join(locations) if locations else ''

            furnished = json_dict.get('furnishedType','')
            furnished = furnished if furnished else ''

            published_at = json_dict.get('createdAt','').split('T')[0]

            id_ = short_id.strip() if short_id else ''
            broker = broker_details.strip() if broker_details else ''
            baathroom_number = baathrooms if baathrooms else ''
            bedroom_number = bedrooms if bedrooms else ''
            aminties = ' ,'.join(aminties_list).strip() if aminties_list else ''
            area = str(area_details) + ' sq.ft' if area_details else ''
            agent_name = agent_names.strip() if agent_names else ''
            agent_phone = agent_phone_no if agent_phone_no else ''
            title = property_title.strip() if property_title else ''
            if geopoint:
                lattitude = geopoint[0]
                longitude = geopoint[1]
            else:
                lattitude = ''
                longitude = ''
            user_id = json_dict.get('agency').get('slug','')
            user_id = user_id if user_id else ''

            now = datetime.now()
            current = datetime(now.year, now.month, 1)
            next_month = datetime(now.year + int(now.month / 12), ((now.month % 12) + 1), 1)
            now_date_int = int(now.strftime("%d"))
            if now_date_int <=31 and now_date_int >=25:
                iteration_month = next_month.strftime("%m")
                iteration_year = next_month.strftime("%Y")
            else:
                iteration_month = now.strftime("%m")
                iteration_year = now.strftime("%Y")
            iteration_number = iteration_year + '_'+ iteration_month
            scraped_ts = (datetime.now()).strftime("%Y-%m-%d")
            item = Houaa_data_item()
            item['reference_number'] = reference_number
            item['id'] = id_
            item['url'] = response.meta.get('url')
            item['broker_display_name'] = broker
            item['broker'] = broker.upper()
            item['category'] = category_name
            item['category_url'] = category_link
            item['title'] = title
            item['description'] = description
            item['location'] = location
            item['price'] = property_price
            item['currency'] = 'AED'
            item['price_per'] = price_per
            item['bedrooms'] = bedroom_number
            item['bathrooms'] = baathroom_number
            item['furnished'] = furnished
            item['rera_permit_number'] = permit_number
            item['rera_registration_number'] = rera_registration_number
            item['dtcm_licence'] = ''
            item['scraped_ts'] = scraped_ts
            item['amenities'] = aminties
            item['details'] = area
            item['agent_name'] = agent_name
            item['number_of_photos'] = img_no
            item['user_id'] = user_id
            item['phone_number'] = agent_phone
            item['date'] = scraped_ts
            item['iteration_number'] = iteration_number
            item['latitude'] = lattitude
            item['longitude'] = longitude
            item['sub_category_1'] = ''
            item['sub_category_2'] = ''
            item['property_type'] = ''
            item['depth'] = ''
            item['published_at']=published_at,
            print(item)
            yield item
            
        else:
            item1={}
            item1['response'] = response.status
            item1['url'] = response.meta.get('url')
            #print(item1)
            if item1.get('response') == '503':
                self.reque(response.meta.get('url'))
            else:
                db['404_collection'].insert(dict(item1))
    def reque(self,url):
        rmqh = RmqHandler(QUEUE_NAME, ip=QUEUE_IP,user=QUEUE_USER, pwd=QUEUE_PASS)
        rmqh.publish(url)