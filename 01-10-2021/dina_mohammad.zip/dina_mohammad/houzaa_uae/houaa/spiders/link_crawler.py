import scrapy
from scrapy.http import *
from scrapy.spiders import Spider
from pymongo import MongoClient
from houaa.settings import *
from houaa.items import *
import json
from rmq import RmqHandler

import logging
h = {"accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
     "accept-encoding": "gzip, deflate",
     "accept-language": "en-GB,en-US;q=0.9,en;q=0.8,ml;q=0.7",
     "cache-control": "max-age=0",
     "upgrade-insecure-requests": "1",
     "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36"
     }
from datetime import datetime

now = datetime.now()
current = datetime(now.year, now.month, 1)
next_month = datetime(now.year + int(now.month / 12), ((now.month % 12) + 1), 1)
now_date_int = int(now.strftime("%d"))
if now_date_int <=31 and now_date_int >=25:
    iteration_month = next_month.strftime("%m")
    iteration_year = next_month.strftime("%Y")
else:
    iteration_month = now.strftime("%m")
    iteration_year = now.strftime("%Y")
iteration_number = iteration_year + '_'+ iteration_month

MONGODB_DB = 'dina_mohammad_monthly_' + iteration_number
MONGO_DATA_COLLECTION = 'houza_uae_' + iteration_number
MONGO_LINK_COLLECTION = 'houza_uae_url_' + iteration_number
client = MongoClient('mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
try:
    client.admin.command("enablesharding", MONGODB_DB)
    client.admin.command("shardcollection", MONGODB_DB + '.' + MONGO_LINK_COLLECTION,key={'url': 1}, unique=True)
except Exception:
    pass
try:
    client.admin.command("shardcollection", MONGODB_DB + "." + MONGO_LINK_COLLECTION, key={'url': 1}, unique=True)
except Exception:
    pass
try:
    client.admin.command("shardcollection", MONGODB_DB + "." + MONGO_DATA_COLLECTION, key={'url': 1}, unique=True)
except Exception:
    pass
db = client[MONGODB_DB]
class Houaa_spider(scrapy.Spider):
    name = 'houza_link_crawler'

    def start_requests(self):
        rmqh = RmqHandler(QUEUE_NAME2, ip=QUEUE_IP,user=QUEUE_USER, pwd=QUEUE_PASS)
        while True:
            count, data = rmqh.get()
            if not data:
                break
            urls = json.loads(data)
            url = urls.get('start_url')
            p_type = urls.get('type')
            meta ={'url':url,'p_type':p_type,'page':0}
            # url ='https://houza.com/en/buy/properties-for-sale'
            yield Request(url, headers=h, callback=self.parse1, dont_filter=True,meta=meta)
    def parse1(self, response):
        if response.status == 200:

            url = response.meta.get('url')
            p_type = response.meta.get('p_type')
            page = response.meta.get('page')
            page=page +1
            meta = response.meta


            if 'COMMERCIAL_RENT' in url:
                SUB_CATEGORY_1 ='Commercial'
                SUB_CATEGORY_2=''
            elif 'COMMERCIAL_SALE' in url:
                SUB_CATEGORY_1 ='Commercial'
                SUB_CATEGORY_2=''
            elif 'RENT' in url:
                SUB_CATEGORY_1 ='Residential'
                SUB_CATEGORY_2=''
            elif 'SALE' in url:
                SUB_CATEGORY_1 ='Residential'
                SUB_CATEGORY_2=''
            elif 'https://api.houza.com/api/v1/properties/browse/rent/short-term' in url:
                SUB_CATEGORY_1 ='Residential'
                SUB_CATEGORY_2='Short-term'

            page_json =json.loads(response.body_as_unicode())
            properties =page_json['properties'] 
            if properties:
                for l in properties:
                    link =l.get('url','')
                    if link:
                        p_url ='https://houza.com'+link
                        item=Houaa_url_item()
                        item['url'] = p_url
                        item['sub_category_1'] = SUB_CATEGORY_1
                        item['sub_category_2'] = SUB_CATEGORY_2
                        item['property_type'] = p_type
                        item['depth'] = ''
                        try:
                            logging.warning(item)
                            db[MONGO_LINK_COLLECTION].insert(dict(item))
                        except:
                            pass
                    else:
                        yield Request(url, headers=h, callback=self.parse1, dont_filter=True,meta=meta)

                nxt_url=url.split('page')[0]+'&page='+str(page)
                if nxt_url:
                    meta ={'url':url,'p_type':p_type,'page':page}
                    yield Request(nxt_url, headers=h, callback=self.parse1, dont_filter=True,meta=meta)
        else:
            rmqh = RmqHandler(QUEUE_NAME2, ip=QUEUE_IP,user=QUEUE_USER, pwd=QUEUE_PASS)
            rmqh.publish(json.dumps(meta))
