from pymongo import MongoClient
import pika
import json
from time import sleep
import datetime
QUEUE_HOST='159.89.47.171'
QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'
QUEUE_NAME = 'ha.houza_url'
credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
connection = pika.BlockingConnection(pika.ConnectionParameters(
    credentials=credentials, host=QUEUE_HOST, socket_timeout=3000))
channel = connection.channel()
channel.queue_declare(queue=QUEUE_NAME, durable=True)

reside_prop_type = ['APARTMENT',
'VILLA',
'TOWNHOUSE',
'PENTHOUSE',
'LAND',
'FULL_BUILDING',
'HOTEL_APARTMENT',
'COMPOUND',
'DUPLEX',
'FULL_FLOOR']

com_prop_type = ['OFFICE',
'WAREHOUSE',
'RETAIL',
'FULL_FLOOR',
'LABOUR_CAMP',
'LAND',
'FULL_BUILDING',
'HOTEL_APARTMENT',
'FACTORY',
'STAFF_ACCOMODATION',
'VILLA',
'COMPOUND',
'SHOP',
'SHOW_ROOM']

urls_list = []

for res_type in reside_prop_type:
      type_ = res_type.lower().replace('_',' ')
      start_url =  'https://api.houza.com/api/v1/properties?listingType=SALE&unitType='+res_type
      urls_list.append({'start_url':start_url, 'type':type_,'sub_category_1':'Residential'})
      start_url =  'https://api.houza.com/api/v1/properties?listingType=RENT&unitType='+res_type
      urls_list.append({'start_url':start_url, 'type':type_,'sub_category_1':'Residential'})

for com_type in com_prop_type:
      type_ = com_type.lower().replace('_',' ')
      start_url =  'https://api.houza.com/api/v1/properties?listingType=COMMERCIAL_SALE&unitType='+com_type
      urls_list.append({'start_url':start_url, 'type':type_,'sub_category_1':'Commercial'})
      start_url =  'https://api.houza.com/api/v1/properties?listingType=COMMERCIAL_RENT&unitType='+com_type
      urls_list.append({'start_url':start_url, 'type':type_,'sub_category_1':'Commercial'})

short_term = [{'start_url':'https://api.houza.com/api/v1/properties/browse/rent/short-term-apartments-for-rent','type':'apartments'},
{'start_url':'https://api.houza.com/api/v1/properties/browse/rent/short-term-hotel-apartments-for-rent','type':'hotel apartments'},
{'start_url':'https://api.houza.com/api/v1/properties/browse/rent/short-term-villas-for-rent','type':'villas'},
{'start_url':'https://api.houza.com/api/v1/properties/browse/rent/short-term-townhouses-for-rent','type':'townhouses'},]

urls_list.append(short_term)


print(urls_list)
# urls_list=[{'start_url':'https://api.houza.com/api/v1/properties/browse/buy/apartments-for-sale?page=1','type':'apartments'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/buy/villas-for-sale?page=1','type':'villas'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/buy/townhouses-for-sale?page=1','type':'townhouses'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/buy/land-for-sale?page=1','type':'land'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/buy/penthouses-for-sale?page=1','type':'penthouses'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/buy/offices-for-sale?page=1','type':'offices'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/buy/hotel-apartments-for-sale?page=1','type':'hotel apartments'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/buy/full-buildings-for-sale?page=1','type':'full buildings'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/buy/full-floors-for-sale?page=1','type':'full floors'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/buy/compounds-for-sale?page=1','type':'compounds'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/buy/labour-camps-for-sale?page=1','type':'labour camps'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/buy/show-rooms-for-sale?page=1','type':'show rooms'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/rent/apartments-for-rent?page=1','type':'apartments'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/rent/villas-for-rent?page=1','type':'villas'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/rent/townhouses-for-rent?page=1','type':'townhouses'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/rent/offices-for-rent?page=1','type':'offices'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/rent/hotel-apartments-for-rent?page=1','type':'hotel apartments'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/rent/penthouses-for-rent?page=1','type':'penthouses'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/rent/full-buildings-for-rent?page=1','type':'full buildings'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/rent/compounds-for-rent?page=1','type':'compounds'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/rent/full-floors-for-rent?page=1','type':'full floors'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/rent/retail-spaces-for-rent?page=1','type':'retail spaces'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/commercial-buy/offices-for-sale?page=1','type':'offices'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/commercial-buy/labour-camps-for-sale?page=1','type':'labour camps'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/commercial-buy/warehouses-for-sale?page=1','type':'warehouses'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/commercial-buy/retail-spaces-for-sale?page=1','type':'retail'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/commercial-buy/land-for-sale?page=1','type':'land'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/commercial-buy/full-floors-for-sale?page=1','type':'full floors'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/commercial-buy/shops-for-sale?page=1','type':'shops'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/commercial-buy/hotel-apartments-for-sale?page=1','type':'hotel apartments'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/commercial-buy/full-buildings-for-sale?page=1','type':'buildings'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/commercial-buy/villas-for-sale?page=1','type':'villas'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/commercial-buy/staff-accomodation-for-sale?page=1','type':'staff accomodation'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/commercial-buy/show-rooms-for-sale?page=1','type':'show rooms'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/commercial-buy/factories-for-sale?page=1','type':'factories'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/rent/short-term-apartments-for-rent?page=1','type':'apartments'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/rent/short-term-hotel-apartments-for-rent?page=1','type':'hotel apartments'},
#             {'start_url':'https://api.houza.com/api/v1/properties/browse/rent/short-term-villas-for-rent?page=1','type':'villas'},
#             {'start_url':'https://api.houza.com/api/v1/properties?listingType=COMMERCIAL_RENT&unitType=OFFICE&page=1','type':'offices'},
#             {'start_url':'https://api.houza.com/api/v1/properties?listingType=COMMERCIAL_RENT&unitType=WAREHOUSE&page=1','type':'warehouses'},
#             {'start_url':'https://api.houza.com/api/v1/properties?listingType=COMMERCIAL_RENT&unitType=RETAIL&page=1','type':'retail'},
#             {'start_url':'https://api.houza.com/api/v1/properties?listingType=COMMERCIAL_RENT&unitType=FULL_FLOOR&page=1','type':'full floors'},
#             {'start_url':'https://api.houza.com/api/v1/properties?listingType=COMMERCIAL_RENT&unitType=LABOUR_CAMP&page=1','type':'labour camps'},
#             {'start_url':'https://api.houza.com/api/v1/properties?listingType=COMMERCIAL_RENT&unitType=LAND&page=1','type':'land'},
#             {'start_url':'https://api.houza.com/api/v1/properties?listingType=COMMERCIAL_RENT&unitType=FULL_BUILDING&page=1','type':'full buildings'},
#             {'start_url':'https://api.houza.com/api/v1/properties?listingType=COMMERCIAL_RENT&unitType=HOTEL_APARTMENT&page=1','type':'hotel apartments'},
#             {'start_url':'https://api.houza.com/api/v1/properties?listingType=COMMERCIAL_RENT&unitType=FACTORY&page=1','type':'factories'},
#             {'start_url':'https://api.houza.com/api/v1/properties?listingType=COMMERCIAL_RENT&unitType=STAFF_ACCOMODATION&page=1','type':'staff accomodation'},
#             {'start_url':'https://api.houza.com/api/v1/properties?listingType=COMMERCIAL_RENT&unitType=VILLA&page=1','type':'villas'},
#             {'start_url':'https://api.houza.com/api/v1/properties?listingType=COMMERCIAL_RENT&unitType=COMPOUND&page=1','type':'compounds'},
#             {'start_url':'https://api.houza.com/api/v1/properties?listingType=COMMERCIAL_RENT&unitType=SHOP&page=1','type':'shops'},
#             {'start_url':'https://api.houza.com/api/v1/properties?listingType=COMMERCIAL_RENT&unitType=SHOW_ROOM&page=1','type':'show rooms'}
#             ]


for document in urls_list:
    channel.basic_publish(exchange='', routing_key=QUEUE_NAME, body=json.dumps(document))
    sleep(0.0001)
connection.close()