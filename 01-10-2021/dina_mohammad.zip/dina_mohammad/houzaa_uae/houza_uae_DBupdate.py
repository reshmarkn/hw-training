import pymongo
from pymongo import MongoClient
import json
from datetime import datetime

now = datetime.now()
current = datetime(now.year, now.month, 1)
next_month = datetime(now.year + int(now.month / 12), ((now.month % 12) + 1), 1)
now_date_int = int(now.strftime("%d"))
if now_date_int <= 31 and now_date_int >= 25:
	iteration_month = next_month.strftime("%m")
	iteration_year = next_month.strftime("%Y")
else:
	iteration_month = now.strftime("%m")
	iteration_year = now.strftime("%Y")
iteration_number = iteration_year + '_' + iteration_month
iteration_number = iteration_number.strip()
MONGODB_DB = 'dina_mohammad_monthly_' + iteration_number
MONGODB_COLLECTION_AGENT = 'houza_uae_'+ iteration_number
MONGODB_COLLECTION_AGENT_URL = 'houza_uae_url_' + iteration_number


client = MongoClient('mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')


DB_NAME = MONGODB_DB
db = client[DB_NAME]

col_up = MONGODB_COLLECTION_AGENT
print(DB_NAME, col_up)
count = db[col_up].count()
print(count)
json_col = MONGODB_COLLECTION_AGENT_URL + '.json'
print('json_col:', json_col)
col_match=open(json_col).readlines()
entry=[json.loads(x.strip()) for x in col_match]


filist=['sub_category_1','sub_category_2','property_type','depth']


for item in entry:
	itemdict=dict()

	url=item['url']

	for i in filist:
		itemdict[i]=item.get(i)

	db[col_up].update_one({'url':url},{"$set":itemdict})

	print(url,itemdict)
