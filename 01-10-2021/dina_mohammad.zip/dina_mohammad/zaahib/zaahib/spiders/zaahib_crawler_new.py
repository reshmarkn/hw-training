# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
import requests

from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime
from scrapy.shell import inspect_response
from rmq import RmqHandler

from zaahib.items import *
from zaahib.settings import *
from zaahib.storm_proxy import parse_proxy

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


class ZaahibSpider(scrapy.Spider):
    name = 'zaahib_crawler_updated'
    headers = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
               'accept-encoding': 'gzip, deflate, br',
               'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
               'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36',
               }

    def start_requests(self):

        rmqh = RmqHandler(QUEUE_AJAX_NAME, ip=QUEUE_IP,
                          user=QUEUE_USER, pwd=QUEUE_PASS)
        while True:
            count, data = rmqh.get()
            if not data:
                break
            if data:
                url = data
                yield Request(url=url.strip(), callback=self.parse, headers=self.headers, errback=lambda x: self.errback_httpbin(x, url.strip()))
        # url = 'https://apiv2.zaahib.com/ajax/modules/classifieds/search_listings.php?sf=yes&ListingCategory%5Bin%5D=154&PropertyType%5Bin%5D=863&PropertyFinalizing%5Bin%5D=&AgencyLanguages%5Bin%5D=&AgencyServices%5Bin%5D=&page=1&version=5.2.0&buildtype=application&lang=ar&country=sa'
        # yield Request(url=url.strip(), callback=self.parse, headers=self.headers)

    def parse(self, response):
        try:
            jsondata = json.loads(response.body_as_unicode())
        except Exception:
            try:
                jsondata = json.loads(response.body_as_unicode())
            except Exception:
                pass

        if jsondata:
            page_number = jsondata.get("pages_number", '')
            data = jsondata.get('listings', '')
            if data:

                for item in data:
                    id_ = item.get('sid', '')
                    if id_:
                        id_ = str(id_).strip()
                        url_input = 'https://apiv2.zaahib.com/ajax/modules/classifieds/display_listing_handler.php?buildType=website&lang=en&listing_id=%s' % (
                            id_)
                        item = ZaahibUrlItem(
                            url=url_input,
                        )
                        yield item

                if page_number and page_number < 500:

                    next_url = response.url.replace(',', '')

                    next_url_ = next_url.split('&page=')[0]
                    split_url = next_url.split('&page=')[1]

                    number = split_url.split('&')[0]
                    if len(number) == 1:
                        portion = split_url[1:]
                    elif len(number) == 2:
                        portion = split_url[2:]
                    elif len(number) == 3:
                        portion = split_url[3:]
                    else:
                        pass
                    next_ = next_url_ + '&page=' + str(int(number) + 1)+portion

                    yield Request(url=next_, callback=self.parse, headers=self.headers)

    def errback_httpbin(self, failure, url):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=600))
        channel = connection.channel()
        channel.queue_declare(queue=QUEUE_AJAX_NAME, durable=True)
        channel.basic_publish(
            exchange='', routing_key=QUEUE_AJAX_NAME, body=url)
        connection.close()
