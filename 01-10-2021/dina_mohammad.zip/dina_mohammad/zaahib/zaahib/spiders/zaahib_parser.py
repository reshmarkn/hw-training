# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
import requests
import js2py
from rmq import RmqHandler

from pymongo import MongoClient
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime
from scrapy.shell import inspect_response

from zaahib.items import *
from zaahib.settings import *
from zaahib.storm_proxy import parse_proxy


now = datetime.now()
current = datetime(now.year, now.month, 1)
next_month = datetime(now.year + int(now.month / 12), ((now.month % 12) + 1), 1)
now_date_int = int(now.strftime("%d"))
if now_date_int <= 31 and now_date_int >= 25:
    iteration_month = next_month.strftime("%m")
    iteration_year = next_month.strftime("%Y")
else:
    iteration_month = now.strftime("%m")
    iteration_year = now.strftime("%Y")
iteration_number = iteration_year + '_' + iteration_month

MONGODB_DB = 'dina_mohammad_monthly_' + iteration_number
# MONGODB_DB='zahhib_test'
MONGODB_COLLECTION_DATA = 'zaahib_data_missing_' + iteration_number

client = MongoClient('mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
try:
    client.admin.command(
        "shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION_DATA, key={'url': 1}, unique=True)
except:
    pass

db = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')[MONGODB_DB]


client = MongoClient(
            'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
db = client[MONGODB_DB]

# try:
#     self.db[MONGODB_COLLECTION_DATA].create_index(
#         [('url', pymongo.DESCENDING)], unique=True)
# except:
#     pass
# db = client[MONGODB_DB]

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


class ZaahibParseSpider(scrapy.Spider):
    name = 'zaahib_parser'
    headers = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
               'accept-encoding': 'gzip, deflate, br',
               'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
               'cache-control': 'max-age=0',
               'if-none-match': 'd47ae0b47368dcc1ef9bb9d7a563dc89',
               'referer': 'https://www.zaahib.com/search/en/list/',
               'upgrade-insecure-requests': '1',
               'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}

    def start_requests(self):

        # credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        # connection = pika.BlockingConnection(pika.ConnectionParameters(
        #     credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        # channel = connection.channel()

        # while True:
        #     try:
        #         channel.basic_qos(prefetch_count=1)
        #         method, properties, url = channel.basic_get(queue=QUEUE_NAME)
        #         if not url.strip():
        #             break
        #         channel.basic_ack(delivery_tag=method.delivery_tag)
        #     except:
        #         try:
        #             connection.close()
        #         except:
        #             pass
        #         connection = pika.BlockingConnection(pika.ConnectionParameters(
        #             credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        #         channel = connection.channel()
        #         channel.basic_qos(prefetch_count=1)
        #         method, properties, url = channel.basic_get(queue=QUEUE_NAME)
        #         if not url.strip():
        #             break
        #         channel.basic_ack(delivery_tag=method.delivery_tag)

        #     if url.strip():
        #         url = str(url, encoding='utf-8')
        rmqh = RmqHandler(QUEUE_NAME, ip=QUEUE_IP,user=QUEUE_USER, pwd=QUEUE_PASS)
        while True:
            count, data = rmqh.get()
            if not data:
                break
            if data:
                url = data
                yield Request(url=url.strip(), callback=self.parse_property, headers=self.headers, errback=lambda x: self.errback_httpbin(x, url.strip()))
        # connection.close()

    def parse_property(self, response):
        data = ''
        phone_numbers = ''
        try:
            data = json.loads(response.body_as_unicode())
        except Exception:
            try:
                data = json.loads(response.body_as_unicode())
            except Exception:
                pass

        if data:
            item = data.get('listing', '')
            if item:
                category = item.get('CategoryEn', '')
                category_ar = item.get('CategoryAr', '')

                if category == 'For Sale':
                    price = item.get('Price', '')
                else:
                    price = item.get('Rent', '')
                id_ = item.get('sid', '')
                bedrooms = item.get('Beds', '')
                bathrooms = item.get('Baths', '')

                furnished = item.get('Furnished', '')
                price_per = item.get('RentAmountPerText', '')
                broker_display_name = ''
                js = """
                e=""" + json.dumps(item) + """
                    function generateDisplayedName(e) {
                        var t = "Anonymous",
                            lang = "en",
                            lang_ucfirst = "En"
                            i = typeof e.agency != "undefined" && e.agency != null,
                            a = typeof e.agency == "undefined" || e.agency == null ? e.user : e.agency,
                            n = typeof e.agency == "undefined" || e.agency == null ? "" : this.generateAgencyDisplayedName(a),
                            r = lang == "ar" ? "En" : "Ar";
                        return e.UseProfileForContacts == 1 ? typeof a != "undefined" && typeof a.IsPrivate != "undefined" && a.IsPrivate != 1 && (i && n != "" ? t = n : typeof a["ProfileName" + lang_ucfirst] != "undefined" && a["ProfileName" + lang_ucfirst] != "" && a["ProfileName" + lang_ucfirst] != null ? t = a["ProfileName" + lang_ucfirst].replace(/\+/g, " ") : typeof a["FirstName" + lang_ucfirst] != "undefined" && a["FirstName" + lang_ucfirst] != "" && a["FirstName" + lang_ucfirst] != null ? (t = a["FirstName" + lang_ucfirst].replace(/\+/g, " "),
                            typeof a["LastName" + lang_ucfirst] && a["LastName" + lang_ucfirst] != "" && a["LastName" + lang_ucfirst] != null && (t = t + " " + a["LastName" + lang_ucfirst].replace(/\+/g, " "))) : typeof a["ProfileName" + r] != "undefined" && a["ProfileName" + r] != "" && a["ProfileName" + r] != null ? t = a["ProfileName" + r].replace(/\+/g, " ") : typeof a["FirstName" + r] != "undefined" && a["FirstName" + r] != "" && a["FirstName" + r] != null ? (t = a["FirstName" + r].replace(/\+/g, " "),
                            typeof a["LastName" + r] && a["LastName" + r] != "" && a["LastName" + r] != null && (t = t + " " + a["LastName" + r].replace(/\+/g, " "))) : typeof a.username != "undefined" && a.username != null && (t = a.username)) : typeof e.FirstName != "undefined" && e.FirstName != "" && e.FirstName != null ? (t = e.FirstName.replace("+", " "),
                            typeof e.LastName != "undefined" && e.LastName != "" && e.LastName != null && (t = t + " " + e.LastName.replace("+", " "))) : typeof a != "undefined" && typeof a.IsPrivate != "undefined" && a.IsPrivate != 1 && (i && n != "" ? t = n : typeof a["ProfileName" + lang_ucfirst] != "undefined" && a["ProfileName" + lang_ucfirst] != "" && a["ProfileName" + lang_ucfirst] != null ? t = a["ProfileName" + lang_ucfirst].replace(/\+/g, " ") : typeof a["FirstName" + lang_ucfirst] != "undefined" && a["FirstName" + lang_ucfirst] != "" && a["FirstName" + lang_ucfirst] != null ? (t = a["FirstName" + lang_ucfirst].replace(/\+/g, " "),
                            typeof a["LastName" + lang_ucfirst] && a["LastName" + lang_ucfirst] != "" && a["LastName" + lang_ucfirst] != null && (t = t + " " + a["LastName" + lang_ucfirst].replace(/\+/g, " "))) : typeof a["ProfileName" + r] != "undefined" && a["ProfileName" + r] != "" && a["ProfileName" + r] != null ? t = a["ProfileName" + r].replace(/\+/g, " ") : typeof a["FirstName" + r] != "undefined" && a["FirstName" + r] != "" && a["FirstName" + r] != null ? (t = a["FirstName" + r].replace(/\+/g, " "),
                            typeof a["LastName" + r] && a["LastName" + r] != "" && a["LastName" + r] != null && (t = t + " " + a["LastName" + r].replace(/\+/g, " "))) : typeof a.username != "undefined" && a.username != null && (t = a.username)),
                        t;
                    };
                    function generateAgencyDisplayedName(e) {
                        var t = "Anonymous",
                        lang = "en"
                            i = "Ar",
                            j = "En";
                        return lang == "en" ? (i = "En", j = "Ar") : (j = "En", i = "Ar"), e.IsPrivate != 1 && (typeof e["AgencyName" + i] != "undefined" && e["AgencyName" + i] != "" && e["AgencyName" + i] != null ? t = e["AgencyName" + i].replace(/\+/g, " ") : typeof e["AgencyName" + j] != "undefined" && e["AgencyName" + j] != "" && e["AgencyName" + j] != null ? t = e["AgencyName" + j].replace(/\+/g, " ") : e.DisplayEmail && typeof e.email != "undefined" && e.email != "" && e.email != null ? t = e.email : e.DisplayMobile && typeof e.MobileNumber != "undefined" && e.MobileNumber != "" && e.MobileNumber != null ? t = e.MobileNumber : e.DisplayPhone && typeof e.PhoneNumber != "undefined" && e.PhoneNumber != "" && e.PhoneNumber != null ? t = e.PhoneNumber : e.DisplayPhone && typeof e.Phone2 != "undefined" && e.Phone2 != "" && e.Phone2 != null ? t = e.Phone2 : e.DisplayPhone && typeof e.Fax != "undefined" && e.Fax != "" && e.Fax != null && (t = e.Fax)),
                        t;
                    };
                    generateDisplayedName(e);
                    """

                broker_display_name = js2py.eval_js(js)

                title = item.get('PropertyTitleEn', '')
                if title:
                    pass
                else:
                    title = item.get('PropertyTitleAr', '')
                if title:
                    pass
                else:
                    type_en = item.get('TypeEn', '')
                    type_ar = item.get('TypeAr', '')
                    if type_en:
                        title = type_en + ' ' + category
                    elif type_ar:
                        title = type_ar + ' ' + category_ar

                building_no = item.get('BuildingNo', '')
                additional_no = item.get('AdditionalNo', '')
                street = item.get('StreetNameEn', '')
                zip_ = item.get('ZipCode', '')
                city = item.get('CityEn', '')
                district = item.get('DistrictEn', '')
                province = item.get('ProvinceEn', '')
                mapaddress = item.get('MapAddressEn', '')
                latitude = item.get('Latitude')
                features = item.get('Features', '')
                features1 = ', '.join(features).strip() if features else ''
                picture = item.get('pictureURLs', '')
                number_of_photos = str(len(picture))
                area = item.get('SquareMeter', '')
                area = str(area)
                published_at = item.get('AddDate')

                t = ''
                if street != 'undefined' and street != '' and street != None and building_no != 'undefined' and building_no != '' and building_no != None:
                    t = t + building_no + ' '
                if street:
                    t = t + street.replace(r'/\+/g', ' ') + ', '
                if zip_ != 'undefined' and zip_ != '' and zip_ != None:
                    t = t + ' ' + zip_ + ', '

                if mapaddress != 'undefined' and mapaddress != '' and mapaddress != None and (mapaddress != 'undefined' or province != 'undefined' and province == 'Property Outside Saudi Arabia') and (province != 'undefined' and province == 'Property Outside Saudi Arabia' or latitude != 'undefined' and latitude != ''):
                    t = t + mapaddress
                else:
                    if district != 'undefined' and district:
                        t = t + district + ', '
                    if city:
                        t = t + city + ', '

                    t = t + province

                location = t if t else ''

                id_ = item.get('sid', '')
                url = 'https://www.zaahib.com/view_listing/en/' + id_

                if furnished == 0:
                    furnished = ''

                if furnished == 1:
                    furnished = "furnished"

                if price == ".00":
                    price = ''

                if price == "0":
                    price = ''
                if category == 'For Sale':
                    price_per = ''

                scraped_ts = (datetime.now()).strftime("%Y-%m-%d")

                phone_numbers = []
                phone1 = item.get('user', '').get('MobileNumber')
                phone2 = item.get('agency', '').get('MobileNumber')
                phone3 = item.get('MobileNumber')
                phone4 = item.get('PhoneNumber')
                phone5 = item.get('agency', '').get('PhoneNumber')
                phone6 = item.get('user', '').get('PhoneNumber')
                phone_numbers = [phone1, phone2,
                                 phone3, phone4, phone5, phone6]
                phone_numbers = [
                    x for x in phone_numbers if x] if phone_numbers else ''
                phone_numbers = [x.strip()
                                 for x in phone_numbers] if phone_numbers else ''
                phone_numbers = list(set([x.strip()
                                          for x in phone_numbers if phone_numbers])) if phone_numbers else ''
                phone_numbers = ', '.join(
                    phone_numbers).strip() if phone_numbers else ''

                now = datetime.now()
                current = datetime(now.year, now.month, 1)
                next_month = datetime(
                    now.year + int(now.month / 12), ((now.month % 12) + 1), 1)
                now_date_int = int(now.strftime("%d"))
                if now_date_int <= 31 and now_date_int >= 25:
                    iteration_month = next_month.strftime("%m")
                    iteration_year = next_month.strftime("%Y")
                else:
                    iteration_month = now.strftime("%m")
                    iteration_year = now.strftime("%Y")
                iteration_number = iteration_year + '_' + iteration_month

                items = ZaahibItem(
                    reference_number='',
                    id=id_,
                    url=url,
                    broker_display_name=broker_display_name,
                    broker=broker_display_name.upper(),
                    category=category,
                    category_url='',
                    title=title,
                    description='',
                    location=location,
                    price=price,
                    currency='SAR',
                    price_per=price_per,
                    bedrooms=bedrooms,
                    bathrooms=bathrooms,
                    furnished=furnished,
                    rera_permit_number='',
                    dtcm_licence='',
                    scraped_ts=scraped_ts,
                    amenities=features1,
                    details=area,
                    agent_name='',
                    number_of_photos=number_of_photos,
                    user_id='',
                    phone_number=phone_numbers,
                    date=scraped_ts,
                    iteration_number=iteration_number,
                    published_at=published_at,

                )
                if title:
                    yield items

            else:
                try:
                    item = ZaahibUrlItem(
                        url=response.url,
                    )
                    db[MONGODB_COLLECTION_DATA].insert(dict(item))
                except Exception:
                    raise DropItem("Dropping ajax item")

    # Errorback to put failed urls back in queue
    def errback_httpbin(self, failure, url):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=600))
        channel = connection.channel()
        channel.queue_declare(queue=QUEUE_NAME, durable=True)
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=url)
        connection.close()
