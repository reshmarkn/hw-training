import scrapy
import re
import pika
import json
import logging
import requests
import io
import ast

from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime
from scrapy.shell import inspect_response

from zaahib.items import *
from zaahib.settings import *
from zaahib.storm_proxy import parse_proxy

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


class ZaahibSpider(scrapy.Spider):
    name = 'zaahib_ajax_Crawler_updated'
    start_urls = ['https://www.zaahib.com/']

    def parse(self, response):
        sort_field = ['activation_date', 'Price']
        sort_order = ['ASC', 'DESC']
        property_types = []

        property_type_ = requests.get(
            'https://zstatic.zahip.com/Scripts/zaahib_js/zaahib.home.636675219405095454.js')
        property_type_ = str(property_type_.content, encoding='utf-8')
        property_type_list = re.findall(
            r'PropertyTypeList\s?=\s?(\[\s?\{.*?\}\s?\])', ' '.join(property_type_.split()))
        property_type_list = property_type_list[
            0].strip() if property_type_list else ''
        property_type_list = re.sub(
            r"([^,^\{^\s]*?):", r'"\1":', property_type_list)

        try:
            property_types = json.loads(property_type_list)
        except Exception:
            try:
                property_types = json.loads(property_type_list)
            except Exception:
                pass
        property_type_list_data = {}
        for propt_ in property_types:
            key = propt_.get('nameEn', '')
            value = propt_.get('id', '')
            key = '-'.join(key.lower().split()) if key else ''
            value = str(value) if value else ''
            if key and value:
                property_type_list_data.update({key: value})
        listing_category = ['153', '154']

        for p_type in property_type_list_data.values():
            for l_cat in listing_category:
                for so in sort_field:
                    for order in sort_order:
                        # ajax_url = 'https://apiv2.zaahib.com/ajax/modules/classifieds/search_listings.php?sf=yes&sorting_field='+so+'&sorting_order='+order+'&ListingCategory%5Bin%5D='+l_cat + \
                        #     '&PropertyType%5Bin%5D='+p_type + \
                        #     '&PropertyFinalizing%5Bin%5D=&AgencyLanguages%5Bin%5D=&AgencyServices%5Bin%5D=&page=1&version=5.2.0&buildtype=application&lang=ar&country=sa'

                        ajax_url = 'https://apiv2.zaahib.com/ajax/modules/classifieds/search_listings.php?sf=yes&ListingCategory%5Bin%5D='+l_cat + \
                            '&PropertyType%5Bin%5D='+p_type + \
                            '&PropertyFinalizing%5Bin%5D=&AgencyLanguages%5Bin%5D=&AgencyServices%5Bin%5D=&page=1&version=5.2.0&buildtype=application&lang=ar&country=sa'

                        items = ZaahibAjaxUrlItem(
                            url=ajax_url.strip(),
                        )
                        if ajax_url:
                            yield items
