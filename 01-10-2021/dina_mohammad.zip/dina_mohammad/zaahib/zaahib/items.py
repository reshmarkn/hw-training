# -*- coding: utf-8 -*-
import scrapy


class ZaahibUrlItem(scrapy.Item):
    url = scrapy.Field()


class ZaahibAjaxUrlItem(scrapy.Item):
    url = scrapy.Field()

class ZaahibItem(scrapy.Item):

    reference_number = scrapy.Field()
    id = scrapy.Field()
    url = scrapy.Field()
    broker_display_name = scrapy.Field()
    broker = scrapy.Field()
    category = scrapy.Field()
    category_url = scrapy.Field()
    title = scrapy.Field()
    description = scrapy.Field()
    location = scrapy.Field()
    price = scrapy.Field()
    currency = scrapy.Field()
    price_per = scrapy.Field()
    bedrooms = scrapy.Field()
    bathrooms = scrapy.Field()
    furnished = scrapy.Field()
    rera_permit_number = scrapy.Field()
    dtcm_licence = scrapy.Field()
    scraped_ts = scrapy.Field()
    amenities = scrapy.Field()
    details = scrapy.Field()
    agent_name = scrapy.Field()
    number_of_photos = scrapy.Field()
    user_id = scrapy.Field()
    phone_number = scrapy.Field()
    latitude = scrapy.Field()
    longitude = scrapy.Field()
    listing_type = scrapy.Field()
    price_per_area = scrapy.Field()
    near_by_facilities = scrapy.Field()
    floor_area = scrapy.Field()
    posted_date = scrapy.Field()
    age_of_building = scrapy.Field()
    date = scrapy.Field()
    iteration_number = scrapy.Field()
    published_at = scrapy.Field()
