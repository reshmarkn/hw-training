{
ad_reference_number :
    {
        'type': str,
    },
property_id :
    {
        'type': str,
    },
url:
    {
        'type': str,
    },
listing_type :
    {
        'type': str,
    },
category :
    {
        'type': str,
    },
category_url :
    {
        'type': str,
    },
title :
    {
        'type': str,
    },
description :
    {
        'type': str,
    },
location:
    {
        'type': dict,
        'fields':
            {
                address :
                    {
                        'type': str,
                    },
                latitude :
                    {
                        'type': str,
                    },
                longitude :
                    {
                        'type': str,
                    },
            },
    }
price :
    {
        'type': dict,
        'fields':
            {
                ammount:
                        {
                            'type': float,
                        },
            price_per_tenure:
                {
                    'type': float,
                },
            price_per_area :
                {
                    'type': float,
                },
            currency :
                {
                    'type': str,
                },
            },
    },

bedrooms :
    {
        'type': str,
    },
bathrooms :
    {
        'type': str,
    },
furnished:
    {
        'type': str,
    },
flooring:
    {
        'type': str,
    },
roofing:
    {
        'type': str,
    },
built_type:
    {
        'type': str,
    },
number_of_floors:
    {
        'type': int,
    },
age_of_building:
    {
        'type': str,
    },
amenities :
    {
        'type': list,
    },
near_by_facilities/neighborhood:
    {
        'type': list,
    },
floor_area:
    {
        'type': str,
    },
total_sq:
    {
        'type': str,
    },
photos :
    {
        'type': list,
    },
property_registration_number:
    {
        'type': str,
    },
property_licence_number:
    {
        'type': str,
    },
broker:
    {

        'type': dict,
        'fields':
            {
                broker_name:  
                {
                    'type': str,
                },
                broker_registration_number:
                {
                    'type': str,
                },
            },
    },
agent:
    {
        'type': dict,
        'fields':
            {

                agent_name:
                    {
                        'type': str,
                    },
                user_id :
                    {
                        'type': str,
                    },
                agent_registration_number:
                    {
                        'type': str,
                    },
            },
    },
money_transaction_type:
    {
        'type': str,
    },
type_of_Ownership:
    {
        'type': str,
    },
phone_number:
    {
        'type': str,
    },
email:
    {
        'type': str,
    },
fax:
    {
        'type': str,
    },
ad_posted_date
    {
        'type': str,
    }
}