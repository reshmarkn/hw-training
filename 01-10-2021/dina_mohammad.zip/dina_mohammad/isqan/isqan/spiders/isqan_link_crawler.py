# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
import random
from pymongo import MongoClient
import pymongo
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime
from time import sleep

from isqan.items import *
from isqan.settings import *
headers = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
           'accept-encoding': 'gzip, deflate',
           'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
           'upgrade-insecure-requests': '1',
           'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Mobile Safari/537.36'
           }

class IsqanCrawlerSpider(Spider):
    name = 'isqan_crawler'

    def start_requests(self):
        # urls = [https://www.isqan.com/en/properties/commercial-buy/properties-for-sale-in-egypt
                # https://www.isqan.com/en/properties/commercial-rent/properties-for-rent-in-egypt
                # https://www.isqan.com/en/properties/buy/properties-for-sale-in-egypt
                # https://www.isqan.com/en/properties/rent/properties-for-rent-in-egypt]
        urls = ['https://www.isqan.com/api/properties/published?availability=sale&page=1&pageSize=25',
                'https://www.isqan.com/api/properties/published?availability=rent&page=1&pageSize=25']
        # urls = ["https://www.isqan.com/api/properties/published?page=1&pageSize=25&category=commercial&availability=sale",
        #         "https://www.isqan.com/api/properties/published?page=1&pageSize=25&category=commercial&availability=rent",
        #         "https://www.isqan.com/api/properties/published?page=1&pageSize=25&category=residential&availability=sale",
        #         "https://www.isqan.com/api/properties/published?page=1&pageSize=25&category=residential&availability=rent"]
        for url in urls:
            yield Request(url, headers=headers, callback=self.parse_link, meta={'page': 1,'url':url})

    def parse_link(self, response):
        page = response.meta.get('page')
        url = response.meta.get('url')
        data = json.loads(response.text)
        name_link = data.get('data').get('properties').get('results')
        # name_link = response.xpath('//div[@class="row no-gutters h-100"]/a[@class="stretched-link"]/@href').extract()
        for n_links in name_link:
            depth = n_links.get('package').get('name')
            p_id = n_links.get('id')
            published_at = n_links.get('createdAt','').split('T')[0]
            property_type = n_links.get('type')
            category = n_links.get('category')
            if 'residential' in category:
                sub_category_1 = 'Residential'
            else:
                sub_category_1 = 'Commercial'
            product_url = 'https://www.isqan.com/en/properties/'+str(p_id)
            item = IsqanUrlItem()
            item['sub_category_1'] = sub_category_1
            item['sub_category_2'] = ''
            item['depth'] = depth
            item['published_at'] = published_at
            item['property_type'] = property_type
            item['url'] = product_url
            logging.warning(item)
            yield item
        link = response.url
        if name_link:
            page = page + 1
            next_url = str(link.rsplit('&page=', 1)[
                           0]) + '&page=' + str(page) + '&pageSize=25'
            meta = {'page': page, 'url': next_url}
            yield Request(next_url, headers=headers, meta=meta, callback=self.parse_link)
