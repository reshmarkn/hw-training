# -*- coding: utf-8 -*-
import scrapy
import string
import io
import gzip
import logging
import re
import pika
import json
import requests
from time import sleep
from scrapy.http import Request, FormRequest
from xml.dom import minidom
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime
from isqan.settings import *
from isqan.items import *
from rmq import RmqHandler

logger = logging.getLogger('pika')
logger.propagate = False
h = {"accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
     "accept-encoding": "gzip, deflate, br",
     "accept-language": "en-GB,en-US;q=0.9,en;q=0.8,ml;q=0.7",
     "cache-control": "max-age=0",
     "upgrade-insecure-requests": "1",
     "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36"
    }


class IsqanParserSpider(scrapy.Spider):
    name = 'isqan_img_parser'

    def start_requests(self):
        rmqh = RmqHandler(QUEUE_NAME, ip=QUEUE_HOST,
                          user=QUEUE_USER, pwd=QUEUE_PASS)
        while True:
            count, data = rmqh.get()
            if not data:
                break
            url = str(data.strip())
            if url:
                yield Request(url, callback=self.parse_data)
    def parse_data(self, response):
        url = response.url
        # url_id = url.split('-')[-1]
        # user_id = ''
        # ament_str = ''
        # amenities = response.xpath(
        #     '//ul[@class="amenities list-unstyled mb-0"]/li/p/text()').extract()
        # title = response.xpath(
        #     '//h1[@class="text-truncate mb-0"]//text() | //h1[@class="mb-0 h-title"]/text()').extract_first()
        # category = response.xpath(
        #     '//ol[@class="breadcrumb px-0"]/li/a/text()').extract()
        # category_url = response.xpath(
        #     '//ol[@class="breadcrumb px-0"]/li/a/@href').extract()
        # desc = response.xpath(
        #     '//p[@class="description"]/text()').extract()
        # description = [x.replace('\n', '')
        #                for x in desc if x.strip()] if desc else ''
        # description = ','.join(description).strip()
        # reference_number = response.xpath('//h4[@class="h5"]/text()').extract()
        # reference_number = reference_number[0].replace(
        #     'Reference Number: ', '') if reference_number else ''
        # category = category[0] if category else ''
        # category_url = category_url[0] if category_url else ''
        # if 'for-sale' in url:
        #     category_name = 'sale'
        #     category_link = '/en/properties?availability=sale'
        # elif 'for-rent' in url:
        #     category_name = 'rent'
        #     category_link = '/en/properties?availability=rent'
        # else:
        #     category_name = ''
        #     category_link = ''

        # amenities = [x.strip() for x in amenities] if amenities else ''
        # amenities = [x.strip()
        #              for x in amenities if x] if amenities else ''
        # amenities = ' , '.join(amenities).strip() if amenities else ''

        # id_url = response.xpath('//link[@rel="shortlink"]/@href').extract()
        # location = response.xpath(
        #     '//section[@id="location"]/p/text()').extract_first('')
        # price_xpath = response.xpath(
        #     '//h2[@class="h1 text-secondary mb-0"]/text() | //h2[@class="h1 text-secondary mb-0 h-price"]/text()').extract_first('').strip()
        # price_per_xpath = price_xpath.split()
        # if 'Month' in price_per_xpath:
        #     price_per = 'per month'
        # elif 'Day' in price_per_xpath:
        #     price_per = 'per day'
        # else:
        #     price_per = ''
        # price = price_xpath.replace('EGP ', '').replace(' / Month', '')
        # currency = 'EGP'
        # res = response.text
        # long_ = re.findall('lng&q;:.*?,', res)
        # longitude = long_[0].replace(
        #     'lng&q;:', '').replace(',', '') if long_ else ''
        # lat_ = re.findall('lat&q;:.*?,', res)
        # latitude = lat_[0].replace('lat&q;:', '').replace(
        #     '},', '') if lat_ else ''
        # furnished = response.xpath(
        #     '//fa-icon[@icon="couch"]/following-sibling::p/text()').extract_first('').strip()
        # bedrooms_text = response.xpath(
        #     '//fa-icon[@icon="bed"]/following-sibling::p/text()').extract_first('').strip()
        # bedrooms_text = bedrooms_text.replace(
        #     ' Rooms', '') if bedrooms_text else ''
        # bathrooms_text = response.xpath(
        #     '//fa-icon[@icon="toilet"]/following-sibling::p/text()').extract_first('').strip()
        # bathrooms_text = bathrooms_text.replace(' Bathrooms', '')
        # broker = response.xpath(
        #     '//div[@class="col-8"]//h2/text() | //h2[@class="h3 mb-0"]/text()').extract_first('').strip()
        # area = response.xpath(
        #     '//fa-icon[@icon="ruler-combined"]/following-sibling::p/text()').extract_first('').strip()
        img = response.xpath(
            '//app-mosaic-gallery//img').extract()
        number_of_photos = str(len(img))
        # now = datetime.now()
        # current = datetime(now.year, now.month, 1)
        # next_month = datetime(now.year + int(now.month / 12), ((now.month % 12) + 1), 1)
        # now_date_int = int(now.strftime("%d"))
        # if now_date_int <=31 and now_date_int >=25:
        #     iteration_month = next_month.strftime("%m")
        #     iteration_year = next_month.strftime("%Y")
        # else:
        #     iteration_month = now.strftime("%m")
        #     iteration_year = now.strftime("%Y")
        # iteration_number = iteration_year + '_'+ iteration_month        
        # agent_name = response.xpath(
        #     '//div[@class="row align-items-center mb-4"]//div[@class="col-8"]//h1/text() | //h1[@class="h3 mb-0"]/text()').extract_first('').strip()
        # url2 = 'https://www.isqan.com/api/properties/' + \
        #     str(url_id)+'/contact?type=calls&hasClickedProperty=true'
        # response = requests.get(url2)
        # data = json.loads(response.text)
        # phone_number = data.get('data')
        # scraped_ts = (datetime.now()).strftime("%Y-%m-%d")


        item = IsqanImgItem()
        # item["id"]= url_id
        item["url"]= url
        # item["broker_display_name"]= broker
        # item["broker"]= broker.upper()
        # item["category"]= category_name
        # item["category_url"]= category_link
        # item["title"]= title
        # item["property_type"]=''
        # item["sub_category_1"]=''
        # item["sub_category_2"]=''
        # item["depth"]=''
        # item["description"]= description
        # item["location"]= location
        # item["price"]= price
        # item["currency"]= currency
        # item["price_per"]= price_per
        # item["bedrooms"]= bedrooms_text
        # item["bathrooms"]= bathrooms_text
        # item["furnished"]= furnished
        # item["rera_permit_number"]= ''
        # item["dtcm_licence"]= ''
        # item["scraped_ts"]=scraped_ts
        # item["amenities"]= amenities
        # item["details"]= area
        # item["agent_name"]= agent_name
        item["number_of_photos"]= number_of_photos
        # item["reference_number"]= reference_number
        # item["user_id"]= user_id
        # item["phone_number"] = phone_number
        # item["date"] = scraped_ts
        # item["iteration_number"]= iteration_number
        # item["latitude"]= latitude
        # item["longitude"]= longitude
        yield item
