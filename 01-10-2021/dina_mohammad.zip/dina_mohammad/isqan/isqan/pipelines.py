# -*- coding: utf-8 -*-

from pymongo import MongoClient
from datetime import datetime
from scrapy.exceptions import DropItem
from isqan.items import *

now = datetime.now()
current = datetime(now.year, now.month, 1)
next_month = datetime(now.year + int(now.month / 12), ((now.month % 12) + 1), 1)
now_date_int = int(now.strftime("%d"))
if now_date_int <= 31 and now_date_int >= 25:
    iteration_month = next_month.strftime("%m")
    iteration_year = next_month.strftime("%Y")
else:
    iteration_month = now.strftime("%m")
    iteration_year = now.strftime("%Y")
iteration_number = iteration_year + '_' + iteration_month


MONGODB_DB = 'dina_mohammad_monthly_' + iteration_number
MONGODB_COLLECTION_AGENT = 'isqan_egp_' + iteration_number
MONGODB_COLLECTION_AGENT_IMG = 'isqan_egp_img_' + iteration_number
MONGODB_COLLECTION_AGENT_URL = 'isqan_egp_url_' + iteration_number


class IsqanPipeline(object):

    def __init__(self, *args, **kwargs):

        self.client = MongoClient(
            'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
        # self.client = MongoClient('mongodb://localhost:27017')
        try:
            self.client.admin.command("enablesharding", MONGODB_DB)
            self.client.admin.command("shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION_AGENT_URL,
                                      key={'url': 1}, unique=True)
        except Exception:
            pass
        try:
            self.client.admin.command(
                "shardcollection", MONGODB_DB + "." + MONGODB_COLLECTION_AGENT_URL, key={'url': 1}, unique=True)
        except Exception:
            pass
        try:
            self.client.admin.command(
                "shardcollection", MONGODB_DB + "." + MONGODB_COLLECTION_AGENT, key={'url': 1}, unique=True)
        except Exception:
            pass
        try:
            self.client.admin.command(
                "shardcollection", MONGODB_DB + "." + MONGODB_COLLECTION_AGENT_IMG, key={'url': 1}, unique=True)
        except Exception:
            pass

        self.db = self.client[MONGODB_DB]
    @classmethod
    def from_crawler(cls, crawler):
        return cls(
            settings=crawler.settings
        )
    def close_spider(self, spider):
        self.client.close()

    def process_item(self, item, spider):
        if isinstance(item, IsqanItem):
            try:
                self.db[MONGODB_COLLECTION_AGENT].insert(dict(item))
            except Exception:
                raise DropItem("Dropping duplicate item")
        if isinstance(item, IsqanUrlItem):
            try:
                self.db[MONGODB_COLLECTION_AGENT_URL].insert(dict(item))
            except Exception:
                raise DropItem("Dropping duplicate item")

        if isinstance(item, IsqanImgItem):
            try:
                self.db[MONGODB_COLLECTION_AGENT_IMG].insert(dict(item))
            except Exception:
                raise DropItem("Dropping duplicate item")

        return item
