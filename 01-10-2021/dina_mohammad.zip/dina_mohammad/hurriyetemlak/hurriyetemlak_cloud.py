import requests
import json
import random
import logging
import pika
from datetime import datetime
from pymongo import MongoClient
import lxml
import lxml.html
import cloudscraper
import re


MONGODB_DB = 'dina_mohammad'
MONGODB_COLLECTION_AGENT = 'hurriyetemlak_tur_2020_06_26'
MONGODB_COLLECTION_AGENT_FAIL = 'hurriyetemlak_tur_fail_2020_06_26'
client = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')
try:
    client.admin.command(
        "shardcollection", MONGODB_DB + "." + MONGODB_COLLECTION_AGENT, key={'url': 1}, unique=True)

except Exception:
    pass
db = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')[MONGODB_DB]
PROXY_LIST = requests.get('http://68.183.58.145/stormproxies',
                          headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
QUEUE_NAME = 'ha.hurriyetemlak'
QUEUE_IP = '159.89.47.171'
QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'


def parse_requests(url, j):
    while True:
        final_response = ''
        if j <= 3:
            try:
                j = j+1
                pr = random.choice(PROXY_LIST)
                proxy = 'https://' + pr
                proxies = {'https': proxy, 'http': proxy}
                logging.warning("Proxy Changed to %s" % proxy)
                scraper = cloudscraper.create_scraper(
                    browser={
                        'custom': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'}

                )
                final_response = scraper.get(url)
                if final_response and final_response.status_code == 200:
                    msg = 'status:'+url+':'+str(final_response.status_code)
                    logging.warning(msg)

                    break

                elif final_response.status_code == 404:
                    msg = 'status: '+url+': '+str(final_response.status_code)
                    logging.warning(msg)
                    final_response = ''
                    not_found = {'url': url}
                    db.hurriyetemlak_tur_2020_05_not_found.insert(
                        dict(not_found))
                    break
                else:
                    msg = 'status: '+url+': '+str(final_response.status_code)
                    logging.warning(msg)
                    final_response = ''
                    not_found = {'url': url}
                    db.hurriyetemlak_tur_2020_05_09_not_found.insert(
                        dict(not_found))
                    break

            except:
                pass
        else:
            msg = 'failed: '+url
            logging.warning(msg)
            final_response_c = str(
                final_response.content) if final_response else '3 try no response'
            data = {'url': str(url), 'status': "three tries failed",
                    'redirect_url': str(url), 'response': final_response_c}
            db[MONGODB_COLLECTION_AGENT_FAIL].insert(dict(data))
            break
    if final_response:
        cat = ''
        category = ''
        category_url = ''
        bedrooms = ''
        bathrooms = ''
        details = ''
        agent_name = ''
        details1 = ''
        details2 = ''
        id_ = ''
        location = ''
        price = ''
        currency = ''
        number_of_photos = ''
        phone_number = ''
        neighborhood = ''
        city = ''
        map_data = ''
        location_data = ''
        latitude = ''
        longitude = ''

        tree = lxml.html.fromstring(final_response.content.decode('utf-8'))

        name = tree.xpath('//h1[@class="fontRB"]/text()')
        name = name[0].strip() if name else ''
        ID_XPATH = '//span[@class="redy"]/text()'
        NAME_XPATH = '//h1[@class="fontRB"]/text()'
        BREADCRUM_XPATH = '//div[@class="bradcrumb"]'
        BREADCRUMLIST_XPATH = 'div/a//text()'
        CATEGORY_URL_XPATH = 'div/a/@href'
        DESCRIPTION_XPATH = '//div[@class="inner-html"]//text()'
        DETAILS_DATA = '//ul[@class="adv-info-list"]'
        AREA_XPATH = 'li[contains(span/text(),"Metrekare")]//text()'
        BATHROOM_XAPTH = '//span[contains(text(), "Banyo Say")]/following-sibling::span[1]/text()'
        BEDROOM_XPATH = 'li[contains(span/text(),"Oda + Salon")]//text()'
        AMENITIES_XPATH = '//section[@class="properties detail"]//text()'
        AREA_XPATH1 = 'li/div/span//text()'
        AD_INFORMATION_XPATH = '//div[@class="det-adv-info"]/ul[@class="adv-info-list"]/li'
        KEY_XPATH = 'span[1]/text()'
        VALUE_XPATH = 'span[2]/text() | div/span/text()'
        PHONE_NUMBERS = '//div[@class="owner-phone-numbers-list-wrapper"]/ul[@class="owner-phone-numbers-list"]//li/a/text()'

        id_ = ''.join(tree.xpath(ID_XPATH))
        broker_display_name = ''.join(tree.xpath(NAME_XPATH))
        breadcrum = tree.xpath(BREADCRUM_XPATH)
        title = ''.join(tree.xpath(NAME_XPATH))
        description = ''.join(tree.xpath(DESCRIPTION_XPATH)).replace('\n', '')
        details_data = tree.xpath(DETAILS_DATA)
        amenities = tree.xpath(AMENITIES_XPATH)

        id_ = id_.strip() if id_ else ''
        reference_number = id_.strip() if id_ else ''
        broker_display_name = broker_display_name.strip() if broker_display_name else ''
        broker = broker_display_name.upper() if broker_display_name else ''
        broker = broker.strip() if broker else ''
        title = title.strip() if title else ''
        description = description.strip() if description else ''
        amenities = [x.strip() for x in [x.strip()
                                         for x in amenities] if x] if amenities else ''
        amenities = ' '.join(amenities).strip() if amenities else ''

        for i in details_data:
            if AREA_XPATH:
                details = i.xpath(AREA_XPATH)
                details1 = details[-1] if details else ''
                details = details1 if details1 else ''

            if AREA_XPATH1:
                details = i.xpath(AREA_XPATH1)
                details2 = details[0] if details else ''
                details = details2 if details2 else ''

            bathrooms = i.xpath(BATHROOM_XAPTH)
            bathrooms = bathrooms[-1].strip() if bathrooms else ''
            bedrooms = i.xpath(BEDROOM_XPATH)
            bedrooms = bedrooms[-1].strip() if bedrooms else ''
            bedrooms = bedrooms[0].split('+')[0].strip() if bedrooms else ''

        for b in breadcrum:
            breadcrumlist_ = b.xpath(BREADCRUMLIST_XPATH)
            breadcrumlist_ = [x.strip()
                              for x in breadcrumlist_] if breadcrumlist_ else []
            cat = ' > '.join(breadcrumlist_) if breadcrumlist_ else ''
            category = cat.strip().replace('\n', ' ').strip() if cat else ''
            c_url = b.xpath(CATEGORY_URL_XPATH)
            category_url = c_url[0] if c_url else ''

        Ad_Information = tree.xpath(AD_INFORMATION_XPATH)
        ad_information = []
        for data in Ad_Information:
            key = data.xpath(KEY_XPATH)
            key = ''.join(key).strip().replace('\n', '')
            value = data.xpath(VALUE_XPATH)
            value = ''.join(value).strip().replace('\n', '')
            ad_information.append({key: value})
        phone_numbers = tree.xpath(PHONE_NUMBERS)
        phone_numbers = [x.replace('\n', '')
                         for x in phone_numbers if x.strip()]
        phone_number = ', '.join(phone_numbers)

        script = tree.xpath(
            '//script[contains(text(),"mainEntity")]/text()')

        if script:

            js = json.loads(script[0].strip()) if script else ''

            price = js.get('mainEntity').get(
                'offers').get('price') if js else ''
            price = price if price else ''

            currency = js.get('mainEntity').get(
                'offers').get('priceCurrency') if js else ''
            currency = currency if currency else ''

            agent_name = js.get('mainEntity').get('offers')

            if 'seller' in agent_name:
                agent_name = js.get('mainEntity').get(
                    'offers').get('seller').get('name') if js else ''
            else:
                agent_name = ''

            locality = js.get('mainEntity').get(
                'offers').get('itemOffered')
            locality = locality if locality else ''
            if type(locality) == list:
                locality = js.get('mainEntity').get('offers').get(
                    'itemOffered')[0].get('address').get('addressLocality')
            if type(locality) == dict:
                locality = js.get('mainEntity').get('offers').get(
                    'itemOffered').get('address').get('addressLocality')
                locality_data = locality.split(',')
                neighborhood = locality_data[0]
                city = locality_data[1]
            street = js.get('mainEntity').get('offers').get('itemOffered')
            street = street if street else ''
            if type(street) == dict:
                street = js.get('mainEntity').get('offers').get(
                    'itemOffered').get('address').get('streetAddress')
            if type(street) == list:
                street = js.get('mainEntity').get('offers').get(
                    'itemOffered')[0].get('address').get('streetAddress')

            image = js.get('mainEntity').get('offers').get('image')
            number_of_photos = len(image) if image else ''

            locality = locality if locality else ''
            street = street if street else ''
            if street or locality:
                location = street + ', ' + locality
                location = location.strip().strip(',').strip()
            else:
                location = ''
        else:
            script = ''

        price_per = ''
        furnished = ''
        rera_permit_number = ''
        dtcm_licence = ''

        scraped_ts = (datetime.now()).strftime("%Y-%m-%d")
        date = scraped_ts

        user_id = re.findall(
            'firmUser:{id:(.*?),', str(final_response.content))
        user_id = user_id[0] if user_id else ''

        iteration_number = '2020_08'

        lat_url = 'https://www.hurriyetemlak.com/api/realties/bulk-without-passive?listingIds=' + \
            str(id_)
        api_response = scraper.get(lat_url)
        if api_response and api_response.status_code == 200:
            data = json.loads(api_response.text)
            map_data = data.get('content')[0] if data else ''
            location_data = map_data.get('mapLocation') if map_data else ''
            latitude = location_data.get('lat') if location_data else ''
            longitude = location_data.get('lon') if location_data else ''

        reference_number = id_
        id_ = id_
        url = url = url.strip()
        broker_display_name = broker_display_name
        broker = broker
        category = category if category else ''
        category_url = category_url
        title = title
        description = description
        location = location
        price = price
        currency = currency
        neighborhood = neighborhood
        city = city
        ad_information = ad_information
        price_per = price_per
        bedrooms = bedrooms
        bathrooms = bathrooms
        furnished = furnished
        rera_permit_number = rera_permit_number
        dtcm_licence = dtcm_licence
        scraped_ts = scraped_ts
        amenities = amenities
        details = details
        agent_name = agent_name
        number_of_photos = number_of_photos
        user_id = user_id
        phone_number = phone_number
        date = date
        iteration_number = iteration_number
        latitude = latitude
        longitude = longitude

        data = {'reference_number': reference_number, 'id': id_, 'url': str(url), 'broker_display_name': broker_display_name, 'broker': broker, 'category': category, 'category_url': category_url, 'title': title, 'description': description, 'location': location, 'price': price, 'currency': currency, 'price_per': price_per, 'bedrooms': bedrooms, 'bathrooms': bathrooms,
                'furnished': furnished, 'city': city, 'neighborhood': neighborhood, 'rera_permit_number': rera_permit_number, 'dtcm_licence': '', 'amenities': amenities, 'details': details, 'agent_name': agent_name, 'number_of_photos': number_of_photos, 'user_id': user_id, 'phone_number': phone_number, 'iteration_number': iteration_number, 'scraped_ts': scraped_ts, 'date': date, 'ad_information': ad_information, 'latitude': latitude, 'longitude': longitude}

        print(data)

        if name:
            msg = 'success:  '+name
            try:
                db[MONGODB_COLLECTION_AGENT].insert(dict(data))
                logging.warning(msg)

            except:
                logging.warning("dupicate")
                pass

        else:
            msg = 'failed'
            logging.warning(msg)
            data = {'url': str(url), 'status': 'failed', 'status_response': str(
                final_response.status_code), 'response': str(final_response.content), 'redirect_url': final_response.url}
            db[MONGODB_COLLECTION_AGENT_FAIL].insert(dict(data))
    else:
        msg = 'failed'
        logging.warning(msg)
        data = {'url': str(url), 'status': "no response",
                'redirect_url': str(url)}
        db[MONGODB_COLLECTION_AGENT_FAIL].insert(dict(data))


if __name__ == '__main__':

    credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
    while True:
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        channel = connection.channel()
        channel.basic_qos(prefetch_count=1)
        method, properties, url = channel.basic_get(queue=QUEUE_NAME)
        if not url.strip():
            break
        url = str(url.strip(), encoding='utf-8')
        channel.basic_ack(delivery_tag=method.delivery_tag)
        if url.strip():
            url = url.strip()
            j = 0
            parse_requests(url, j)
    connection.close()

(url, j)
