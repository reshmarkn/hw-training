import requests
import json
import random
import logging
import pika
from datetime import datetime
from pymongo import MongoClient
import lxml
import lxml.html
import cloudscraper

MONGODB_DB = 'dina_mohammad'
MONGODB_COLLECTION_AGENT = 'hurriyetemlak_url_2020_06_26'
MONGODB_COLLECTION_AGENT_FAIL = 'hurriyetemlak_url_fail_2020_06_26'

db = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')[MONGODB_DB]

try:
    db[MONGODB_COLLECTION_AGENT].create_index('item_url', unique=True)
except:
    pass
try:
    db[MONGODB_COLLECTION_AGENT_FAIL].create_index('missing_url', unique=True)
except:
    pass

QUEUE_NAME = 'ha.hurriyetemlak_district_urls'
QUEUE_IP = '159.89.47.171'
QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'

headers = {
    "accept-encoding": "gzip, deflate, br",
    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
    "sec-fetch-dest": "document",
    "sec-fetch-mode": "navigate",
    "sec-fetch-site": "none",
    "sec-fetch-user": "?1",
    "upgrade-insecure-requests": "1",
    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.92 Safari/537.36"
}

count = 0


class hurriyetemlak:

    def __init__(self):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        channel = connection.channel()
        while True:
            url = ''
            try:
                channel.basic_qos(prefetch_count=1)
                method, properties, url = channel.basic_get(queue=QUEUE_NAME)
                if not url:
                    break
            except:
                connection = pika.BlockingConnection(pika.ConnectionParameters(
                    credentials=credentials, host=QUEUE_IP, socket_timeout=300))
                channel = connection.channel()
                channel.basic_qos(prefetch_count=1)
                method, properties, url = channel.basic_get(queue=QUEUE_NAME)
                if not url:
                    break
            channel.basic_ack(delivery_tag=method.delivery_tag)
            url = str(url.strip(), encoding='utf-8')
            main_url = url + '?page=1'
            self.page = 1
            self.number_of_pages = 1
            self.next_page_check = False
            print(main_url)
            self.parse_requests(main_url)

    def parse_requests(self, url):
        global count

        response = ''
        while True:
            try:
                logging.warning(url+"\nRequesting...")
                scraper = cloudscraper.create_scraper(
                    browser={
                        'custom': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'}


                )
                response = scraper.get(url, headers=headers)  # verify=False)

                if response.status_code == 200:
                    logging.warning("Got a response..")
                    break
                else:
                    response = ''
            except:
                response = ''
                pass
        if response:
            tree = lxml.html.fromstring(response.content)
            data = tree.xpath('//script[@type="application/ld+json"]/text()')
            not_found = tree.xpath('//div[@class="result-not-found"]')
            if self.page == 1:
                number_of_pages_el = tree.xpath(
                    '//section[contains(@class,"pagination")]//li[contains(@class,"page-item")][last()]//text()')
                if number_of_pages_el:
                    self.next_page_check = True
                    self.number_of_pages = int(number_of_pages_el[0])
            if data:
                try:
                    json_data = json.loads(data[0])
                except:
                    json_data = ''
                if json_data:
                    items = json_data['mainEntity']['offers']['itemOffered']
                    if items:
                        for item in items:
                            count = count+1
                            item_url = item['url'].replace(
                                "https://www.hurriyetemlak.com/https://www.hurriyetemlak.com", "https://www.hurriyetemlak.com")
                            data = {}
                            data['item_url'] = item_url
                            data['count'] = count
                            data['page_number'] = self.page
                            try:
                                logging.warning(data)
                                db[MONGODB_COLLECTION_AGENT].insert(dict(data))
                            except:
                                logging.warning("duplicates found...!!!!")
                                pass
                    elif not_found:
                        logging.info("Items not found...!!!")
                        pass
                    else:
                        self.parse_requests(url)
                else:
                    self.parse_requests(url)
            else:
                self.parse_requests(url)

            if self.next_page_check == True:
                self.next_page_check = False
                for i in range(2, self.number_of_pages+1):
                    self.page += 1
                    split_url = url.split("?page=")
                    next_page = split_url[0] + '?page=' + str(self.page)
                    self.parse_requests(next_page)


hurriyetemlak()
