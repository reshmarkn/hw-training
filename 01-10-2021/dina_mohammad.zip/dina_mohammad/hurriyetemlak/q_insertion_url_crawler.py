import requests
import json
import random
import logging
import pika
from datetime import datetime
import lxml
import lxml.html
import cloudscraper


QUEUE_NAME = 'ha.hurriyetemlak_district_urls'
QUEUE_IP = '159.89.47.171'
QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'
PROXY_LIST = requests.get('http://68.183.58.145/microleaves',headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
    
country_list = ['istanbul','ankara','izmir','adana','adiyaman','afyonkarahisar','agri','aksaray','amasya','antalya','ardahan','artvin','aydin','balikesir','bartin','batman','bayburt','bilecik','bingol','bitlis','bolu','burdur','bursa','canakkale','cankiri','corum','denizli','diyarbakir','duzce','edirne','elazig','erzincan','erzurum','eskisehir','gaziantep','giresun','gumushane','hakkari','hatay','igdir','isparta','kahramanmaras','karabuk','karaman','kars','kastamonu','kayseri','kirikkale','kirklareli','kirsehir','kilis','kocaeli','konya','kutahya','malatya','manisa','mardin','mersin-icel','mugla','mus','nevsehir','nigde','ordu','osmaniye','rize','sakarya','samsun','siirt','sinop','sivas','sanliurfa','sirnak','tekirdag','tokat','trabzon','tunceli','usak','van','yalova','yozgat','zonguldak','kktc',]

page = 1
count = 0

headers = {
    "accept-encoding": "gzip, deflate, br",
    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
    "sec-fetch-dest": "document",
    "sec-fetch-mode": "navigate",
    "sec-fetch-site": "none",
    "sec-fetch-user": "?1",
    "upgrade-insecure-requests": "1",
    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.92 Safari/537.36"
}

def start_requests(url):
    response = ''
    while True:
        PROXY = random.choice(PROXY_LIST)
        proxy = 'https://' + PROXY
        proxies = {'https': proxy, 'http': proxy}
        try:
            scraper = cloudscraper.create_scraper()
            print("requesting...")
            response = scraper.get(url,headers=headers,proxies=proxies)
            print(response.status_code)
            if response.status_code == 200:
                data_page(response)
                break
            else:
                response = ''
        except:
            response = ''
            pass


def data_page(response):
    global count
    global page 
    try:
        json_data = response.json()
    except:
        json_data = ''
    if json_data:
        values = json_data.get("values")
        filter_urls = []
        for val in values:
            district = val.get("url")
            filter_url1 = 'https://www.hurriyetemlak.com/' + district +'-satilik'
            filter_urls.append(filter_url1)
            filter_url2 = 'https://www.hurriyetemlak.com/' + district +'-kiralik'
            filter_urls.append(filter_url2)
            filter_url3 = 'https://www.hurriyetemlak.com/' + district +'-gunluk-kiralik'
            filter_urls.append(filter_url3)
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=3000))
        channel = connection.channel()
        for filter_url in filter_urls:
            print(filter_url)
            count+=1
            print(str(count))
            f = open("hurriyetemlak_urls1.txt","a")
            f.write(filter_url+"\n")
            f.close()
            channel.queue_declare(queue=QUEUE_NAME, durable=True)
            channel.basic_publish(exchange='', routing_key=QUEUE_NAME, body=filter_url)
        connection.close()
    else:
        start_requests(response.request.url)


for country in country_list:
    url = 'https://www.hurriyetemlak.com/api/county?cityUrl='+ country
    start_requests(url)
