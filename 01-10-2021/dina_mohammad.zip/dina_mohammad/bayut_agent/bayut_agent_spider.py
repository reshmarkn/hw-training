import requests
import random
from scrapy.selector import Selector
from time import sleep
import json
import re
import lxml.html
from pymongo import MongoClient

MONGODB_DB = 'dina_mohammad'
MONGODB_COLLECTION_AGENT = 'bayut_uae_agents_2020_08'
client = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')
try:
    client.admin.command(
        "shardcollection", MONGODB_DB + "." + MONGODB_COLLECTION_AGENT, key={'url': 1}, unique=True)

except Exception:
    pass
db = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')[MONGODB_DB]


PROXY_LIST = requests.get(
    'http://68.183.58.145/torproxies', headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()


PROXY = random.choice(PROXY_LIST)
proxies = {"http": "http://%s" % PROXY,
           "https": "https://%s" % PROXY}


# get broker urls(company urls)

COLLECTION_NAME = 'bayut_uae_company_2020_08'
FIELD = 'url'

FIELD = FIELD.split(',')
FIELD = [x.strip() for x in FIELD if x.strip()]

searchString = {'_id': 1}
for field in FIELD:
    searchString[field] = 1
# searchString = {'url': 1}
print(searchString)
result = db[COLLECTION_NAME].find({}, searchString)
urls = []

for data in result:

    document = dict(data)
    if len(FIELD) == 1:
        url = document[FIELD[0]]
        url = url.strip()
        urls.append(url)


# get agent data(api) for each company url

for url in urls:
    url = url.strip()
    print('broker_url', url)
    if url:
        sleep(5)
        broker_url = url
        broker_id = re.findall(r'-\d+/', broker_url)
        broker_id = broker_id[-1].strip().strip(
            '-').strip('/') if broker_id else ''
        if broker_id:
            print('broker_id', broker_id)
            api_url = 'https://www.bayut.com/api/agency/' + broker_id + '/agents?format=json'
            response = requests.get(api_url,  proxies=proxies)
            print(url, ">>>", response.status_code)
            if response.status_code == 200:
                print('sucess:', broker_url)
                agent_json = json.loads(response.text)
                for agent in agent_json:
                    user_id = agent.get('user_id', '')
                    slug = agent.get('slug', '')
                    name = agent.get('name', '')
                    about_user = agent.get('about_user', '')
                    user_image = agent.get('user_image', '')
                    email = agent.get('email', '')
                    cell = agent.get('cell', '')
                    cell_numbers = agent.get('cell_numbers', '')
                    phone = agent.get('phone', '')
                    phone_numbers = agent.get('phone_numbers', '')
                    proxy_mobile = agent.get('proxy_mobile', '')
                    proxy_phone = agent.get('proxy_phone', '')
                    active = agent.get('active', '')
                    user_langs = agent.get('user_langs', '')
                    languages = []
                    if user_langs:
                        lan_keys = user_langs.keys()
                        for lan in lan_keys:
                            language = user_langs.get(lan)
                            language = language[0] if language else ''
                            languages.append(language)

                    sale_count = agent.get('sale_count', '')
                    rent_count = agent.get('rent_count', '')
                    specialities = agent.get('specialities', '')
                    service_areas = agent.get('service_areas', '')
                    social_media = agent.get('social_media', '')
                    agency_dict = agent.get('agency', '')
                    agency = agency_dict.get('name').get('en')
                    ageny_url = agency_dict.get('slug', '')
                    ageny_url = 'https://www.bayut.com/companies/'+ageny_url+'/'
                    external_id = agent.get('external_id', '')
                    user_external_id = agent.get('user_external_id', '')

                    agent_url = 'https://www.bayut.com/brokers/'+slug+'.html'
                    if not specialities or service_areas:
                        agent_page = requests.get(agent_url,   proxies=proxies)
                        if agent_page.status_code == 200:
                            sel = lxml.html.fromstring(agent_page.text)
                            specialities = sel.xpath(
                                '//span[contains(text(),"Specialities")]/following-sibling::div//text()')
                            service_areas = sel.xpath(
                                '//span[contains(text(),"Service Areas")]/following-sibling::div//text()')
                            languages = sel.xpath(
                                '//span[contains(text(),"Language")]/following-sibling::div//text()')
                        # {'url': agent_url, 'about_user': about_user, 'active': active, 'agency': agency, 'ageny_url':ageny_url, 'cell': cell, 'cell_numbers': cell_numbers,
                        #  'email': email, 'external_id': external_id, 'name': name, 'phone': phone, 'phone_numbers': phone_numbers, 'proxy_mobile': proxy_mobile,
                        #  'proxy_phone': proxy_phone, 'rent_count': rent_count, 'sale_count': sale_count, 'service_areas': service_areas,
                        #  'slug': slug, 'social_media': social_media, 'specialities': specialities,
                        #  'user_external_id': user_external_id, 'user_id': user_id, 'user_image': user_image, 'user_langs': user_langs}
                    specialities = ' '.join(
                        specialities).strip() if specialities else ''
                    service_areas = ' '.join(
                        service_areas).strip() if service_areas else ''
                    languages = ' '.join(
                        languages).strip() if languages else ''

                    data = {'url': agent_url, 'about': about_user, 'agency': agency, 'ageny_url': ageny_url, 'email': email, 'name': name, 'phone': phone, 'properties_rent': rent_count,
                            'properties_sale': sale_count, 'service_areas': service_areas, 'specialities': specialities, 'user_id': user_id, 'user_image': user_image, 'languages': languages}
                    print('Agent', agent_url)
                    try:
                        db[MONGODB_COLLECTION_AGENT].insert(dict(data))
                    except Exception:
                        raise DropItem("Dropping duplicate item")

            else:
                f1 = open('bayut_broker_issue.txt', 'a')
                f1.write(url+'\n')
                f1.close()

        else:
            f1 = open('bayut_broker_issue.txt', 'a')
            f1.write(url+'\n')
            f1.close()
