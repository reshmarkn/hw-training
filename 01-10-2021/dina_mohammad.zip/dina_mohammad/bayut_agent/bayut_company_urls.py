import requests
import random
from scrapy.selector import Selector
from time import sleep
import json
from pymongo import MongoClient

MONGODB_DB = 'dina_mohammad'
MONGODB_COLLECTION_COMPANY = 'bayut_uae_company_2020_08'


client = MongoClient('mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')

try:
    client.admin.command(
        "shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION_COMPANY, key={'url': 1}, unique=True)
except:
    pass

db = client[MONGODB_DB]


urls = ['https://www.bayut.com/companies/abu-dhabi/', 'https://www.bayut.com/companies/dubai/', 'https://www.bayut.com/companies/sharjah/',
        'https://www.bayut.com/companies/ajman/', 'https://www.bayut.com/companies/fujairah/', 'https://www.bayut.com/companies/al-ain/', 'https://www.bayut.com/companies/umm-al-quwain/', 'https://www.bayut.com/companies/ras-al-khaimah/']


PROXY_LIST = requests.get(
    'http://68.183.58.145/torproxies', headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()


PROXY = random.choice(PROXY_LIST)
proxies = {"http": "http://%s" % PROXY,
           "https": "https://%s" % PROXY}

for url in urls:
    while url:
        sleep(10)
        response = requests.get(url,  proxies=proxies)
        sel = Selector(text=response.content)
        agent_urls = sel.xpath(
            '//a[@aria-label="Agency link"]/@href').extract()
        for ag_url in agent_urls:
            ag_url = 'https://www.bayut.com'+ag_url
            data = {
                'url': ag_url}
            if ag_url:
                print(ag_url)
                try:
                    db[MONGODB_COLLECTION_COMPANY].insert(dict(data))
                except Exception:
                    print("Dropping duplicate item")
                    pass

        url = sel.xpath('//a[@title="Next"]/@href').extract()
        url = 'https://www.bayut.com' + url[0] if url else ''
        print("Next page", url)
