import requests
import lxml.html
import json
import re
import io
import ast

headers = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
           'accept-encoding': 'gzip, deflate, br',
           'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
           'cache-control': 'max-age=0',
           'referer:https': '//www.zaahib.com/search/en/list/',
           'upgrade-insecure-requests': '1',
           'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'}
full_data = []
proxies = {'http':'http://5.79.66.2:13200',
    'https':'https://5.79.66.2:13200',}


class ajaxLinkCrawler:
    def __init__(self):

        self.area_type_url = 'https://zstatic.zahip.com/Scripts/data_files/areas_list_sa.636617206057510131.js'
        self.property_type_url = 'https://zstatic.zahip.com/Scripts/zaahib_js/zaahib.home.636675219405095454.js'
        self.link_crawl(self.area_type_url,self.property_type_url)

    def link_crawl(self, area_type_url, property_type_url):
        location_list_ = []
        property_types = []
        area_list_ = requests.get(
            area_type_url,proxies=proxies)
        area_list_ = str(area_list_.content, encoding='utf-8')
        location_tree = re.findall(
            r'var LocationTree=(\[.*\]);', ' '.join(area_list_.split()))
        location_tree = location_tree[0].strip() if location_tree else ''
        try:
            location_list_ = ast.literal_eval(location_tree)
        except Exception:
            try:
                location_list_ = ast.literal_eval(location_tree)
            except Exception:
                pass
        location_list = {}
        for loc_ in location_list_:
            key = loc_.get('AEn', '')
            value = loc_.get('id', '')
            key = '-'.join(key.lower().split()) if key else ''
            value = str(value) if value else ''
            if key:
                location_list.update({key: value})

        property_type_ = requests.get(
            property_type_url,proxies=proxies)
        property_type_ = str(property_type_.content, encoding='utf-8')
        property_type_list = re.findall(
            r'PropertyTypeList\s?=\s?(\[\s?\{.*?\}\s?\])', ' '.join(property_type_.split()))
        property_type_list = property_type_list[
            0].strip() if property_type_list else ''
        property_type_list = re.sub(
            r"([^,^\{^\s]*?):", r'"\1":', property_type_list)

        try:
            property_types = json.loads(property_type_list)
        except Exception:
            try:
                property_types = json.loads(property_type_list)
            except Exception:
                pass
        property_type_list_data = {}
        for propt_ in property_types:
            key = propt_.get('nameEn', '')
            value = propt_.get('id', '')
            key = '-'.join(key.lower().split()) if key else ''
            value = str(value) if value else ''
            if key and value:
                property_type_list_data.update({key:value})
        listing_category = ['153','154']
        ajaxlink = {}
        for loc in location_list.values():
            for p_type in property_type_list_data.values():
                for l_cat in listing_category:
                    ajax_url = 'https://www.zaahib.com/ajax/modules/classifieds/search_listings.php?sf=yes&PropertyType[equal]=%s&Province_City_District[in]=%s&ListingCategory[in]=%s&keywords[contains]=&lang=en&buildType=website&Status[in]=2&page=1'%(
                        str(p_type), str(loc), str(l_cat))
                    ajax_url = ajax_url.strip()
                    ajaxlink['url'] = ajax_url
                    self.next_function(ajaxlink)      


    def next_function(self, data):
        full_data.append(data)
        print('next........................', data)


ajaxLinkCrawler()
