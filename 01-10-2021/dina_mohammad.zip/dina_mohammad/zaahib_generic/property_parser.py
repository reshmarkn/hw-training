import requests
import json
import re
import pika
import json
import logging
import requests
import js2py
import random

import lxml.html
from datetime import datetime

headers = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
           'accept-encoding': 'gzip, deflate, br',
           'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
           'upgrade-insecure-requests': '1',
           'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.87 Safari/537.36'}


# proxies = {'http':'http://5.79.66.2:13200',
#     'https':'https://5.79.66.2:13200',}
PROXY_LIST = [
    '195.154.161.89:11789',
    '195.154.161.89:11790',
    '195.154.161.89:11791',
    '195.154.161.89:11792',
    '195.154.161.89:11793',
    '195.154.161.89:11794',
    '195.154.161.89:11795',
    '195.154.161.89:11796',
    '195.154.161.89:11797',
    '195.154.161.89:11798',
    '195.154.161.89:11799',
    '195.154.161.89:11800',
    '195.154.161.89:11801',
    '195.154.161.89:11802',
    '195.154.161.89:11803',
    '195.154.161.89:11804',
    '195.154.161.89:11805',
    '195.154.161.89:11806',
    '195.154.161.89:11807',
    '195.154.161.89:11808',
    '195.154.161.89:11809',
    '195.154.161.89:11810',
    '195.154.161.89:11811',
    '195.154.161.89:11812',
    '195.154.161.89:11813'
]

PROXY = random.choice(PROXY_LIST)
proxies = {"http": "http://%s" % PROXY,
           "https": "https://%s" % PROXY}
full_data = []


class PropertyParser:
    def __init__(self):
        # this is a sample property_url
        self.url = 'https://www.zaahib.com/ajax/modules/classifieds/display_listing_handler.php?buildType=website&lang=en&listing_id=3609197'
        self.link_crawl(self.url)

    def link_crawl(self, url):

        if url.strip():
            # url = str(url, encoding='utf-8')
            url = str(url)
            response = requests.get(
                url=url.strip(), headers=headers, proxies=proxies)

        data = ''
        phone_numbers = ''
        try:
            data = json.loads(response.text)
        except Exception:
            try:
                data = json.loads(response.text)
            except Exception:
                pass
        print("JSON::", data)
        if data:
            item = data.get('listing', '')
            if item:
                category = item.get('CategoryEn', '')
                category_ar = item.get('CategoryAr', '')

                if category == 'For Sale':
                    price = item.get('Price', '')
                else:
                    price = item.get('Rent', '')
                id_ = item.get('sid', '')
                bedrooms = item.get('Beds', '')
                bathrooms = item.get('Baths', '')

                furnished = item.get('Furnished', '')
                price_per = item.get('RentAmountPerText', '')
                broker_display_name = ''
                js = """
                e=""" + json.dumps(item) + """
                    function generateDisplayedName(e) {
                        var t = "Anonymous",
                            lang = "en",
                            lang_ucfirst = "En"
                            i = typeof e.agency != "undefined" && e.agency != null,
                            a = typeof e.agency == "undefined" || e.agency == null ? e.user : e.agency,
                            n = typeof e.agency == "undefined" || e.agency == null ? "" : this.generateAgencyDisplayedName(a),
                            r = lang == "ar" ? "En" : "Ar";
                        return e.UseProfileForContacts == 1 ? typeof a != "undefined" && typeof a.IsPrivate != "undefined" && a.IsPrivate != 1 && (i && n != "" ? t = n : typeof a["ProfileName" + lang_ucfirst] != "undefined" && a["ProfileName" + lang_ucfirst] != "" && a["ProfileName" + lang_ucfirst] != null ? t = a["ProfileName" + lang_ucfirst].replace(/\+/g, " ") : typeof a["FirstName" + lang_ucfirst] != "undefined" && a["FirstName" + lang_ucfirst] != "" && a["FirstName" + lang_ucfirst] != null ? (t = a["FirstName" + lang_ucfirst].replace(/\+/g, " "),
                            typeof a["LastName" + lang_ucfirst] && a["LastName" + lang_ucfirst] != "" && a["LastName" + lang_ucfirst] != null && (t = t + " " + a["LastName" + lang_ucfirst].replace(/\+/g, " "))) : typeof a["ProfileName" + r] != "undefined" && a["ProfileName" + r] != "" && a["ProfileName" + r] != null ? t = a["ProfileName" + r].replace(/\+/g, " ") : typeof a["FirstName" + r] != "undefined" && a["FirstName" + r] != "" && a["FirstName" + r] != null ? (t = a["FirstName" + r].replace(/\+/g, " "),
                            typeof a["LastName" + r] && a["LastName" + r] != "" && a["LastName" + r] != null && (t = t + " " + a["LastName" + r].replace(/\+/g, " "))) : typeof a.username != "undefined" && a.username != null && (t = a.username)) : typeof e.FirstName != "undefined" && e.FirstName != "" && e.FirstName != null ? (t = e.FirstName.replace("+", " "),
                            typeof e.LastName != "undefined" && e.LastName != "" && e.LastName != null && (t = t + " " + e.LastName.replace("+", " "))) : typeof a != "undefined" && typeof a.IsPrivate != "undefined" && a.IsPrivate != 1 && (i && n != "" ? t = n : typeof a["ProfileName" + lang_ucfirst] != "undefined" && a["ProfileName" + lang_ucfirst] != "" && a["ProfileName" + lang_ucfirst] != null ? t = a["ProfileName" + lang_ucfirst].replace(/\+/g, " ") : typeof a["FirstName" + lang_ucfirst] != "undefined" && a["FirstName" + lang_ucfirst] != "" && a["FirstName" + lang_ucfirst] != null ? (t = a["FirstName" + lang_ucfirst].replace(/\+/g, " "),
                            typeof a["LastName" + lang_ucfirst] && a["LastName" + lang_ucfirst] != "" && a["LastName" + lang_ucfirst] != null && (t = t + " " + a["LastName" + lang_ucfirst].replace(/\+/g, " "))) : typeof a["ProfileName" + r] != "undefined" && a["ProfileName" + r] != "" && a["ProfileName" + r] != null ? t = a["ProfileName" + r].replace(/\+/g, " ") : typeof a["FirstName" + r] != "undefined" && a["FirstName" + r] != "" && a["FirstName" + r] != null ? (t = a["FirstName" + r].replace(/\+/g, " "),
                            typeof a["LastName" + r] && a["LastName" + r] != "" && a["LastName" + r] != null && (t = t + " " + a["LastName" + r].replace(/\+/g, " "))) : typeof a.username != "undefined" && a.username != null && (t = a.username)),
                        t;
                    };
                    function generateAgencyDisplayedName(e) {
                        var t = "Anonymous",
                        lang = "en"
                            i = "Ar",
                            j = "En";
                        return lang == "en" ? (i = "En", j = "Ar") : (j = "En", i = "Ar"), e.IsPrivate != 1 && (typeof e["AgencyName" + i] != "undefined" && e["AgencyName" + i] != "" && e["AgencyName" + i] != null ? t = e["AgencyName" + i].replace(/\+/g, " ") : typeof e["AgencyName" + j] != "undefined" && e["AgencyName" + j] != "" && e["AgencyName" + j] != null ? t = e["AgencyName" + j].replace(/\+/g, " ") : e.DisplayEmail && typeof e.email != "undefined" && e.email != "" && e.email != null ? t = e.email : e.DisplayMobile && typeof e.MobileNumber != "undefined" && e.MobileNumber != "" && e.MobileNumber != null ? t = e.MobileNumber : e.DisplayPhone && typeof e.PhoneNumber != "undefined" && e.PhoneNumber != "" && e.PhoneNumber != null ? t = e.PhoneNumber : e.DisplayPhone && typeof e.Phone2 != "undefined" && e.Phone2 != "" && e.Phone2 != null ? t = e.Phone2 : e.DisplayPhone && typeof e.Fax != "undefined" && e.Fax != "" && e.Fax != null && (t = e.Fax)),
                        t;
                    };
                    generateDisplayedName(e);
                    """

                broker_display_name = js2py.eval_js(js)

                title = item.get('PropertyTitleEn', '')
                if title:
                    pass
                else:
                    title = item.get('PropertyTitleAr', '')
                if title:
                    pass
                else:
                    type_en = item.get('TypeEn', '')
                    type_ar = item.get('TypeAr', '')
                    if type_en:
                        title = type_en + ' ' + category
                    elif type_ar:
                        title = type_ar + ' ' + category_ar

                building_no = item.get('BuildingNo', '')
                additional_no = item.get('AdditionalNo', '')
                street = item.get('StreetNameEn', '')
                zip_ = item.get('ZipCode', '')
                city = item.get('CityEn', '')
                district = item.get('DistrictEn', '')
                province = item.get('ProvinceEn', '')
                mapaddress = item.get('MapAddressEn', '')
                latitude = item.get('Latitude')
                features = item.get('Features', '')
                features1 = ', '.join(features).strip() if features else ''
                picture = item.get('pictureURLs', '')
                number_of_photos = str(len(picture))
                area = item.get('SquareMeter', '')
                area = str(area)

                t = ''
                if street != 'undefined' and street != '' and street != None and building_no != 'undefined' and building_no != '' and building_no != None:
                    t = t + building_no + ' '
                if street:
                    t = t + street.replace(r'/\+/g', ' ') + ', '
                if zip_ != 'undefined' and zip_ != '' and zip_ != None:
                    t = t + ' ' + zip_ + ', '

                if mapaddress != 'undefined' and mapaddress != '' and mapaddress != None and (mapaddress != 'undefined' or province != 'undefined' and province == 'Property Outside Saudi Arabia') and (province != 'undefined' and province == 'Property Outside Saudi Arabia' or latitude != 'undefined' and latitude != ''):
                    t = t + mapaddress
                else:
                    if district != 'undefined' and district:
                        t = t + district + ', '
                    if city:
                        t = t + city + ', '

                    t = t + province

                location = t if t else ''

                id_ = item.get('sid', '')
                url = 'https://www.zaahib.com/view_listing/en/' + id_

                if furnished == 0:
                    furnished = ''

                if furnished == 1:
                    furnished = "furnished"

                if price == ".00":
                    price = ''

                if price == "0":
                    price = ''
                if category == 'For Sale':
                    price_per = ''

                scraped_ts = (datetime.now()).strftime("%Y-%m-%d")

                phone_numbers = []
                phone1 = item.get('user', '').get('MobileNumber')
                phone2 = item.get('agency', '').get('MobileNumber')
                phone3 = item.get('MobileNumber')
                phone4 = item.get('PhoneNumber')
                phone5 = item.get('agency', '').get('PhoneNumber')
                phone6 = item.get('user', '').get('PhoneNumber')
                phone_numbers = [phone1, phone2,
                                 phone3, phone4, phone5, phone6]
                phone_numbers = [
                    x for x in phone_numbers if x] if phone_numbers else ''
                phone_numbers = [x.strip()
                                 for x in phone_numbers] if phone_numbers else ''
                phone_numbers = list(set([x.strip()
                                          for x in phone_numbers if phone_numbers])) if phone_numbers else ''
                phone_numbers = ', '.join(
                    phone_numbers).strip() if phone_numbers else ''

                reference_number = ''
                id = id_
                url = url
                broker_display_name = broker_display_name
                broker = broker_display_name.upper()
                category = category
                category_url = ''
                title = title
                description = ''
                location = location
                price = price
                currency = 'SAR'
                price_per = price_per
                bedrooms = bedrooms
                bathrooms = bathrooms
                furnished = furnished
                rera_permit_number = ''
                dtcm_licence = ''
                scraped_ts = scraped_ts
                amenities = features1
                details = area
                agent_name = ''
                number_of_photos = number_of_photos
                user_id = ''
                phone_number = phone_numbers
                date = scraped_ts
                iteration_number = iteration_number
                print("DATA::", reference_number, '*******',  id, '*******',  url, '*******',  broker_display_name, '*******',  broker, '*******',  category, '*******',  category_url, '*******',  title, '*******',  description, '*******',  location, '*******',  price, '*******',  currency, '*******',  price_per, '*******',  bedrooms,
                      '*******',  bathrooms, '*******',  furnished, '*******',  rera_permit_number, '*******',  dtcm_licence, '*******',  scraped_ts, '*******',  amenities, '*******',  details, '*******',  agent_name, '*******',  number_of_photos, '*******',  user_id, '*******',  phone_number, '*******',  date, '*******',  iteration_number)


PropertyParser()
