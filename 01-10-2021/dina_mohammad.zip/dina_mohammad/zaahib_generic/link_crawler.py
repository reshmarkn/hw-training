import requests
import lxml.html
import json
import re
import io
import ast

headers = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
           'accept-encoding': 'gzip, deflate, br',
           'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
           'upgrade-insecure-requests': '1',
           'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.87 Safari/537.36'}

proxies = {'http':'http://5.79.66.2:13200',
    'https':'https://5.79.66.2:13200',}
full_data = []
class linkCrawler:
    def __init__(self):
        #this is a sample category_url
        self.category_url = 'https://www.zaahib.com/ajax/modules/classifieds/search_listings.php?sf=no&lang=en&PropertyType=869&ListingCategory=154&Province_City_District=9961&buildType=website&Status=2&page=1'
        self.link_crawl(self.category_url)

    def link_crawl(self, category_url):
        if category_url.strip():
            # category_url = category_url.encode('utf-8') 
            category_url = str(category_url)
            response = requests.get(url=category_url.strip(), headers=headers,proxies=proxies)
        jsondata = {}

        try:
            jsondata = json.loads(response.text)
        except Exception:
            try:
                jsondata = json.loads(response.text)
            except Exception:
                pass
        
        print(jsondata)

        if jsondata:
            page_number = jsondata.get("pages_number", '')
            data = jsondata.get('listings', '')
            link = {}
            if data:
                for item in data:
                    id_ = item.get('sid', '')
                    if id_:
                        id_ = str(id_).strip()
                        url_input = 'https://www.zaahib.com/ajax/modules/classifieds/display_listing_handler.php?buildType=website&lang=en&listing_id=%s' % (
                            id_)

                    url_input = url_input.strip()
                    link['url'] = url_input
                    self.next_function(link)      

                if page_number:

                    next_url = category_url.replace(',', '')
                    next_url = next_url.split(
                        '&page=')[0] + '&page=' + str(int(next_url.split('&page=')[1]) + 1)
                    self.link_crawl(next_url)
        else:
            print("***************NO DATA FOUND*************")


    def next_function(self, data):
        full_data.append(data)
        print('next........................', data)

linkCrawler()
