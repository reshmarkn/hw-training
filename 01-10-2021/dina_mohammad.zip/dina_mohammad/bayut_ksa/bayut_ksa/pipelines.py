# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html

from pymongo import MongoClient
from scrapy.exceptions import DropItem
from datetime import datetime
from bayut_ksa.items import *

now = datetime.now()
current = datetime(now.year, now.month, 1)
next_month = datetime(now.year + int(now.month / 12), ((now.month % 12) + 1), 1)
now_date_int = int(now.strftime("%d"))
if now_date_int <=31 and now_date_int >=25:
    iteration_month = next_month.strftime("%m")
    iteration_year = next_month.strftime("%Y")
else:
    iteration_month = now.strftime("%m")
    iteration_year = now.strftime("%Y")
iteration_number = iteration_year + '_'+ iteration_month

MONGODB_DB = 'dina_mohammad_monthly_' + iteration_number
MONGODB_COLLECTION_AGENT = 'bayut_ksa_' + iteration_number
MONGODB_COLLECTION_AGENT_URL = 'bayut_ksa_url_' + iteration_number


class BayutKsaPipeline(object):
    def __init__(self, *args, **kwargs):
        self.client = MongoClient(
            'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
        try:
            self.client.admin.command("enablesharding", MONGODB_DB)
            self.client.admin.command(
                "shardcollection", MONGODB_DB + "." + MONGODB_COLLECTION_AGENT, key={'url': 1}, unique=True)
            self.client.admin.command("shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION_AGENT_URL,
                                      key={'url': 1}, unique=True)
        except Exception:
            try:
                self.client.admin.command("shardcollection", MONGODB_DB + "." + MONGODB_COLLECTION_AGENT,
                                          key={'url': 1}, unique=True)
                self.client.admin.command("shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION_AGENT_URL,
                                          key={'url': 1}, unique=True)
            except Exception:
                try:
                    self.client.admin.command("shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION_AGENT,
                                              key={'url': 1}, unique=True)
                except Exception:
                    try:
                        self.client.admin.command("shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION_AGENT_URL,
                                                  key={'url': 1}, unique=True)
                    except Exception:
                        pass

        # self.client = MongoClient(
        #     'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
        self.db = self.client[MONGODB_DB]
    @classmethod
    def from_crawler(cls, crawler):
        return cls(
            settings=crawler.settings
        )
    def close_spider(self, spider):
        self.client.close()
        # try:
        #     self.db[MONGODB_COLLECTION_AGENT_URL].create_index(
        #         [('url', pymongo.DESCENDING)], unique=True)
        # except:
        #     pass
        # try:
        #     self.db[MONGODB_COLLECTION_AGENT].create_index(
        #         [('url', pymongo.DESCENDING)], unique=True)
        # except:
        #     pass
            
        # self.db = self.client[MONGODB_DB]
    

    def process_item(self, item, spider):
        if isinstance(item, BayutKsaItem):
            try:
                self.db[MONGODB_COLLECTION_AGENT].insert(dict(item))
            except Exception:
                raise DropItem("Dropping duplicate item")
        if isinstance(item, BayutKsaUrlItem):
            try:
                self.db[MONGODB_COLLECTION_AGENT_URL].insert(dict(item))
            except Exception:
                raise DropItem("Dropping duplicate item")

        return item
