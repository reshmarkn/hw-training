# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime
from rmq import RmqHandler

from bayut_ksa.items import *
from bayut_ksa.settings import *
from bayut_ksa.storm_proxy import parse_proxy

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


class BayutSpider(Spider):
    name = 'bayut_ksa_spider'
    headers = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
               'accept-encoding': 'gzip, deflate, br',
               'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
               'cache-control': 'no-cache',
               'pragma': 'no-cache',
               'upgrade-insecure-requests': '1',
               'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', }

    def start_requests(self):
        # Fetching URL from queue until queue is empty
        # credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        # connection = pika.BlockingConnection(pika.ConnectionParameters(
        #     credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        # channel = connection.channel()
        # while True:
        #     channel.basic_qos(prefetch_count=1)
        #     method, properties, url = channel.basic_get(queue=QUEUE_NAME)
        #     if not url.strip():
        #         break
        #     channel.basic_ack(delivery_tag=method.delivery_tag)
        #     url = str(url.strip(), encoding='utf-8')
        # # f = open('urls.txt')
        # # for url in f.readlines():
        # #   url = url.strip()
        # connection.close()
        rmqh = RmqHandler(QUEUE_NAME, ip=QUEUE_IP,user=QUEUE_USER, pwd=QUEUE_PASS)
        while True:
            count, data = rmqh.get()
            if not data:
                break
            if data:
                url = data
                yield Request(url=url.strip(), callback=self.parse_data, headers=self.headers, errback=lambda x: self.errback_httpbin(x, url.strip()))


    def parse_data(self, response):

        amenities = []
        user_id = ''
        agent_name = ''
        ID__XPATH = '//script[contains(text(), "layout_preference")]/text()'
        BROKER_DISPLAY_NAME_XPATH = '//span[@aria-label="Agency name"]/text()'
        CATEGORY_XPATH = '//div[@aria-label="Breadcrumb"]/a//text()'
        CATEGORY_URL_XPATH = '//div[@aria-label="Breadcrumb"]/a/@href'
        TITLE_XPATH = '//h1/text()'
        DESCRIPTION_XPATH = '//h3[contains(text(),"Description")]/following-sibling::div//div[@aria-label="Property description"]//span/text()|//div[@aria-label="Property description"]/span//text()|//div[@aria-label="Property description"]/span/ul/li//text()|//div[@aria-label="Property description"]//span//text()'
        LOCATION_XPATH = '//div[@aria-label="Property basic info"]//div[@aria-label="Property header"]/text()'
        PRICE_XPATH = '//span[@aria-label="Property compact price"]/text()|//span[@aria-label="Price"]/text()'
        PRICE_PER_XPATH = '//span[@aria-label="Property compact frequency"]/text()|//span[@aria-label="Frequency"]/text()'
        BEDROOMS_XPATH1 = '//li[@aria-label="Property detail beds"]/span[@aria-label="Value"]/text()'
        BEDROOMS_XPATH2 = '//span[@aria-label="Beds"]/span[contains(text(),"Bed")]/text()'
        BATHROOMS_XPATH1 = '//li[@aria-label="Property detail baths"]/span[@aria-label="Value"]/text()'
        BATHROOMS_XPATH2 = '//span[@aria-label="Baths"]/span[contains(text(),"Bath")]/text()'
        RERA_PERMIT_NUMBER = '//div[@aria-label="Agency info"]//span[contains(text(),"Permit")]/text()|//span[contains(text(),"Permit")]/text()'
        REFER_NUB_XPATH = '//li[@aria-label="Property detail reference"]/span[@aria-label="Value"]/text()|//li/span[contains(text(),"Reference no.")]/following-sibling::span//text()'

        details = response.xpath(
            '//span[@aria-label="Area"]/span/text()|//span[contains(text(),"Area")]/following-sibling::span[@aria-label="Value"]/span/text()|//span[@aria-label="Area"]//text()').extract()
        reference_number = response.xpath(
            '//span[contains(text(),"Ref. No:")]/following-sibling::span/text()').extract()
        agent = response.xpath(
            '//span[contains(text(),"Agent")]/following-sibling::span/text()').extract()

        img = response.xpath(
            '//div[@class="ad0f1024"]//picture/img/@data-src').extract()
        if not img:
            img = response.xpath(
                '//div[@class="image-gallery-thumbnails-container"]//picture/img/@src').extract()
        number_of_photos = str(len(img))

        amen = response.xpath(
            '//ul[@class="e475b606"]//text() | //div[@class="e475b606"]//text()').extract()
        amenities = ', '.join(amen).strip().replace('  ', ' ') if amen else ''
        data = response.xpath(
            '//h3[contains(text(),"Details")]/following-sibling::div/ul/li')
        phone_script = response.xpath(
            '//script[contains(text(),"phoneNumber")]').extract()
        rera_registration_number = response.xpath(
            '//div[@aria-label="Agency info"]//span[contains(text(),"RERA#")]/text()|//span[contains(text(),"RERA#")]/text()').extract()
        ded_license_number = response.xpath(
            '//div[@aria-label="Agency info"]//span[contains(text(),"DED#")]/text()|//span[contains(text(),"DED#")]/text()').extract()
        currency = response.xpath(
            '//span[@aria-label="Currency"]/text()').extract()
        property_type = response.xpath('//li/span[contains(text(),"Type")]/following-sibling::span/text()').extract()
        published_at = response.xpath('//span[contains(text(),"Added on")]/following-sibling::span/text()').extract()

        # Extract values using above XPATHs
        title = response.xpath(TITLE_XPATH).extract()
        location = response.xpath(LOCATION_XPATH).extract()
        description = response.xpath(DESCRIPTION_XPATH).extract()
        bedrooms1 = response.xpath(BEDROOMS_XPATH1).extract()
        bathrooms1 = response.xpath(BATHROOMS_XPATH1).extract()
        bedrooms2 = response.xpath(BEDROOMS_XPATH2).extract()
        bathrooms2 = response.xpath(BATHROOMS_XPATH2).extract()

        broker_display_name = response.xpath(
            BROKER_DISPLAY_NAME_XPATH).extract()
        id_ = response.xpath(ID__XPATH).extract()
        category = response.xpath(CATEGORY_XPATH).extract()
        category_url = response.xpath(CATEGORY_URL_XPATH).extract()
        rera_permit_number = response.xpath(RERA_PERMIT_NUMBER).extract()
        price_per = response.xpath(PRICE_PER_XPATH).extract()
        price = response.xpath(PRICE_XPATH).extract()
        reference_nub = response.xpath(REFER_NUB_XPATH).extract_first()

        currency = currency[0].strip() if currency else ''
        if not price:
            price = response.xpath(
                '//span[@aria-label="Price"]/text()').extract()
        price = price[0].strip() if price else ''
        reference_nub = reference_nub.strip() if reference_nub else ''

        if not price_per:
            price_per = response.xpath(
                '//span[@aria-label="Frequency"]/text()').extract()
        price_per = price_per[0].strip() if price_per else ''

        if 'per' in price_per:
            price_per = price_per.replace('per', '')
        title = title[0].strip() if title else ''
        location = ''.join(location)
        location = location.strip() if location else ''
        description = ' '.join(' '.join(description).strip().split())
        bedrooms2 = bedrooms2 if bedrooms2 else []
        bedrooms = bedrooms1 if bedrooms1 else bedrooms2
        bedrooms = bedrooms[0].strip() if bedrooms else ''
        bedrooms = bedrooms.replace('Beds', '').strip() if bedrooms else ''
        bedrooms = bedrooms.replace('Bed', '').strip() if bedrooms else ''
        bathrooms2 = bathrooms2 if bathrooms2 else []
        bathrooms = bathrooms1 if bathrooms1 else bathrooms2
        bathrooms = bathrooms[0].strip() if bathrooms else ''
        bathrooms = bathrooms.replace('Baths', '').strip() if bathrooms else ''
        bathrooms = bathrooms.replace('Bath', '').strip() if bathrooms else ''
        broker_display_name = broker_display_name[
            0].strip() if broker_display_name else ''
        property_type_ = property_type[0] if property_type else '' 
        # category = ' > '.join(category).strip()
        category_url = category_url[-1].strip() if category_url else ''

        if 'for-rent' in category_url:
            category = 'rent'
            category_url = '/en/ksa/properties-for-rent/'
        elif 'for-sale' in category_url:
            category = 'sale'
            category_url = '/en/ksa/properties-for-sale/'

        # rera_permit_number = ' '.join(rera_permit_number).replace(
        #   'Permit', '').replace('#','').replace(
        #   ',', '').strip() if rera_permit_number else ''
        id_ = id_[0].strip() if id_ else ''
        id_ = re.findall('ad_id":(.*),"object_id"', id_)[0]

        if agent:
            agent_ = ','.join(agent).split(',')
            agent_name = agent_[0] if agent_ else ''

        amenities_str = ''
        if data:
            for amt in data:
                key = amt.xpath('span[@class="_3af7fa95"]/text()').extract()
                value = amt.xpath('span[@class="_812aa185"]/text()').extract()
                keys = ' '.join(''.join(key).strip().strip().strip(
                    ':').split()) if key else ''
                values = ' '.join(
                    ''.join(value).strip().split()) if value else ''
                if key:
                    amenities_str = amenities_str + keys + ':' + values + ', '
        amenities_str = amenities_str.strip(
            ', ').strip() if amenities_str else ''
        amenities_str = amenities_str.strip(
            ', ').strip() if amenities_str else ''
        reference_number = ' '.join(
            ''.join(reference_number).strip().split()) if reference_number else ''
        details = ' '.join(''.join(details).strip().split()) if details else ''
        details = 'Area :' + details if details else ''

        reference_number = ''.join(
            reference_number) if reference_number else ''

        user = response.xpath(
            '//div[@aria-label="Agency info"]//a/@href').extract()
        user = ''.join(user) if user else ''
        if '-' in user:
            user_data = user.split('-') if user else ''
            user_id = user_data[-1] if user_data else ''
        user_id = user_id.replace('/', '') if user_id else ''

        phone_script = re.findall(
            r'\"phoneNumber\":\{.*?\},', phone_script[0].strip()) if phone_script else ''
        phone_script = json.loads(phone_script[0].strip().strip(
            '"phoneNumber":').strip(',').replace('[', '').replace(']', '').replace(':,', ':null,')).values() if phone_script else ''
        phone_numbers = list(phone_script) if phone_script else ''
        phone_numbers = [x.strip()
                         for x in phone_numbers if x] if phone_numbers else ''
        phone_numbers = [x.strip()
                         for x in phone_numbers] if phone_numbers else ''
        phone_numbers = [x.strip()
                         for x in phone_numbers if x] if phone_numbers else ''
        phone_numbers = ', '.join(phone_numbers) if phone_numbers else ''

        rera_permit_number_script = response.xpath(
            '//script[contains(text(),"permitNumber")]/text()').extract()
        rera_permit_number_script = re.findall(
            r'\"permitNumber\":\"\d+"', rera_permit_number_script[0].strip()) if rera_permit_number_script else []
        rera_permit_number = rera_permit_number_script[0].strip().replace(
            '\"permitNumber\":', '').replace('"', '').strip() if rera_permit_number_script else ''

        rera_registration_number_script = response.xpath(
            '//script[contains(text(),"RERA") and contains(text(),"authority")]/text()').extract()
        rera_registration_number_script = re.findall(
            r'\{\"number\":\"\d+\",\"authority\":\"RERA\"\}', rera_registration_number_script[0].strip()) if rera_registration_number_script else []
        rera_registration_number_script = re.findall(
            r'\d+', rera_registration_number_script[0].strip()) if rera_registration_number_script else []
        rera_registration_number = rera_registration_number_script[0].strip(
        ) if rera_registration_number_script else ''

        ded_license_number_script = response.xpath(
            '//script[contains(text(),"DED") and contains(text(),"authority")]/text()').extract()
        ded_license_number_script = re.findall(
            r'\{\"number\":\"\d+\",\"authority\":\"DED\"\}', ded_license_number_script[0].strip()) if ded_license_number_script else []
        ded_license_number_script = re.findall(
            r'\d+', ded_license_number_script[0].strip()) if ded_license_number_script else []
        ded_license_number = ded_license_number_script[0].strip(
        ) if ded_license_number_script else ''

        rera_pn_len = len(str(rera_permit_number))
        rera_length = True if rera_pn_len == 10 else False
        scraped_ts = (datetime.now()).strftime("%Y-%m-%d")

        now = datetime.now()
        current = datetime(now.year, now.month, 1)
        next_month = datetime(now.year + int(now.month / 12), ((now.month % 12) + 1), 1)
        now_date_int = int(now.strftime("%d"))
        if now_date_int <=31 and now_date_int >=25:
            iteration_month = next_month.strftime("%m")
            iteration_year = next_month.strftime("%Y")
        else:
            iteration_month = now.strftime("%m")
            iteration_year = now.strftime("%Y")
        iteration_number = iteration_year + '_'+ iteration_month 

        reference_number = reference_number if reference_number else reference_nub

        published_at = published_at[0].strip() if published_at else ''


        item = BayutKsaItem(
            reference_number=reference_number,
            id=id_,
            url=response.url,
            broker_display_name=broker_display_name,
            broker=broker_display_name.upper(),
            category=category,
            category_url=category_url,
            title=title,
            property_type='',
            sub_category_1='',
            sub_category_2='',
            depth='',
            description=description,
            location=location,
            price=price,
            currency=currency,
            price_per=price_per,
            bedrooms=bedrooms,
            bathrooms=bathrooms,
            furnished='',
            rera_permit_number=rera_permit_number,
            dtcm_licence='',
            scraped_ts=scraped_ts,
            amenities=amenities,
            details=details,
            agent_name=agent_name,
            number_of_photos=number_of_photos,
            user_id=user_id,
            phone_number=phone_numbers,
            date=scraped_ts,
            iteration_number=iteration_number,
            published_at=published_at
        )
        yield item

    # Errorback to put failed urls back in queue
    def errback_httpbin(self, failure, url):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=600))
        channel = connection.channel()
        channel.queue_declare(queue=QUEUE_NAME, durable=True)
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=url)
        connection.close()
