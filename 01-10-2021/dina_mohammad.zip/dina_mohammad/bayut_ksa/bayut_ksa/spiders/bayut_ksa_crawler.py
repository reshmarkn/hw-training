# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging

from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime

from bayut_ksa.items import *
from bayut_ksa.settings import *
from bayut_ksa.storm_proxy import parse_proxy

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


class BayutCrawlerSpider(Spider):
    name = 'bayut_ksa_crawler'
    allowed_domains = ['bayut.sa']

    header = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
              'accept-encoding': 'gzip, deflate, br',
              'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
              'cache-control': 'no-cache',
              'pragma': 'no-cache',
              'upgrade-insecure-requests': '1',
              'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', }

    def start_requests(self):
        # urls = ['https://www.bayut.com/for-sale/property/uae/',
        #         'https://www.bayut.com/to-rent/property/uae/']
        urls = [{'url': 'https://www.bayut.sa/en/ksa/apartments-for-sale/',
                  "sub_category_1": "Residential",
                  "property_type": "Apartment",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/villas-for-sale/',
                  "sub_category_1": "Residential",
                  "property_type": "Villa",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/residential-floors-for-sale/',
                  "sub_category_1": "Residential",
                  "property_type": "Floor",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/hotel-apartments-for-sale/',
                  "sub_category_1": "Residential",
                  "property_type": "Hotel Apartment",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/residential-buildings-for-sale/',
                  "sub_category_1": "Residential",
                  "property_type": "Residential Building",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/residential-lands-for-sale/',
                  "sub_category_1": "Residential",
                  "property_type": "Residential Land",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/rest-houses-for-sale/',
                  "sub_category_1": "Residential",
                  "property_type": "Rest House",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/chalets-for-sale/',
                  "sub_category_1": "Residential",
                  "property_type": "Chalet",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/labour-camps-for-sale/',
                  "sub_category_1": "Residential",
                  "property_type": "Labour Camp",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/hotel-rooms-for-sale/',
                  "sub_category_1": "Residential",
                  "property_type": "Hotel Room",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/palaces-for-sale/',
                  "sub_category_1": "Residential",
                  "property_type": "Palace",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/apartments-for-rent/',
                  "sub_category_1": "Residential",
                  "property_type": "Apartment",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/villas-for-rent/',
                  "sub_category_1": "Residential",
                  "property_type": "Villa",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/residential-floors-for-rent/',
                  "sub_category_1": "Residential",
                  "property_type": "Floor",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/hotel-apartments-for-rent/',
                  "sub_category_1": "Residential",
                  "property_type": "Hotel Apartment",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/residential-buildings-for-rent/',
                  "sub_category_1": "Residential",
                  "property_type": "Residential Building",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/residential-lands-for-rent/',
                  "sub_category_1": "Residential",
                  "property_type": "Residential Land",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/rest-houses-for-rent/',
                  "sub_category_1": "Residential",
                  "property_type": "Rest House",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/chalets-for-rent/',
                  "sub_category_1": "Residential",
                  "property_type": "Chalet",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/labour-camps-for-rent/',
                  "sub_category_1": "Residential",
                  "property_type": "Labour Camp",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/hotel-rooms-for-rent/',
                  "sub_category_1": "Residential",
                  "property_type": "Hotel Room",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/palaces-for-rent/',
                  "sub_category_1": "Residential",
                  "property_type": "Palace",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/offices-for-sale/',
                  "sub_category_1": "Commercial",
                  "property_type": "Office",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/shops-for-sale/',
                  "sub_category_1": "Commercial",
                  "property_type": "Shop",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/showrooms-for-sale/',
                  "sub_category_1": "Commercial",
                  "property_type": "Showroom",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/commercial-buildings-for-sale/',
                  "sub_category_1": "Commercial",
                  "property_type": "Commercial Building",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/warehouses-for-sale/',
                  "sub_category_1": "Commercial",
                  "property_type": "Warehouse",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/commercial-lands-for-sale/',
                  "sub_category_1": "Commercial",
                  "property_type": "Commercial Land",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/industrial-lands-for-sale/',
                  "sub_category_1": "Commercial",
                  "property_type": "Industrial Land",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/farms-for-sale/',
                  "sub_category_1": "Commercial",
                  "property_type": "Farm",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/commercial-properties-for-sale/',
                  "sub_category_1": "Commercial",
                  "property_type": "Other Commercial",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/agriculture-plots-for-sale/',
                  "sub_category_1": "Commercial",
                  "property_type": "Agriculture Plot",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/offices-for-rent/',
                  "sub_category_1": "Commercial",
                  "property_type": "Office",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/shops-for-rent/',
                  "sub_category_1": "Commercial",
                  "property_type": "Shop",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/showrooms-for-rent/',
                  "sub_category_1": "Commercial",
                  "property_type": "Showroom",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/commercial-buildings-for-rent/',
                  "sub_category_1": "Commercial",
                  "property_type": "Commercial Building",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/warehouses-for-rent/',
                  "sub_category_1": "Commercial",
                  "property_type": "Warehouse",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/commercial-lands-for-rent/',
                  "sub_category_1": "Commercial",
                  "property_type": "Commercial Land",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/industrial-lands-for-rent/',
                  "sub_category_1": "Commercial",
                  "property_type": "Industrial Land",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/farms-for-rent/',
                  "sub_category_1": "Commercial",
                  "property_type": "Farm",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/commercial-properties-for-rent/',
                  "sub_category_1": "Commercial",
                  "property_type": "Other Commercial",
                  "sub_category_2": ""},
                {'url': 'https://www.bayut.sa/en/ksa/agriculture-plots-for-rent/',
                  "sub_category_1": "Commercial",
                  "property_type": "Agriculture Plot",
                  "sub_category_2": ""}

                  ]
        # urls = ['https://www.bayut.sa/en/ksa/properties-for-sale/',
        #         'https://www.bayut.sa/en/ksa/properties-for-rent/']

        for data in urls:
            meta=data
            url = data.get('url')
            yield Request(url, callback=self.parse_profile, headers=self.header,meta=meta)

    def parse_profile(self, response):
        sub_category_1 = response.meta['sub_category_1']
        sub_category_2 = response.meta['sub_category_2']
        property_type = response.meta['property_type']
        meta = response.meta
        all_links = response.xpath('//li[@aria-label="Listing"]/article')
        links = response.xpath(
            '//li[@role="article"]/article/div/a/@href').extract()
        for link in all_links:
            url = link.xpath('div/a[@aria-label="Listing link"]/@href').extract_first()
            url = 'https://www.bayut.sa' + url
            item = BayutKsaUrlItem(
                url=url,
                sub_category_1=sub_category_1,
                sub_category_2=sub_category_2,
                depth='',
                property_type=property_type
            )
            if url:
                yield item

        location_url = response.xpath(
            '//div[@class="_5734cfeb"]//a/@href').extract()
        for url in location_url:
            url = response.urljoin(url)
            if url:
                yield Request(url=url, callback=self.parse_profile, headers=self.header,meta=meta)

        next_page = response.xpath(
            '//a[@title="Next"]/@href').extract_first('')
        if next_page:
            yield Request(url=response.urljoin(next_page), callback=self.parse_profile, headers=self.header,meta=meta)
