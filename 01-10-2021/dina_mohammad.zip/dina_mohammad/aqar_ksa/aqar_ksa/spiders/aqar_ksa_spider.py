# -*- coding: utf-8 -*-
import pymongo
import scrapy
import string
import pika
import logging
import requests
import re
import json

from pymongo import MongoClient
from scrapy.exceptions import DropItem
from scrapy.http import Request, FormRequest
from scrapy.selector import Selector
from datetime import datetime
from time import sleep
from scrapy.spiders import Spider
from rmq import RmqHandler

from scrapy.shell import inspect_response

from aqar_ksa.settings import *
from aqar_ksa.items import *
from aqar_ksa.storm_proxy import parse_proxy

now = datetime.now()
current = datetime(now.year, now.month, 1)
next_month = datetime(now.year + int(now.month / 12), ((now.month % 12) + 1), 1)
now_date_int = int(now.strftime("%d"))
if now_date_int <=31 and now_date_int >=25:
    iteration_month = next_month.strftime("%m")
    iteration_year = next_month.strftime("%Y")
else:
    iteration_month = now.strftime("%m")
    iteration_year = now.strftime("%Y")
iteration_number = iteration_year + '_'+ iteration_month


MONGODB_DB = 'dina_mohammad_monthly_' + iteration_number
MONGODB_COLLECTION_AGENT = 'aqar_ksa_' + iteration_number

client = MongoClient('mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
try:
    client.admin.command("enablesharding", MONGODB_DB)
except:
    pass
try:
    client.admin.command("shardcollection", MONGODB_DB + "." + MONGODB_COLLECTION_AGENT, key={'url': 1}, unique=True)
except:
    pass

db = client[MONGODB_DB]

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


class AqarKsaSpider(Spider):
    name = 'aqar_ksa_spider'
    start_urls = ['https://sa.aqar.fm/']

    def start_requests(self):
        rmqh = RmqHandler(QUEUE_NAME, ip=QUEUE_IP,user=QUEUE_USER, pwd=QUEUE_PASS)
        while True:
            count, data = rmqh.get()
            if not data:
                break
            if data:

            # if url.strip():
                url = data
                # url = str(url, encoding='utf-8')
                meta={'url':url}
                yield Request(url,callback=self.parse_item,meta=meta)
                # try:
                #     proxy = parse_proxy()
                #     proxies = proxy['proxies']
                #     h = proxy['headers']
                #     re = requests.get(url=url, proxies=proxies, timeout=10)
                # except:
                #     try:
                #         proxy = parse_proxy()
                #         proxies = proxy['proxies']
                #         h = proxy['headers']
                #         re = requests.get(
                #             url=url.strip(), proxies=proxies, timeout=10)
                #     except:
                #         try:
                #             proxy = parse_proxy()
                #             proxies = proxy['proxies']
                #             h = proxy['headers']
                #             re = requests.get(
                #                 url=url.strip(), proxies=proxies, timeout=10)
                #         except:
                #             re = ''
                #             pass
                # # print("XXXXXXX",re.status_code,"XXXXXXXX")
                # if re and re.status_code == 200:
                #     self.parse_item(re, url)
                # elif  re == '':
                #     pass
                # elif "span class=\"notfounditle\"" in re.text:
                #     print("not found :",url)
                #     pass
                # else:
                #     self.errback_httpbin(url.strip())
                #     pass


        client.close()

    def parse_item(self, response):

    # def parse_item(self, response, url):
            # sel = Selector(text=response.content)
            sel = Selector(text=response.body)
            user_id = ''
            price_per = ''
            price_per_ = ''
            price_value = ''
            currency = ''
            latitude = ''
            longitude = ''
            url = response.meta['url']
            phone_number = ''
            # Grab XPATH
            NAME_XPATH = '//h1[@class="title listingPageTitle"]/a//text()'
            CATEGORY_XPATH = '//div[@class="tree treeMargin"]/li/a/text()'
            CATEGORY_URL_XPATH = '//div[@class="tree treeMargin"]/li/a/@href'
            DESCRIPTION_XPATH = '//meta[@property="og:description"]/@content'
            ID_XPATH = '//table[@class="dc-listingInfoTable"]//td[contains(text(),"#")]/text()'
            BEDROOM_XPATH = '//td[contains(text(),"غرف النوم")]/preceding-sibling::*[1][self::td]/text()'
            BATHROOM_XPATH = '//td[contains(text(),"دورات مياه")]/preceding-sibling::*[1][self::td]/text()'
            # FURNISHED_XPATH = '//table[@class="detailsTable"]//tr/td[contains(text(),"مؤثثة")]//text()'
            PRICE_XPATH = '//span[@class="listingPagePrice"]//text()|//span[@class="price listingPagePrice"]//text()'
            BROKER_XPATH = '//div[@class="userName"]//text()'

            # Extract values using above XPATHs
            name = sel.xpath(NAME_XPATH).extract()
            category = sel.xpath(CATEGORY_XPATH).extract()
            description = sel.xpath(DESCRIPTION_XPATH).extract()
            id_ = sel.xpath(ID_XPATH).extract()
            bedroom = sel.xpath(BEDROOM_XPATH).extract()
            bathroom = sel.xpath(BATHROOM_XPATH).extract()
            # furnished = sel.xpath(FURNISHED_XPATH).extract()
            price_text = sel.xpath(PRICE_XPATH).extract()
            category_url = sel.xpath(CATEGORY_URL_XPATH).extract()
            broker = sel.xpath(BROKER_XPATH).extract()

            user = sel.xpath(
                '//script[@type="text/javascript"]//text()').extract()[0]
            phone_script = sel.xpath(
                '//script[contains(text(),"phone")]').extract()
            lat_long = sel.xpath('*').re_first('"location":(\{.*?\})')
            published_at = sel.xpath('//table[@class="dc-listingInfoTable"]//tr//span[contains(text(),"قبل")]/text()').extract()

            # Clear Data
            name = ' '.join(''.join(name).strip().split()) if name else ''
            description = ' '.join(
                ''.join(description).strip().split()) if description else ''
            id_ = ' '.join(''.join(id_).strip().split()).strip(
                '#').strip() if id_ else ''
            if not id_:
                id_ = re.findall(r'-\d+', response.url)
                id_ = id_[0].strip('-').strip() if id_ else ''

            bedroom = ' '.join(''.join(bedroom).strip().split()) if bedroom else ''
            bathroom = ' '.join(
                ''.join(bathroom).strip().split()) if bathroom else ''
            # furnished = ' '.join(
            #     ''.join(furnished).strip().split()) if furnished else ''
            # category = [x.strip() for x in category] if category else ''
            # category = [x.strip()
            #           for x in category if x] if category else ''
            # category = ' > '.join(category).strip() if category else ''
            category = category[0] if category else ''
            category_url = category_url[0] if category_url else ''
            # category_url = category_url[-1] if category_url else ''
            broker = ' '.join(''.join(broker).strip().split()) if broker else ''
            price_text = ' '.join(
                ''.join(price_text).strip().split()) if price_text else ''
            price_value = re.findall(r'\d+', price_text) if price_text else []
            price_value = ''.join(price_value).strip() if price_value else ''

            if '/' in price_text:
                price_text_1 = price_text.split('/')
                price_per = price_text_1[-1] if price_text_1 else ''
                price_per_ = price_per.replace(',', '') if price_per else ''
                price_per_ = price_per_.replace(
                    price_value, '').strip() if price_per_ else ''
                price_text = price_text.replace(
                    price_per, '').replace('/', '').strip()
                price_text_ = price_text.split(' ')
                currency1 = price_text_[1] if price_text_ else ''
                currency2 = price_text_[-1] if price_text_ else ''
                currency = currency1 + ' ' + currency2
                if currency1 and currency2:
                    currency = currency1 + ' ' + currency2
                else:
                    currency = ''

            elif ' ' in price_text:
                price_text_ = price_text.split(' ')
                currency1 = price_text_[1] if price_text_ else ''
                currency2 = price_text_[-1] if price_text_ else ''
                currency = currency1 + ' ' + currency2
                if currency1 and currency2:
                    currency = currency1 + ' ' + currency2
                else:
                    currency = ''

            price_per_ = ' '.join(
                ''.join(price_per_).strip().split()) if price_per_ else ''
            currency = ' '.join(
                ''.join(currency).strip().split()) if currency else ''
            price_value = ' '.join(
                ''.join(price_value).strip().split()) if price_value else ''
            bedrooms = re.findall(r'\d+', bedroom)
            bedrooms = ' '.join(
                ''.join(bedrooms).strip().split()) if bedrooms else ''

            bathroom = re.findall(r'\d+', bathroom)
            bathroom = ' '.join(
                ''.join(bathroom).strip().split()) if bathroom else ''
            area = sel.xpath(
                '//td[contains(text(),"المساحة")]/preceding-sibling::*[1][self::td]/text()').extract()
            area = ''.join(area) if area else ''
            amenities = sel.xpath(
                '//table[@class="dc-extraDetailsTable"]//text()').extract()
            amenities = [x.strip() for x in amenities] if amenities else ''
            amenities = [x.strip()
                         for x in amenities if x] if amenities else ''
            amenities = ' , '.join(amenities).strip() if amenities else ''

            if user:
                data = user.replace(u'window.__store__ = ', '')if user else ''
                user_data = json.loads(data) if data else ''
                user_id = user_data.get('listingReducer').get(
                    'selectedListing').get('user_id')if user_data else ''
            user_id = user_id if user_id else ''

            phone_numbers = re.findall(
                r'{"usersInfo.*?\"phone\":\d+,', phone_script[0].strip()) if phone_script else ''

            phone_numbers = phone_numbers[0].strip() if phone_numbers else ''
            phone_numbers = re.findall(
                r'\"phone\":\d+,', phone_numbers.strip()) if phone_script else ''
            phone_numbers = phone_numbers[0].strip().strip(
                '\"phone\":').strip(',') if phone_numbers else ''
            if phone_numbers =='0' or phone_numbers is None:
                # phone_url ='https://sa.aqar.fm/graphql'
                # # phone_form_data ='{\"query\":\"{\n  Web {\n    getPhone(id:'+id_+')\n  }\n}\"}'
                # payload = {"query":"{\n  Web {\n    getPhone(id: "+id_+")\n  }\n}"}
                # phone_header={"accept-encoding": "gzip, deflate, br",
                #     "accept-language": "en-GB,en-US;q=0.9,en;q=0.8", 
                #     "content-type": "application/json", 
                #     "origin": "https://sa.aqar.fm", 
                #     'referer' : response.url,
                #     "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36" 
                #     }
                proxy = parse_proxy()
                proxies = proxy['proxies']
                # try:
                #     phone_response = requests.post(phone_url,headers=phone_header, proxies=proxies, json=payload)
                #     phone_json = phone_response.json()
                #     print("XXXXXXXXX Phone Json XXXXXXXX", phone_json)
                #     phone_numbers =phone_json.get('data','').get('Web','').get('getPhone')
                # except:
                #     phone_numbers=''

                url = url.strip()
                h = {"accept": "*/*",
                     "accept-encoding": "gzip, deflate, br",
                     "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
                     "cache-control": "no-cache",
                     "content-length": "57",
                     "content-type": "application/json",
                     "pragma": "no-cache",
                     "sec-fetch-dest": "empty",
                     "referer": url.encode(),
                     "sec-fetch-mode": "cors",
                     "sec-fetch-site": "same-origin",
                     "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36", }

                id_ = url.split('-')[-1].strip()
                payload = {"query": "{\n  Web {\n    getPhone(id: "+id_+")\n  }\n}"}
                phone_response = None
                phone_json = None
                try:
                    phone_response = requests.post(
                        phone_url, json=payload, headers=h, proxies=proxies)
                    phone_json = phone_response.json()
                except:
                    try:
                        phone_response = requests.post(
                            phone_url, json=payload, headers=h, proxies=proxies)
                        phone_json = phone_response.json()
                    except:
                        pass
                if phone_json:
                    phone_number = phone_json.get('data', {}).get(
                        'Web', {}).get('getPhone', '')
                    errors = phone_json.get('errors')
                    if phone_number:
                        phone_number = phone_number
                    else:
                        phone_number = ''


            images_json=re.findall('imgs":.*?]',str(response.body))
            if images_json:
                image1 = images_json[0].replace('imgs":[','').replace(']','').split(',') 
                number_of_photos = len(image1)
            else:
                number_of_photos=''
            lat_long = lat_long.strip() if lat_long else ''
            lat_long = re.findall(r'\"premium\":\d+,\"location\":{\"lat\":.*?,\"lng\":.*?},\"links\"', lat_long) if lat_long else ''
            latitude = re.findall(r'\"lat\":.*?,', lat_long) if lat_long else ''
            latitude = latitude[0].strip().strip(
                '"lat":').strip(',').strip() if latitude else ''
            longitude = re.findall(r'\"lng\":.*?}', lat_long) if lat_long else ''
            longitude = longitude[0].strip().strip('"lng":').strip(
                ',').strip('}').strip() if longitude else ''

            scraped_ts = (datetime.now()).strftime("%Y-%m-%d")

            now = datetime.now()
            current = datetime(now.year, now.month, 1)
            next_month = datetime(now.year + int(now.month / 12), ((now.month % 12) + 1), 1)
            now_date_int = int(now.strftime("%d"))
            if now_date_int <=31 and now_date_int >=25:
                iteration_month = next_month.strftime("%m")
                iteration_year = next_month.strftime("%Y")
            else:
                iteration_month = now.strftime("%m")
                iteration_year = now.strftime("%Y")
            iteration_number = iteration_year + '_'+ iteration_month
            latitude = latitude if latitude else ''
            longitude = longitude if longitude else ''
            published_at = published_at[0].strip() if published_at else ''

            item = AqarKsaItem(
                reference_number='',
                id=id_,
                url=url,
                broker_display_name=broker,
                broker=broker.upper(),
                category=category,
                category_url=category_url,
                title=name,
                description=description,
                location='',
                price=price_value,
                currency=currency,
                price_per=price_per_,
                bedrooms=bedrooms,
                bathrooms=bathroom,
                furnished='',
                rera_permit_number='',
                dtcm_licence='',
                scraped_ts=scraped_ts,
                amenities=amenities,
                details=area,
                agent_name='',
                number_of_photos=number_of_photos,
                user_id=user_id,
                phone_number=phone_number,
                date=scraped_ts,
                iteration_number=iteration_number,
                latitude=latitude,
                longitude=longitude,
                published_at=published_at,
            )

            if url:
                logging.warning(dict(item))
                try:
                    db[MONGODB_COLLECTION_AGENT].insert(dict(item))
                except Exception:
                    print("Dropping duplicate item")
                    pass


    # Errorback to put failed urls back in queue
    def errback_httpbin(self, failure, url):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=600))
        channel = connection.channel()
        channel.queue_declare(queue=QUEUE_NAME, durable=True)
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=url)
        connection.close()
