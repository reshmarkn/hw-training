# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
import random

from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime
from time import sleep

from aqar_ksa.items import *
from aqar_ksa.settings import *


class AqarKsaCrawlerNewSpider(Spider):
    name = 'aqar_ksa_crawler_new'
    start_urls = ['https://sa.aqar.fm/']

    # headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    #            'Accept-Encoding': 'gzip, deflate, sdch, br',
    #            'User-Agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Mobile Safari/537.36'}
    headers = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
               'accept-encoding': 'gzip, deflate',
               'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
               'upgrade-insecure-requests': '1',
               'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Mobile Safari/537.36'
               }

    def parse(self, response):
        name_link = response.xpath(
            '//h4/a[@class="listTitle"]/@href').extract()
        for n_links in name_link:
            name_url = response.urljoin(n_links)
            item = AqarKsaUrlItem(
                url=name_url,
            )
            yield item


        next_page = response.xpath('//a[@rel="next"]/@href').extract()
        if next_page:
            next_url = response.urljoin(next_page[0])
            meta={'url':next_url}
            sleep(2)
            yield Request(next_url, headers=self.headers, meta=meta, callback=self.parse)

        category_links = response.xpath(
            '//a[@class="catLink"]/@href').extract()
        for links in category_links:
            category_urls = 'https://sa.aqar.fm' + links
            meta={'url':category_urls}
            yield Request(category_urls, headers=self.headers, meta=meta, callback=self.category_data)


        city_links = response.xpath('//div[@class="cityLinks"]//a/@href').extract()
        for links in city_links:
            city_urls = 'https://sa.aqar.fm' + links
            meta={'url':city_urls}
            yield Request(city_urls, headers=self.headers, meta=meta, callback=self.parse_data)

    def parse_data(self, response):
        if response.status == 400:
            sleep(5)
            url = response.meta['url']
            meta={'url':url}
            yield Request(url, headers=self.headers, meta=meta, callback=self.parse_data)

        name_link = response.xpath(
            '//h4/a[@class="listTitle"]/@href').extract()
        for n_links in name_link:
            name_url = response.urljoin(n_links)
            item = AqarKsaUrlItem(
                url=name_url,
            )
            yield item

        next_page = response.xpath('//a[@rel="next"]/@href').extract()
        if next_page:
            next_url = response.urljoin(next_page[0])
            meta={'url':next_url}
            sleep(2)
            yield Request(next_url, headers=self.headers, meta=meta, callback=self.parse_data)

        city_links = response.xpath('//div[@class="cityLinks"]//a/@href').extract()
        for links in city_links:
            city_urls = 'https://sa.aqar.fm' + links
            meta={'url':city_urls}
            
            yield Request(city_urls, headers=self.headers, meta=meta, callback=self.parse_data)

    def category_data(self, response):
        if response.status == 400:
            sleep(5)
            url = response.meta['url']
            meta={'url':url}
            yield Request(url, headers=self.headers, meta=meta, callback=self.parse_data)

        name_link = response.xpath(
            '//h4/a[@class="listTitle"]/@href').extract()
        for n_links in name_link:
            name_url = response.urljoin(n_links)
            item = AqarKsaUrlItem(
                url=name_url,
            )
            yield item

        next_page = response.xpath('//a[@rel="next"]/@href').extract()
        if next_page:
            next_url = response.urljoin(next_page[0])
            meta={'url':next_url}
            sleep(2)
            yield Request(next_url, headers=self.headers, meta=meta, callback=self.category_data)

        city_links = response.xpath('//div[@class="cityLinks"]//a/@href').extract()
        for links in city_links:
            city_urls = 'https://sa.aqar.fm' + links
            meta={'url':city_urls}
            
            yield Request(city_urls, headers=self.headers, meta=meta, callback=self.category_data)
