import random
import base64
from scrapy.utils.project import get_project_settings
import requests




def parse_proxy():
    settings = get_project_settings()
    # storm

    # proxies = {'http': 'http://5.79.66.2:13200',
    #            'https': 'https://5.79.66.2:13200', }

    # torr

    # PROXY_LIST = requests.get(
    #     'http://68.183.58.145/torproxies', headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
    # proxies = {'http':'http://104.236.18.76:5566',
    #   'https':'https://104.236.18.76:5566',}

    # microleaves
    # PROXY_LIST = requests.get('http://68.183.58.145/microleaves',
    # headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()

    PROXY_LIST = requests.get('http://68.183.58.145/stormproxies', headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()

    PROXY = random.choice(PROXY_LIST)
    proxies = {"http": "http://%s" % PROXY,
               "https": "https://%s" % PROXY}

    user_agent = random.choice(settings.get('USER_AGENT_LIST'))
    headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
        'accept-encoding': 'gzip, deflate, br',
        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
        'cache-control': 'no-cache',
        'pragma': 'no-cache',
        'upgrade-insecure-requests': '1',
        'user-agent': user_agent,
    }

    return {'headers': headers, 'proxies': proxies}
