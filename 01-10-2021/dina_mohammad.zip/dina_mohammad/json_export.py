import os
import pymongo
from pymongo import MongoClient
from datetime import datetime

now = datetime.now()
current = datetime(now.year, now.month, 1)
next_month = datetime(now.year + int(now.month / 12), ((now.month % 12) + 1), 1)
now_date_int = int(now.strftime("%d"))
if now_date_int <= 31 and now_date_int >= 25:
    iteration_month = next_month.strftime("%m")
    iteration_year = next_month.strftime("%Y")
else:
    iteration_month = now.strftime("%m")
    iteration_year = now.strftime("%Y")
iteration_number = iteration_year + '_' + iteration_month

db = 'dina_mohammad_monthly_' + iteration_number



coll_list = ['aqar_ksa', 'aqarmap_egp', 'bayut_uae', 'bayut_ksa', 'dubizzle_uae', 'emlakjet_tur', 
			 'olx_egp', 'olx_bah', 'qatarliving_qat', 'zaahib_ksa', 'houza_uae','isqan_egp','sakneen_egp']

for coll in coll_list:
	coll = coll + '_' +iteration_number
    out = coll+'.json'
    # out = 'bayut_uae_2020_08_4.json'
    os.system(
        '''mongoexport --host 104.131.41.31 --forceTableScan  --port 27017 --db {}  -c {} --username datahut --password 'cGFzc21lMTIz' --authenticationDatabase admin  | sed '/"_id":/s/"_id":[^,]*,//' > {}'''.format(db, coll, out))
    print('exported: ', out)
