import pymongo
import requests
import json
import random
from rmq import RmqHandler
from pymongo import MongoClient
from datetime import datetime
import logging
# url = 'https://45.60.244.176/en/property-for-sale/dpv/svc/api/v1/listing-id?category_id=24&listing_id=21650663'
# url = 'https://uae.dubizzle.com/en/property-for-sale/dpv/svc/api/v1/listing/property-for-rent/residential/apartmentflat/2020/11/29/neat-and-clean-2bhk-in-al-warqaa-only-40k--2/'
h = {
	'User-Agent': 'Android',
	'x-access-token': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJpZCI6IjI0MDE4YmUxLTFmOTgtNDU5NC04ZmQyLTg2ODg3MGNkNjI4MCIsImlzcyI6ImR1Yml6emxlLmNvbSIsImF1ZCI6WyJkdWJpenpsZS5jb20iXSwic3ViIjoiMjQwMThiZTEtMWY5OC00NTk0LThmZDItODY4ODcwY2Q2MjgwIiwiZXhwIjoxNjMwMDY2ODQ1LCJpYXQiOjE2Mjk5ODA0NDUsImp0aSI6IjY0NWFkYmZmLWI5NWEtNDM5Yy1iYTIxLTVkMWIwYzc3ZTM3MiIsInR5cCI6IkFjY2VzcyBKV1QgVG9rZW4iLCJmbGFncyI6eyJsb2dnZWRfaW4iOmZhbHNlLCJpc19zdGFmZiI6ZmFsc2UsImlzX3N1cGVydXNlciI6ZmFsc2UsImlzX3Byb3BlcnR5X2FnZW50IjpmYWxzZSwiaXNfbGFuZGxvcmQiOmZhbHNlLCJpc19tb3RvcnNfYWdlbnQiOmZhbHNlLCJpc19qb2JzX2FnZW50IjpmYWxzZSwiaGFzX2NhbGxfdHJhY2tpbmciOmZhbHNlfSwidXNlcl9kYXRhIjp7InVzZXJfaWQiOm51bGwsImdlbmRlciI6bnVsbCwibmF0aW9uYWxpdHkiOm51bGwsImVkdWNhdGlvbiI6bnVsbCwicm9sZSI6bnVsbCwiZG9iIjpudWxsLCJhZ2UiOm51bGwsImZpcnN0X25hbWUiOiIiLCJsYXN0X25hbWUiOiIiLCJlbWFpbCI6IiIsInBob25lIjoiIn19.oUnkNagjiIetWYPoTJWeUlPdUMhIWs7bjNAtnAxxhRYpJHQFed8Za-aIJLrL5S1mwOqdgVaSFgxQIesVVtn5By16JiTdsuDDE_KVfCQdWwkQwKFcNMbhLsn4Hf897-t_jdQtv0ARA9r9PbOw9ATTL6uS1If3Gh-zTR6wvKEJxS2iv1N1ecmdQ3Qed2o1Zvdsda2V-7-wqdBYC6ejn8K0nW5wdR3oN2U8K2UjPiYnyDh2jpC8TsMgGUF3Bkcs_S1pK-J4Vb_Yufnr0YzW4Q62ZcbJvXhFOc6gIFORE_UQAfGv3NTelpAGRNKqt-utlxX6m0_HqkfarRGaEHEHZ-gmJH6Ti3OYh0Lq8Rle6lN75A_4784mWIvJi3EQGDMBrtpkZfu0IDQoJtAm0w4CaROuDJrawfUexSDTA8nZJWETLBJVJrzBtkLNx2niebIXRmERj8vE7-P4WMrPV3p9oM42W-DqyI59Rzbd2BCAqWqyuZk1JVOWHtggaq_PpfdmswKKns9RFZeTcnJ-HVl5wHKA8eWITQQbmlMG9HgJkdEwkTDvH4-na91_epGT4jjEyA3029njmT6JAGmiMCsAiEjrAQDC8YGFTadm3ChIYT0ExUFa4BDiAVNNMWo6x8RHFJBJYcKOe6OWHGsVh6qKO3n6CIbyF__7CzDgs3iejDrR3AE',
	'Content-Type': 'application/json',
	'Host': 'uae.dubizzle.com',
	'Connection': 'Keep-Alive',
	'Accept-Encoding': 'gzip'
}

# PROXY_LIST = requests.get('http://68.183.58.145/microleaves',
#                           headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()

PROXY_LIST = requests.get(
    'http://68.183.58.145/torproxies', headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()


PROXY = random.choice(PROXY_LIST)
proxies = {"http": "http://%s" % PROXY,
                   "https": "https://%s" % PROXY}

# proxies = {'http': 'http://68.183.58.145:5566',
# 		   'https': 'https://68.183.58.145:5566'}


now = datetime.now()
current = datetime(now.year, now.month, 1)
next_month = datetime(now.year + int(now.month / 12), ((now.month % 12) + 1), 1)
now_date_int = int(now.strftime("%d"))
if now_date_int <=31 and now_date_int >=25:
	iteration_month = next_month.strftime("%m")
	iteration_year = next_month.strftime("%Y")
else:
	iteration_month = now.strftime("%m")
	iteration_year = now.strftime("%Y")
iteration_number = iteration_year + '_'+ iteration_month


MONGODB_DB = 'dina_mohammad_monthly_' + iteration_number
failed_urls ='dubizzle_failed_'+iteration_number
other_response = 'dubizzle_other_response_' + iteration_number
success_urls = 'dubizzle_success_' + iteration_number

client = MongoClient('mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
try:
	client.admin.command("enablesharding", MONGODB_DB)
except:
	pass
try:
	client.admin.command("shardcollection", MONGODB_DB + "." + failed_urls, key={'url': 1}, unique=True)
except:
	pass
try:
	client.admin.command("shardcollection", MONGODB_DB + "." + other_response, key={'url': 1}, unique=True)
except:
	pass
try:
	client.admin.command("shardcollection", MONGODB_DB + "." + success_urls, key={'url': 1}, unique=True)
except:
	pass

# db = MongoClient(
#     'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')[MONGODB_DB]

# client = MongoClient(
#     'mongodb://datahut:cGFzc21lMTIz@64.225.9.179:27017')
db = client[MONGODB_DB]
# try:
#     db[failed_urls].create_index(
#         [('url', pymongo.DESCENDING)], unique=True)

# except:
#     pass
# try:
#     db[other_response].create_index(
#         [('url', pymongo.DESCENDING)], unique=True)

# except:
#     pass
# try:
#     db[success_urls].create_index(
#         [('url', pymongo.DESCENDING)], unique=True)

# except:
#     pass

# db = client[MONGODB_DB]




QUEUE_IP = '159.89.47.171'
QUEUE_NAME = 'ha.dubizzle_uae'
QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'

def parse(url_):
	logging.warning(url_)
	url = 'https://uae.dubizzle.com/en/property-for-sale/dpv/svc/api/v1/listing' + url_.strip().split('dubizzle.com')[-1]
	c = ''
	print('api_url : ',url)
	try:
		c = requests.get(url, headers=h, proxies=proxies, verify=False)
	except:
		try:
			c = requests.get(url, headers=h, proxies=proxies, verify=False)
		except:
			pass

	if c == '':
		print('failed : ',url_)
		item1={}
		item1['url'] = url_
		try:
			db[failed_urls].insert_one(dict(item1))
		except:
			pass
	else:
		if c.status_code == 200:
			scraped_ts = (datetime.now()).strftime("%Y-%m-%d")
			print('success : ',url_)
			json_data = json.dumps(c.json())
			item2={}
			item2['json_data'] = json_data
			item2['url'] = url_
			item2['scraped_ts'] = scraped_ts
			try:
				db[success_urls].insert_one(dict(item2))
			except:
				pass
		elif c.status_code == 401:
			print('others : ',url_)
			item3={}
			item3['response_code'] = str(c.status_code)
			item3['resonse'] = c.content
			item3['url'] = url_
			try:
				db[other_response].insert_one(dict(item3))
			except:
				pass

		else:
			print('others : ',url_)
			item3={}
			item3['response_code'] = str(c.status_code)
			if c.content:
				item3['resonse'] = c.content
			item3['url'] = url_
			try:
				db[other_response].insert_one(dict(item3))
			except:
				pass
	client.close()


if __name__ == "__main__":

	# try:
	# 	rmqh = RmqHandler(QUEUE_NAME, ip=QUEUE_IP,user=QUEUE_USER, pwd=QUEUE_PASS)
	# 	while True:
	# 		count, data = rmqh.get()
	# 		if not data:
	# 			break
	# 		url_ = str(data.strip())
	# except:
	# 	try:
	# 		rmqh = RmqHandler(QUEUE_NAME, ip=QUEUE_IP,user=QUEUE_USER, pwd=QUEUE_PASS)
	# 		while True:
	# 			count, data = rmqh.get()
	# 			if not data:
	# 				break
	# 			url_ = str(data.strip())
	# 	except:
	# 		rmqh = RmqHandler(QUEUE_NAME, ip=QUEUE_IP,user=QUEUE_USER, pwd=QUEUE_PASS)
	# 		while True:
	# 			count, data = rmqh.get()
	# 			if not data:
	# 				break
	# 			url_ = str(data.strip())
	rmqh = RmqHandler(QUEUE_NAME, ip=QUEUE_IP,user=QUEUE_USER, pwd=QUEUE_PASS)
	while True:
		count, data = rmqh.get()
		if not data:
			break
		url_ = str(data.strip())
		logging.warning(url_)
		if url_:
			logging.warning('/////////////////////////url fetched from queue/////////////////////')
			logging.warning(url_)
			parse(url_)
