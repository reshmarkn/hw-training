# -*- coding: utf-8 -*-
import scrapy


class DubizzleUrlItem(scrapy.Item):

    url = scrapy.Field()


class DubizzleItem(scrapy.Item):

    reference_number = scrapy.Field()
    id = scrapy.Field()
    url = scrapy.Field()
    broker_display_name = scrapy.Field()
    broker = scrapy.Field()
    category = scrapy.Field()
    category_url = scrapy.Field()
    title = scrapy.Field()
    description = scrapy.Field()
    location = scrapy.Field()
    price = scrapy.Field()
    currency = scrapy.Field()
    price_per = scrapy.Field()
    bedrooms = scrapy.Field()
    bathrooms = scrapy.Field()
    furnished = scrapy.Field()
    rera_permit_number = scrapy.Field()
    dtcm_licence = scrapy.Field()
    scraped_ts = scrapy.Field()
    amenities = scrapy.Field()
    details = scrapy.Field()
    agent_name = scrapy.Field()
    number_of_photos = scrapy.Field()
    user_id = scrapy.Field()
    phone_number = scrapy.Field()
    date = scrapy.Field()
    iteration_number = scrapy.Field()