# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
import io
import gzip

from xml.dom import minidom
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from dubizzle.items import *
from dubizzle.settings import *

from datetime import datetime

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


class DubizzleCrawlerSpider(scrapy.Spider):
    name = "dubizzle_crawler"

    start_urls = [
                'https://dubai.dubizzle.com/sitemaps/sitemaps/property-for-rent-dpv-en-1.xml',
                'https://dubai.dubizzle.com/sitemaps/sitemaps/property-for-rent-dpv-en-2.xml',
                'https://dubai.dubizzle.com/sitemaps/sitemaps/property-for-rent-dpv-en-3.xml',
                'https://dubai.dubizzle.com/sitemaps/sitemaps/property-for-rent-dpv-en-4.xml',
                'https://dubai.dubizzle.com/sitemaps/sitemaps/property-for-sale-dpv-en-1.xml',
                'https://dubai.dubizzle.com/sitemaps/sitemaps/property-for-sale-dpv-en-2.xml',
                'https://abudhabi.dubizzle.com/sitemaps/sitemaps/property-for-rent-dpv-en-1.xml',
                'https://abudhabi.dubizzle.com/sitemaps/sitemaps/property-for-sale-dpv-en-1.xml',
                'https://rak.dubizzle.com/sitemaps/sitemaps/property-for-rent-dpv-en-1.xml',
                'https://rak.dubizzle.com/sitemaps/sitemaps/property-for-sale-dpv-en-1.xml',
                'https://sharjah.dubizzle.com/sitemaps/sitemaps/property-for-rent-dpv-en-1.xml',
                'https://sharjah.dubizzle.com/sitemaps/sitemaps/property-for-sale-dpv-en-1.xml',
                'https://fujairah.dubizzle.com/sitemaps/sitemaps/property-for-rent-dpv-en-1.xml',
                'https://fujairah.dubizzle.com/sitemaps/sitemaps/property-for-sale-dpv-en-1.xml',
                'https://ajman.dubizzle.com/sitemaps/sitemaps/property-for-rent-dpv-en-1.xml',
                'https://ajman.dubizzle.com/sitemaps/sitemaps/property-for-sale-dpv-en-1.xml',
                'https://uaq.dubizzle.com/sitemaps/sitemaps/property-for-rent-dpv-en-1.xml',
                'https://uaq.dubizzle.com/sitemaps/sitemaps/property-for-sale-dpv-en-1.xml',
                'https://alain.dubizzle.com/sitemaps/sitemaps/property-for-rent-dpv-en-1.xml',
                'https://alain.dubizzle.com/sitemaps/sitemaps/property-for-sale-dpv-en-1.xml',
    ]

    allowed_domains = ['dubizzle.com']

    def parse(self, response):
        xmldoc = minidom.parseString(response.body)
        LOCS = xmldoc.getElementsByTagName('loc')
        for loc in LOCS:
            url_ = loc.childNodes[0].data
            item = DubizzleUrlItem(
                url=url_.strip(),
            )
            yield item
