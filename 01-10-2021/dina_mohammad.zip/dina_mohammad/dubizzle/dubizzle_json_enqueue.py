import pika
import json
from time import sleep

# QUEUE_IP = '104.236.210.100' #beta1
# QUEUE_IP = '104.236.210.101' #beta2
# QUEUE_IP = '104.236.210.106' #beta3
# QUEUE_IP = '104.236.122.186' #beta4
# QUEUE_IP = '104.236.192.43' #beta5
# QUEUE_IP = '104.236.193.20' #beta6
# QUEUE_IP = '138.197.109.170' #alpha1
# QUEUE_IP = '138.197.103.108' #alpha2
# QUEUE_IP = '138.197.105.12' #alpha3
# QUEUE_IP = '138.197.105.52' #alpha4
QUEUE_IP = '159.89.47.171'  # new
# QUEUE_IP = '134.209.174.206'  # new

QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'
# QUEUE_PASS = 'betaqueue123'

QUEUE_NAME = 'ha.dubizzle_uae_json'

credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
connection = pika.BlockingConnection(pika.ConnectionParameters(
    credentials=credentials, host=QUEUE_IP, socket_timeout=3000))
channel = connection.channel()

f = open('dubizzle_success_2021_09.json')
lines = f.readlines()
channel.queue_declare(queue=QUEUE_NAME, durable=True)
for line in lines:
    channel.basic_publish(
        exchange='', routing_key=QUEUE_NAME, body=line.strip())
    sleep(0.001)
