import json 
import logging
from datetime import datetime
import lxml.html
from pymongo import MongoClient
from rmq import RmqHandler

logger = logging.getLogger('pika')
logger.propagate = False

now = datetime.now()
current = datetime(now.year, now.month, 1)
next_month = datetime(now.year + int(now.month / 12), ((now.month % 12) + 1), 1)
now_date_int = int(now.strftime("%d"))
if now_date_int <=31 and now_date_int >=25:
    iteration_month = next_month.strftime("%m")
    iteration_year = next_month.strftime("%Y")
else:
    iteration_month = now.strftime("%m")
    iteration_year = now.strftime("%Y")
iteration_number = iteration_year + '_'+ iteration_month


MONGODB_DB = 'dina_mohammad_monthly_' + iteration_number
COLLECTION_NAME='dubizzle_uae_'+iteration_number

client = MongoClient('mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
try:
    client.admin.command("enablesharding", MONGODB_DB)
except:
    pass
try:
    client.admin.command("shardcollection", MONGODB_DB + "." + COLLECTION_NAME, key={'url': 1}, unique=True)
except:
    pass

# db = MongoClient(
#     'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')[MONGODB_DB]

# client = MongoClient(
#     'mongodb://datahut:cGFzc21lMTIz@64.225.9.179:27017')
# db = client[MONGODB_DB]
# try:
#     db[COLLECTION_NAME].create_index(
# [('url', pymongo.DESCENDING)], unique=True)
# except:
#     pass

db = client[MONGODB_DB]


QUEUE_IP = '159.89.47.171'
QUEUE_NAME = 'ha.dubizzle_uae_json'
QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'

def parse(item):
    input_url = item.get('url')
    scraped_ts = item.get('scraped_ts')
    logging.warning('input url is readded from the db')
    logging.warning(input_url)
    final_raw = item.get('json_data')
    final_json = json.loads(final_raw)
    final_raw = final_json.get('data', {})
    if final_raw:
        url = final_raw.get('absolute_url')
        name = str(final_raw.get('name_en', ''))
        title = name
        reference_number = str(final_raw.get(
            'company_item_id', ''))
        id_ = str(final_raw.get('id', ''))
        # url = url.replace(
        #     '/en/property-for-sale/dpv/svc/api/v1/listing', '/')

        broker_display_name = final_raw.get('agent_name', '')
        broker = broker_display_name.upper() if broker_display_name else ''
        broker_display_name = broker_display_name if broker_display_name else ''

        if '/property-for-sale/' in url:
            category = 'sale'
            category_url = '/property-for-sale/home/'
        elif '/property-for-rent/' in url:
            category = 'rent'
            category_url = '/property-for-rent/home/'
        else:
            category = ''
            category_url = ''
        
        if '/commercial/' in url:
            sub_category_1 = 'commercial'
        elif  '/multiple-units/' in url:
            sub_category_1 = 'commercial'
        elif '/land/' in url:
            sub_category_1 = 'commercial'
        else:
            sub_category_1 = 'residential'


        if '/rooms-for-rent-flatmates/' in url:
            sub_category_2 = 'rooms for rent flatmates'
        elif '/short-term/' in url:
            sub_category_2 = 'short term'
        elif '/short-term-daily/' in url:
            sub_category_2 = 'short term daily'
        else:
            sub_category_2 = ''

        property_type = final_raw.get(
            'category')[0].get('slug') if final_raw.get(
            'category') else ''
        added_ts = final_raw.get('added')
        added_ = datetime.fromtimestamp(added_ts)
        published_at = added_.strftime("%Y-%m-%d")


        description_text = final_raw.get('description_en', '')
        des_sel = lxml.html.fromstring(
            description_text) if description_text else ''
        description = ' '.join(des_sel.xpath(
            '//text()')) if description_text else ''

        location_path = final_raw.get('location_path', '')
        location_path = location_path.get('en') if location_path else ''
        location = ', '.join(
            [x.strip() for x in location_path]) if location_path else ''

        price = str(final_raw.get('price', ''))
        currency = 'AED'
        price_per = final_raw.get('rent_is_paid_display_en', '')

        bedrooms = str(final_raw.get('bedrooms', ''))
        bathrooms = str(final_raw.get('bathrooms', ''))
        furnished = "Yes" if final_raw.get('furnished', '') else ''

        rera_permit_number = str(final_raw.get('rera_permit_number', ''))
        rera_registration_number = str(final_raw.get(
            'rera_registration_number', ''))
        dtcm_licence = ''

        amenities = []
        amenities_list = final_raw.get('tag_dicts', [])
        if amenities_list:
            for am in amenities_list:
                amenities_name = am.get('name_en', '')
                amenities.append(amenities_name) if amenities_name else ''
        if amenities:
            amenities_ = ', '.join(amenities)
        else:
            amenities_ = ''
        amenities = ''
        agent_name = ''
        user_id = ''
        details = str(final_raw.get('size', ''))
        details = 'Area:' + details if details else ''
        number_of_photos = str(final_raw.get('photos_count', ''))
        phone_number = str(final_raw.get('phone_number', ''))

        longitude = final_raw.get('location_get_x', '')
        latitude = final_raw.get('location_get_y', '')

        promoted = 'promoted' if final_raw.get('promoted') else ''
        featured_listing = 'featured' if final_raw.get('featured_listing') else ''
        package_type = promoted + ', ' + featured_listing
        package_type = package_type.strip().strip(',').strip()

        # scraped_ts = (datetime.now()).strftime("%Y-%m-%d")
        date = scraped_ts

        # iteration_number
        now = datetime.now()
        current = datetime(now.year, now.month, 1)
        next_month = datetime(now.year + int(now.month / 12), ((now.month % 12) + 1), 1)
        now_date_int = int(now.strftime("%d"))
        if now_date_int <= 31 and now_date_int >= 25:
            iteration_month = next_month.strftime("%m")
            iteration_year = next_month.strftime("%Y")
        else:
            iteration_month = now.strftime("%m")
            iteration_year = now.strftime("%Y")
        iteration_number = iteration_year + '_' + iteration_month

        data = {
            'reference_number': reference_number,
            'id': id_,
            'url': str(url),
            'broker_display_name': broker_display_name,
            'broker': broker,
            'category': category,
            'category_url': category_url,
            'title': title,
            'description': description,
            'location': location,
            'price': price,
            'currency': currency,
            'price_per': price_per,
            'bedrooms': bedrooms,
            'bathrooms': bathrooms,
            'furnished': furnished,
            'rera_permit_number': rera_permit_number,
            'rera_registration_number': rera_registration_number,
            'dtcm_licence': '',
            'amenities': amenities_,
            'details': details,
            'agent_name': '',
            'number_of_photos': number_of_photos,
            'user_id': user_id,
            'phone_number': phone_number,
            'scraped_ts': scraped_ts,
            'date': date,
            'iteration_number': iteration_number,
            'latitude': latitude,
            'longitude': longitude,
            'depth': package_type,
            'package_type' : package_type,
            'sub_category_1' : sub_category_1,
            'sub_category_2' : sub_category_2,
            'property_type' : property_type,
            'published_at' : published_at,
        }
        if name:
            # logging.warning(data)
            try:
                logging.warning(data)
                db[COLLECTION_NAME].insert(dict(data))
            except:
                logging.warning('droping duplicate items')
    client.close()
if __name__ == "__main__":
    rmqh = RmqHandler(QUEUE_NAME, ip=QUEUE_IP,user=QUEUE_USER, pwd=QUEUE_PASS)
    while True:
        count, data = rmqh.get()
        if not data:
            break
        
        item =json.loads(data)
        parse(item)
    # try:
    #     rmqh = RmqHandler(QUEUE_NAME, ip=QUEUE_IP,user=QUEUE_USER, pwd=QUEUE_PASS)
    #     while True:
    #         count, data = rmqh.get()
    #         if not data:
    #             break
    #         item =json.loads(data)
            
    # except:
    #     try:
    #         rmqh = RmqHandler(QUEUE_NAME, ip=QUEUE_IP,user=QUEUE_USER, pwd=QUEUE_PASS)
    #         while True:
    #             count, data = rmqh.get()
    #             if not data:
    #                 break
    #             item =json.loads(data)
               
    #     except:
    #         rmqh = RmqHandler(QUEUE_NAME, ip=QUEUE_IP,user=QUEUE_USER, pwd=QUEUE_PASS)
    #         while True:
    #             count, data = rmqh.get()
    #             if not data:
    #                 break
    #             item =json.loads(data)
                