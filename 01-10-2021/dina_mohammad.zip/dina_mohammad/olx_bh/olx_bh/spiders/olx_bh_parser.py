# -*- coding: utf-8 -*-
import scrapy
import string
import pika
import logging
import requests
import re
import json

from scrapy.http import Request, FormRequest
from scrapy.selector import Selector
from time import sleep
from datetime import datetime
from scrapy.shell import inspect_response
from rmq import RmqHandler


from olx_bh.settings import *
from olx_bh.items import *

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

class OlxBhParserSpider(scrapy.Spider):
    name = "olx_bh_parser"
    allowed_domains = ["olx.com.bh"]
    start_urls = ['https://olx.com.bh/en/properties/']
    def start_requests(self):
        rmqh = RmqHandler(QUEUE_NAME, ip=QUEUE_IP,user=QUEUE_USER, pwd=QUEUE_PASS)
        while True:
            count, data = rmqh.get()
            if not data:
                break
            if data:
                url = data
                if '/en/' not in url:
                    url = url.replace('/ad/', '/en/ad/').strip()
                yield Request(url=url, callback=self.parse_data)



    #     urls =['https://olx.com.bh/en/properties/properties-for-rent/apartments-for-rent/',
    #             'https://olx.com.bh/en/properties/properties-for-rent/commercial-for-rent/',
    #             'https://olx.com.bh/en/properties/properties-for-rent/chalet-for-rent/',
    #             'https://olx.com.bh/en/properties/properties-for-rent/rooms-for-rent/',
    #             'https://olx.com.bh/en/properties/properties-for-rent/villas-for-rent/',
    #             'https://olx.com.bh/en/properties/properties-for-rent/garage-for-rent/',
    #             'https://olx.com.bh/en/properties/properties-for-rent/land-for-rent/',
    #             'https://olx.com.bh/en/properties/properties-for-rent/multiple-units-for-rent/',
    #             'https://olx.com.bh/en/properties/properties-for-sale/apartments-for-sale/',
    #             'https://olx.com.bh/en/properties/properties-for-sale/land-for-sale/',
    #             'https://olx.com.bh/en/properties/properties-for-sale/multiple-units-for-sale/',
    #             'https://olx.com.bh/en/properties/properties-for-sale/chalet-for-sale/',
    #             'https://olx.com.bh/en/properties/properties-for-sale/buildings-for-sale/',
    #             'https://olx.com.bh/en/properties/properties-for-sale/commercial-for-sale/',
    #             'https://olx.com.bh/en/properties/properties-for-sale/villas-for-sale/']
    #     for url in urls:
    #         meta={'url':url}
    #         yield Request(url,callback=self.parse,dont_filter=True,meta=meta)

    # def parse(self, response):
    #     url = response.meta.get('url')
    #     if 'properties-for-rent' in url:
    #         SUB_CATEGORY_1 = 'Residential'
    #     elif 'for-sale' in url:
    #         SUB_CATEGORY_1 ='Commercial'
    #     meta ={'url':url}

    #     sub_cat_links = response.xpath(
    #         '//a[@class="topLink tdnone "]/@href').extract()
    #     sub_loc_links = response.xpath(
    #         '//div[@id="locationLinks"]//a/@href').extract()

    #     if sub_loc_links:
    #         for link in sub_loc_links:
    #             link = link.strip().strip('#')
    #             if 'http' in link:
    #                 yield Request(url=link, callback=self.parse,meta=meta)

    #     if sub_cat_links:
    #         for link in sub_cat_links:
    #             link = link.strip().strip('#')
    #             if 'http' in link:
    #                 yield Request(url=link, callback=self.parse,meta=meta)

    #     links = response.xpath(
    #         '//div[@class="ads__item__info"]/a/@href').extract()
    #     next_page = response.xpath(
    #         '//span[@class="item fright"]/a/@href').extract_first()
    #     for url in links:
    #         url = url.strip()
    #         if '/en/' not in url:
    #             url = url.replace('/ad/', '/en/ad/').strip()
    #         item = OlxBh_url_Item(
    #             url = url,
    #             sub_category_1=SUB_CATEGORY_1,
    #             sub_category_2='',
    #             depth =''
    #             )
    #         if url:
    #             yield item
    #         yield Request(url=url, callback=self.parse_data)
    #     if next_page:
    #         yield Request(next_page, callback=self.parse,meta=meta)

    def parse_data(self, response):
        img = ''
        phone_number = ''
        price_per = ''
        ID_XPATH = '//span[@class="rel inlblk"]/text()'
        BROKER_XPATH = '//p[@class="user-box__info__name"]/text()'
        CATEGORY_XPATH = '//li[contains(@class, "inline")]/a/span/text() | //li[contains(@class, "inline")]/span/a/@href'
        CATEGORY_URL_XPATH = '//li[contains(@class, "inline")]/a/@href'
        PRICE_RAW_XPATH = '//div[@class="pricelabel tcenter"]/strong/text()'
        TITLE_XPATH = '//p[@class="xx-large fbold lheight26 pdingtop10"]/text()'
        DESCRIPTION_XPATH = '//div[@class="clr descriptioncontent marginbott20"]/div[@id="textContent"]//text()'
        BEDROOMS_XPATH = '//th[contains(text(), "غرف نوم")]/following-sibling::td/strong/a/text()|//th[contains(text(),"Bedrooms")]/following-sibling::td[@class="value"]/strong/a/text()'
        BATHROOMS_XPATH = '//th[contains(text(), "الحمامات")]/following-sibling::td[@class="value"]/strong/a/text()|//th[contains(text(),"Bathrooms")]/following-sibling::td[@class="value"]/strong/a/text()'
        FURNISHED_XPATH = '//th[contains(text(), "مفروش")]/following-sibling::td[@class="value"]/strong/a/text()|//th[contains(text(), "Furnished")]/following-sibling::td[@class="value"]/strong/a/text()'
        LOCATION_XPATH = '//span[@class="show-map-link link gray cpointer"]/strong/text()'

        id_ = response.xpath(ID_XPATH).extract()
        broker_display_name = response.xpath(BROKER_XPATH).extract()
        category = response.xpath(CATEGORY_XPATH).extract()
        category_url = response.xpath(CATEGORY_URL_XPATH).extract()
        bedrooms = response.xpath(BEDROOMS_XPATH).extract()
        bathrooms = response.xpath(BATHROOMS_XPATH).extract()
        furnished = response.xpath(FURNISHED_XPATH).extract()
        loc = response.xpath(LOCATION_XPATH).extract()
        price_raw_ = response.xpath(PRICE_RAW_XPATH).extract_first()
        description = response.xpath(DESCRIPTION_XPATH).extract()
        title = response.xpath(TITLE_XPATH).extract()

        id_ = id_[0].strip() if id_ else ''
        broker_display_name = broker_display_name[0].replace("agent", "").replace(
            "The Marketer", "").replace("Real Estate Agent", "").strip() if broker_display_name else ''
        category = ' > '.join(category).strip() if category else ''
        category_url = category_url[-1].strip() if category_url else ''
        category_url = category_url.replace('https://olx.com.bh/', '').strip()
        if '/properties-for-rent/' in category_url:
            category = 'rent'
            category_url = '/en/properties/properties-for-rent/'
        elif '/buy/' in category_url:
            category = 'sale'
            category_url = '/en/properties/properties-for-sale/'

        title = ''.join(title).strip() if title else ''
        description = ' '.join(
            ' '.join(description).split()) if description else ''
        location = loc[0].strip() if loc else ''
        price_raw_ = ''.join(price_raw_).replace("d. B", "").replace("BHD", "").replace(
            u'\u062f. \u0628', '').replace('BHD', '').strip() if price_raw_ else ''
        bedrooms = bedrooms[0].strip() if bedrooms else ''
        bathrooms = bathrooms[0].strip() if bathrooms else ''
        furnished = furnished[0].strip() if furnished else ''
        rera_permit_number = ''
        dtcm_licence = ''

        if bathrooms:
            bathrooms = bathrooms.split('-')
            bathrooms = bathrooms[0].strip()

        if furnished:
            furnished = furnished.split('-')
            furnished = furnished[0].strip()

        if bedrooms:
            bedrooms = bedrooms.split('-')
            bedrooms = bedrooms[0].strip()

        area = response.xpath(
            '//tr/th[contains(text(),"المساحة (م٢)")]/following-sibling::td/strong/text()|//tr/th[contains(text(),"Area (m²)")]/following-sibling::td/strong/text()').extract()
        area = [x.strip().replace('-', '') for x in [x.strip()
                                                     for x in area] if x]if area else ''
        details = ''.join(area).strip() if area else ''
        details = details + "m2" if details else ''
        img1 = response.xpath(
            '//div[@class="tcenter img-item"]/div/img/@src').extract()
        img2 = response.xpath(
            '//div[@class="photo-handler rel inlblk"]/img/@src').extract()
        if img1 and img2:
            img = img1 + img2
        elif img1:
            img = img1
        elif img2:
            img = img2
        img = img if img else ''
        number_of_photos = str(len(img))
        if number_of_photos == '0':
            number_of_photos = ''
        number_of_photos = number_of_photos if number_of_photos else ''

        amen = response.xpath(
            '//tr/th[contains(text(),"Amenities")]/following-sibling::td/strong/a/text()').extract()
        amen = [x.strip() for x in [x.strip()
                                    for x in amen] if x]if amen else ''
        amenities = ', '.join(amen).strip().replace(
            '\t', '').replace('\n', '') if amen else ''

        published_at = response.xpath('//span[contains(text(),"Added at")]/text()').extract()
        published_at = ''.join(published_at).split(',')[1].strip()


        is_phone = response.xpath(
            '//span[@class="link spoiler small nowrap"][contains(text(),"Show phone")]')
        if is_phone:
            ad_id = response.url.split('ID')
            if len(ad_id) == 2:
                ad_id = ad_id[1].replace('.html', '')
                phone_url = 'https://olx.com.bh/en/ajax/misc/contact/phone/'+ad_id+'/'

                h = {'Accept': '*/*',
                     'Accept-Encoding': 'gzip, deflate, br',
                     'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
                     'Cache-Control': 'no-cache',
                     'Connection': 'keep-alive',
                     'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36',
                     'X-Requested-With': 'XMLHttpRequest', }
                try:
                    r = requests.get(phone_url, headers=h)
                    phone_number = r.json().get('value')
                except:
                    try:
                        r = requests.get(phone_url, headers=h)
                        phone_number = r.json().get('value')
                    except:
                        phone_number = ''
                        pass

        # scraped_ts = (datetime.now()).strftime("%Y-%m-%d")
        scraped_ts = (datetime.now()).strftime("%Y-%m-%d")

        now = datetime.now()
        current = datetime(now.year, now.month, 1)
        next_month = datetime(now.year + int(now.month / 12),
                              ((now.month % 12) + 1), 1)
        now_date_int = int(now.strftime("%d"))
        if now_date_int <= 31 and now_date_int >= 25:
            iteration_month = next_month.strftime("%m")
            iteration_year = next_month.strftime("%Y")
        else:
            iteration_month = now.strftime("%m")
            iteration_year = now.strftime("%Y")
        iteration_number = iteration_year + '_' + iteration_month

        item = OlxBhItem(
            reference_number='',
            id=id_,
            url=response.url,
            broker_display_name=broker_display_name,
            broker=broker_display_name.upper(),
            category=category,
            category_url=category_url,
            title=title,
            description=description,
            location=location,
            price=price_raw_,
            currency="BHD",
            price_per=price_per,
            bedrooms=bedrooms,
            bathrooms=bathrooms,
            furnished=furnished,
            rera_permit_number=rera_permit_number,
            dtcm_licence=dtcm_licence,
            scraped_ts=scraped_ts,
            amenities=amenities,
            details=details,
            agent_name='',
            number_of_photos=number_of_photos,
            user_id='',
            phone_number=phone_number,
            date=scraped_ts,
            iteration_number=iteration_number,
            depth='',
            sub_category_1='',
            property_type ='',
            sub_category_2='',
            published_at=published_at,
        )
        if title:
            yield item
