# -*- coding: utf-8 -*-
import scrapy
import string
import pika
import logging
import requests
import re
import json

from scrapy.http import Request, FormRequest
from scrapy.selector import Selector
from time import sleep
from datetime import datetime
from scrapy.shell import inspect_response

from olx_bh.settings import *
from olx_bh.items import *


class OlxBhUrlCrawlerSpider(scrapy.Spider):
    name = "olx_bh_crawler"
    allowed_domains = ["olx.com.bh"]
    start_urls = ['https://olx.com.bh/en/properties/']
    def start_requests(self):
        urls =['https://olx.com.bh/en/properties/properties-for-rent/apartments-for-rent/',
                'https://olx.com.bh/en/properties/properties-for-rent/commercial-for-rent/',
                'https://olx.com.bh/en/properties/properties-for-rent/chalet-for-rent/',
                'https://olx.com.bh/en/properties/properties-for-rent/rooms-for-rent/',
                'https://olx.com.bh/en/properties/properties-for-rent/villas-for-rent/',
                'https://olx.com.bh/en/properties/properties-for-rent/garage-for-rent/',
                'https://olx.com.bh/en/properties/properties-for-rent/land-for-rent/',
                'https://olx.com.bh/en/properties/properties-for-rent/multiple-units-for-rent/',
                'https://olx.com.bh/en/properties/properties-for-sale/apartments-for-sale/',
                'https://olx.com.bh/en/properties/properties-for-sale/land-for-sale/',
                'https://olx.com.bh/en/properties/properties-for-sale/multiple-units-for-sale/',
                'https://olx.com.bh/en/properties/properties-for-sale/chalet-for-sale/',
                'https://olx.com.bh/en/properties/properties-for-sale/buildings-for-sale/',
                'https://olx.com.bh/en/properties/properties-for-sale/commercial-for-sale/',
                'https://olx.com.bh/en/properties/properties-for-sale/villas-for-sale/',
                'https://olx.com.bh/en/properties/properties-for-rent/apartments-for-rent/?search%5Bpaidads_listing%5D=1',
                'https://olx.com.bh/en/properties/properties-for-rent/villas-for-rent/?search%5Bpaidads_listing%5D=1',
                ]
        for url in urls:
            meta={'url':url}
            yield Request(url,callback=self.parse,dont_filter=True,meta=meta)

    def parse(self, response):
        url = response.meta.get('url')
        if 'properties-for-rent' in url:
            SUB_CATEGORY_1 = 'Residential'
        elif 'for-sale' in url:
            SUB_CATEGORY_1 ='Commercial'
        if 'apartments' in url:
            property_type ='Apartments'
        elif 'commercial' in url:
            property_type ='Commercial'
        elif 'chalet' in url:
            property_type='Chalet'
        elif 'rooms' in url:
            property_type='Rooms'
        elif 'villas' in url :
            property_type='Villas'
        elif 'garage' in url:
            property_type='Garage'
        elif 'land' in url:
            property_type='land'
        elif 'multiple-units' in url:
            property_type='Multiple-units'
        elif 'buildings' in url:
            property_type='Buildings'
        if '5Bpaidads_listing' in url:
            depth='featured'
        else:
            depth=''
        meta ={'url':url}

        sub_cat_links = response.xpath(
            '//a[@class="topLink tdnone "]/@href').extract()
        sub_loc_links = response.xpath(
            '//div[@id="locationLinks"]//a/@href').extract()

        if sub_loc_links:
            for link in sub_loc_links:
                link = link.strip().strip('#')
                if 'http' in link:
                    yield Request(url=link, callback=self.parse,meta=meta)

        if sub_cat_links:
            for link in sub_cat_links:
                link = link.strip().strip('#')
                if 'http' in link:
                    yield Request(url=link, callback=self.parse,meta=meta)

        links = response.xpath(
            '//div[@class="ads__item__info"]/a/@href').extract()
        next_page = response.xpath(
            '//span[@class="item fright"]/a/@href').extract_first()
        for url in links:
            url = url.strip()
            if '/en/' not in url:
                url = url.replace('/ad/', '/en/ad/').strip()
            item = OlxBh_url_Item(
                url = url,
                sub_category_1=SUB_CATEGORY_1,
                sub_category_2='',
                depth =depth,
                property_type=property_type

                )
            if url:
                yield item
        if next_page:
            yield Request(next_page, callback=self.parse,meta=meta)