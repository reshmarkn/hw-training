import random
import random
import base64
import requests
from time import sleep
from sahibinden.settings import *
from scrapy.utils.project import get_project_settings


def parse_proxy():

    settings = get_project_settings()

    PROXY = random.choice(PROXY_LIST)
    proxies = {"http": "http://%s" % PROXY,
                       "https": "https://%s" % PROXY}

    user_agent = random.choice(settings.get('USER_AGENT_LIST'))
    headers = {'Accept-Encoding': 'gzip', 'User-Agent': user_agent,
               'Accept': 'application/json, text/javascript, */*; q=0.01', 'X-Requested-With': 'XMLHttpRequest'}
    return {'headers': headers, 'proxies': proxies}
