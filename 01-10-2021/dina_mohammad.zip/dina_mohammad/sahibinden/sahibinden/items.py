# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class SahibindenItem(scrapy.Item):
    id = scrapy.Field()
    url = scrapy.Field()
    broker_display_name = scrapy.Field()
    category = scrapy.Field()
    category_url = scrapy.Field()
    title = scrapy.Field()
    description = scrapy.Field()
    location = scrapy.Field()
    price = scrapy.Field()
    currency = scrapy.Field()
    price_per = scrapy.Field()
    bedrooms = scrapy.Field()
    bathrooms = scrapy.Field()
    furnished = scrapy.Field()
    rera_permit_number = scrapy.Field()
    dtcm_licence = scrapy.Field()
    broker = scrapy.Field()
    scraped_ts = scrapy.Field()
    reference_number = scrapy.Field()
    amenities = scrapy.Field()
    details = scrapy.Field()
    agent_name = scrapy.Field()
    number_of_photos = scrapy.Field()
    user_id = scrapy.Field()
    phone_number = scrapy.Field()
    date = scrapy.Field()
    iteration_number = scrapy.Field()


class SahibindenUrlItem(scrapy.Item):
    url = scrapy.Field()


class SahibindenCatUrlItem(scrapy.Item):
    url = scrapy.Field()


class SahibindenIdItem(scrapy.Item):
    url = scrapy.Field()
    user_id = scrapy.Field()
