import os
import random
from scrapy.utils.project import get_project_settings
import logging
import base64
from sahibinden.storm_proxy import parse_proxy

class ProxyMiddleware(object):
	def process_request(self, request, spider):
		proxy = parse_proxy()
		proxies = proxy['proxies']
		request.meta['proxy'] = proxies['https']
		logging.log(logging.DEBUG, "Proxy added")

class RandomUserAgentMiddleware(object):
	def process_request(self, request, spider):
		settings = get_project_settings()
		ua = random.choice(settings.get('USER_AGENT_LIST'))
		if ua:
			request.headers.setdefault('User-Agent', ua)
		logging.log(logging.DEBUG, "USER AGENT IS: " + ua)
