# # -*- coding: utf-8 -*-

from pymongo import MongoClient
from scrapy.exceptions import DropItem
from sahibinden.items import *
from sahibinden.settings import *

MONGODB_DB = 'dina_mohammad'
MONGODB_COLLECTION_CAT = 'sahibinden_tur_cat_url_2020_08'
MONGODB_COLLECTION_URL = 'sahibinden_tur_url_2020_08'
MONGODB_COLLECTION_AGENT = 'sahibinden_tur_2020_08'


class SahibindenPipeline(object):

    def __init__(self, *args, **kwargs):
        self.client = MongoClient(
            'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')
        try:
            self.client.admin.command("enablesharding", MONGODB_DB)
            self.client.admin.command(
                "shardcollection", MONGODB_DB+'.'+MONGODB_COLLECTION_CAT, key={'url': 1}, unique=True)
        except:
            try:
                self.client.admin.command(
                    "shardcollection", MONGODB_DB+'.'+MONGODB_COLLECTION_CAT, key={'url': 1}, unique=True)
            except:
                pass

        self.db = self.client[MONGODB_DB]

    def process_item(self, item, spider):
        if isinstance(item, SahibindenItem):
            try:
                self.db[MONGODB_COLLECTION_AGENT].insert(
                    dict(item), check_keys=False)
            except:
                raise DropItem("Dropping duplicate item")

        if isinstance(item, SahibindenUrlItem):
            try:
                self.db[MONGODB_COLLECTION_URL].insert(
                    dict(item), check_keys=False)
            except:
                raise DropItem("Dropping duplicate item")
        if isinstance(item, SahibindenCatUrlItem):
            try:
                self.db[MONGODB_COLLECTION_CAT].insert(
                    dict(item), check_keys=False)
            except:
                raise DropItem("Dropping duplicate item")

        return item
