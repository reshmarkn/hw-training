import time
import urllib
import pika
import scrapy
import re
import requests
import json
import logging
import string
import random
from scrapy.http import Request
from datetime import datetime
from time import sleep
from scrapy.shell import inspect_response
from scrapy.http import Request, FormRequest
from string import ascii_lowercase
from scrapy.selector import Selector
from xml.dom import minidom
from sahibinden.storm_proxy import parse_proxy

from sahibinden.items import *
from sahibinden.settings import *


headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9',
    'Host': 'www.sahibinden.com',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Mobile Safari/537.36'
}


class SahibindenCatCrawler(scrapy.Spider):
    name = "sahibinden_cat_crawler"
    allowed_domains = ["sahibinden.com"]
    start_urls = ['https://www.sahibinden.com/sitemap/search/real-estate.xml']

    def parse(self, response):
        xmldoc = minidom.parseString(response.body)
        LOCS = xmldoc.getElementsByTagName('loc')
        for loc in LOCS:
            p_url = loc.childNodes[0].data
            p_url = p_url.strip()
            ua = random.choice(USER_AGENT_LIST_ANDRO)
            headers.update({'User-Agent': ua})

            yield Request(p_url, callback=self.parsedata, headers=headers)

    def parsedata(self, response):
        xmldoc = minidom.parseString(response.body)
        LOCS = xmldoc.getElementsByTagName('loc')
        for loc in LOCS:
            p_url = loc.childNodes[0].data
            p_url1 = p_url.strip()
            item = SahibindenCatUrlItem(
                url=p_url1
            )
            yield item
