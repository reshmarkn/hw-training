import time
import urllib
import pika
import scrapy
import re
import requests
import json
import logging
import string
import random
# import js2py

from pymongo import MongoClient
from scrapy.http import Request
from time import sleep
from datetime import datetime
from scrapy.shell import inspect_response
from scrapy.http import Request, FormRequest
from string import ascii_lowercase
from scrapy.selector import Selector
from xml.dom import minidom

from sahibinden.items import *
from sahibinden.settings import *
from sahibinden.storm_proxy import parse_proxy


MONGODB_DB = 'dina_mohammad'
MONGODB_COLLECTION_URL = 'sahibinden_tur_url_2020_08'
MONGODB_COLLECTION_URL_FAIL = 'sahibinden_tur_cat_fail_2020_08'

client = MongoClient('mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')

try:
    client.admin.command("enablesharding", MONGODB_DB)
except:
    pass

try:
    client.admin.command(
        "shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION_URL, key={'url': 1}, unique=True)
except:
    pass
try:

    client.admin.command(
        "shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION_URL_FAIL, key={'url': 1}, unique=True)
except:
    pass

db = client[MONGODB_DB]

logger = logging.getLogger('pika')
logger.propagate = False

# proxies = {
# 	'http': 'http://5.79.66.2:13200',
# 	'https': 'https://5.79.66.2:13200',
# }
# PROXY_LIST = requests.get('http://68.183.58.145/microleaves',
#                           headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()

PROXY_LIST = ['51.159.3.47:2060']

# headers = {
#     'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
#     'Accept-Encoding': 'gzip, deflate, br',
#     'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
#     'Host': 'www.sahibinden.com',
#     'Cache-Control': 'no-cache',
#     'Connection': 'keep-alive',
#     'Pragma': 'no-cache',
#     'Upgrade-Insecure-Requests': '1',
#     'User-Agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Mobile Safari/537.36'
# }

headers  = {'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
'Accept-Encoding':'gzip, deflate, br',
'Accept-Language':'en-US,en;q=0.5',
'Connection':'keep-alive',
'Host':'www.sahibinden.com',
'Upgrade-Insecure-Requests':'1',
'User-Agent':'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:79.0) Gecko/20100101 Firefox/79.0',
}

class SahibindenCrawler(scrapy.Spider):
    name = "sahibinden_crawler"
    allowed_domains = ["sahibinden.com"]

    def get_request(self, link):
        ua = random.choice(USER_AGENT_LIST_ANDRO)
        headers.update({'User-Agent': ua})
        r2 = requests.session()
        PROXY = random.choice(PROXY_LIST)
        proxies = {"http": "http://%s" % PROXY,
                           "https": "https://%s" % PROXY}
        r3 = r2.get('http://sahibinden.com/',
                    headers=headers, proxies=proxies, verify=True)
        time.sleep(2)
        response = r2.get(
            link.strip(), headers=headers, proxies=proxies, verify=True)
        return response

    def start_requests(self):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_CAT_IP, socket_timeout=300))
        channel = connection.channel()

        while True:
            try:
                channel.basic_qos(prefetch_count=1)
                method, properties, url = channel.basic_get(
                    queue=QUEUE_CAT_NAME)
                if not url.strip():
                    break
                channel.basic_ack(delivery_tag=method.delivery_tag)
            except:
                try:
                    connection.close()
                except:
                    pass
                connection = pika.BlockingConnection(pika.ConnectionParameters(
                    credentials=credentials, host=QUEUE_CAT_IP, socket_timeout=300))
                channel = connection.channel()
                channel.basic_qos(prefetch_count=1)
                method, properties, url = channel.basic_get(
                    queue=QUEUE_CAT_NAME)
                if not url.strip():
                    break
                channel.basic_ack(delivery_tag=method.delivery_tag)
            url = str(url, encoding='utf-8')

            link = url
            if link.strip():
                try:
                    r = self.get_request(link.strip())
                except:
                    try:
                        r = self.get_request(link.strip())
                    except:
                        try:
                            r = self.get_request(link.strip())
                        except:
                            r = ''
                            pass

                if r and r.status_code == 200:
                    self.parse_item(r, url.strip())
                else:
                    self.errback_httpbin(url.strip())
                    pass

        connection.close()

    def parse_item(self, response, url):
        print('current:', url)
        content = str(response.content, encoding='utf-8')
        sel = Selector(text=content)

        name_link = sel.xpath(
            '//a[contains(@href,"/detay")]/@href').extract()
        if name_link:
            for urlslink in name_link:
                if 'ilan' in urlslink:
                    urls = 'https://www.sahibinden.com' + urlslink
                    print('found url : ',urls)
                    item = SahibindenUrlItem(
                        url=urls
                    )
                    try:
                        print("sucess:", urls)
                        db[MONGODB_COLLECTION_URL].insert(dict(item))
                    except:
                        pass
        else:
            try:
                items = SahibindenCatUrlItem(
                    url=url,)
                db[MONGODB_COLLECTION_URL_FAIL].insert(
                    dict(items))
            except:
                pass

        pagination = sel.xpath('//link[@rel="next"]/@href').extract()
        if pagination:
            for page in pagination:
                if 'Offset' in page:
                    next_url = 'https://www.sahibinden.com' + page
                    link = next_url.strip()
                    print('next:', link)
                    try:
                        r = self.get_request(link.strip())
                    except:
                        try:
                            r = self.get_request(link.strip())
                        except:
                            try:
                                r = self.get_request(link.strip())
                            except:
                                r = ''
                                pass
                    if r and r.status_code == 200:
                        self.parse_item(r, link.strip())
                    else:
                        self.errback_httpbin(link.strip())
                        pass

    # Errorback to put failed urls back in queue

    def errback_httpbin(self, url):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_CAT_IP, socket_timeout=600))
        channel = connection.channel()
        channel.queue_declare(queue=QUEUE_CAT_NAME, durable=True)
        channel.basic_publish(
            exchange='', routing_key=QUEUE_CAT_NAME, body=url)
        connection.close()
