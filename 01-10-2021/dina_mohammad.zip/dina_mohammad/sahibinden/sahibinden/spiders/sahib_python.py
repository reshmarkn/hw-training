# -*- coding: utf-8 -*-
import re
import pika
import time
import json
import random
import string
import urllib
import scrapy
import logging
import requests
# import js2py

from time import sleep
from datetime import datetime
from sahibinden.items import *
from sahibinden.clean import *
from sahibinden.xpaths import *
from sahibinden.settings import *
from pymongo import MongoClient
from string import ascii_lowercase
from scrapy.selector import Selector
from scrapy.shell import inspect_response
from scrapy.http import Request, FormRequest
from sahibinden.storm_proxy import parse_proxy


MONGODB_DB = 'dina_mohammad'
MONGODB_COLLECTION_AGENT = 'sahibinden_tur_2020_08'
MONGODB_COLLECTION_URL_FAIL = 'sahibinden_tur_2020_08_fail'
MONGODB_COLLECTION_URL_MISS = 'sahibinden_tur_2020_08_missing'


client = MongoClient('mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')
try:
    # client.admin.command("enablesharding", MONGODB_DB)
    client.admin.command(
        "shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION_AGENT, key={'url': 1}, unique=True)
except:
    pass
try:
    client.admin.command(
        "shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION_URL_FAIL, key={'url': 1}, unique=True)
except:
    pass
try:
    client.admin.command(
        "shardcollection", MONGODB_DB + '.' + MONGODB_COLLECTION_URL_MISS, key={'url': 1}, unique=True)
except:
    pass

db = client[MONGODB_DB]

logger = logging.getLogger('pika')
logger.propagate = False


# headers = {
#     "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
#     "Accept-Encoding": "gzip, deflate, br",
#     "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
#     "Connection": "keep-alive",
#     "Host": "www.sahibinden.com",
#     "Referer": "https://www.sahibinden.com/kategori/emlak",
#     "Sec-Fetch-Mode": "navigate",
#     "Sec-Fetch-Site": "same-origin",
#     "Sec-Fetch-User": "?1",
#     "Upgrade-Insecure-Requests": "1",
#     "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) snap Chromium/79.0.3945.79 Chrome/79.0.3945.79 Safari/537.36"
# }

headers  = {'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
'Accept-Encoding':'gzip, deflate, br',
'Accept-Language':'en-US,en;q=0.5',
'Connection':'keep-alive',
'Host':'www.sahibinden.com',
'Upgrade-Insecure-Requests':'1',
'User-Agent':'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:79.0) Gecko/20100101 Firefox/79.0',
}

class SahibindenPythonSpider(scrapy.Spider):

    name = "sahibinden_python"
    allowed_domains = ["sahibinden.com"]
    r2 = requests.session()

    def get_session(self):
        self.r2 = requests.session()
        proxy = parse_proxy()
        proxies = proxy['proxies']
        r3 = self.r2.get('http://sahibinden.com/',
                         headers=headers, proxies=proxies, verify=True)

        return self.r2

    def get_request(self, link):

        self.r2 = requests.session()
        ua = random.choice(USER_AGENT_LIST)
        headers.update({'User-Agent': ua})
        proxy = parse_proxy()
        proxies = proxy['proxies']
        r3 = self.r2.get('http://sahibinden.com/',
                         headers=headers, proxies=proxies, verify=True)
        time.sleep(2)
        response = self.r2.get(
            link.strip(), headers=headers, proxies=proxies, verify=True)

        if response.status_code == 200:
            print('!!!!!!!!!get_request sucess!!!!!!!!!')
            return response
        else:
            self.r2 = self.get_session()
            response = self.r2.get(
                link.strip(), headers=headers, verify=True)
            if response.status_code == 200:
                return response

    def start_requests(self):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        channel = connection.channel()

        while True:
            try:
                channel.basic_qos(prefetch_count=1)
                method, properties, url = channel.basic_get(queue=QUEUE_NAME)
                if not url.strip():
                    break
                channel.basic_ack(delivery_tag=method.delivery_tag)
            except:
                try:
                    connection.close()
                except:
                    pass
                connection = pika.BlockingConnection(pika.ConnectionParameters(
                    credentials=credentials, host=QUEUE_IP, socket_timeout=300))
                channel = connection.channel()
                channel.basic_qos(prefetch_count=1)
                method, properties, url = channel.basic_get(queue=QUEUE_NAME)
                if not url.strip():
                    break
                channel.basic_ack(delivery_tag=method.delivery_tag)
            url = str(url, encoding='utf-8')
            link = url
            if link.strip():
                try:
                    r = self.get_request(link.strip())
                except:
                    try:
                        r = self.get_request(link.strip())
                    except:
                        try:
                            r = self.get_request(link.strip())
                        except:
                            r = ''
                            pass

                if r and r.status_code == 200:
                    print('sucess')
                    self.parse_item(r, url.strip())
                else:
                    print('Failure')
                    print(r.content)
                    self.errback_httpbin(url.strip())
                    pass

        connection.close()

    def parse_item(self, response, url):

        link_id = ''
        content = str(response.content, encoding='utf-8')
        sel = Selector(text=content)
        price_final = ''
        currency = ''
        category_url_new = ''
        phone_numbers = ''
        agent_name1 = ''

        title = sel.xpath(TITLE_XPATH).extract()
        print('Success, title : ',title)
        price = sel.xpath(PRICE_XPATH).extract()
        id_ = sel.xpath(ID_XPATH).extract()
        broker = sel.xpath(BROKER_XPATH).extract()
        description = sel.xpath(DESCRIPTION_XPATH).extract()
        category = sel.xpath(CATEGORY_XPATH).extract()
        category_url = sel.xpath(CATEGORY_URL_XPATH).extract()
        bathrooms = sel.xpath(BATHROOMS_XPATH).extract()
        bedrooms = sel.xpath(BEDROOMS_XPATH).extract()
        agent_name = sel.xpath(AGENT_NAME_XPATH).extract()
        amenities = sel.xpath(AMENITIES_XPATH).extract()
        area1 = sel.xpath(AREA_1_XPATH).extract()
        area1 = [x.replace("\\n", "").strip() for x in area1] if area1 else ''
        area2 = sel.xpath(AREA_2_XPATH).extract()
        number_of_photos = sel.xpath(PHOTOS_XPATH).extract()
        furnishe = sel.xpath(FURNISH_XPATH).extract()
        user = sel.xpath(USER_XPATH).extract()
        phone_numbers = sel.xpath(PHONE_NUMBER_XPATH).extract()

        data_1 = cleandata_1(title, price, id_, broker, description)
        data_2 = cleandata_2(category, category_url,
                             bathrooms, bedrooms, agent_name, amenities)
        data_3 = cleandata_3(area1, area2, number_of_photos,
                             furnishe, user, phone_numbers)
        title = data_1['title']
        price = data_1['price']
        currency = data_1['currency']
        id_ = data_1['id_']
        broker = data_1['broker']
        description = data_1['description']
        category = data_2['category']
        category_url = data_2['category_url']
        bathrooms = data_2['bathrooms']
        bedrooms = data_2['bedrooms']
        agent_name = data_2['agent_name']
        amenities = data_2['amenities']
        area = data_3['area']
        number_of_photos = data_3['number_of_photos']
        furnishe = data_3['furnishe']
        link_id = data_3['link_id']
        phone_numbers = data_3['phone_numbers']

        scraped_ts = (datetime.now()).strftime("%Y-%m-%d")
        scraped_ts = (datetime.now()).strftime("%Y-%m-%d")

        item = SahibindenItem(
            id=id_,
            url=url,
            broker_display_name=broker,
            category=category,
            category_url=category_url,
            title=title,
            description=description,
            location='',
            price=price,
            currency=currency,
            price_per='',
            bedrooms=bedrooms,
            bathrooms=bathrooms,
            furnished=furnishe,
            rera_permit_number='',
            dtcm_licence='',
            broker=broker.upper(),
            scraped_ts=scraped_ts,
            reference_number='',
            amenities=amenities,
            details=area,
            agent_name=agent_name,
            number_of_photos=number_of_photos,
            user_id=link_id,
            phone_number=phone_numbers,
            date=scraped_ts,
            iteration_number='2020_08',
        )
        print(item)
        if title and 'Loading site please wait' not in title and title != "\"\"":
            print('Success', title)

            try:
                db[MONGODB_COLLECTION_AGENT].insert(dict(item))
            except:
                items = SahibindenUrlItem(
                    url=url,)
                try:
                    db[MONGODB_COLLECTION_URL_FAIL].insert(dict(items))
                except:
                    pass
        else:
            print('FAILED')
            items = SahibindenUrlItem(
                url=url,)

            try:
                db[MONGODB_COLLECTION_URL_MISS].insert(dict(items))
            except:
                pass

    # Errorback to put failed urls back in queue
    def errback_httpbin(self, url):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=600))
        channel = connection.channel()
        channel.queue_declare(queue=QUEUE_NAME, durable=True)
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=url)
        connection.close()
