def cleandata_1(title, price, id_, broker, description):
    title = ' '.join(''.join(title).replace("\\n", '').replace("\\t", "").strip().split()
                     ).strip('"') if title else ''
    id_ = ' '.join(''.join(id_).strip().split()) if id_ else ''
    price = ' '.join(''.join(price).replace("\\n", '').replace("\\t", "").strip().replace(
            'QAR', '').split()) if price else ''
    price_final = ''
    currency = ''
    if price:
        if ' ' in price:
            price_1 = price.split(' ')
            price_final = price_1[0]
            currency = price_1[1]
    broker = ' '.join(''.join(broker).replace("\\n", '').replace(
        "\\t", "").strip().split()) if broker else ''
    description = ' '.join(''.join(description).replace("\\n", '').replace("\\t", "").strip().replace(
        '*', '').split()) if description else ''
    meta = {'title': title, 'price': price_final, 'currency': currency, 'id_': id_,
            'broker': broker, 'description': description}
    return meta


def cleandata_2(category, category_url, bathrooms, bedrooms, agent_name, amenities):

    category = [x.strip() for x in category] if category else ''
    category = [x.strip()
                for x in category if x] if category else ''
    category = ' > '.join(category).strip() if category else ''
    if category_url:
        category_url = [x.strip()
                        for x in category_url if not "javascript:void(0)" in x]
        category_url = [x.strip()
                        for x in category_url if not "javascript:void(0)" in x]
        category_url_new = category_url[-1] if category_url else ''
        if category_url_new:
            if '/satilik-' in category_url_new:
                category = 'satilik'
                category_url = '/satilik'
            elif '/kiralik-' in category_url_new:
                category = 'kiralik'
                category_url = '/kiralik'
            else:
                category = category
                category_url = category_url_new
        else:
            category_url = ''
            category = ''
    else:
        category_url = ''
        category = ''

    bedrooms = ' '.join(
        ''.join(bedrooms).replace("\\n", '').replace("\\t", "").strip().split()) if bedrooms else ''
    bathrooms = ' '.join(
        ''.join(bathrooms).replace("\\n", '').replace("\\t", "").strip().split()) if bathrooms else ''

    amenities = ','.join([x.strip() for x in [x.strip()
                                              for x in amenities] if x]) if amenities else ''
    agent_name = agent_name[0].strip() if agent_name else ''
    meta = {'category': category, 'category_url': category_url,
            'bathrooms': bathrooms, 'bedrooms': bedrooms, 'agent_name': agent_name, 'amenities': amenities}
    return meta


def cleandata_3(area1, area2, number_of_photos, furnishe, user, phone_numbers):
    link_id = ''
    area2 = area2 if area2 else ''
    area = area1 if area1 else area2
    area = area[0].strip() + ' m²' if area else ''
    number_of_photos = str(len(number_of_photos)
                           ) if number_of_photos else ''

    furnishe = furnishe[0].replace("\\n", '').replace(
        "\\t", "").strip() if furnishe else ''

    if user:
        u_link = user[0] if user else ''
        if 'userId=' in u_link:
            link = u_link.split('userId=')
            link_id = link[1] if link else ''
    link_id = link_id if link_id else ''
    phone_numbers = [x.strip()
                     for x in phone_numbers] if phone_numbers else []
    phone_numbers = [x.strip()
                     for x in phone_numbers if x] if phone_numbers else []
    phone_numbers = ', '.join(phone_numbers) if phone_numbers else ''

    meta = {'area': area, 'number_of_photos': number_of_photos,
            'furnishe': furnishe, 'link_id': link_id, 'phone_numbers': phone_numbers}
    return meta
