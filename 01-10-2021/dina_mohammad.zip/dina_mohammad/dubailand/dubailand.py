import requests
import re
import json
import lxml.html
import pika
import logging
import datetime
import random
from pymongo import MongoClient
from datetime import datetime

logger = logging.getLogger('pika')
logger.propagate = False
header = {'accept': 'application/json',
          'Accept-Encoding': 'gzip, deflate, br',
          'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
          'consumer-id': 'gkb3WvEG0rY9eilwXC0P2pTz8UzvLj9F',
          'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) snap Chromium/83.0.4103.61 Chrome/83.0.4103.61 Safari/537.36'}
header2 = {
    "accept": "application/json",
    "Accept-Encoding": "gzip, deflate, br",
    "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
    "consumer-id": "gkb3WvEG0rY9eilwXC0P2pTz8UzvLj9F",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-site",
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) snap Chromium/83.0.4103.61 Chrome/83.0.4103.61 Safari/537.36"
}
PROXY_LIST = requests.get('http://68.183.58.145/torproxies?',
                          headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()

# PROXY_LIST = requests.get('http://68.183.58.145/stormproxies?type=3',
#                           headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
# MAIN_LIST = ['5.79.66.2:13200' for i in range(10)]
# PROXY_LIST.extend(MAIN_LIST)
DB_NAME = 'dubailand_test'
COLLECTION_NAME = 'dubailand_data_final'
MISSING_URL = 'MISSING_URL'
QUEUE_NAME = 'ha.dubailand'
QUEUE_IP = '159.89.47.171'
QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'


db = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')[DB_NAME]


def parse_data(url):
    # print('%%%%%%%%%%%%%%%%%%%%', url)
    PROXY = random.choice(PROXY_LIST)
    proxies = {"http": "http://%s" % PROXY, "https": "https://%s" % PROXY}
    url1 = "https://dubailand.gov.ae/en/eservices/real-estate-transaction/#/form"
    r = requests.get(url1, headers=header, proxies=proxies)
    sel = lxml.html.fromstring(r.text)
    consumer = sel.xpath('//script[contains(text(),"consumerId")]/text()')
    consumer = re.findall(r'consumerId.*?,', consumer[0])
    consumer = consumer[0].split(':')[1].replace(',', '').replace('"', '')
    header['consumer-id'] = consumer
    # print('11111111111111111111111111111', header)
    # urls = ["https://gateway.dubailand.gov.ae/areawise/transaction/sales/details/?fromDate=2020-05-03&toDate=2020-05-03&propertyStatus=1&data=Flat",
    #         "https://gateway.dubailand.gov.ae/areawise/transaction/sales/details/?fromDate=2020-05-03&toDate=2020-05-03&propertyStatus=2&data=Flat",
    #         "https://gateway.dubailand.gov.ae/areawise/transaction/mortgage/details/?fromDate=2020-05-03&toDate=2020-05-03&propertyStatus=2&data=Flat",
    #         "https://gateway.dubailand.gov.ae/areawise/transaction/mortgage/details/?fromDate=2020-05-03&toDate=2020-05-03&propertyStatus=1&data=Flat",
    #         "https://gateway.dubailand.gov.ae/areawise/transaction/others/details/?fromDate=2020-05-03&toDate=2020-05-03&propertyStatus=2&data=Flat",
    #         "https://gateway.dubailand.gov.ae/areawise/transaction/others/details/?fromDate=2020-05-03&toDate=2020-05-03&propertyStatus=1&data=Flat",
    #         "https://gateway.dubailand.gov.ae/areawise/transaction/sales/details/?fromDate=2020-05-04&toDate=2020-05-04&propertyStatus=1&data=Flat",
    #         "https://gateway.dubailand.gov.ae/areawise/transaction/sales/details/?fromDate=2020-05-04&toDate=2020-05-04&propertyStatus=2&data=Flat",
    #         "https://gateway.dubailand.gov.ae/areawise/transaction/mortgage/details/?fromDate=2020-05-04&toDate=2020-05-04&propertyStatus=2&data=Flat",
    #         "https://gateway.dubailand.gov.ae/areawise/transaction/mortgage/details/?fromDate=2020-05-04&toDate=2020-05-04&propertyStatus=1&data=Flat",
    #         "https://gateway.dubailand.gov.ae/areawise/transaction/others/details/?fromDate=2020-05-04&toDate=2020-05-04&propertyStatus=2&data=Flat",
    #         "https://gateway.dubailand.gov.ae/areawise/transaction/others/details/?fromDate=2020-05-04&toDate=2020-05-04&propertyStatus=1&data=Flat",
    #         "https://gateway.dubailand.gov.ae/areawise/transaction/sales/details/?fromDate=2020-05-05&toDate=2020-05-05&propertyStatus=1&data=Flat",
    #         "https://gateway.dubailand.gov.ae/areawise/transaction/sales/details/?fromDate=2020-05-05&toDate=2020-05-05&propertyStatus=2&data=Flat",
    #         "https://gateway.dubailand.gov.ae/areawise/transaction/mortgage/details/?fromDate=2020-05-05&toDate=2020-05-05&propertyStatus=2&data=Flat",
    #         "https://gateway.dubailand.gov.ae/areawise/transaction/mortgage/details/?fromDate=2020-05-05&toDate=2020-05-05&propertyStatus=1&data=Flat",
    #         "https://gateway.dubailand.gov.ae/areawise/transaction/others/details/?fromDate=2020-05-05&toDate=2020-05-05&propertyStatus=2&data=Flat",
    #         "https://gateway.dubailand.gov.ae/areawise/transaction/others/details/?fromDate=2020-05-05&toDate=2020-05-05&propertyStatus=1&data=Flat", ]
    # credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
    # connection = pika.BlockingConnection(pika.ConnectionParameters(
    #     credentials=credentials, host=QUEUE_IP, socket_timeout=300))
    # channel = connection.channel()
    # channel.basic_qos(prefetch_count=1)
    # while True:
    #     try:
    #         method, properties, body = channel.basic_get(
    #             queue=QUEUE_NAME)
    #         if not body:
    #             break
    #         publication_url = body.strip()
    #         publication_url = str(publication_url, encoding="utf-8")
    #         channel.basic_ack(delivery_tag=method.delivery_tag)
    #         connection.close()
    #         if publication_url:
    #             # print(publication_url, '****')
    #             data_parser(url)
    #             # yield Request(url=publication_url, callback=self.parse_data,
    #             # dont_filter=True, headers=headers, meta={'request_url':
    #             # publication_url, 'sample_url': publication_url},
    #             # errback=lambda x: self.errback_httpbin(x, publication_url))

    #     except:
    #         connection = pika.BlockingConnection(pika.ConnectionParameters(
    #             credentials=credentials, host=QUEUE_IP, socket_timeout=300))
    #         channel = connection.channel()
    #         channel.basic_qos(prefetch_count=1)


# def data_parser(url):
    # for url in urls:
    PROXY = random.choice(PROXY_LIST)
    proxies = {"http": "http://%s" %
                       PROXY, "https": "https://%s" % PROXY}

    try:

        # print(proxies)
        # print(url)
        response = requests.get(url, headers=header2, proxies=proxies)
        # print(response)
    # parse_data(response)
    except:
        try:
            response = requests.get(url, headers=header2, proxies=proxies)
    # parse_data(response)
        except:
            response = ''
    if response:
        data = json.loads(response.text)
        b = re.findall(r'toDate.*?&', url)

        b = b[0].split('=')[1].split('&')[0]

        date = url.split('&')[1].split('=')[-1]
        data_sources = re.findall(r'propertyStatus.*?&', url)
        data_source = re.findall(r'\d+', data_sources[0])[0]
        if data_source == '1':
            data_source = "Off-Plan Properties"
        elif data_source == '2':
            data_source = "Existing Properties"
        else:
            pass
        if 'sales' in url:
            procedure_type = 'sale'
        elif 'mortgage' in url:
            procedure_type = 'mortgage'
        elif 'others' in url:
            procedure_type = 'Gifts'

        details = data.get('response')
        if details:
            details = details.get('result', '')
            for contents in details:
                property_type = contents.get(
                    'propertyTypeName', '').get('englishName', '')
                # property_id_type=contents.get('propertyTypeId','')
                # if property_id_type == 3:
                #   data_source="Off-Plan Properties"
                # elif property_id_type ==2:
                #   data_source="Existing Properties"
                # else:
                #   pass
                # y[0]['transactions']
                content = contents.get('transactions', '')
                for items in content:
                    region = items.get('area', '').get(
                        'name', '').get('englishName', '')
                    property_description = items.get('propertySubType', '')
                    if property_description:
                        # print(property_description)
                        property_description = property_description.get(
                            'name', '').get('englishName', '')
                    else:
                        property_description = items.get('usage', '').get(
                            'name', '').get('englishName', '')

                    sale_sequence = items.get('saleType', '')
                    if sale_sequence:
                        sale_sequence = sale_sequence.get(
                            'name', '').get('englishName', '')
                    # building_name=items.get('saleType','').get('name','').get('englishName','')
                    total_area = items.get('size', '')
                    per_sqmt = items.get('per_Sqm', '')
                    totalworth = items.get('value', '')
                    building_name = items.get('building', '')
                    if building_name:
                        building_name = building_name.get(
                            'name', '').get('englishName', '')
                    if procedure_type != 'sale':
                        sale_sequence = ''
                    datas = {'Date': date,
                             'Region': region,
                             'Property Description': property_description,
                             'Sale sequence': sale_sequence,
                             'Building Name': building_name,
                             'Total Area': total_area,
                             'Per Sq_Mt value': per_sqmt,
                             'Total Worth': totalworth,
                             'Property_Type': property_type,
                             'Data_Source': data_source,
                             'Procedure_Type': procedure_type,
                             }
                    try:
                        db[COLLECTION_NAME].insert(dict(datas))
                        logging.warning(datas)
                    except:
                        pass
    else:
        try:
            db[MISSING_URL].insert(dict(url))
        except:
            pass
# parse_data()

if __name__ == "__main__":
    credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
    connection = pika.BlockingConnection(pika.ConnectionParameters(
        credentials=credentials, host=QUEUE_IP, socket_timeout=300))
    channel = connection.channel()
    channel.basic_qos(prefetch_count=1)
    while True:
        try:
            method, properties, body = channel.basic_get(
                queue=QUEUE_NAME)
            if not body:
                break
            publication_url = body.strip()
            publication_url = str(publication_url, encoding="utf-8")
            channel.basic_ack(delivery_tag=method.delivery_tag)
            connection.close()
            if publication_url:
                # print(publication_url, '****')
                parse_data(publication_url)
                # yield Request(url=publication_url, callback=self.parse_data,
                # dont_filter=True, headers=headers, meta={'request_url':
                # publication_url, 'sample_url': publication_url},
                # errback=lambda x: self.errback_httpbin(x, publication_url))

        except:
            connection = pika.BlockingConnection(pika.ConnectionParameters(
                credentials=credentials, host=QUEUE_IP, socket_timeout=300))
            channel = connection.channel()
            channel.basic_qos(prefetch_count=1)
