import scrapy
from scrapy.http import Request, FormRequest
# from grab.items import *
import re
import json
import xmltodict

class  PropertyfinderSpider(scrapy.Spider):
	name = 'property_spider'
	start_urls = ['https://gateway.dubailand.gov.ae/brokers/?sortCriteria=2&pageIndex=0&pageSize=4523&consumer-id=gkb3WvEG0rY9eilwXC0P2pTz8UzvLj9F'
	]
	def parse(self, response):
		if response.status == 200:
			data = response.body
			my_dict = xmltodict.parse(data)
			json_data = json.dumps(my_dict)
			print(json_data)

			_data=json.loads(json_data) 
			d = _data.keys()

			p = _data.get('ApiResponseOfArrayOfRealEstateCardDetailResponseSQGlecte')
			p.keys()
			p.get('Response')
			all_data = p.get('Response')
			all_data = p.get('Response').keys()
			for i in all_data:
				email = i.get('d2p1:CardHolderEmail','')
				phone = i.get('d2p1:CardHolderPhone','')
				print(email)
				print(phone)

