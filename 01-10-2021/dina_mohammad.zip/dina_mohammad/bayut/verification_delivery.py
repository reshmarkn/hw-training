from pymongo import MongoClient
import ast

MONGODB_DB = 'dina_mohammad_2020_08'

MONGODB_COLLECTION_AGENT = 'bayut_uae_2020_08_weekly03_dedup'
client = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@64.225.9.179:27017')
db = client[MONGODB_DB]

fields = ['ad_type', 'agent_name', 'amenities', 'bathrooms', 'bedrooms', 'broker', 'broker_display_name', 'category', 'category_url', 'completion_status', 'currency', 'date', 'ded_license_number', 'description', 'details', 'dtcm_licence', 'furnished', 'id', 'iteration_number',
          'latitude', 'listing_id', 'locality', 'location', 'longitude', 'number_of_photos', 'object_id', 'package_type', 'phone_number', 'price', 'price_per', 'reference_number', 'rera_length', 'rera_permit_number', 'rera_registration_number', 'scraped_ts', 'title', 'url', 'user_id', 'verified']


count = db[MONGODB_COLLECTION_AGENT].find().count()
print(MONGODB_COLLECTION_AGENT, ":", count)
for field in fields:
    query = '{"'+field+'":{"$exists": True, "$ne":""}}'
    query = ast.literal_eval(query)
    my_col = db[MONGODB_COLLECTION_AGENT].find(query)
    count = my_col.count()
    print(field, ":", count)
