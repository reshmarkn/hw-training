import boto3
import datetime
import time
queue_name = 'queinsert_test'
Aws_access_key_id = 'AKIAI6QJACHIXHRGJZCQ' 
Aws_secret_access_key = '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'
#sqs = boto3.client('sqs', region_name='us-west-1',aws_access_key_id=Aws_access_key_id,aws_secret_access_key=Aws_secret_access_key)
sqs = boto3.client('sqs', region_name='eu-west-2',aws_access_key_id=Aws_access_key_id,aws_secret_access_key=Aws_secret_access_key)
queue_url ="https://sqs.us-west-1.amazonaws.com/433218223882/"+queue_name

 # Receive message from SQS queue
print(queue_url)
start_time = datetime.datetime.now().time().strftime('%H:%M:%S')
print('>>>> Start_time',start_time)
while True:    
    response = sqs.receive_message(
        QueueUrl=queue_url,
        AttributeNames=[
            'SentTimestamp'
        ],
        MaxNumberOfMessages=1,
        MessageAttributeNames=[
            'All'
        ],
        VisibilityTimeout=10,
        WaitTimeSeconds=10
    )
    if response.get('Messages'):
        message = response['Messages'][0]
        receipt_handle = message['ReceiptHandle']# Delete received message from queue
        sqs.delete_message(
            QueueUrl=queue_url,
            ReceiptHandle=receipt_handle
        )
        print('Received and deleted message: %s' % message.get('Body'))

    else:
        break
end_time = datetime.datetime.now().time().strftime('%H:%M:%S')
print('>>>>>>> End_time',end_time)
total_time=(datetime.datetime.strptime(end_time,'%H:%M:%S') - datetime.datetime.strptime(start_time,'%H:%M:%S'))
print('<<<<<<<<<<<< Total_time',total_time)