import random
import base64
# from scrapy.conf import settings
from scrapy.utils.project import get_project_settings
import random
import requests
from time import sleep


def parse_proxy():

    # storm

    # proxies = {'http':'http://5.79.66.2:13200',
    #   'https':'https://5.79.66.2:13200',}

    # torr

    # proxies = {'http': 'http://157.230.189.5:5566',
    #            'https': 'https://157.230.189.5:5566', }

    # PROXY_LIST = requests.get('http://68.183.58.145/microleaves',
    #                           headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()

    PROXY_LIST = requests.get(
        'http://68.183.58.145/torproxies', headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()

    PROXY = random.choice(PROXY_LIST)

    proxies = {"http": "http://%s" % PROXY,
                       "https": "https://%s" % PROXY}

    settings = get_project_settings()
    user_agent = random.choice(settings.get('USER_AGENT_LIST'))
    headers = {'Accept-Encoding': 'gzip', 'User-Agent': user_agent,
               'Accept': 'application/json, text/javascript, */*; q=0.01', 'X-Requested-With': 'XMLHttpRequest'}
    return {'headers': headers, 'proxies': proxies}
