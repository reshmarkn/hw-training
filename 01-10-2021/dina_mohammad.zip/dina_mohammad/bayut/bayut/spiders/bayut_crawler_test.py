# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging

from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime
from pymongo import MongoClient
from scrapy.exceptions import DropItem

from bayut.items import *
from bayut.settings import *


handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


class BayutCrawlerTestSpider(Spider):
    name = 'bayut_crawler_test'

    allowed_domains = ['bayut.com']

    header = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
              'accept-encoding': 'gzip, deflate, br',
              'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
              'cache-control': 'no-cache',
              'pragma': 'no-cache',
              'upgrade-insecure-requests': '1',
              'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', }

    def start_requests(self):
        urls = [
            'https://www.bayut.com/for-sale/property/uae/?completion_status=ready',
            'https://www.bayut.com/for-sale/property/uae/?completion_status=off-plan',
            'https://www.bayut.com/to-rent/property/uae/'

        ]
        for url in urls:
            meta = {'parent': url}
            try:
                yield Request(url, callback=self.parse_profile, meta=meta, headers=self.header)
            except:
                try:
                    sleep(5)
                    yield Request(url, callback=self.parse_profile, meta=meta, headers=self.header)
                except:
                    try:
                        sleep(5)
                        yield Request(url, callback=self.parse_profile, meta=meta, headers=self.header)
                    except:
                        print("ERROR:",url)

    def parse_profile(self, response):
        parent = response.meta['parent']
        property_list = response.xpath(
            '//li[@role="article"]/article')
        for prop in property_list:
            link = prop.xpath(
                'div/a/@href').extract()
            listing_label = prop.xpath(
                'div//div[@aria-label="Listing label"]/span/@aria-label').extract()
            link = link[0].strip() if link else ''
            listing_label = listing_label[0].strip(
            ) if listing_label else 'no_adv_type'
            if link:
                url = response.urljoin(link.strip())
                status = ''
                if parent == 'https://www.bayut.com/for-sale/property/uae/?completion_status=off-plan':
                    status = 'off-plan'
                elif parent == 'https://www.bayut.com/for-sale/property/uae/?completion_status=ready':
                    status = 'ready'
                else:
                    status = 'rent'
                status = status if status else 'no_status'
                listing_label = listing_label if listing_label else 'no_label'
                url_string = url + '||' + status + '||' + listing_label

                item = BayutUrlItem(
                    url=url,
                    url_string=url_string,
                    status=status,
                    listing_label=listing_label,
                )
                if url:
                    yield item

        meta = {'parent': parent}
        location_url = response.xpath(
            '//div[@aria-label="Search location links"]//a/@href').extract()
        for url in location_url:
            if url.startswith('/'):
                url = 'https://www.bayut.com'+url
            if url:
                try:
                    yield Request(url, callback=self.parse_loc, meta=meta, headers=self.header)
                except:
                    try:
                        sleep(5)
                        yield Request(url, callback=self.parse_loc, meta=meta, headers=self.header)
                    except:
                        try:
                            sleep(5)
                            yield Request(url, callback=self.parse_loc, meta=meta, headers=self.header)
                        except:
                            print(url)


        # next_page = response.xpath(
        #     '//a[@title="Next"]/@href').extract_first('')
        # if next_page:
        #     if next_page.startswith('/'):
        #         next_page_url = 'https://www.bayut.com'+next_page
        #     else:
        #         next_page_url = next_page
        #     try:
        #         yield Request(next_page_url, callback=self.parse_loc, meta=meta, headers=self.header)
        #     except:
        #         try:
        #             sleep(5)
        #             yield Request(next_page_url, callback=self.parse_loc, meta=meta, headers=self.header)
        #         except:
        #             try:
        #                 sleep(5)
        #                 yield Request(next_page_url, callback=self.parse_loc, meta=meta, headers=self.header)
        #             except:
        #                 print("ERROR:",next_page_url)


    def parse_loc(self, response):
        parent = response.meta['parent']
        property_list = response.xpath(
            '//li[@role="article"]/article')
        for prop in property_list:
            link = prop.xpath(
                'div/a/@href').extract()
            listing_label = prop.xpath(
                'div//div[@aria-label="Listing label"]/span/@aria-label').extract()
            link = link[0].strip() if link else ''
            listing_label = listing_label[0].strip(
            ) if listing_label else 'no_adv_type'
            if link:
                url = response.urljoin(link.strip())
                status = ''
                if parent == 'https://www.bayut.com/for-sale/property/uae/?completion_status=off-plan':
                    status = 'off-plan'
                elif parent == 'https://www.bayut.com/for-sale/property/uae/?completion_status=ready':
                    status = 'ready'
                else:
                    status = 'rent'
                status = status if status else 'no_status'
                listing_label = listing_label if listing_label else 'no_label'
                url_string = url + '||' + status + '||' + listing_label

                item = BayutUrlItem(
                    url=url,
                    url_string=url_string,
                    status=status,
                    listing_label=listing_label,
                )
                if url:
                    yield item
                    
        meta = {'parent': parent}
        location_url = response.xpath(
            '//div[@aria-label="Search location links"]//a/@href').extract()
        for url in location_url:
            if url.startswith('/'):
                url = 'https://www.bayut.com'+url
            if url:
                try:
                    yield Request(url, callback=self.parse_loc, meta=meta, headers=self.header)
                except:
                    try:
                        sleep(5)
                        yield Request(url, callback=self.parse_loc, meta=meta, headers=self.header)
                    except:
                        try:
                            sleep(5)
                            yield Request(url, callback=self.parse_loc, meta=meta, headers=self.header)
                        except:
                            print(url)


        next_page = response.xpath(
            '//a[@title="Next"]/@href').extract_first('')
        if next_page:
            if next_page.startswith('/'):
                next_page_url = 'https://www.bayut.com'+next_page
            else:
                next_page_url = next_page
            try:
                yield Request(next_page_url, callback=self.parse_loc, meta=meta, headers=self.header)
            except:
                try:
                    sleep(5)
                    yield Request(next_page_url, callback=self.parse_loc, meta=meta, headers=self.header)
                except:
                    try:
                        sleep(5)
                        yield Request(next_page_url, callback=self.parse_loc, meta=meta, headers=self.header)
                    except:
                        print("ERROR:",next_page_url)
