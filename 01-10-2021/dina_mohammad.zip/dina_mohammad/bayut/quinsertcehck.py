import boto3 

from datetime import datetime

queue_name = 'SQS_Bayut_test'
Aws_access_key_id = 'AKIAI6QJACHIXHRGJZCQ' 
Aws_secret_access_key = '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' 
sqs = boto3.client('sqs', region_name='eu-west-2',aws_access_key_id=Aws_access_key_id,aws_secret_access_key=Aws_secret_access_key)
queue = sqs.create_queue(QueueName=queue_name)#Attributes={'FifoQueue': 'true'})
#queue = sqs.create_queue(QueueName=queue_name, Attributes={'FifoQueue': 'true','DelaySeconds': '5',"ContentBasedDeduplication": "true"})
QueueUrl = "https://sqs.us-west-1.amazonaws.com/433218223882/"+queue_name

start_time = datetime.now().time().strftime('%H:%M:%S')

print('>>>> Start_time',start_time)

with open('bayut_uae_url_2021_05_weekly01.csv') as ifile:
    for i in ifile:
        #int(len(i.encode('utf-16')))
        response = sqs.send_message(QueueUrl=QueueUrl,MessageBody=(str(i)))#,MessageGroupId='msg2')

end_time = datetime.now().time().strftime('%H:%M:%S')
print('>>>>>>> End_time',end_time)
total_time=(datetime.strptime(end_time,'%H:%M:%S')-datetime.strptime(start_time,'%H:%M:%S'))
print('<<<<<<<<<<<< Total_time',total_time)