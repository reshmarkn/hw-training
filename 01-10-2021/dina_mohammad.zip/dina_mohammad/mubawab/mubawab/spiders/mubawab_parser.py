# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
import requests

from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from scrapy.shell import inspect_response
from datetime import datetime

from mubawab.items import *
from mubawab.settings import *

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


class MubawabParserSpider(scrapy.Spider):
    name = "mubawab_qa_parser"
    allowed_domains = ["mubawab.com.qa"]
    start_urls = ['https://www.mubawab.com.qa/en/crp/qatar/qatar/real-estate-for-rent-all:sc:apartments-for-rent,commercial-property-for-rent,houses-for-rent,land-for-rent,riads-for-rent,rooms-for-rent,villas-and-luxury-homes-for-rent',
                  'https://www.mubawab.com.qa/en/crp/qatar/qatar/real-estate-for-sale-all:sc:apartments-for-sale,commercial-property-for-sale,houses-for-sale,land-for-sale,villas-and-luxury-homes-for-sale']
    headers = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
               'accept-encoding': 'gzip, deflate, br',
               'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
               'cache-control': 'no-cache',
               'pragma': 'no-cache',
               'sec-fetch-mode': 'navigate',
               'sec-fetch-site': 'none',
               'upgrade-insecure-requests': '1',
               'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36',
               }

    def parse(self, response):
        links = response.xpath(
            '//ul[@class="ulListing"]/li/@linkref').extract()
        next_page = response.xpath('//a[@class="arrowDot "]/@href').extract()

        for link in links:
            link = response.urljoin(link.strip())
            yield Request(link, callback=self.parse_data, headers=self.headers)
        if next_page:
            yield Request(next_page[-1].strip(), callback=self.parse, headers=self.headers)

    def parse_data(self, response):
        user_id = ''
        id_final_ = ''
        currency = ''
        price = ''
        id_ = response.xpath('//input[@id="adId"]/@value').extract()
        description = response.xpath(
            '//div[@class="blockProp"]/p/text()').extract()
        category = response.xpath(
            '//div[@class="col-8 vAlignM"]/a/text()').extract()
        location = response.xpath('//h3[@class="greyTit"]/text()').extract()
        price_ = response.xpath(
            '//h3[@class="orangeTit"]/text()').extract()
        title = response.xpath(
            '//h1[@class="searchTitle"]/text()').extract()
        bathrooms = response.xpath(
            '//span[@class="tagProp"][contains(text(),"Bathroom")]/text()').extract()
        bedrooms = response.xpath(
            '//span[@class="tagProp"][contains(text(),"Room")]/text()').extract()
        category_url = response.xpath(
            '//div[@class="col-8 vAlignM"]/a/@href').extract()
        broker_display_name = response.xpath(
            '//div[@class="agency-info"]/p[2]//text()').extract()

        id_ = id_[0].strip() if id_ else ''
        price_ = ''.join(price_).replace("Price on request", "").replace(
            ",", '').strip() if price_ else ''
        price_ = ' '.join(''.join(price_).split()) if price_ else ''
        price_ = price_.split(' ')
        if len(price_) >= 2:
            currency = price_[0].strip()
            price = price_[1].strip()
        elif len(price_) == 1:
            price_join = price_[0]
            currency = re.sub('[0-9]+', '', price_join)
            price = price_join.strip().replace(currency, '')
        else:
            currency = ''
            price = ''
        location = ' '.join(''.join(location).split()) if location else ''
        title = ''.join(title).strip() if title else ''
        bathrooms = bathrooms[0].strip().replace('Bathrooms', '').replace(
            'Bathroom', '').strip() if bathrooms else ''
        bedrooms = bedrooms[0].strip().replace('Rooms', '').replace(
            'Room', '').strip() if bedrooms else ''
        description = ' '.join(
            ' '.join(description).split()) if description else ''
        category_url = category_url[-1].strip() if category_url else ''
        category_url = category_url.replace('https://www.mubawab.com.qa', '')

        if 'sale' in category_url:
            category = 'sale'
            category_url = '/en/crp/qatar/qatar/real-estate-for-sale-all:sc:apartments-for-sale,commercial-property-for-sale,houses-for-sale,land-for-sale,villas-and-luxury-homes-for-sale'
        elif 'rent' in category_url:
            category = 'rent'
            category_url = '/en/crp/qatar/qatar/real-estate-for-rent-all:sc:apartments-for-rent,commercial-property-for-rent,houses-for-rent,land-for-rent,riads-for-rent,rooms-for-rent,villas-and-luxury-homes-for-rent'

        else:
            category = [x.strip() for x in category if x] if category else ''
            category = ' > '.join(category).strip() if category else ''

        broker_display_name = ''.join(
            broker_display_name).strip() if broker_display_name else ''

        amen = response.xpath(
            '//ul[@class="features-list inBlock w100"]/li/i/following-sibling::text()').extract()
        area = response.xpath(
            '//span[@class="tagProp"][contains(text(),"m²")]/text()').extract()
        img = response.xpath(
            '//div[@class="thumbSldrProp"]//img/@src').extract()
        amen = [x.strip() for x in [x.strip()
                                    for x in amen] if x]if amen else ''
        amenities = ', '.join(amen).strip().replace(
            '  ', ' ').strip() if amen else ''
        number_of_photos = str(len(img))
        area = area[0].strip() if area else ''
        details = ' '.join([x.strip() for x in area.split()]) if area else ''
        user = response.xpath('//div[@class="agency-info"]//a/@href').extract()

        if user:
            user = ''.join(user).split('/')if user else ''
            user_data = user[-2]if user else ''
            user_id = user_data.split('/') if user_data else ''
            user_id = user_id[0] if user_id else ''

        scraped_ts = (datetime.now()).strftime("%Y-%m-%d")

        phone_input = response.xpath(
            '//div[@class="hide-phone-number-box"]/@onclick').extract()
        phone_data = re.findall(
            r'\'.*?\'', phone_input[0].strip()) if phone_input else ''
        if phone_data and len(phone_data) >= 2:
            url = phone_data[0].strip('\'').strip()
            encrypted_phone = phone_data[1].strip('\'').strip()
            form_data = {'adId': id_,
                         'source': 'NON_PAID',
                         'landingPage': 'https://www.mubawab.com.qa/',
                         'encryptedPhone': encrypted_phone}
            headers = {'accept': '*/*',
                       'accept-encoding': 'gzip, deflate, br',
                       'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
                       'cache-control': 'no-cache',
                       'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                       'origin': 'https://www.mubawab.com.qa',
                       'pragma': 'no-cache',
                       'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36',
                       'x-requested-with': 'XMLHttpRequest', }

            r = requests.post(url, headers=headers, data=form_data)
            phone_number = ''
            sel = Selector(text=r.content)
            if r and r.status_code == 200:
                phone_number = sel.xpath(
                    '//p[@class="phoneText dirLtr"]/text()').extract()
                phone_number = [x.strip()
                                for x in phone_number] if phone_number else []
                phone_number = [x.strip()
                                for x in phone_number if x] if phone_number else []
                phone_number = ', '.join(phone_number) if phone_number else ''

        now = datetime.now()
        current = datetime(now.year, now.month, 1)
        next_month = datetime(now.year + int(now.month / 12),
                              ((now.month % 12) + 1), 1)
        now_date_int = int(now.strftime("%d"))
        if now_date_int <= 31 and now_date_int >= 25:
            iteration_month = next_month.strftime("%m")
            iteration_year = next_month.strftime("%Y")
        else:
            iteration_month = now.strftime("%m")
            iteration_year = now.strftime("%Y")
        iteration_number = iteration_year + '_' + iteration_month

        item = MubawabQaItem(
            reference_number='',
            id=id_,
            url=response.url,
            broker_display_name=broker_display_name,
            broker=broker_display_name.upper(),
            category=category,
            category_url=category_url,
            title=title,
            description=description,
            location=location,
            price=price,
            currency=currency,
            price_per='',
            bedrooms=bedrooms,
            bathrooms=bathrooms,
            furnished='',
            rera_permit_number='',
            dtcm_licence='',
            scraped_ts=scraped_ts,
            amenities=amenities,
            details=details,
            agent_name='',
            number_of_photos=number_of_photos,
            user_id=user_id,
            phone_number=phone_number,
            date=scraped_ts,
            iteration_number=iteration_number
        )
        if id_ and title:
            yield item
