import os
import random
# from scrapy.conf import settings
from scrapy.utils.project import get_project_settings
import logging
# from scrapy import log
import base64
from qatarliving.storm_proxy import parse_proxy


class ProxyMiddleware(object):

    def process_request(self, request, spider):
        proxy = parse_proxy()
        proxies = proxy['proxies']
        request.meta['proxy'] = proxies['https']
        # log.msg("Proxy added", level=log.DEBUG)
        logging.log(logging.DEBUG, "Proxy added")


class RandomUserAgentMiddleware(object):

    def process_request(self, request, spider):
        settings = get_project_settings()
        ua = random.choice(settings.get('USER_AGENT_LIST'))
        if ua:
            request.headers.setdefault('User-Agent', ua)
        # log.msg("USER AGENT IS: " + ua, level=log.DEBUG)
        logging.log(logging.DEBUG, "USER AGENT IS: " + ua)
