# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
import re

from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime
from scrapy.shell import inspect_response

from qatarliving.items import *
from qatarliving.settings import *

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


class QatarlivingParserSpider(scrapy.Spider):
    name = "qatarliving_old_parser"
    allowed_domains = ["qatarliving"]

    # start_urls = ['https://www.qatarliving.com/classifieds/properties/sale',
    #               'https://www.qatarliving.com/classifieds/properties/rent',
    #               'https://www.qatarliving.com/classifieds/commercial-properties/sale',
    #               'https://www.qatarliving.com/classifieds/commercial-properties/rent']

    allowed_domains = ['qatarliving.com']
    HEADERS = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
               'accept-encoding': 'gzip, deflate',
               'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
               'cache-control': 'no-cache',
               'upgrade-insecure-requests': '1',
               'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', }

    def start_requests(self):
        urls = ['https://www.qatarliving.com/classifieds/properties/sale',
                'https://www.qatarliving.com/classifieds/properties/rent',
                'https://www.qatarliving.com/classifieds/commercial-properties/sale',
                'https://www.qatarliving.com/classifieds/commercial-properties/rent']

        for url in urls:
            yield Request(url=url, headers=self.HEADERS, callback=self.parse,)

    def parse(self, response):
        # inspect_response(response, self)
        parent_url = response.url.replace(
            'https://www.qatarliving.com', '').strip()
        type_select = response.xpath(
            '//div[@id="edit-type"]/div/label/text()').extract()
        bedrooms_select = response.xpath(
            '//select[@id="edit-property-bedroom"]/option/@value').extract()
        location_select = response.xpath(
            '//select[@id="edit-search-location"]/option/text()').extract()

        location_select = [x.strip().replace(' / ', '-').strip().replace(' ', '-').strip(
        ).strip('-').lower() for x in location_select] if location_select else ''
        type_select = [x.strip().lower().replace(' ', '-')
                       for x in type_select] if type_select else []

        if bedrooms_select:
            for loc in location_select:
                for bed in bedrooms_select:
                    for p_type in type_select:
                        url = 'https://www.qatarliving.com/classifieds/properties/%s/in-%s/?price_min=0&price_max=500000&property_bedroom=%s&advertiser=all' % (
                            str(p_type), str(loc), str(bed))
                        meta = {'parent_url': parent_url}
                        yield Request(url=url, meta=meta, headers=self.HEADERS, callback=self.parse_search,)
        else:
            for loc in location_select:
                for p_type in type_select:
                    url = 'https://www.qatarliving.com/classifieds/commercial-properties/%s/in-%s/?price_min=0&price_max=500000&advertiser=all' % (
                        str(p_type), str(loc))
                    meta = {'parent_url': parent_url}
                    yield Request(url=url, meta=meta, headers=self.HEADERS, callback=self.parse_search,)

    def parse_search(self, response):
        # inspect_response(response, self)
        parent_url = response.meta['parent_url']
        properties_list = response.xpath(
            '//div[@id="classified_search_results"]/span/@href').extract()
        for prop in properties_list:
            prop = response.urljoin(prop)
            meta = {'parent_url': parent_url}
            yield Request(url=prop, meta=meta, headers=self.HEADERS, callback=self.parse_property,)

        pagination = response.xpath(
            '//div[contains(@class,"pagination")]/a/@href').extract()
        if pagination:
            pagination_url = response.urljoin(pagination[-2].strip())
            meta = {'parent_url': parent_url}
            yield Request(url=pagination_url, meta=meta, headers=self.HEADERS, callback=self.parse_search,)

    def parse_property(self, response):
        parent_url = response.meta['parent_url']
        currency = ''
        price_per = ''
        published_at = ''
        property_id_url = response.xpath(
            '//link[@rel="shortlink"]/@href').extract()
        broker_display_name = response.xpath(
            '//div[@class="b-seller--el-header"]//a[contains(@href,"user")]/text()').extract()
        category = response.xpath(
            '//aside[@class="b-aside"]/div/a/text()').extract()
        category_url = response.xpath(
            '//aside[@class="b-aside"]/div/a/@href').extract()
        title = response.xpath('//h1/text()').extract()
        description = response.xpath(
            '//div[@class="b-property-description"]//div[@class="col-md-8"]//text()').extract()
        location = response.xpath(
            '//div[@class="col-md-4 fa-location"]/p/text()').extract()
        price = response.xpath(
            '//p[@class="b-price-conditions--el-deposit-val b-par-mod-clear b-line-mod-thin"]/text()').extract()
        # price_per_text = response.xpath(
        #     '//div[@class="b-aside--el-wrapper-desktop"]//div[@class="b-price-conditions--el-header"]/p[@class="b-price-conditions--el-deposit-time b-par-mod-clear b-line-mod-thin"]//text()').extract()
        bedrooms = response.xpath(
            '//p[contains(text(),"Property bedrooms")]/following-sibling::p[1]/text()').extract()
        bathrooms = response.xpath(
            '//p[contains(text(),"Property bathrooms")]/following-sibling::p[1]/text()').extract()
        furnished = response.xpath(
            '//p[contains(text(),"Property furnish")]/following-sibling::p[1]/text()').extract()
        img = response.xpath('//li//@src').extract()
        aminity = response.xpath(
            '//div[@class="row"]/div/ul//li/em/text()|//h3[contains(text(), "Facilities")]/following-sibling::ul//li/text()').extract()

        price_per_text = response.xpath(
            '//div[@class="b-aside--el-wrapper-desktop"]//p[@class="b-price-conditions--el-deposit-time b-par-mod-clear b-line-mod-thin"]//text()').extract()

        property_id = property_id_url[0].strip().replace(
            'https://www.qatarliving.com/node/', '') if property_id_url else ''
        broker_display_name = broker_display_name[
            0].strip() if broker_display_name else ''
        published_at = response.xpath(
            '//time[@class="timeago"]/@datetime').extract()

        # category = [x.strip() for x in category] if category else ''
        # category = [x.strip()
        #             for x in category if category] if category else ''
        # category = ' > '.join(category).strip() if category else ''
        # category_url = category_url[-1].strip().replace(
        #     'https://www.qatarliving.com', '').strip() if category_url else ''
        if 'rent' in parent_url:
            category_url = parent_url
            category = 'rent'
        elif 'sale' in parent_url:
            category_url = parent_url
            category = 'sale'
        title = title[0].strip() if title else ''
        description = ' '.join(''.join(description).lstrip(
            'Information').strip().split())if description else ''
        location = location[-1].strip() if location else ''
        price = price[0].strip() if price else ''
        price_per_text = ' '.join(price_per_text) if price_per_text else ''
        if price_per_text and '/' in price_per_text:
            price_per_split = price_per_text.split('/')
            currency = price_per_split[0].strip()
            price_per = price_per_split[1].strip()
        elif 'QAR' in price_per_text:
            currency = 'QAR'
        bedrooms = bedrooms[0].strip() if bedrooms else ''
        bathrooms = bathrooms[0].strip() if bathrooms else ''
        furnished = furnished[0].strip() if furnished else ''
        scraped_ts = (datetime.now()).strftime("%Y-%m-%d")
        aminity = ' '.join(', '.join(aminity).split())
        img1 = str(len(img))
        phone_numbers = response.xpath(
            '//aside[@class="b-aside"]//a[contains(text(),"Call Now")]/@mobile').extract()
        phone_numbers = list(set(phone_numbers)) if phone_numbers else ''
        phone_numbers = ', '.join(phone_numbers) if phone_numbers else ''

        now = datetime.now()
        current = datetime(now.year, now.month, 1)
        next_month = datetime(now.year + int(now.month / 12),
                              ((now.month % 12) + 1), 1)
        now_date_int = int(now.strftime("%d"))
        if now_date_int <= 31 and now_date_int >= 25:
            iteration_month = next_month.strftime("%m")
            iteration_year = next_month.strftime("%Y")
        else:
            iteration_month = now.strftime("%m")
            iteration_year = now.strftime("%Y")
        iteration_number = iteration_year + '_' + iteration_month
        published_at = published_at[0].strip().split('T')[0].strip() if published_at else ''

        items = QatarlivingItem(
            id=property_id,
            url=response.url,
            broker_display_name=broker_display_name,
            broker=broker_display_name.upper(),
            category=category,
            category_url=category_url,
            title=title,
            description=description,
            location=location,
            price=price,
            currency=currency,
            price_per=price_per,
            bedrooms=bedrooms,
            bathrooms=bathrooms,
            furnished=furnished,
            rera_permit_number='',
            dtcm_licence='',
            scraped_ts=scraped_ts,
            number_of_photos=img1,
            amenities=aminity,
            details='',
            agent_name='',
            reference_number='',
            user_id='',
            phone_number=phone_numbers,
            date=scraped_ts,
            iteration_number=iteration_number,
            sub_category_1='',
            sub_category_2='',
            property_type='',
            depth='',
            published_at=published_at,

        )
        if title:
            yield items
