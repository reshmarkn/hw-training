# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html

# -*- coding: utf-8 -*-
import pymongo
from pymongo import MongoClient
from scrapy.exceptions import DropItem
from datetime import datetime
from bayut_weekly.items import *
from bayut_weekly.settings import *
from datetime import date,timedelta
import timeit
import sys
import boto3

from queuehandler import Sqshandler



class BayutWeeklyPipeline(object):

    def __init__(self, *args, **kwargs):

        self.mongo_uri = MONGO_URI
        self.mongo_db = MONGODB_DB
        self.dup_key = 'url'
        self.mongo_collection_product = MONGODB_COLLECTION_AGENT
        self.mongo_collection_links = MONGODB_COLLECTION_AGENT_URL
        self.mongo_collection_product_failed=MONGODB_COLLECTION_AGENT_FAILED_URLS
        
        self.batch=[]
        self.insert_count=0
        self.totalsize=0

    def open_spider(self, spider):

        print("=====================START==================================")

        self.start=timeit.default_timer()

        self.client = MongoClient(self.mongo_uri)
        try:
            self.client.admin.command(
                "enablesharding", self.mongo_db)
            self.client.admin.command("shardcollection", self.mongo_db + '.' + self.mongo_collection_product, key={
                'url': 1}, unique=True)
            self.client.admin.command("shardcollection", self.mongo_db + '.' + self.mongo_collection_links, key={
                'url': 1}, unique=True)
            self.client.admin.command("shardcollection", self.mongo_db + '.' + self.mongo_collection_product_failed, key={
                'url': 1}, unique=True)
        except:
            try:
                self.client.admin.command("shardcollection", self.mongo_db + '.' + self.mongo_collection_product, key={
                    'url': 1}, unique=True)
            except:
                pass
            try:
                self.client.admin.command("shardcollection", self.mongo_db + '.' + self.mongo_collection_links, key={
                    'url': 1}, unique=True)

            except:
                pass
            try:
                self.client.admin.command("shardcollection", self.mongo_db + '.' + self.mongo_collection_product_failed, key={
                    'url': 1}, unique=True)

            except:
                pass


        self.db = self.client[self.mongo_db]

        self.sqsobj = Sqshandler(Aws_access_key_id,Aws_secret_access_key,QUEUE_NAME,'eu-west-2')



    def close_spider(self, spider):

        if len(self.batch)!=0:
            print("/////////Batch",self.batch)

            self.totalsize+=sys.getsizeof(self.batch)
            self.sqsobj.btachenqueue(self.batch)
            self.insert_count+=len(self.batch)

        

        print("=====================FINISH==================================")
        self.stop=timeit.default_timer()


        total_time =str(self.stop - self.start )

        print(QUEUE_NAME)
        
        print('Total time : ',total_time,' seconds')
        print("Duration:",timedelta(seconds=float(total_time)))
        print("Total inserted count:",self.insert_count)
        print("Total size:",self.totalsize," bytes")
        self.client.close()



    def process_item(self, item, spider):
        
        if isinstance(item, BayutItem):
            try:
                self.db[self.mongo_collection_product].insert(dict(item))
            except Exception:
                raise DropItem("Dropping duplicate item")


        if isinstance(item, BayutFailUrlItem):
            try:
                self.db[self.mongo_collection_product_failed].insert(dict(item))
            except Exception:
                raise DropItem("Dropping duplicate item")
        
        
        if isinstance(item, BayutUrlItem):
            try:
                self.db[self.mongo_collection_links].insert(dict(item))

                link=item.get("url_string")
                if link:
                    self.batch.append(link)

                    print("----------------------Recoreded:",link)
                    
                    print("batch length",len(self.batch))
                    
                    if len(self.batch)==10:
                        print("///////////Batch",self.batch)

                        self.totalsize+=sys.getsizeof(self.batch)
                        self.sqsobj.btachenqueue(self.batch)
                        self.insert_count+=len(self.batch)
                        
                        self.batch=[]
            except Exception:
                raise DropItem("Dropping duplicate item")
        
        return item
