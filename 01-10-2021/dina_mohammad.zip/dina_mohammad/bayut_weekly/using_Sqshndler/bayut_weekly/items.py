# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

# -*- coding: utf-8 -*-
import scrapy


class BayutUrlItem(scrapy.Item):
    url = scrapy.Field()
    url_string = scrapy.Field()
    status = scrapy.Field()
    listing_label = scrapy.Field()
    sub_category_1 = scrapy.Field()
    sub_category_2 = scrapy.Field()
    property_type = scrapy.Field()
    depth = scrapy.Field()
    
class BayutFailUrlItem(scrapy.Item):
    url = scrapy.Field()


class BayutItem(scrapy.Item):

    reference_number = scrapy.Field()
    id = scrapy.Field()
    url = scrapy.Field()
    broker_display_name = scrapy.Field()
    broker = scrapy.Field()
    category = scrapy.Field()
    category_url = scrapy.Field()
    title = scrapy.Field()
    description = scrapy.Field()
    location = scrapy.Field()
    price = scrapy.Field()
    currency = scrapy.Field()
    price_per = scrapy.Field()
    bedrooms = scrapy.Field()
    bathrooms = scrapy.Field()
    furnished = scrapy.Field()
    rera_permit_number = scrapy.Field()
    dtcm_licence = scrapy.Field()
    scraped_ts = scrapy.Field()
    amenities = scrapy.Field()
    details = scrapy.Field()
    agent_name = scrapy.Field()
    number_of_photos = scrapy.Field()
    user_id = scrapy.Field()
    phone_number = scrapy.Field()
    date = scrapy.Field()
    iteration_number = scrapy.Field()
    rera_registration_number = scrapy.Field()
    ded_license_number = scrapy.Field()
    rera_length = scrapy.Field()
    latitude = scrapy.Field()
    longitude = scrapy.Field()
    listing_id = scrapy.Field()
    package_type = scrapy.Field()
    locality = scrapy.Field()
    object_id = scrapy.Field()
    completion_status = scrapy.Field()
    ad_type = scrapy.Field()
    verified = scrapy.Field()
    sub_category_1 = scrapy.Field()
    sub_category_2 = scrapy.Field()
    property_type = scrapy.Field()
    depth = scrapy.Field()
    published_at = scrapy.Field()
