# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging

from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime
from pymongo import MongoClient
from scrapy.exceptions import DropItem

from bayut_weekly.items import *
from bayut_weekly.settings import *


handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


class BayutWeeklyCrawlerSpider(Spider):
	name = 'bayut_weekly_crawler'

	allowed_domains = ['bayut.com']

	header = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
			  'accept-encoding': 'gzip, deflate, br',
			  'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
			  'cache-control': 'no-cache',
			  'pragma': 'no-cache',
			  'upgrade-insecure-requests': '1',
			  'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', }

	def start_requests(self):
		datas = [
				{'parent': 'https://www.bayut.com/for-sale/apartments/uae/?completion_status=ready',
				"sub_category_1": "Residential",
				"property_type": "Apartment",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/townhouses/uae/?completion_status=ready',
				"sub_category_1": "Residential",
				"property_type": "Townhouse",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/villa-compound/uae/?completion_status=ready',
				"sub_category_1": "Residential",
				"property_type": "Villa Compound",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/residential-plots/uae/?completion_status=ready',
				"sub_category_1": "Residential",
				"property_type": "Residential Plot",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/residential-building/uae/?completion_status=ready',
				"sub_category_1": "Residential",
				"property_type": "Residential Building",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/villas/uae/?completion_status=ready',
				"sub_category_1": "Residential",
				"property_type": "Villa",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/penthouse/uae/?completion_status=ready',
				"sub_category_1": "Residential",
				"property_type": "Penthouse",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/hotel-apartments/uae/?completion_status=ready',
				"sub_category_1": "Residential",
				"property_type": "Hotel Apartment",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/residential-floors/uae/?completion_status=ready',
				"sub_category_1": "Residential",
				"property_type": "Residential Floor",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/offices/uae/?completion_status=ready',
				"sub_category_1": "Commercial",
				"property_type": "Office",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/warehouses/uae/?completion_status=ready',
				"sub_category_1": "Commercial",
				"property_type": "Warehouse",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/commercial-villas/uae/?completion_status=ready',
				"sub_category_1": "Commercial",
				"property_type": "Commercial Villa",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/commercial-plots/uae/?completion_status=ready',
				"sub_category_1": "Commercial",
				"property_type": "Commercial Plot",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/commercial-buildings/uae/?completion_status=ready',
				"sub_category_1": "Commercial",
				"property_type": "Commercial Building",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/industrial-land/uae/?completion_status=ready',
				"sub_category_1": "Commercial",
				"property_type": "Industrial Land",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/showrooms/uae/?completion_status=ready',
				"sub_category_1": "Commercial",
				"property_type": "Showroom",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/shops/uae/?completion_status=ready',
				"sub_category_1": "Commercial",
				"property_type": "Shop",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/labour-camps/uae/?completion_status=ready',
				"sub_category_1": "Commercial",
				"property_type": "Labour Camp",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/bulk-units/uae/?completion_status=ready',
				"sub_category_1": "Commercial",
				"property_type": "Bulk Unit",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/commercial-floors/uae/?completion_status=ready',
				"sub_category_1": "Commercial",
				"property_type": "Commercial Floor",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/factories/uae/?completion_status=ready',
				"sub_category_1": "Commercial",
				"property_type": "Factory",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/mixed-use-land/uae/?completion_status=ready',
				"sub_category_1": "Commercial",
				"property_type": "Mixed Use Land",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/commerical-properties/uae/?completion_status=ready',
				"sub_category_1": "Commercial",
				"property_type": "Other Commercial",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/apartments/uae/?completion_status=off-plan',
				"sub_category_1": "Residential",
				"property_type": "Apartment",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/townhouses/uae/?completion_status=off-plan',
				"sub_category_1": "Residential",
				"property_type": "Townhouse",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/villa-compound/uae/?completion_status=off-plan',
				"sub_category_1": "Residential",
				"property_type": "Villa Compound",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/residential-plots/uae/?completion_status=off-plan',
				"sub_category_1": "Residential",
				"property_type": "Residential Plot",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/residential-building/uae/?completion_status=off-plan',
				"sub_category_1": "Residential",
				"property_type": "Residential Building",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/villas/uae/?completion_status=off-plan',
				"sub_category_1": "Residential",
				"property_type": "Villa",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/penthouse/uae/?completion_status=off-plan',
				"sub_category_1": "Residential",
				"property_type": "Penthouse",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/hotel-apartments/uae/?completion_status=off-plan',
				"sub_category_1": "Residential",
				"property_type": "Hotel Apartment",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/residential-floors/uae/?completion_status=off-plan',
				"sub_category_1": "Residential",
				"property_type": "Residential Floor",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/offices/uae/?completion_status=off-plan',
				"sub_category_1": "Commercial",
				"property_type": "Office",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/warehouses/uae/?completion_status=off-plan',
				"sub_category_1": "Commercial",
				"property_type": "Warehouse",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/commercial-villas/uae/?completion_status=off-plan',
				"sub_category_1": "Commercial",
				"property_type": "Commercial Villa",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/commercial-plots/uae/?completion_status=off-plan',
				"sub_category_1": "Commercial",
				"property_type": "Commercial Plot",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/commercial-buildings/uae/?completion_status=off-plan',
				"sub_category_1": "Commercial",
				"property_type": "Commercial Building",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/industrial-land/uae/?completion_status=off-plan',
				"sub_category_1": "Commercial",
				"property_type": "Industrial Land",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/showrooms/uae/?completion_status=off-plan',
				"sub_category_1": "Commercial",
				"property_type": "Showroom",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/shops/uae/?completion_status=off-plan',
				"sub_category_1": "Commercial",
				"property_type": "Shop",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/labour-camps/uae/?completion_status=off-plan',
				"sub_category_1": "Commercial",
				"property_type": "Labour Camp",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/bulk-units/uae/?completion_status=off-plan',
				"sub_category_1": "Commercial",
				"property_type": "Bulk Unit",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/commercial-floors/uae/?completion_status=off-plan',
				"sub_category_1": "Commercial",
				"property_typoff-plane": "Commercial Floor",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/factories/uae/?completion_status=off-plan',
				"sub_category_1": "Commercial",
				"property_type": "Factory",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/mixed-use-land/uae/?completion_status=off-plan',
				"sub_category_1": "Commercial",
				"property_type": "Mixed Use Land",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/for-sale/commerical-properties/uae/?completion_status=off-plan',
				"sub_category_1": "Commercial",
				"property_type": "Other Commercial",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/to-rent/apartments/uae/',
				"sub_category_1": "Residential",
				"property_type": "Apartment",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/to-rent/townhouses/uae/',
				"sub_category_1": "Residential",
				"property_type": "Townhouse",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/to-rent/villa-compound/uae/',
				"sub_category_1": "Residential",
				"property_type": "Villa Compound",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/to-rent/residential-plots/uae/',
				"sub_category_1": "Residential",
				"property_type": "Residential Plot",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/to-rent/residential-building/uae/',
				"sub_category_1": "Residential",
				"property_type": "Residential Building",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/to-rent/villas/uae/',
				"sub_category_1": "Residential",
				"property_type": "Villa",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/to-rent/penthouse/uae/',
				"sub_category_1": "Residential",
				"property_type": "Penthouse",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/to-rent/hotel-apartments/uae/',
				"sub_category_1": "Residential",
				"property_type": "Hotel Apartment",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/to-rent/residential-floors/uae/',
				"sub_category_1": "Residential",
				"property_type": "Residential Floor",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/to-rent/offices/uae/',
				"sub_category_1": "Commercial",
				"property_type": "Office",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/to-rent/warehouses/uae/',
				"sub_category_1": "Commercial",
				"property_type": "Warehouse",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/to-rent/commercial-villas/uae/',
				"sub_category_1": "Commercial",
				"property_type": "Commercial Villa",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/to-rent/commercial-plots/uae/',
				"sub_category_1": "Commercial",
				"property_type": "Commercial Plot",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/to-rent/commercial-buildings/uae/',
				"sub_category_1": "Commercial",
				"property_type": "Commercial Building",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/to-rent/industrial-land/uae/',
				"sub_category_1": "Commercial",
				"property_type": "Industrial Land",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/to-rent/showrooms/uae/',
				"sub_category_1": "Commercial",
				"property_type": "Showroom",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/to-rent/shops/uae/',
				"sub_category_1": "Commercial",
				"property_type": "Shop",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/to-rent/labour-camps/uae/',
				"sub_category_1": "Commercial",
				"property_type": "Labour Camp",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/to-rent/bulk-units/uae/',
				"sub_category_1": "Commercial",
				"property_type": "Bulk Unit",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/to-rent/commercial-floors/uae/',
				"sub_category_1": "Commercial",
				"property_type": "Commercial Floor",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/to-rent/factories/uae/',
				"sub_category_1": "Commercial",
				"property_type": "Factory",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/to-rent/mixed-use-land/uae/',
				"sub_category_1": "Commercial",
				"property_type": "Mixed Use Land",
				"sub_category_2": ""},
				{'parent': 'https://www.bayut.com/to-rent/commerical-properties/uae/',
				"sub_category_1": "Commercial",
				"property_type": "Other Commercial",
				"sub_category_2": ""}

		]

		for data in datas:
			meta = data
			url = data.get('parent')
			yield Request(url, callback=self.parse_profile, meta=meta, headers=self.header)

	def parse_profile(self, response):
		if response.status != 404:
			parent = response.meta['parent']
			meta = response.meta
			property_list = response.xpath(
				'//li[@role="article"]/article')
			for prop in property_list:
				depth =''
				link = prop.xpath(
					'div/a/@href').extract()
				listing_label = prop.xpath(
					'div//div[@aria-label="Listing label"]/span/@aria-label').extract()
				link = link[0].strip() if link else ''
				listing_label = listing_label[0].strip(
				) if listing_label else 'no_adv_type'
				if link:
					url = response.urljoin(link.strip())
					status = ''
					if '?completion_status=ready' in  parent:
						status = 'ready'
					elif '?completion_status=off-plan' in parent:
						status = 'off-plan'
					else:
						status = 'rent'
					status = status if status else 'no_status'
					listing_label = listing_label if listing_label else 'no_label'
					url_string = url + '||' + status + '||' + listing_label
					sub_category_1 = meta.get('sub_category_1')
					sub_category_2 = meta.get('sub_category_2')
					property_type = meta.get('property_type')

					if listing_label ==  'no_adv_type' or listing_label == 'no_label':
						depth = ''
					else:
						depth = listing_label

					item = BayutUrlItem(
						url=url,
						url_string=url_string,
						status=status,
						listing_label=listing_label,
						sub_category_1=sub_category_1,
						sub_category_2=sub_category_2,
						property_type=property_type,
						depth=depth
					)
					if url:
						yield item

			location_url = response.xpath(
				'//div[@aria-label="Search location links"]//a/@href').extract()
			for url in location_url:
				if url.startswith('/'):
					url = 'https://www.bayut.com'+url
				if url:
					yield Request(url, callback=self.parse_loc, meta=meta, headers=self.header)

			next_page = response.xpath(
				'//a[@title="Next"]/@href').extract_first('')
			if next_page:
				if next_page.startswith('/'):
					next_page_url = 'https://www.bayut.com'+next_page
				else:
					next_page_url = next_page
				yield Request(next_page_url, callback=self.parse_loc, meta=meta, headers=self.header)

		else:
			sleep(5)
			parent = response.meta['parent']
			meta = response.meta
			url = response.url
			yield Request(next_page_url, callback=self.parse_loc, meta=meta, headers=self.header)

	def parse_loc(self, response):
		if response.status != 404:
			parent = response.meta['parent']
			meta = response.meta
			sub_category_1 = meta.get('sub_category_1')
			sub_category_2 = meta.get('sub_category_2')
			property_type = meta.get('property_type')
			property_list = response.xpath(
				'//li[@role="article"]/article')
			for prop in property_list:
				depth = ''
				link = prop.xpath(
					'div/a/@href').extract()
				listing_label = prop.xpath(
					'div//div[@aria-label="Listing label"]/span/@aria-label').extract()
				link = link[0].strip() if link else ''
				listing_label = listing_label[0].strip(
				) if listing_label else 'no_adv_type'
				if link:
					url = response.urljoin(link.strip())
					status = ''
					if '?completion_status=ready' in parent:
						status = 'ready'
					elif '?completion_status=off-plan' in parent:
						status = 'off-plan'
					else:
						status = 'rent'
					status = status if status else 'no_status'
					listing_label = listing_label if listing_label else 'no_label'
					url_string = url + '||' + status + '||' + listing_label
					if listing_label ==  'no_adv_type' or listing_label == 'no_label':
						depth = ''
					else:
						depth = listing_label

					item = BayutUrlItem(
						url=url,
						url_string=url_string,
						status=status,
						listing_label=listing_label,
						sub_category_1=sub_category_1,
						sub_category_2=sub_category_2,
						property_type=property_type,
						depth=depth
					)
					if url:
						yield item

			location_url = response.xpath(
				'//div[@aria-label="Search location links"]//a/@href').extract()
			for url in location_url:
				if url.startswith('/'):
					url = 'https://www.bayut.com'+url
				if url:
					yield Request(url, callback=self.parse_loc, meta=meta, headers=self.header)

			next_page = response.xpath(
				'//a[@title="Next"]/@href').extract_first('')
			if next_page:
				if next_page.startswith('/'):
					next_page_url = 'https://www.bayut.com'+next_page
				else:
					next_page_url = next_page
				yield Request(next_page_url, callback=self.parse_loc, meta=meta, headers=self.header)

		else:
			sleep(5)
			parent = response.meta['parent']
			meta = response.meta
			url = response.url
			yield Request(next_page_url, callback=self.parse_loc, meta=meta, headers=self.header)
