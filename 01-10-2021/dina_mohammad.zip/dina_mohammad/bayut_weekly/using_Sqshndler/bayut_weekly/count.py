from pymongo import MongoClient
from settings import *

client = MongoClient(MONGO_URI)
db = client[MONGODB_DB ]
print(MONGODB_DB )
colist = [MONGODB_COLLECTION_AGENT,MONGODB_COLLECTION_AGENT_URL,MONGODB_COLLECTION_AGENT_FAILED_URLS]

for j in colist:
	print(colist.index(j)+1, j, ":",str(db[j].estimated_document_count()))