import ast
import logging
import pika
import json
from pymongo import MongoClient
from datetime import datetime
from slacker import Slacker
from time import sleep
from slacker import Slacker

Slack = Slacker(
    'xoxp-24300212688-35464554529-262255845088-43b7f5b45d669c16a2fc81caa80fa6e2')
USERS = ['@Ramesh']

QUEUE_HOST = '159.89.47.171'  # load balancer
QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'
QUEUE_NAME = 'ha.bayut_uae_weekly'

sucess_flag = False
queue_flag = False

Slack = Slacker(
	'xoxp-24300212688-35464554529-262255845088-43b7f5b45d669c16a2fc81caa80fa6e2')
USERS = ['@Ramesh','@anu']

now = datetime.now()
iteration_month = now.strftime("%m")
iteration_year = now.strftime("%Y")
now_date_int = int(now.strftime("%d"))
if now_date_int <=7 and now_date_int >=1:
	iteration_suffix = '01'
elif now_date_int <=14 and now_date_int >=8:
	iteration_suffix = '02'

elif now_date_int <=21 and now_date_int >=15:
	iteration_suffix = '03'

elif now_date_int <=28 and now_date_int >=22:
	iteration_suffix = '04'

elif now_date_int <=31 and now_date_int >=29:
	iteration_suffix = '05'

db_monthly = iteration_year + '_'+ iteration_month
coll_weekly = iteration_year + '_'+ iteration_month + '_weekly' + iteration_suffix

MONGODB_DB = 'dina_mohammad_weekly_'  + db_monthly
MONGODB_COLLECTION_AGENT = coll = 'bayut_uae_url_' + coll_weekly

client = MongoClient(
	'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
db = client[MONGODB_DB]


COLLECTION_NAME = MONGODB_COLLECTION_AGENT
FIELD = 'url_string'

FIELD = FIELD.split(',')
FIELD = [x.strip() for x in FIELD if x.strip()]

searchString = {'_id': 1}
for field in FIELD:
    searchString[field] = 1
# searchString = {'url': 1}
print(searchString)
result = db[COLLECTION_NAME].find({}, searchString)
count = db[MONGODB_COLLECTION_AGENT].find().count()
if count>=100000:
    message = 'Bayut crawler Running succesfull, count :' + str(count)  
    logging.info('%s', message)
    for user in USERS:
        Slack.chat.post_message(user, str(message))

    try:
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_HOST, socket_timeout=3000))
        channel = connection.channel()

        channel.queue_declare(queue=QUEUE_NAME, durable=True)

        for data in result:

            document = dict(data)
            if len(FIELD) == 1:
                document = document[FIELD[0]]
                channel.basic_publish(
                    exchange='', routing_key=QUEUE_NAME, body=document)
                sleep(0.0001)

            else:
                channel.basic_publish(
                    exchange='', routing_key=QUEUE_NAME, body=json.dumps(document))
                sleep(0.0001)
        connection.close()
        queue_flag = True
    except:
        try:
            credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
            connection = pika.BlockingConnection(pika.ConnectionParameters(
                credentials=credentials, host=QUEUE_HOST, socket_timeout=3000))
            channel = connection.channel()

            channel.queue_declare(queue=QUEUE_NAME, durable=True)

            for data in result:

                document = dict(data)
                if len(FIELD) == 1:
                    document = document[FIELD[0]]
                    channel.basic_publish(
                        exchange='', routing_key=QUEUE_NAME, body=document)
                    sleep(0.0001)

                else:
                    channel.basic_publish(
                        exchange='', routing_key=QUEUE_NAME, body=json.dumps(document))
                    sleep(0.0001)
            connection.close()
            queue_flag = True
        except:
            queue_flag = False

    if queue_flag:
        message = 'Bayut crawler enqueue succesfull, count :' + str(count)  
        logging.info('%s', message)
        for user in USERS:
            Slack.chat.post_message(user, str(message))            

else:
    message = 'Bayut crawler Running failed,aborting queueing, count :' + str(count)  
    logging.info('%s', message)
    for user in USERS:
        Slack.chat.post_message(user, str(message))    


client.close()