import os
import ast
import logging
from pymongo import MongoClient
from datetime import datetime
from slacker import Slacker

export_flag = False
delivery_flag = False

Slack = Slacker(
	'xoxp-24300212688-35464554529-262255845088-43b7f5b45d669c16a2fc81caa80fa6e2')
USERS = ['@Ramesh']

now = datetime.now()
iteration_month = now.strftime("%m")
iteration_year = now.strftime("%Y")
now_date_int = int(now.strftime("%d"))
if now_date_int <=7 and now_date_int >=1:
	iteration_suffix = '01'
elif now_date_int <=14 and now_date_int >=8:
	iteration_suffix = '02'

elif now_date_int <=21 and now_date_int >=15:
	iteration_suffix = '03'

elif now_date_int <=28 and now_date_int >=22:
	iteration_suffix = '04'

elif now_date_int <=31 and now_date_int >=29:
	iteration_suffix = '05'

db_monthly = iteration_year + '_'+ iteration_month
coll_weekly = iteration_year + '_'+ iteration_month + '_weekly' + iteration_suffix
iteration_num = iteration_year + '_'+ iteration_month + '_' + iteration_suffix
MONGODB_DB = db_name = 'dina_mohammad_weekly_'  + db_monthly
MONGODB_COLLECTION_AGENT = coll = 'bayut_uae_' + coll_weekly
iteration_suffix_strip = iteration_suffix.strip('0')
out = 'bayut_uae_' + db_monthly + '_' + iteration_suffix_strip+'.json'

client = MongoClient(
	'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
db = client[MONGODB_DB]


fields = ['ad_type', 'agent_name', 'amenities', 'bathrooms', 'bedrooms', 'broker', 'broker_display_name', 'category', 'category_url', 'completion_status', 'currency', 'date', 'ded_license_number', 'description', 'details', 'dtcm_licence', 'furnished', 'id', 'iteration_number',
		  'latitude', 'listing_id', 'locality', 'location', 'longitude', 'number_of_photos', 'object_id', 'package_type', 'phone_number', 'price', 'price_per', 'reference_number', 'rera_length', 'rera_permit_number', 'rera_registration_number', 'scraped_ts', 'title', 'url', 'user_id', 'verified']


field_count =  {}
count = db[MONGODB_COLLECTION_AGENT].find().count()
field_count.update({'total count':count})
date = db[MONGODB_COLLECTION_AGENT].distinct('date')
iteration_number = db[MONGODB_COLLECTION_AGENT].distinct('iteration_number')
field_count.update({'dates':date})
field_count.update({'iteration_number_value':iteration_number})

empty_fields = []
for field in fields:
	query = '{"'+field+'":{"$exists": True, "$ne":""}}'
	query = ast.literal_eval(query)
	my_col = db[MONGODB_COLLECTION_AGENT].find(query)
	count = my_col.count()
	count_int = int(count)
	if field != 'dtcm_licence' and field != 'furnished' and field != 'ad_type':
		if count_int ==0:
			empty_fields.append(field)

	field_count.update({field:count})

if len(empty_fields) != 0:
	print('empty fields found')
	empty = ', '.join(empty_fields)
	message = 'aborted data delivery, empty fields found :'+ empty + '. fields count :' + str(field_count)  
	logging.info('%s', message)
	for user in USERS:
		Slack.chat.post_message(user, str(message))

else:
	if len(iteration_number) ==1 and iteration_number[0] == iteration_num :
		message = 'no issues in crawl.iteration_number : ' + iteration_number[0] + 'and details as follows::' + '\n' +str(field_count)
		logging.info('%s', message)
		for user in USERS:
			Slack.chat.post_message(user, str(message))
		try:
			os.system(
			'''mongoexport --host 104.131.41.31  --port 27017 --db {}  --collection {} --forceTableScan --type json --username datahut --password 'cGFzc21lMTIz' --authenticationDatabase admin  | sed '/"_id":/s/"_id":[^,]*,//' > {}'''.format(db_name, coll, out))
			export_flag = True

		except:
			pass

		if export_flag:
			file_path = './'+ str(out)
			file_size_bytes = os.path.getsize(file_path)
			file_size_mb = round(file_size_bytes/(1024*1024),2)
			message = 'mongoexport sucessfull :' + str(out) + ':' + str(file_size_mb)+ ' MB'
			logging.info('%s', message)
			for user in USERS:
				Slack.chat.post_message(user, str(message))
			try:
				os.system(
				'''aws s3 cp {} s3://pf-datahut-data-prod-eu/datahut/bayut_uae/{}/{}/weekly_{}/  --acl bucket-owner-full-control --profile clouduser'''.format(out, iteration_year, iteration_month, iteration_suffix))
				delivery_flag = True
			except:
				pass
			if delivery_flag:
				message = 'delivery sucessfull :' + str(out)
				logging.info('%s', message)
				for user in USERS:
					Slack.chat.post_message(user, str(message))
				os.system('''rm {}'''.format(out))
			else:
				message = 'delivery failed :' + str(out)
				logging.info('%s', message)
				for user in USERS:
					Slack.chat.post_message(user, str(message))
		else:
			message = 'mongoexport failed :' + str(out)
			logging.info('%s', message)
			for user in USERS:
				Slack.chat.post_message(user, str(message))

	else:
		message = 'issues with iteration_number :'+ str(iteration_number)
		logging.info('%s', message)
		for user in USERS:
			Slack.chat.post_message(user, str(message))

client.close()