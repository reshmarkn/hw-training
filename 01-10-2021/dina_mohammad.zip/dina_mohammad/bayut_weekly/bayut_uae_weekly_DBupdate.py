import pymongo
from pymongo import MongoClient
import json
from scrapy.exceptions import DropItem
from bayut_weekly.items import *
from datetime import datetime

now = datetime.now()
iteration_month = now.strftime("%m")
iteration_year = now.strftime("%Y")
now_date_int = int(now.strftime("%d"))
if now_date_int <=7 and now_date_int >=1:
    iteration_suffix = '01'
elif now_date_int <=14 and now_date_int >=8:
    iteration_suffix = '02'

elif now_date_int <=21 and now_date_int >=15:
    iteration_suffix = '03'

elif now_date_int <=28 and now_date_int >=22:
    iteration_suffix = '04'

elif now_date_int <=31 and now_date_int >=29:
    iteration_suffix = '05'

iteration_month = iteration_month.strip()
db_monthly = iteration_year + '_'+ iteration_month
coll_weekly = iteration_year + '_'+ iteration_month + '_weekly' + iteration_suffix

MONGODB_DB = 'SQS_dina_mohammad_weekly_'  + db_monthly
MONGODB_COLLECTION_AGENT = 'SQS_bayut_uae_'+ coll_weekly
MONGODB_COLLECTION_AGENT_URL = 'SQS_bayut_uae_url_' + coll_weekly


client = MongoClient('mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')


DB_NAME = MONGODB_DB
db = client[DB_NAME]

col_up= MONGODB_COLLECTION_AGENT
print(DB_NAME, col_up)
count = db[col_up].count()
print(count)
json_col = MONGODB_COLLECTION_AGENT_URL + '.json'
print('json_col:', json_col)
col_match=open(json_col).readlines()
entry=[json.loads(x.strip()) for x in col_match]


filist=['sub_category_1','sub_category_2','property_type','depth']


for item in entry:
	itemdict=dict()

	url=item['url']

	for i in filist:
		itemdict[i]=item.get(i)

	db[col_up].update_one({'url':url},{"$set":itemdict})

	print(url,itemdict)
