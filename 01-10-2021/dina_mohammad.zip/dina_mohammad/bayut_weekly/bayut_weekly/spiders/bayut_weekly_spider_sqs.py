# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
import boto3

from pymongo import MongoClient
from scrapy.exceptions import DropItem
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime

from bayut_weekly.items import *
from bayut_weekly.settings import *

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


class BayutWeeklySpider(Spider):
    name = 'bayut_weekly_spider_sqs'
    allowed_domains = ['https://www.bayut.com']
    headers = {'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
               'accept-encoding': 'gzip, deflate, br',
               'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
               'cache-control': 'no-cache',
               'pragma': 'no-cache',
               'upgrade-insecure-requests': '1',
               'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', }

    def start_requests(self):
        # Fetching URL from queue until queue is empty


        queue_name = 'bayut_test_std'
        Aws_access_key_id = 'AKIAI6QJACHIXHRGJZCQ'
        Aws_secret_access_key = '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'
        sqs = boto3.client('sqs', region_name='eu-west-2', aws_access_key_id=Aws_access_key_id,
                           aws_secret_access_key=Aws_secret_access_key)
        queue_url = "https://sqs.us-west-1.amazonaws.com/433218223882/" + \
            queue_name  # Receive message from SQS queue
        while True:
            response = sqs.receive_message(
                QueueUrl=queue_url,
                AttributeNames=[
                    'SentTimestamp'
                ],
                MaxNumberOfMessages=1,
                MessageAttributeNames=[
                    'All'
                ],
                VisibilityTimeout=10,
                WaitTimeSeconds=15
            )
            # if response:
            if response.get('Messages'):
                message = response['Messages'][0]
                # Delete received message from queue
                receipt_handle = message['ReceiptHandle']
                url = message['Body']
                # print('Body :',url)
                # url = str(url.strip(), encoding='utf-8')
                url.replace('%7C%7','||')
                url_ = url
                # print('url :',url)
                if url.strip():
                    url = url.split('||')
                    prop_url = url[0].strip()
                    status = url[1].strip()
                    listing_label = url[2].strip()
                    meta = {'prop_url': prop_url, 'status': status,
                            'listing_label': listing_label}
                sqs.delete_message(
                    QueueUrl=queue_url,
                    ReceiptHandle=receipt_handle
                )

                yield Request(url=prop_url.strip(), meta=meta, callback=self.parse_data, headers=self.headers)
                # print('Received and deleted message: %s' % message)

            else:
                print('No response >>>>>>>>>>>')
                break

        # credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        # connection = pika.BlockingConnection(pika.ConnectionParameters(
        #     credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        # channel = connection.channel()
        # while True:
        #     channel.basic_qos(prefetch_count=1)
        #     method, properties, url = channel.basic_get(queue=QUEUE_NAME)
        #     if not url.strip():
        #         break
        #     channel.basic_ack(delivery_tag=method.delivery_tag)
        #     url = str(url.strip(), encoding='utf-8')
        #     url_ = url
        #     if url.strip():
        #         url = url.split('||')
        #         prop_url = url[0].strip()
        #         status = url[1].strip()
        #         listing_label = url[2].strip()
        #         meta = {'prop_url': prop_url, 'status': status,
        #                 'listing_label': listing_label}
        #         yield Request(url=prop_url.strip(), meta=meta, callback=self.parse_data, headers=self.headers, errback=lambda x: self.errback_httpbin(x, url_.strip()))
        # connection.close()

    def parse_data(self, response):
        status = response.meta['status']
        listing_label = response.meta['listing_label']
        if status == 'no_status':
            status = ''
        if listing_label == 'no_adv_type' or listing_label == 'no_label':
            listing_label = ''

        amenities = []
        user_id = ''
        agent_name = ''
        ID__XPATH = '//script[contains(text(), "layout_preference")]/text()'
        BROKER_DISPLAY_NAME_XPATH = '//span[@aria-label="Agency name"]/text()'
        CATEGORY_XPATH = '//div[@aria-label="Breadcrumb"]/a//text()'
        CATEGORY_URL_XPATH = '//div[@aria-label="Breadcrumb"]/a/@href'
        TITLE_XPATH = '//h1/text()'
        DESCRIPTION_XPATH = '//h3[contains(text(),"Description")]/following-sibling::div//div[@aria-label="Property description"]//span/text()|//div[@aria-label="Property description"]/span//text()|//div[@aria-label="Property description"]/span/ul/li//text()|//div[@aria-label="Property description"]//span//text()'
        LOCATION_XPATH = '//div[@aria-label="Property basic info"]//div[@aria-label="Property header"]/text()'
        PRICE_XPATH = '//span[@aria-label="Property compact price"]/text()|//span[@aria-label="Price"]/text()'
        PRICE_PER_XPATH = '//span[@aria-label="Property compact frequency"]/text()|//span[@aria-label="Frequency"]/text()'
        BEDROOMS_XPATH1 = '//li[@aria-label="Property detail beds"]/span[@aria-label="Value"]/text()'
        BEDROOMS_XPATH2 = '//span[@aria-label="Beds"]/span[contains(text(),"Bed")]/text()'
        BATHROOMS_XPATH1 = '//li[@aria-label="Property detail baths"]/span[@aria-label="Value"]/text()'
        BATHROOMS_XPATH2 = '//span[@aria-label="Baths"]/span[contains(text(),"Bath")]/text()'
        RERA_PERMIT_NUMBER = '//div[@aria-label="Agency info"]//span[contains(text(),"Permit")]/text()|//span[contains(text(),"Permit")]/text()'
        REFER_NUB_XPATH = '//li[@aria-label="Property detail reference"]/span[@aria-label="Value"]/text()|//li/span[contains(text(),"Reference no.")]/following-sibling::span//text()'
        FURNISHED_XPATH = '//li[@aria-label="Property furnishing status"]/span[@aria-label="Furnishing"]/text()'

        details = response.xpath(
            '//span[@aria-label="Area"]/span/text()|//span[contains(text(),"Area")]/following-sibling::span[@aria-label="Value"]/span/text()|//span[@aria-label="Area"]//text()').extract()
        reference_number = response.xpath(
            '//span[contains(text(),"Ref. No:")]/following-sibling::span/text()|//li/span[contains(text(),"Reference no.")]/following-sibling::span//text()').extract()
        agent = response.xpath(
            '//span[contains(text(),"Agent")]/following-sibling::span/text()').extract()

        img = response.xpath(
            '//div[@class="image-gallery-thumbnails-container"]//picture/img/@src').extract()
        number_of_photos = str(len(img))
        amen = response.xpath(
            '//h3[contains(text(),"Amenities")]/following-sibling::div//span/text()').extract()

        amenities = ' '.join(amen).strip().replace('  ', ' ') if amen else ''
        data = response.xpath(
            '//h3[contains(text(),"Details")]/following-sibling::div/ul/li')
        phone_script = response.xpath(
            '//script[contains(text(),"primaryPhoneNumber")]').extract()
        rera_registration_number = response.xpath(
            '//div[@aria-label="Agency info"]//span[contains(text(),"RERA#")]/text()|//span[contains(text(),"RERA#")]/text()').extract()
        ded_license_number = response.xpath(
            '//div[@aria-label="Agency info"]//span[contains(text(),"DED#")]/text()|//span[contains(text(),"DED#")]/text()').extract()
        currency = response.xpath(
            '//span[@aria-label="Currency"]/text()').extract()
        verified = response.xpath(
            '//div[@class="d9b69373"]//text()').extract()
        truechek = response.xpath(
            '//div[@class="d9b69373"]//path/@d').extract()

        # Extract values using above XPATHs
        title = response.xpath(TITLE_XPATH).extract()
        location = response.xpath(LOCATION_XPATH).extract()
        description = response.xpath(DESCRIPTION_XPATH).extract()
        bedrooms1 = response.xpath(BEDROOMS_XPATH1).extract()
        bathrooms1 = response.xpath(BATHROOMS_XPATH1).extract()
        bedrooms2 = response.xpath(BEDROOMS_XPATH2).extract()
        bathrooms2 = response.xpath(BATHROOMS_XPATH2).extract()

        broker_display_name = response.xpath(
            BROKER_DISPLAY_NAME_XPATH).extract()
        id_ = response.xpath(ID__XPATH).extract()
        category = response.xpath(CATEGORY_XPATH).extract()
        category_url = response.xpath(CATEGORY_URL_XPATH).extract()
        rera_permit_number = response.xpath(RERA_PERMIT_NUMBER).extract()
        price_per = response.xpath(PRICE_PER_XPATH).extract()
        price = response.xpath(PRICE_XPATH).extract()
        reference_nub = response.xpath(REFER_NUB_XPATH).extract_first()
        furnished = response.xpath(FURNISHED_XPATH).extract_first()

        furnished = furnished if furnished else ''

        currency = currency[0].strip() if currency else ''
        if not price:
            price = response.xpath(
                '//span[@aria-label="Price"]/text()').extract()
        price = price[0].strip() if price else ''
        reference_nub = reference_nub[0].strip() if reference_nub else ''

        if not price_per:
            price_per = response.xpath(
                '//span[@aria-label="Frequency"]/text()').extract()
        price_per = price_per[0].strip() if price_per else ''

        if 'per' in price_per:
            price_per = price_per.replace('per', '')
        title = title[0].strip() if title else ''
        location = ''.join(location)
        location = location.strip() if location else ''
        description = ' '.join(' '.join(description).strip().split())
        bedrooms2 = bedrooms2 if bedrooms2 else []
        bedrooms = bedrooms1 if bedrooms1 else bedrooms2
        bedrooms = bedrooms[0].strip() if bedrooms else ''
        bedrooms = bedrooms.replace('Beds', '').strip() if bedrooms else ''
        bedrooms = bedrooms.replace('Bed', '').strip() if bedrooms else ''
        bathrooms2 = bathrooms2 if bathrooms2 else []
        bathrooms = bathrooms1 if bathrooms1 else bathrooms2
        bathrooms = bathrooms[0].strip() if bathrooms else ''
        bathrooms = bathrooms.replace('Baths', '').strip() if bathrooms else ''
        bathrooms = bathrooms.replace('Bath', '').strip() if bathrooms else ''
        broker_display_name = broker_display_name[
            0].strip() if broker_display_name else ''

        category_url = category_url[-1].strip() if category_url else ''
        if '/to-rent/' in category_url:
            category = 'rent'
            category_url = '/to-rent/property/uae/'
        elif '/for-sale/' in category_url:
            category = 'sale'
            category_url = '/for-sale/property/uae/'


        id_ = id_[0].strip() if id_ else ''
        id_ = re.findall('ad_id":(.*),"object_id"', id_)[0]

        if agent:
            agent_ = ','.join(agent).split(',')
            agent_name = agent_[0] if agent_ else ''

        amenities_str = ''
        if data:
            for amt in data:
                key = amt.xpath('span[@class="_3af7fa95"]/text()').extract()
                value = amt.xpath('span[@class="_812aa185"]/text()').extract()
                keys = ' '.join(''.join(key).strip().strip().strip(
                    ':').split()) if key else ''
                values = ' '.join(
                    ''.join(value).strip().split()) if value else ''
                if key:
                    amenities_str = amenities_str + keys + ':' + values + ', '
        amenities_str = amenities_str.strip(
            ', ').strip() if amenities_str else ''
        amenities_str = amenities_str.strip(
            ', ').strip() if amenities_str else ''
        reference_number = ' '.join(
            ''.join(reference_number).strip().split()) if reference_number else ''
        details = ' '.join(''.join(details).strip().split()) if details else ''
        details = 'Area :' + details if details else ''

        reference_number = ''.join(
            reference_number) if reference_number else ''

        user = response.xpath(
            '//div[@aria-label="Agency info"]//a/@href').extract()
        user = ''.join(user) if user else ''
        if '-' in user:
            user_data = user.split('-') if user else ''
            user_id = user_data[-1] if user_data else ''
        user_id = user_id.replace('/', '') if user_id else ''

        phone_number = re.findall(
            r'\"primaryPhoneNumber\":\".*?\",', phone_script[0].strip()) if phone_script else ''
        phone_numbers = phone_number[0].strip().replace(
            '"primaryPhoneNumber":', '').replace(',', '').replace('\"', '')

        rera_permit_number_script = response.xpath(
            '//script[contains(text(),"permitNumber")]/text()').extract()
        rera_permit_number_script = re.findall(
            r'\"permitNumber\":\"\d+"', rera_permit_number_script[0].strip()) if rera_permit_number_script else []
        rera_permit_number = rera_permit_number_script[0].strip().replace(
            '\"permitNumber\":', '').replace('"', '').strip() if rera_permit_number_script else ''

        rera_registration_number_script = response.xpath(
            '//script[contains(text(),"RERA") and contains(text(),"authority")]/text()').extract()
        rera_registration_number_script = re.findall(
            r'\{\"number\":\"\d+\",\"authority\":\"RERA\"\}', rera_registration_number_script[0].strip()) if rera_registration_number_script else []
        rera_registration_number_script = re.findall(
            r'\d+', rera_registration_number_script[0].strip()) if rera_registration_number_script else []
        rera_registration_number = rera_registration_number_script[0].strip(
        ) if rera_registration_number_script else ''

        ded_license_number_script = response.xpath(
            '//script[contains(text(),"DED") and contains(text(),"authority")]/text()').extract()
        ded_license_number_script = re.findall(
            r'\{\"number\":\"\d+\",\"authority\":\"DED\"\}', ded_license_number_script[0].strip()) if ded_license_number_script else []
        ded_license_number_script = re.findall(
            r'\d+', ded_license_number_script[0].strip()) if ded_license_number_script else []
        ded_license_number = ded_license_number_script[0].strip(
        ) if ded_license_number_script else ''

        rera_pn_len = len(str(rera_permit_number))

        rera_length = True if rera_pn_len == 10 else False

        lat_script = response.xpath(
            '//script[contains(text(),"latitude")]/text()').extract()

        long_script = response.xpath(
            '//script[contains(text(),"longitude")]/text()').extract()

        obid_script = response.xpath(
            '//script[contains(text(),"objectID")]/text()').extract()

        listid_script = response.xpath(
            '//script[contains(text(),"listingid")]/text()').extract()
        pakage_script = response.xpath(
            '//script[contains(text(),"package_type")]/text()').extract()
        locality_script = response.xpath(
            '//script[contains(text(),"locality")]/text()').extract()

        latitude = re.findall(
            'latitude":.*?,', lat_script[0].strip()) if lat_script else []
        latitude = latitude[0].strip().replace(
            'latitude":', '').strip(',').strip() if latitude else ''

        longitude = re.findall(
            'longitude":.*?,', long_script[0].strip()) if long_script else []
        longitude = longitude[0].strip().replace(
            'longitude":', '').strip(',').strip() if longitude else ''

        listing_id = re.findall(
            'listingid":.*?,', listid_script[0].strip()) if listid_script else []
        listing_id = listing_id[0].strip().replace(
            'listingid":', '').strip(',').strip() if listing_id else ''

        package_type = re.findall(
            'package_type":.*?,', pakage_script[0].strip()) if pakage_script else []
        package_type = package_type[0].strip().replace(
            'package_type":', '').strip(',').strip('"').strip() if package_type else ''

        locality = re.findall(
            'locality":.*?,', locality_script[0].strip()) if locality_script else []
        locality = locality[0].strip().replace(
            'locality":', '').strip(',').strip('"').strip() if locality else ''

        object_id = re.findall(
            'objectID":.*?,', obid_script[0].strip()) if obid_script else []
        object_id = object_id[-1].strip().replace(
            'objectID":', '').strip(',').strip('"').strip() if object_id else ''

        verified = ''.join([x.strip() for x in [x.strip()
                                                for x in verified] if x]) if verified else ''

        truechek = truechek[0].strip() if truechek else ''
        if 'M26.25 2.81h-2.74v7.55h-1.27V2.81H19.5V1.75h6.76zm.82 2.63a2.79 2.79 0 0 1 .7-.95 1.51 1.51 0 0 1 1-.34 1.52 1.52 0 0 1 .38.05.97.97 0 0 1 .3.13l-.07.88a.19.19 0 0 1-.2.17 1.44 1.44 0 0 1-.25-.04 1.87 1.87 0 0 0-.36-.03 1.41 1.41 0 0 0-.5.08 1.16 1.16 0 0 0-.39.24 1.63 1.63 0 0 0-.3.4 3.9 3.9 0 0 0-.24.52v3.81h-1.18v-6.1h.67a.37.37 0 0 1 .27.07.45.45 0 0 1 .1.24zm8.36-1.18v6.1h-.7a.3.3 0 0 1-.32-.23l-.08-.61a4.13 4.13 0 0 1-.41.38 2.56 2.56 0 0 1-.47.3 2.54 2.54 0 0 1-.52.2 2.44 2.44 0 0 1-.59.06 2.18 2.18 0 0 1-.89-.17 1.76 1.76 0 0 1-.64-.47 2.04 2.04 0 0 1-.39-.73 3.17 3.17 0 0 1-.13-.94V4.26h1.18v3.88a1.55 1.55 0 0 0 .3 1.02 1.12 1.12 0 0 0 .92.36 1.73 1.73 0 0 0 .84-.2 2.86 2.86 0 0 0 .73-.6V4.27zm7.74 4.05a.32.32 0 0 1 .23.1l.64.7a3.5 3.5 0 0 1-1.3 1 4.48 4.48 0 0 1-1.85.35 4.37 4.37 0 0 1-1.74-.33 3.83 3.83 0 0 1-1.31-.92 4.02 4.02 0 0 1-.84-1.4 5.27 5.27 0 0 1-.3-1.78 4.96 4.96 0 0 1 .32-1.79 4.12 4.12 0 0 1 .88-1.4 3.98 3.98 0 0 1 1.35-.91A4.49 4.49 0 0 1 41 1.6a4.27 4.27 0 0 1 1.69.31 4 4 0 0 1 1.25.82l-.54.75a.49.49 0 0 1-.13.12.35.35 0 0 1-.2.06.4.4 0 0 1-.19-.05l-.21-.13-.26-.17a2.17 2.17 0 0 0-.35-.16 2.84 2.84 0 0 0-.46-.13 3.17 3.17 0 0 0-.6-.05 2.68 2.68 0 0 0-1.07.21 2.31 2.31 0 0 0-.83.6 2.77 2.77 0 0 0-.54.96 4.02 4.02 0 0 0-.19 1.3 3.8 3.8 0 0 0 .2 1.3 2.86 2.86 0 0 0 .57.95 2.4 2.4 0 0 0 .83.6A2.58 2.58 0 0 0 41 9.1a4.5 4.5 0 0 0 .6-.04 2.53 2.53 0 0 0 .49-.11 2.18 2.18 0 0 0 .42-.2 2.66 2.66 0 0 0 .4-.3.57.57 0 0 1 .13-.09.3.3 0 0 1 .13-.04zm3.23-3.45a3.22 3.22 0 0 1 .79-.54 2.3 2.3 0 0 1 1.01-.21 2.2 2.2 0 0 1 .9.17 1.77 1.77 0 0 1 .65.48 2.11 2.11 0 0 1 .4.74 3.14 3.14 0 0 1 .13.94v3.92H48.8V6.44a1.32 1.32 0 0 0-.26-.87.97.97 0 0 0-.79-.3 1.54 1.54 0 0 0-.72.17 2.58 2.58 0 0 0-.63.47v4.45H44.9V1.45h1.49zm9.25 1.71a1.78 1.78 0 0 0-.08-.54 1.3 1.3 0 0 0-.24-.45 1.13 1.13 0 0 0-.41-.3 1.41 1.41 0 0 0-.58-.1 1.37 1.37 0 0 0-1.02.36 1.8 1.8 0 0 0-.47 1.04zm-2.83.9a2.92 2.92 0 0 0 .17.82 1.68 1.68 0 0 0 .35.57 1.36 1.36 0 0 0 .51.33 1.86 1.86 0 0 0 .66.11 2.04 2.04 0 0 0 .62-.08 2.91 2.91 0 0 0 .46-.19l.34-.18a.57.57 0 0 1 .28-.09.3.3 0 0 1 .28.14l.43.54a2.47 2.47 0 0 1-.56.48 3.1 3.1 0 0 1-.63.32 3.5 3.5 0 0 1-.68.16 4.86 4.86 0 0 1-.67.05 3.29 3.29 0 0 1-1.2-.21 2.67 2.67 0 0 1-.96-.63 2.96 2.96 0 0 1-.64-1.03 4 4 0 0 1-.23-1.43 3.4 3.4 0 0 1 .2-1.18 2.85 2.85 0 0 1 .58-.97 2.75 2.75 0 0 1 .93-.65 3.06 3.06 0 0 1 1.24-.24 3.01 3.01 0 0 1 1.08.19 2.34 2.34 0 0 1 .84.54 2.52 2.52 0 0 1 .56.88 3.26 3.26 0 0 1 .2 1.18.96.96 0 0 1-.07.45.3.3 0 0 1-.28.12zM62.5 5.5a.74.74 0 0 1-.13.14.3.3 0 0 1-.18.04.4.4 0 0 1-.22-.06l-.26-.16a1.93 1.93 0 0 0-.36-.16 1.64 1.64 0 0 0-.51-.07 1.56 1.56 0 0 0-.68.15 1.3 1.3 0 0 0-.5.4 1.82 1.82 0 0 0-.28.63 3.43 3.43 0 0 0-.1.85 3.33 3.33 0 0 0 .1.88 1.87 1.87 0 0 0 .3.64 1.3 1.3 0 0 0 .48.4 1.46 1.46 0 0 0 .64.14 1.58 1.58 0 0 0 .57-.09 1.8 1.8 0 0 0 .37-.19q.15-.1.26-.2a.4.4 0 0 1 .25-.08.3.3 0 0 1 .27.14l.43.54a2.68 2.68 0 0 1-.54.48 2.89 2.89 0 0 1-.6.31 3.04 3.04 0 0 1-.63.17 4.48 4.48 0 0 1-.65.05 2.73 2.73 0 0 1-1.07-.21 2.54 2.54 0 0 1-.88-.62 2.97 2.97 0 0 1-.6-1 3.86 3.86 0 0 1-.22-1.35 3.92 3.92 0 0 1 .2-1.26 2.85 2.85 0 0 1 .57-1 2.63 2.63 0 0 1 .93-.66 3.22 3.22 0 0 1 1.29-.24 3.05 3.05 0 0 1 1.2.22 2.95 2.95 0 0 1 .94.64zm2.86-4.06v5.11h.27a.59.59 0 0 0 .24-.04.49.49 0 0 0 .18-.16l1.53-1.89a.7.7 0 0 1 .21-.19.61.61 0 0 1 .3-.06h1.36l-1.91 2.28a1.59 1.59 0 0 1-.45.42 1.18 1.18 0 0 1 .23.2 2.86 2.86 0 0 1 .19.26l2.05 3h-1.34a.72.72 0 0 1-.3-.06.47.47 0 0 1-.21-.21l-1.57-2.34a.44.44 0 0 0-.18-.18.67.67 0 0 0-.27-.04h-.33v2.82h-1.48V1.45zm8.24.52H72v4.4h-.74v-4.4h-1.6v-.62h3.94zm6.01-.62v5.02h-.65V2.78v-.17q0-.1.02-.18L77.31 5.5a.28.28 0 0 1-.27.17h-.1a.28.28 0 0 1-.27-.17l-1.7-3.08a3.46 3.46 0 0 1 .02.37v3.57h-.65V1.34h.55a.47.47 0 0 1 .15.02.22.22 0 0 1 .1.1l1.67 3.01a2.1 2.1 0 0 1 .1.2l.07.2a3.37 3.37 0 0 1 .18-.4l1.65-3a.2.2 0 0 1 .1-.12.47.47 0 0 1 .15-.01zm-65.98.58a.31.31 0 0 0-.04-.44L11.85.08a.32.32 0 0 0-.44.04l-5.2 6.2a.3.3 0 0 1-.44.03L3.03 3.9a.32.32 0 0 0-.44.02L1.04 5.6a.31.31 0 0 0 .02.44l4.98 4.47a.3.3 0 0 0 .43-.04z' in truechek:
            truechek = 'TruCheckTM'

        else:
            truechek = ''
            
        verified = truechek if truechek else verified

        scraped_ts = (datetime.now()).strftime("%Y-%m-%d")

        now = datetime.now()
        iteration_month = now.strftime("%m")
        iteration_year = now.strftime("%Y")
        now_date_int = int(now.strftime("%d"))
        if now_date_int <=7 and now_date_int >=1:
            iteration_suffix = '01'
        elif now_date_int <=14 and now_date_int >=8:
            iteration_suffix = '02'

        elif now_date_int <=21 and now_date_int >=15:
            iteration_suffix = '03'

        elif now_date_int <=28 and now_date_int >=22:
            iteration_suffix = '04'

        elif now_date_int <=31 and now_date_int >=29:
            iteration_suffix = '05'

        iteration_number = iteration_year + '_'+ iteration_month + '_' + iteration_suffix

        reference_number = reference_number if reference_number else reference_nub


        item = BayutUrlSqsItem(
            reference_number=reference_number,
            id=id_,
            url=response.url,
            broker_display_name=broker_display_name,
            broker=broker_display_name.upper(),
            category=category,
            category_url=category_url,
            title=title,
            description=description,
            location=location,
            price=price,
            currency=currency,
            price_per=price_per,
            bedrooms=bedrooms,
            bathrooms=bathrooms,
            furnished=furnished,
            rera_permit_number=rera_permit_number,
            dtcm_licence='',
            scraped_ts=scraped_ts,
            amenities=amenities,
            details=details,
            agent_name=agent_name,
            number_of_photos=number_of_photos,
            user_id=user_id,
            phone_number=phone_numbers,
            date=scraped_ts,
            iteration_number=iteration_number,
            rera_registration_number=rera_registration_number,
            ded_license_number=ded_license_number,
            rera_length=rera_length,
            latitude=latitude,
            longitude=longitude,
            listing_id=listing_id,
            package_type=package_type,
            locality=locality,
            object_id=object_id,
            completion_status=status,
            ad_type=listing_label,
            verified=verified,
            sub_category_1='',
            sub_category_2='',
            property_type='',
            depth=''

        )
        if title:
            yield item


    # Errorback to put failed urls back in queue
    def errback_httpbin(self, failure, url):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=600))
        channel = connection.channel()
        channel.queue_declare(queue=QUEUE_NAME, durable=True)
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=url)
        connection.close()
