# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html

# -*- coding: utf-8 -*-
import pymongo
from pymongo import MongoClient
from scrapy.exceptions import DropItem
from datetime import datetime
from bayut_weekly.items import *


now = datetime.now()
iteration_month = now.strftime("%m")
iteration_year = now.strftime("%Y")
now_date_int = int(now.strftime("%d"))
if now_date_int <=7 and now_date_int >=1:
    iteration_suffix = '01'
elif now_date_int <=14 and now_date_int >=8:
    iteration_suffix = '02'

elif now_date_int <=21 and now_date_int >=15:
    iteration_suffix = '03'

elif now_date_int <=28 and now_date_int >=22:
    iteration_suffix = '04'

elif now_date_int <=31 and now_date_int >=29:
    iteration_suffix = '05'

db_monthly = iteration_year + '_'+ iteration_month
coll_weekly = iteration_year + '_'+ iteration_month + '_weekly' + iteration_suffix + "_test"


MONGO_URI = 'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false'  # shard
MONGODB_DB = 'dina_mohammad_weekly_'  + db_monthly
MONGODB_COLLECTION_AGENT_URL = 'bayut_uae_url_' + coll_weekly
# MONGODB_COLLECTION_AGENT_NEW = 'bayut_uae_adtype_' + coll_weekly
MONGODB_COLLECTION_AGENT = 'bayut_uae_'+ coll_weekly
MONGODB_COLLECTION_AGENT_SQS = 'bayut_uae_sqs_'+ coll_weekly
# MONGODB_COLLECTION_VERIFIED = 'bayut_uae_verified_'+ coll_weekly


class BayutWeeklyPipeline(object):

    def __init__(self, *args, **kwargs):

        self.mongo_uri = MONGO_URI
        self.mongo_db = MONGODB_DB
        self.dup_key = 'url'
        self.mongo_collection_product = MONGODB_COLLECTION_AGENT
        self.mongo_collection_links = MONGODB_COLLECTION_AGENT_URL
        self.mongo_collection_sqs = MONGODB_COLLECTION_AGENT_SQS

    def open_spider(self, spider):
        # self.client = pymongo.MongoClient(self.mongo_uri)
        self.client = MongoClient(self.mongo_uri)
        try:
            self.client.admin.command(
                "enablesharding", self.mongo_db)
            self.client.admin.command("shardcollection", self.mongo_db + '.' + self.mongo_collection_product, key={
                'url': 1}, unique=True)
            self.client.admin.command("shardcollection", self.mongo_db + '.' + self.mongo_collection_links, key={
                'url': 1}, unique=True)
        except:
            try:
                self.client.admin.command("shardcollection", self.mongo_db + '.' + self.mongo_collection_product, key={
                    'url': 1}, unique=True)
            except:
                pass
            try:
                self.client.admin.command("shardcollection", self.mongo_db + '.' + self.mongo_collection_links, key={
                    'url': 1}, unique=True)

            except:
                pass
            try:
                self.client.admin.command("shardcollection", self.mongo_db + '.' + self.mongo_collection_sqs, key={
                    'url': 1}, unique=True)

            except:
                pass
        self.db = self.client[self.mongo_db]

    def close_spider(self, spider):
        self.client.close()

    def process_item(self, item, spider):
        if isinstance(item, BayutItem):
            try:
                self.db[self.mongo_collection_product].insert(dict(item))
            except Exception:
                raise DropItem("Dropping duplicate item")
        if isinstance(item, BayutUrlItem):
            try:
                self.db[self.mongo_collection_links].insert(dict(item))
            except Exception:
                raise DropItem("Dropping duplicate item")
        if isinstance(item, BayutUrlSqsItem):
            try:
                self.db[self.mongo_collection_sqs].insert(dict(item))
            except Exception:
                raise DropItem("Dropping duplicate item")
        return item
