import scrapy
import logging
import json
from scrapy.spiders import Spider
from scrapy.http import Request
from pymongo import MongoClient
from rmq import RmqHandler
import requests
from scrapy.selector import Selector
from datetime import datetime
import random
from datetime import datetime

logger = logging.getLogger('pika')
logger.propagate = False


now = datetime.now()
current = datetime(now.year, now.month, 1)
next_month = datetime(now.year + int(now.month / 12),
                      ((now.month % 12) + 1), 1)
now_date_int = int(now.strftime("%d"))
if now_date_int <= 31 and now_date_int >= 25:
    iteration_month = next_month.strftime("%m")
    iteration_year = next_month.strftime("%Y")
else:
    iteration_month = now.strftime("%m")
    iteration_year = now.strftime("%Y")
iteration_number = iteration_year + '_' + iteration_month
MONGODB_DB = 'dina_mohammad_monthly_' + iteration_number
COLLECTION_NAME = 'sakneen_egp_'+iteration_number


client = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
try:
    client.admin.command("enablesharding", MONGODB_DB)
except:
    pass
try:
    client.admin.command(
        "shardcollection", MONGODB_DB + '.' + COLLECTION_NAME, key={'url': 1}, unique=True)
except:
    pass
db = client[MONGODB_DB]
# PROXY_LIST = requests.get('http://68.183.58.145/torproxies',
#                           headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
# PROXY = random.choice(PROXY_LIST)
# proxies = {"http": "http://%s" % PROXY,
#            "https": "http://%s" % PROXY}

proxies = {
    'http': 'http://testhw:67ca95-e1d5c9-1d6090-4c527d-5d9aa7@usa.rotating.proxyrack.net:333',
    'https': 'http://testhw:67ca95-e1d5c9-1d6090-4c527d-5d9aa7@usa.rotating.proxyrack.net:333',
}

h = {
    "Accept": "*/*",
    "app-request-origin": "sakneen-platform",
    "Origin": "https://www.sakneen.com",
    "Referer": "https://www.sakneen.com/en/search",
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36"
}

QUEUE_HOST = '159.89.47.171'
QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'
QUEUE_NAME = 'ha.sakeen'


class SakneenSpider():

    def __init__(self):
        self.start_requests()

    def start_requests(self):
        # url = 'https://www.sakneen.com/en/house/apartment-for-sale-north-coast-sidi-abdel-rahman-memaar-al-morshedy-zahraa-b3225c8b54fd46089b1c7d79287a0745'
        rmqh = RmqHandler(QUEUE_NAME, ip=QUEUE_HOST,
                          user=QUEUE_USER, pwd=QUEUE_PASS)
        while True:
            count, data = rmqh.get()
            if not data:
                break
            url = str(data.strip())
            if url:
                response = requests.get(
                    url=url, headers=h, proxies=proxies)
                self.parse_urls(response)
        # response = requests.get(url=url, headers=h, proxies=proxies)
        # self.parse_urls(response)

    def parse_urls(self, response):
        sel = Selector(text=response.content)
        product_url = response.url
        id_ = product_url.split('-')[-1]
        title = sel.xpath('//title/text()').extract()
        title = title[0].strip() if title else ''

        meta = {'product_url': product_url, 'id_': id_, 'title': title}
        link = response.url.replace('https://www.sakneen.com/en/house/',
                                    'https://app.sakneen.com/apis/marketplace/listings/slug/')
        response = requests.get(url=link, headers=h, verify=False, timeout=5)
        if response:
            self.parse_api(response, meta)

    def parse_api(self, response, meta):
        json_data = json.loads(response.text)
        product_url = meta.get('product_url')
        id_ = meta.get('id_')
        title = meta.get('title')
        amenities = json_data.get('listing', {})
        if amenities:
            amenities = amenities.get('garden', '')
        bedrooms = json_data.get('listing').get('bedrooms')
        bathrooms = json_data.get('listing').get('bathrooms')

        now = datetime.now()
        current = datetime(now.year, now.month, 1)
        next_month = datetime(
            now.year + int(now.month / 12), ((now.month % 12) + 1), 1)
        now_date_int = int(now.strftime("%d"))
        if now_date_int <= 31 and now_date_int >= 25:
            iteration_month = next_month.strftime("%m")
            iteration_year = next_month.strftime("%Y")
        else:
            iteration_month = now.strftime("%m")
            iteration_year = now.strftime("%Y")
        iteration_number = iteration_year + '_' + iteration_month
        property_type = json_data.get('listing', {}).get('unitType', '')
        longitude = json_data.get('listing', {}).get('longitude', '')
        latitude = json_data.get('listing', {}).get('latitude', '')
        compound = json_data.get('listing', {}).get('compoundName', '')
        district = json_data.get('listing', {}).get(
            'district', '').get('slugEnglish')
        city = json_data.get('listing', {}).get('city', '').get('nameEnglish')
        location = compound+', '+district+', '+city
        images = json_data.get('listing').get('photos')
        number_of_photos = str(len(images))
        Land_Area = json_data.get('listing', {}).get('land', '')
        BuiltUpArea = json_data.get('listing', {}).get('bua', '')
        Land_Area = str(Land_Area) + 'M'
        BuiltUpArea = str(BuiltUpArea) + 'M'
        details = BuiltUpArea+', '+Land_Area
        price = json_data.get('listing', {}).get('totalPrice', '')
        description = json_data.get('listing', {}).get('description', '')
        full_description = description.replace('\n', '')

        currency = 'EGP'
        phone_number = '+201008613723'
        category = 'buy'
        scraped_ts = (datetime.now()).strftime("%Y-%m-%d")

        rera_permit_number = ''
        dtcm_licence = ''
        price_per = ''
        broker_display_name = ''
        user_id = ''
        reference_number = ''
        broker = ''
        agent_name = ''
        category_url = ''
        furnished = ''
        depth = ''
        sub_category_1 = ''
        sub_category_2 = ''

        item = {}
        item['id'] = id_
        item['url'] = product_url
        item['broker_display_name'] = broker_display_name
        item['broker'] = broker
        item['category'] = category
        item['category_url'] = category_url
        item['title'] = title
        item['property_type'] = property_type
        item['depth'] = depth
        item['sub_category_1'] = sub_category_1
        item['sub_category_2'] = sub_category_2
        item['description'] = full_description
        item['location'] = location
        item['price'] = price
        item['currency'] = currency
        item['price_per'] = price_per
        item['bedrooms'] = bedrooms
        item['bathrooms'] = bathrooms
        item['furnished'] = furnished
        item['rera_permit_number'] = rera_permit_number
        item['dtcm_licence'] = dtcm_licence
        item['scraped_ts'] = scraped_ts
        item['amenities'] = amenities
        item['details'] = details
        item['agent_name'] = agent_name
        item['number_of_photos'] = number_of_photos
        item['reference_number'] = reference_number
        item['user_id'] = user_id
        item['phone_number'] = phone_number
        item['date'] = scraped_ts
        item['iteration_number'] = iteration_number
        item['latitude'] = latitude
        item['longitude'] = longitude
        logging.warning(item)
        try:
            db[COLLECTION_NAME].insert(dict(item))
        except:
            pass
        client.close()


SakneenSpider()
