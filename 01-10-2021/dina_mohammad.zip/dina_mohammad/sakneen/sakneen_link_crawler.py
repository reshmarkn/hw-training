import scrapy
import logging
import json
from xml.dom import minidom
from scrapy.spiders import Spider
from scrapy.http import Request
from pymongo import MongoClient
import requests
from datetime import datetime
import random


logger = logging.getLogger('pika')
logger.propagate = False

now = datetime.now()
current = datetime(now.year, now.month, 1)
next_month = datetime(now.year + int(now.month / 12),
                      ((now.month % 12) + 1), 1)
now_date_int = int(now.strftime("%d"))
if now_date_int <= 31 and now_date_int >= 25:
    iteration_month = next_month.strftime("%m")
    iteration_year = next_month.strftime("%Y")
else:
    iteration_month = now.strftime("%m")
    iteration_year = now.strftime("%Y")
iteration_number = iteration_year + '_' + iteration_month
MONGODB_DB = 'dina_mohammad_monthly_' + iteration_number
COLLECTION_NAME = 'sakneen_egp_url_'+iteration_number


client = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
try:
    client.admin.command("enablesharding", MONGODB_DB)
except:
    pass
try:
    client.admin.command(
        "shardcollection", MONGODB_DB + '.' + COLLECTION_NAME, key={'url': 1}, unique=True)
except:
    pass
db = client[MONGODB_DB]

QUEUE_HOST = '159.89.47.171'
QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'
QUEUE_NAME = 'ha.sakeen'

PROXY_LIST = requests.get('http://68.183.58.145/stormproxies?',
                          headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
PROXY = random.choice(PROXY_LIST)
proxies = {"http": "http://%s" % PROXY,
           "https": "http://%s" % PROXY}

h = {
    "Accept": "*/*",
    "app-request-origin": "sakneen-platform",
    "Origin": "https://www.sakneen.com",
    "Referer": "https://www.sakneen.com/en/search",
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36"
}


class SakneenurlSpider():

    def __init__(self):
        self.start_requests()

    def start_requests(self):
        start_url = 'https://www.sakneen.com/en/sitemap.xml'
        response = requests.get(start_url, headers=h, proxies=proxies)
        self.parse(response)

    def parse(self, response):
        xmldoc = minidom.parseString(response.text)
        LOCS = xmldoc.getElementsByTagName('loc')
        LOCS.pop(0)
        for loc in LOCS:
            p_url = loc.childNodes[0].data
            if 'https://www.sakneen.com/en/house' in p_url:
                item = {}
                item['url'] = p_url
                logging.warning(item)
                try:
                    db[COLLECTION_NAME].insert(dict(item))
                except:
                    pass
        client.close()


SakneenurlSpider()
