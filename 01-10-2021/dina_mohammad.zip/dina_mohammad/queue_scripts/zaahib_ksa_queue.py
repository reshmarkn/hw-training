from pymongo import MongoClient
import pika
import json
from time import sleep
import datetime
from datetime import datetime

now = datetime.now()
current = datetime(now.year, now.month, 1)
next_month = datetime(now.year + int(now.month / 12), ((now.month % 12) + 1), 1)
now_date_int = int(now.strftime("%d"))
if now_date_int <=31 and now_date_int >=25:
    iteration_month = next_month.strftime("%m")
    iteration_year = next_month.strftime("%Y")
else:
    iteration_month = now.strftime("%m")
    iteration_year = now.strftime("%Y")
iteration_number = iteration_year + '_'+ iteration_month

QUEUE_HOST = '159.89.47.171'  # load balancer
QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'
QUEUE_NAME = 'ha.zaahib'


DB_NAME = 'dina_mohammad_monthly_' + iteration_number

# client = MongoClient()
client = MongoClient('mongodb://datahut:cGFzc21lMTIz@104.131.41.31:27017/?authSource=admin&retryWrites=false')
db = client[DB_NAME]


COLLECTION_NAME = 'zaahib_ksa_url_' + iteration_number
FIELD = 'url'

FIELD = FIELD.split(',')
FIELD = [x.strip() for x in FIELD if x.strip()]

searchString = {'_id': 1}
for field in FIELD:
    searchString[field] = 1
# searchString = {'url': 1}
print(searchString)
result = db[COLLECTION_NAME].find({}, searchString)

credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
connection = pika.BlockingConnection(pika.ConnectionParameters(
    credentials=credentials, host=QUEUE_HOST, socket_timeout=3000))
channel = connection.channel()

channel.queue_declare(queue=QUEUE_NAME, durable=True)

for data in result:

    document = dict(data)
    if len(FIELD) == 1:
        document = document[FIELD[0]]
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=document)
        sleep(0.0001)

    else:
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=json.dumps(document))
        sleep(0.0001)
connection.close()
