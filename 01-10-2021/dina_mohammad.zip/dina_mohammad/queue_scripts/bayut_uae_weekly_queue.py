from pymongo import MongoClient
import pika
import json
from time import sleep
import datetime


QUEUE_HOST = '159.89.47.171'  # load balancer
QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'
QUEUE_NAME = 'ha.bayut_uae'


DB_NAME = 'dina_mohammad_2020_08'

# client = MongoClient()
client = MongoClient('mongodb://datahut:cGFzc21lMTIz@64.225.9.179:27017')
db = client[DB_NAME]


COLLECTION_NAME = 'bayut_uae_url_2020_08_18'
FIELD = 'url_string'

FIELD = FIELD.split(',')
FIELD = [x.strip() for x in FIELD if x.strip()]

searchString = {'_id': 1}
for field in FIELD:
    searchString[field] = 1
# searchString = {'url': 1}
print(searchString)
result = db[COLLECTION_NAME].find({}, searchString)

credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
connection = pika.BlockingConnection(pika.ConnectionParameters(
    credentials=credentials, host=QUEUE_HOST, socket_timeout=3000))
channel = connection.channel()

channel.queue_declare(queue=QUEUE_NAME, durable=True)

for data in result:

    document = dict(data)
    if len(FIELD) == 1:
        document = document[FIELD[0]]
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=document)
        sleep(0.0001)

    else:
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=json.dumps(document))
        sleep(0.0001)
connection.close()
