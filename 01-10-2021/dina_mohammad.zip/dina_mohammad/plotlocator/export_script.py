from pymongo import MongoClient
from datetime import datetime
import csv
DB_NAME = 'plotlocator'
COLLECTION_NAME = 'items_2020_08_09'
db = MongoClient("mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017")[DB_NAME]

file = open('plotlocator_2020_08_10.csv', 'a')

file.write('plotno,zone_code,height_en,height_ar,GFA,FAR,parking_en,parking_ar,remark_en,remark_ar,setback_en,setback_ar,landuse_en,landuse_ar,schoolreg,exepdetails,frozdetails,partdetails,fullfrozendetails,fullyaffdetails,coastdetails,metrodetails,message\n')
for item in db[COLLECTION_NAME].find(no_cursor_timeout=True):
    URL = item.get('URL', '').replace('\n', '')
    plotno = item.get('plotno','')
    zone_code = str(item.get('zone_code',''))
    height_en = str(item.get('height_en',''))
    height_ar = str(item.get('height_ar',''))
    GFA = str(item.get('GFA',''))
    FAR = item.get('Reg')
    if FAR:
        FAR = str(FAR[0].get('FAR',''))
    else:
        FAR = ''
    parking_en = str(item.get('parking_en',''))
    parking_ar = str(item.get('parking_ar',''))
    remark_en = str(item.get('remark_en',''))
    remark_ar = str(item.get('remark_ar',''))
    setback_en = str(item.get('setback_en',''))
    setback_ar = str(item.get('setback_ar',''))
    landuse_en = str(item.get('landuse_en',''))
    landuse_ar = str(item.get('landuse_ar',''))
    schoolreg = str(item.get('schoolreg',''))
    exepdetails = str(item.get('exepdetails',''))
    frozdetails = str(item.get('frozdetails',''))
    partdetails = str(item.get('partdetails',''))
    fullfrozendetails = str(item.get('fullfrozendetails',''))
    fullyaffdetails = str(item.get('fullyaffdetails',''))
    coastdetails = str(item.get('coastdetails',''))
    metrodetails = str(item.get('metrodetails',''))
    message = str(item.get('message',''))


    data = [plotno,zone_code,height_en,height_ar,GFA,FAR,parking_en,parking_ar,remark_en,remark_ar,setback_en,setback_ar,landuse_en,landuse_ar,schoolreg,exepdetails,frozdetails,partdetails,fullfrozendetails,fullyaffdetails,coastdetails,metrodetails,message]
    row_data = ','.join(data)+'\n'
    file.write(row_data)

COLLECTION_NAME1 = 'items_plot_not_2020_08_09'
db1 = MongoClient("mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017")[DB_NAME]
file_2 = open('plotlocator_not_found_2020_08_10.csv', 'a')

file_2.write('plotno,schoolreg,exepdetails,frozdetails,partdetails,fullfrozendetails,fullyaffdetails,coastdetails,metrodetails,message,reg\n')
for item1 in db[COLLECTION_NAME1].find(no_cursor_timeout=True):
    plotno1 = str(item1.get('plotno'))
    schoolreg1 = str(item1.get('schoolreg'))
    exepdetails1 = str(item1.get('exepdetails'))
    frozdetails1 = str(item1.get('frozdetails'))
    partdetails1 = str(item1.get('partdetails'))
    fullfrozendetails1 = str(item1.get('fullfrozendetails'))
    fullyaffdetails1 = str(item1.get('fullyaffdetails'))
    coastdetails1 = str(item1.get('coastdetails'))
    metrodetails1 = str(item1.get('metrodetails'))
    message1 = str(item1.get('message'))
    reg1 = str(item1.get('reg'))
    data2 = [plotno1,schoolreg1,exepdetails1,frozdetails1,partdetails1,fullfrozendetails1,fullyaffdetails1,coastdetails1,metrodetails1,message1,reg1]
    row_data1 = ','.join(data2)+'\n'
    file_2.write(row_data1)   