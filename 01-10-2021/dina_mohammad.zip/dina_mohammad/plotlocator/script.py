import csv
import json
import pika
import random
import logging
import xmltodict

import pymongo
from pymongo import MongoClient
from scrapy.selector import Selector

QUEUE_NAME = 'ha.plotlocator'
QUEUE_IP = '159.89.47.171'
QUEUE_USER = 'datahut'
QUEUE_PASS = 'datahutqueue123'

db = MongoClient(
    'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017').plotlocator

def CollectDb():

    credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
    while True:
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        channel = connection.channel()
        channel.basic_qos(prefetch_count=1)
        method, properties, body = channel.basic_get(queue=QUEUE_NAME)
        channel.basic_ack(delivery_tag=method.delivery_tag)
        data = json.loads(body.decode('utf-8'))
        if data:
            rawxml = data.get('rawxml')
            plotno = data.get('plotno')
            data = json.loads(json.dumps(xmltodict.parse(rawxml)))
            response = data.get('RESPONSE',{})
            zoneregulations = data.get('RESPONSE').get('ZONINGREGULATIONS',{})
            regulation = data.get('RESPONSE').get('ZONINGREGULATIONS').get('REGULATION')
            if regulation:
                zone_code = regulation.get('ZONE_CODE','')
                GFA = regulation.get('GFA')
                if GFA is None:
                    GFA = ''
                FAR = regulation.get('FAR')
                if FAR is None:
                    FAR = '' 
                    
                meta = {'plotno':plotno,'response':response,'zoneregulations':zoneregulations,'regulation':regulation,'GFA':GFA,'FAR':FAR} 
                db.plotlocator_data_07_06_new.insert(dict(meta))
                print(meta)
        

CollectDb()
