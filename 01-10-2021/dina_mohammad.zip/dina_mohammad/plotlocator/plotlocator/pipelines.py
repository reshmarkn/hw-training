# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html



import pymongo
from scrapy.exceptions import DropItem
from plotlocator.items import *
from plotlocator.settings import *


class PlotlocatorPipeline(object):
    def __init__(self, settings):
        self.mongo_uri = settings.get('MONGO_URI')
        self.mongo_db = settings.get('MONGO_DB')
        self.mongo_collection = settings.get('MONGO_COLLECTION')
        self.dup_key = settings.get('DUP_KEY')

    @classmethod
    def from_crawler(cls, crawler):
        return cls(
            settings=crawler.settings
        )

    def open_spider(self, spider):
        self.client = pymongo.MongoClient(self.mongo_uri)
        self.db = self.client[self.mongo_db]
        if self.dup_key:
            self.db[self.mongo_collection].create_index(
                self.dup_key, unique=True)

    def close_spider(self, spider):
        self.client.close()

    def process_item(self, item, spider):
        if isinstance(item, PlotlocatorItem):
            try:
                self.db[self.mongo_collection].insert(dict(item))
            except:
                raise DropItem("Dropping duplicate item")
        return item
