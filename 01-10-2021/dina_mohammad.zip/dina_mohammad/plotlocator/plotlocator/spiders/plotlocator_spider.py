# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from plotlocator.items import *
from plotlocator.settings import *
from plotlocator.proxy import parse_proxy
from pymongo import MongoClient

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

headers = {'Accept': 'application/json, text/javascript, */*; q=0.01', 
    'Accept-Encoding': 'gzip, deflate', 
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8', 
    'Cache-Control': 'no-cache', 
    'Connection': 'keep-alive', 
    'Content-Length': '14', 
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 
    'Host': 'plotlocator.dm.gov.ae', 
    'Origin': 'http://plotlocator.dm.gov.ae', 
    'Pragma': 'no-cache', 
    'Referer': 'http://plotlocator.dm.gov.ae/PlotFinder/Findplot?lang=en', 
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36', 
    'X-Requested-With': 'XMLHttpRequest',}
db = MongoClient('mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017').plotlocator  

class PlotlocatorSpider(Spider):
    name = 'plotlocator'

    def start_requests(self):
        # credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        # while True:
        #     connection = pika.BlockingConnection(pika.ConnectionParameters(
        #         credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        #     channel = connection.channel()
        #     channel.basic_qos(prefetch_count=1)
        #     method, properties, url = channel.basic_get(queue=QUEUE_NAME)
        #     if not url.strip():
        #         break
        #     channel.basic_ack(delivery_tag=method.delivery_tag)
        #     url = str(url, encoding='utf-8')
        #     form_data = {'plotno': str(url)}
        #     if url.strip():
        #         link = 'http://plotlocator.dm.gov.ae/PlotFinder/getZoneRegulation'
        #         yield FormRequest(url=link.strip(),headers=headers,formdata=form_data,meta=form_data, callback=self.parse_profile,dont_filter=True,errback=lambda x: self.errback_httpbin(x, url))
        # connection.close()
        list_ = ['4161788',
                '6867233',
                '3120571',
                '1191223',
                '1191228',
                '1180682',]
        # plotno = 5980118
        for plotno in list_:
            # plotno = plotno + 1 
            url = 'http://plotlocator.dm.gov.ae/PlotFinder/getZoneRegulation'
            form_data = {'plotno': '5980118'}
            meta = {'plotno': str(plotno)}
            yield FormRequest(url=url, headers=headers, formdata=form_data, callback=self.parse_profile,meta=meta)
            # plotno = int(plotno)
    def parse_profile(self, response):
        json_data = json.loads(response.body_as_unicode())
        schoolreg = json_data.get('response').get('SchoolReg','')
        exepdetails = json_data.get('response').get('ExepDetails','')  
        frozdetails = json_data.get('response').get('FrozDetails','')
        partdetails = json_data.get('response').get('PartDetails','')
        fullfrozendetails = json_data.get('response').get('FullFrozenDetails','')
        fullyaffdetails = json_data.get('response').get('FullyAffDetails','')
        coastdetails = json_data.get('response').get('CoastDetails','')
        metrodetails = json_data.get('response').get('MetroDetails','')
        message = json_data.get('response').get('MESSAGE','')
        rawxml = json_data.get('response').get('rawXML','')

        if exepdetails.get('EXCEPTION') is None:
            exepdetails.update({'EXCEPTION':''})
        if frozdetails.get('FROZENBY') is None:
            frozdetails.update({'FROZENBY':''})        
        if partdetails.get('PARTIALFROZENDETAIL') is None:
            partdetails.update({'PARTIALFROZENDETAIL':''})   
        if fullfrozendetails.get('FULLYFROZENDETAIL') is None:
            fullfrozendetails.update({'FULLYFROZENDETAIL':''})  
        if fullyaffdetails.get('FULLYAFFECTEDDETAIL') is None:
            fullyaffdetails.update({'FULLYAFFECTEDDETAIL':''}) 
        if coastdetails.get('COASTALDETAIL') is None:
            coastdetails.update({'COASTALDETAIL':''})          
        if metrodetails.get('METRODETAIL') is None:
            metrodetails.update({'METRODETAIL':''})
        if message is None:
            message = ''

        data = json_data.get('response').get('ZoneReg').get('Reg') 
        if data:
            zone_code = data[0].get('ZONE_CODE','')  
            landuse_en = data[0].get('LANDUSE_REG_EN','')
            height_en = data[0].get('HEIGHT_REG_EN','')
            parking_en = data[0].get('PARKING_REG_EN','')
            setback_en = data[0].get('SETBACK_REG_EN','')
            remark_en = data[0].get('REMARKS_REG_EN','')


            landuse_ar = data[0].get('LANDUSE_REG_AR','')
            height_ar = data[0].get('HEIGHT_REG_AR','')
            parking_ar = data[0].get('PARKING_REG_AR','')
            setback_ar = data[0].get('SETBACK_REG_AR','')
            remark_ar = data[0].get('REMARKS_REG_AR','')
            GFA = data[0].get('GFA','')
            FAR = data[0].get('FAR','')


            item = PlotlocatorItem()
            item['URL'] = response.url
            item['zone_code'] = zone_code 
            item['landuse_en'] = landuse_en
            item['height_en'] = height_en
            item['parking_en'] = parking_en
            item['setback_en'] = setback_en
            item['remark_en'] = remark_en
            item['landuse_ar'] = landuse_ar
            item['height_ar'] = height_ar
            item['parking_ar'] = parking_ar
            item['setback_ar'] = setback_ar
            item['remark_ar'] = remark_ar 
            item['schoolreg'] = schoolreg
            item['exepdetails'] = exepdetails
            item['frozdetails'] = frozdetails
            item['partdetails'] = partdetails
            item['fullfrozendetails'] = fullfrozendetails
            item['fullyaffdetails'] = fullyaffdetails
            item['coastdetails'] = coastdetails
            item['metrodetails'] = metrodetails
            item['message'] = message
            item['rawxml'] = rawxml
            item['FAR'] = FAR
            item['GFA'] = GFA
            item['Reg'] = data
            item['plotno'] = response.meta.get('plotno')
            yield item
        else:
            item = PlotlocatorItem()
            item['URL'] = response.url
            item['schoolreg'] = schoolreg
            item['exepdetails'] = exepdetails
            item['frozdetails'] = frozdetails
            item['partdetails'] = partdetails
            item['fullfrozendetails'] = fullfrozendetails
            item['fullyaffdetails'] = fullyaffdetails
            item['coastdetails'] = coastdetails
            item['metrodetails'] = metrodetails
            item['message'] = message
            item['reg'] = data
            item['rawxml'] = rawxml   
            item['plotno'] = response.meta.get('plotno')
            db.plot_not_found_07_09.insert(dict(item))
    def errback_httpbin(self, failure, url):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=600))
        channel = connection.channel()
        channel.queue_declare(queue=QUEUE_NAME, durable=True)
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=url)
        connection.close()
