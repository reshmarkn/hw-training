import requests

from scrapy import Spider, Request
from datetime import datetime

from nomadhomes.settings import *
from nomadhomes.items import *


class NomadhomesSpiderSpider(Spider):
    name = 'nomadhomes_crawler'
    allowed_domains = ['nomadhomes.co']
    start_urls = ["https://nomadhomes.co"]

    def parse(self, response):
        category_json_urls = [
            "https://nomadhomes.co/api/search/map_point?query=&boundingBox%5B%5D=24.88626258114111&boundingBox%5B%5D=55.10529863528487&boundingBox%5B%5D=25.316545073042533&boundingBox%5B%5D=55.36279070071416&filters=%28dealType%3A+%22buy%22%29",
            "https://nomadhomes.co/api/search/map_point?query=&boundingBox%5B%5D=24.88626258114111&boundingBox%5B%5D=55.10529863528487&boundingBox%5B%5D=25.316545073042533&boundingBox%5B%5D=55.36279070071416&filters=%28dealType%3A+%22rent%22%29",
        ]
        for category_json_url in category_json_urls:

            response = requests.get(category_json_url, headers=headers).json()
            list_pages = response.get("data")
            for list_page in list_pages:
                id_ = list_page.get("id")

                item = NomadhomesUrlItem()
                item['id'] = id_
                yield item
