# -*- coding: utf-8 -*-
import requests
import pika
import logging

from scrapy import Spider, Request
from datetime import datetime

from nomadhomes.settings import *
from nomadhomes.items import *

logger = logging.getLogger('pika')
logger.propagate = False


class NomadhomesSpiderSpider(Spider):
    name = 'nomadhomes_spider'
    allowed_domains = ['nomadhomes.co']
    start_urls = ["https://nomadhomes.co"]

    def parse(self, response):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_HOST, socket_timeout=300))
        channel = connection.channel()
        channel.basic_qos(prefetch_count=1)
        # id_ = ''
        while True:
            try:
                method, properties, id_ = channel.basic_get(queue=QUEUE_NAME)
            except Exception as e:
                connection = pika.BlockingConnection(pika.ConnectionParameters(
                    credentials=credentials, host=QUEUE_HOST, socket_timeout=300))
                channel = connection.channel()
                channel.basic_qos(prefetch_count=1)
                method, properties, id_ = channel.basic_get(queue=QUEUE_NAME)
            if not id_:
                logging.warning('Queue completed.')
                break
            if id_:
                channel.basic_ack(delivery_tag=method.delivery_tag)
                id_ = str(id_.strip(), encoding='utf-8')
                data_url = "https://nomadhomes.co/api/listing/" + id_
                # url = category_url + "/" + id_
                response = requests.get(data_url, headers=headers).json()
                data = response.get("data")
                if data:
                    tower = data.get("tower")
                    property_ = data.get("property")
                    location = tower.get("location", {})

                    category = data.get("dealType")
                    description = data.get("description").replace("\n", ". ")
                    location_ = tower.get("city")
                    price = data.get("price")
                    bedrooms = property_.get("bedrooms", "")
                    bathrooms = property_.get("bathrooms", "")
                    furnishing = data.get("furnishing", "")
                    amenities = ", ".join(property_.get("amenities", []))
                    scraped_ts = datetime.now().strftime("%Y-%m-%d")
                    imagesUrls = len(data.get("imagesUrls", []))
                    latitude = str(location.get("latitude"))
                    longitude = str(location.get("longitude"))
                    name = tower.get("name")
                    community = tower.get("community")
                    user_id = tower.get("id")
                    title = ", ".join([x.strip()
                                       for x in [name, community] if x.strip() != ''])
                    if "Buy" in category:
                        category_url = "/buy"
                        url = "https://nomadhomes.co/buy/" + id_
                        price_per = ''
                    elif "Rent" in category:
                        category_url = "/rent"
                        url = "https://nomadhomes.co/rent/" + id_
                        price_per = "Year"

                    item = NomadhomesItem()

                    item["reference_number"] = ''
                    item["id"] = id_
                    item["url"] = url
                    item["broker_display_name"] = ''
                    item["broker"] = ''
                    item["category"] = category
                    item["category_url"] = category_url
                    item["title"] = title
                    item["description"] = description
                    item["location"] = location_
                    item["price"] = price
                    item["currency"] = "AED"
                    item["price_per"] = price_per
                    item["bedrooms"] = bedrooms
                    item["bathrooms"] = bathrooms
                    item["furnished"] = furnishing
                    item["rera_permit_number"] = ''
                    item["dtcm_licence"] = ''
                    item["amenities"] = amenities
                    item["scraped_ts"] = scraped_ts
                    item["details"] = ''
                    item["agent_name"] = ''
                    item["number_of_photos"] = imagesUrls
                    item["user_id"] = user_id
                    item["phone_number"] = ''
                    item["date"] = scraped_ts
                    item["iteration_number"] = "2020_08"
                    item["longitude"] = longitude
                    item["latitude"] = latitude
                    yield item

        connection.close()
