# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
from pymongo import MongoClient
from scrapy.exceptions import DropItem
from nomadhomes.items import *

MONGODB_DB = 'dina_mohammad_nomadhomes'
MONGODB_COLLECTION_PROPERTY_URL = 'nomadhomes_url_2020_08'
MONGODB_COLLECTION_PROPERTY = 'nomadhomes_2020_08'


class NomadhomesPipeline:
    def __init__(self, *args, **kwargs):

        self.client = MongoClient(
            'mongodb://datahut:cGFzc21lMTIz@138.197.68.56:27017')
        self.db = self.client[MONGODB_DB]

        self.db[MONGODB_COLLECTION_PROPERTY_URL].create_index(
            'id', unique=True)
        self.db[MONGODB_COLLECTION_PROPERTY].create_index('id', unique=True)

    def process_item(self, item, spider):
        if isinstance(item, NomadhomesUrlItem):
            try:
                self.db[MONGODB_COLLECTION_PROPERTY_URL].insert(item)
            except Exception:
                raise DropItem("Dropping duplicate item")
        if isinstance(item, NomadhomesItem):
            try:
                self.db[MONGODB_COLLECTION_PROPERTY].insert(dict(item))
            except Exception:
                raise DropItem("Dropping duplicate item")

        return item
