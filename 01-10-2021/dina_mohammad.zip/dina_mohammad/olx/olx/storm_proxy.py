import random
import base64
# from scrapy.conf import settings
from scrapy.utils.project import get_project_settings
import random
# from scrapy import log
import requests
from time import sleep


def parse_proxy():
    # storm
    # proxies = {'http': 'http://5.79.66.2:13200',
    #                    'https': 'https://5.79.66.2:13200', }

    # torr

    # proxies = {'http': 'http://138.197.105.12:5566',
    #            'https': 'https://138.197.105.12:5566', }

    # PROXY_LIST = requests.get('http://68.183.58.145/microleaves',
    #                           headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()

    PROXY_LIST = requests.get(
        'http://68.183.58.145/torproxies', headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()

    PROXY = random.choice(PROXY_LIST)
    proxies = {"http": "http://%s" % PROXY,
                       "https": "https://%s" % PROXY}
    settings = get_project_settings()
    user_agent = random.choice(settings.get('USER_AGENT_LIST'))
    headers = {'accept-encoding': 'gzip, deflate, sdch, br',
               'user-agent': user_agent, 'accept': 'application/json, text/javascript, */*; q=0.01',
               'x-requested-with': 'XMLHttpRequest'}
    return {'headers': headers, 'proxies': proxies}
