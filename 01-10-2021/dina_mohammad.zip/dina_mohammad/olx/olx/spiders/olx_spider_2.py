import re
import json
import requests
import scrapy
import string
import pika
import logging

from scrapy.http import Request, FormRequest
from scrapy.selector import Selector
from datetime import datetime
from scrapy.shell import inspect_response
from time import sleep
from rmq import RmqHandler

from olx.settings import *
from olx.items import *

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


class OlxEg2Spider(scrapy.Spider):
    name = 'olx_eg_spider'
    start_urls = ['https://olx.com.eg/en/properties/']

    def start_requests(self):

        rmqh = RmqHandler(QUEUE_NAME, ip=QUEUE_IP,user=QUEUE_USER, pwd=QUEUE_PASS)
        while True:
            count, data = rmqh.get()
            if not data:
                break
            if data:
                url = data
                if '/en/' not in url:
                    url = url.replace('/ad/', '/en/ad/').strip()
                if url.strip():
                    yield Request(url=url.strip(), callback=self.parse_data, errback=lambda x: self.errback_httpbin(x, url.strip()))



    def parse_data(self, response):
        url=response.url
        category_url = response.xpath('//th[contains(text(),"Sale/Rent")]/following-sibling::td//a/@href').extract()
        category = response.xpath('//th[contains(text(),"Sale/Rent")]/following-sibling::td//a/text()').extract()
        category_url = category_url[0].strip().replace('https://www.olx.com.eg', '').strip() if category_url else ''
        category = category[0].strip() if category else ''


        item = OlxEgCatItem(
            url=response.url,
            category=category,
            category_url=category_url,
        )

        if url:
            yield item

    def errback_httpbin(self, failure, url):

        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=600))
        channel = connection.channel()
        channel.queue_declare(queue=QUEUE_NAME, durable=True)
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=url)
        connection.close()
