import re
import json
import requests
import scrapy
import string
import pika
import logging

from scrapy.http import Request, FormRequest
from scrapy.selector import Selector
from datetime import datetime
from scrapy.shell import inspect_response
from time import sleep
from rmq import RmqHandler

from olx.settings import *
from olx.items import *

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


class OlxSpider(scrapy.Spider):
    name = 'olx_eg'
    start_urls = ['https://olx.com.eg/en/properties/']

    def start_requests(self):
        # credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        # connection = pika.BlockingConnection(pika.ConnectionParameters(
        #     credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        # channel = connection.channel()
        # while True:
        #     channel.basic_qos(prefetch_count=1)
        #     method, properties, url = channel.basic_get(queue=QUEUE_NAME)
        #     if not url.strip():
        #         break
        #     channel.basic_ack(delivery_tag=method.delivery_tag)
        #     url = str(url.strip(), encoding='utf-8')
        rmqh = RmqHandler(QUEUE_NAME, ip=QUEUE_IP,user=QUEUE_USER, pwd=QUEUE_PASS)
        while True:
            count, data = rmqh.get()
            if not data:
                break
            if data:
                url = data
                if '/en/' not in url:
                    url = url.replace('/ad/', '/en/ad/').strip()
                if url.strip():
                    yield Request(url=url.strip(), callback=self.parse_data, errback=lambda x: self.errback_httpbin(x, url.strip()))
        # connection.close()
        # f = open('urls.txt')
        # for url in f.readlines():
        #     url = url.strip()
        #     yield Request(url=url, callback=self.parse_data,)

    def parse_data(self, response):
        rera_permit_number = ''
        dtcm_licence = ''
        price_per = ''
        price = ''
        currency = ''
        img = ''
        phone_number = ''
        ID_XPATH = '//span[@class="rel inlblk"]/text()'
        BROKER_XPATH = '//p[@class="user-box__info__name"]/text()'
        CATEGORY_XPATH = '//li[contains(@class, "inline")]/a/span/text()'
        CATEGORY_URL_XPATH = '//li[contains(@class, "inline")]/a/@href'
        PRICE_RAW_XPATH = '//script[contains(text(), "adTrackingData = ")]/text()'
        DESCRIPTION_XPATH = '//div[@class="clr descriptioncontent marginbott20"]/div[@id="textContent"]/p//text()'
        BEDROOMS_XPATH = '//th[contains(text(), "Bedrooms")]/following-sibling::td/strong/a/text()'
        BATHROOMS_XPATH = '//th[contains(text(), "Bathrooms")]/following-sibling::td[@class="value"]/strong/a/text()'
        FURNISHED_XPATH = '//th[contains(text(), "Furnished")]/following-sibling::td[@class="value"]/strong/a/text()'
        LOCATION_XPATH = '//span[@class="show-map-link link gray cpointer"]/strong/text()'

        title = response.xpath('//h1/text()').extract()
        id_ = response.xpath(ID_XPATH).extract()
        broker_display_name = response.xpath(BROKER_XPATH).extract()
        category = response.xpath(CATEGORY_XPATH).extract()
        category_url = response.xpath(CATEGORY_URL_XPATH).extract()
        description = response.xpath(DESCRIPTION_XPATH).extract()
        bedrooms = response.xpath(BEDROOMS_XPATH).extract()
        bathrooms = response.xpath(BATHROOMS_XPATH).extract()
        furnished = response.xpath(FURNISHED_XPATH).extract()
        loc = response.xpath(LOCATION_XPATH).extract()
        price_raw_ = response.xpath(PRICE_RAW_XPATH).extract()

        title = ' '.join(' '.join(title).split()) if title else ''
        id_ = id_[0].strip() if id_ else ''
        broker_display_name = broker_display_name[
            0].strip() if broker_display_name else ''
        # category = ' > '.join(category)
        category = ''
        category_url = category_url[-1].strip() if category_url else ''
        category_url = category_url.replace('https://www.olx.com.eg', '')
        if 'for-rent' in category_url:
            category = 'rent'
            # category_url = '/en/properties/properties-for-rent/'
        elif 'for-sale' in category_url:
            category = 'sale'
            # category_url = '/en/properties/properties-for-sale/'

        description = ' '.join(
            ' '.join(description).split()) if description else ''
        location = loc[0].strip() if loc else ''
        bedrooms = bedrooms[0].strip() if bedrooms else ''
        bathrooms = bathrooms[0].strip() if bathrooms else ''
        furnished = furnished[0].strip() if furnished else ''
        price_raw_ = price_raw_[0].strip() if price_raw_ else ''
        price_raw_ = price_raw_.replace('var adTrackingData = ', '').replace(
            "\n    mixpanel.track('ad_view', adTrackingData);", "").replace('\n        ', '').replace(',\n    }', '}').replace("'", '"')
        price_raw_ = price_raw_.replace(
            '\n', '').replace('\t', '').replace(';', '')
        price_raw_ = price_raw_.split('if')[0]
        try:
            price_raw_ = json.loads(price_raw_)
        except Exception as e:
            try:
                price_raw_ = json.loads(price_raw_)
            except Exception as e:
                price_raw_ = {}
        price = price_raw_.get('price', '')
        if price:
            currency = 'EGP'
        else:
            price_raw = response.xpath(
                '//div[@class="pricelabel tcenter"]/strong/text()').extract()
            price_raw = price_raw[0].strip() if price_raw else ''
            if 'EGP' in price_raw:
                price_raw = price_raw.split(' ')
                if len(price_raw) >= 2:
                    price = price_raw[0]
                    currency = price_raw[1]
        price = price if price else ''
        currency = currency if currency else ''
        price_per = price_per if price_per else ''
        area = response.xpath(
            '//tr/th[contains(text(),"المساحة (م٢)")]/following-sibling::td/strong/text()|//tr/th[contains(text(),"Area (m²)")]/following-sibling::td/strong/text()').extract()
        area = [x.strip().replace('-', '') for x in [x.strip()
                                                     for x in area] if x]if area else ''
        details = ''.join(area).strip() if area else ''
        img1 = response.xpath(
            '//div[@class="tcenter img-item"]/div/img/@src').extract()
        img2 = response.xpath(
            '//div[@class="photo-handler rel inlblk"]/img/@src').extract()
        if img1 and img2:
            img = img1 + img2
        elif img1:
            img = img1
        elif img2:
            img = img2
        img = img if img else ''
        number_of_photos = str(len(img)) if img else ''
        if number_of_photos == '0':
            number_of_photos = ''
        number_of_photos = number_of_photos if number_of_photos else ''
        amen = response.xpath(
            '//tr/th[contains(text(),"Amenities")]/following-sibling::td/strong/a/text()').extract()
        amen = [x.strip() for x in [x.strip()
                                    for x in amen] if x]if amen else ''
        amenities = ', '.join(amen).strip().replace(
            '\t', '').replace('\n', '') if amen else ''
        propety_type =response.xpath('//th[contains(text(), "Type")]/following-sibling::td[@class="value"]/strong/a/text()').extract()
        propety_type = propety_type[-1].strip() if propety_type else ''

        published_at = response.xpath('//span[contains(text(),"Added at")]/text()').extract()
        published_at = ''.join(published_at).split(',')[1].strip()

        is_phone = response.xpath(
            '//span[@class="link spoiler small nowrap"][contains(text(),"Show phone")]')
        if is_phone:
            ad_id = response.url.split('ID')
            if len(ad_id) == 2:
                ad_id = ad_id[1].replace('.html', '')
                phone_url = 'https://olx.com.eg/en/ajax/misc/contact/phone/'+ad_id+'/'
                h = {'Accept': '*/*',
                     'Accept-Encoding': 'gzip, deflate, br',
                     'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
                     'Cache-Control': 'no-cache',
                     'Connection': 'keep-alive',
                     'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36',
                     'X-Requested-With': 'XMLHttpRequest', }
                try:
                    r = requests.get(phone_url, headers=h)
                    phone_number = r.json().get('value')
                except:
                    try:
                        r = requests.get(phone_url, headers=h)
                        phone_number = r.json().get('value')
                    except:
                        phone_number = ''
                        pass

        # scraped_ts = (datetime.now()).strftime("%Y-%m-%d")
        # scraped_ts = (datetime.now()).date()
        scraped_ts = (datetime.now()).strftime("%Y-%m-%d")

        now = datetime.now()
        current = datetime(now.year, now.month, 1)
        next_month = datetime(now.year + int(now.month / 12),
                              ((now.month % 12) + 1), 1)
        now_date_int = int(now.strftime("%d"))
        if now_date_int <= 31 and now_date_int >= 25:
            iteration_month = next_month.strftime("%m")
            iteration_year = next_month.strftime("%Y")
        else:
            iteration_month = now.strftime("%m")
            iteration_year = now.strftime("%Y")
        iteration_number = iteration_year + '_' + iteration_month

        if '/properties/' in category_url:

            item = OlxEgItem(
                reference_number='',
                id=id_,
                url=response.url,
                broker_display_name=broker_display_name.upper(),
                broker=broker_display_name.upper(),
                category=category,
                category_url=category_url,
                title=title,
                description=description,
                location=location,
                price=price,
                currency=currency,
                price_per=price_per,
                bedrooms=bedrooms,
                bathrooms=bathrooms,
                furnished=furnished,
                rera_permit_number=rera_permit_number,
                dtcm_licence=dtcm_licence,
                scraped_ts=scraped_ts,
                amenities=amenities,
                details=details,
                agent_name='',
                number_of_photos=number_of_photos,
                user_id='',
                phone_number=phone_number,
                date=scraped_ts,
                iteration_number=iteration_number,
                depth = '',
                sub_category_1 = '',
                property_type =propety_type,
                sub_category_2='',
                published_at=published_at,

            )

            if title and id_:
                yield item

    def errback_httpbin(self, failure, url):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=600))
        channel = connection.channel()
        channel.queue_declare(queue=QUEUE_NAME, durable=True)
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=url)
        connection.close()
