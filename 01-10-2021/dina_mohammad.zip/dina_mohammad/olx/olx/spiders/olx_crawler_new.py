import scrapy
import string
import pika
import re
import json
import requests
import logging

from scrapy.http import Request, FormRequest
from scrapy.selector import Selector
from time import sleep
from datetime import datetime
from scrapy.shell import inspect_response

from olx.items import *
from olx.settings import *


class OlxSpider(scrapy.Spider):
    name = 'olx_crawler_new'
    # start_urls = ['https://olx.com.eg/en/properties/']
    def start_requests(self):

        f = open('city_list.txt')
        city_list = f.readlines()

        for city in city_list:
            url = 'https://www.olx.com.eg/en/properties/'+city+'/'
            yield Request(url,callback=self.parse,meta={'url':url},dont_filter=True)
    def parse(self, response):
        DEPTH=''
        SUB_CATEGORY_1 =''
        url = response.meta.get('url')


        featured_ads_link =response.xpath('//h2[contains(text(),"Featured ads")]/parent::div/a/@href').extract_first('') 
        if featured_ads_link:
            yield Request(featured_ads_link,callback=self.parse_featured,meta={'url':url},dont_filter=True)
                                                     
        sub_cat_links = response.xpath(
            '//a[@class="topLink tdnone "]/@href').extract()
        sub_loc_links = response.xpath(
            '//div[@id="locationLinks"]//a/@href').extract()

        if sub_loc_links:
            for link in sub_loc_links:
                link = link.strip().strip('#')
                if 'http' in link:
                    yield Request(url=link, callback=self.parse,meta={'url':url})

        if sub_cat_links:
            for link in sub_cat_links:
                link = link.strip().strip('#')
                if 'http' in link:
                    yield Request(url=link, callback=self.parse,meta={'url':url})

        list_item = response.xpath(
            '//div[@class="ads__item"]')

        for prop in list_item:
            link = prop.xpath('div[@class="ads__item__info"]/a/@href').extract()
            sub_type = prop.xpath('div[@class="ads__item__info"]/p[@class="ads__item__breadcrumbs"]/text()').extract()
            link = link[0].strip() if link else ''
            sub_type = sub_type[0].strip() if sub_type else ''
            if 'Apartments & Duplex' in sub_type: 
                SUB_CATEGORY_1 ='Residential'  
            elif 'Villas' in sub_type: 
                SUB_CATEGORY_1 ='Residential' 
            elif 'Vacation Homes' in sub_type: 
                SUB_CATEGORY_1 ='Residential'  
            elif 'Commercial' in sub_type: 
                SUB_CATEGORY_1='Commercial' 
            elif 'Buildings & Lands' in sub_type: 
                SUB_CATEGORY_1='Commercial' 
            else:
                SUB_CATEGORY_1 = sub_type.strip().replace('Properties »','').strip()    

            items = OlxEgUrlItem(
                sub_category_1=SUB_CATEGORY_1,
                sub_category_2='',
                depth='',
                url=link.strip(),
            )
            yield items


        next_page = response.xpath(
            '//span[@class="item fright"]/a/@href').extract_first()
        if next_page:
            yield Request(next_page, callback=self.parse,meta={'url':url})

    def parse_featured(self, response):
        DEPTH=''
        SUB_CATEGORY_1 =''
        url = response.meta.get('url')

        list_item = response.xpath(
            '//div[@class="ads__item"]')

        for prop in list_item:
            link = prop.xpath('div[@class="ads__item__info"]/a/@href').extract()
            sub_type = prop.xpath('div[@class="ads__item__info"]/p[@class="ads__item__breadcrumbs"]/text()').extract()
            link = link[0].strip() if link else ''
            sub_type = sub_type[0].strip() if sub_type else ''
            if 'Apartments & Duplex' in sub_type: 
                SUB_CATEGORY_1 ='Residential'  
            elif 'Villas' in sub_type: 
                SUB_CATEGORY_1 ='Residential' 
            elif 'Vacation Homes' in sub_type: 
                SUB_CATEGORY_1 ='Residential'  
            elif 'Commercial' in sub_type: 
                SUB_CATEGORY_1='Commercial' 
            elif 'Buildings & Lands' in sub_type: 
                SUB_CATEGORY_1='Commercial' 
            else:
                SUB_CATEGORY_1 = sub_type.strip().replace('Properties »','').strip()

            items = OlxEgUrlItem(
                sub_category_1=SUB_CATEGORY_1,
                sub_category_2='',
                depth='featured',
                url=link.strip(),
            )
            yield items


        next_page = response.xpath(
            '//span[@class="item fright"]/a/@href').extract_first()
        if next_page:
            yield Request(next_page, callback=self.parse_featured,meta={'url':url})