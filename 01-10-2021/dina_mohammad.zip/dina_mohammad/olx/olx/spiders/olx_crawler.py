import scrapy
import string
import pika
import re
import json
import requests
import logging

from scrapy.http import Request, FormRequest
from scrapy.selector import Selector
from time import sleep
from datetime import datetime
from scrapy.shell import inspect_response

from olx.items import *
from olx.settings import *


class OlxSpider(scrapy.Spider):
    name = 'olx_eg_crawler'
    # start_urls = ['https://olx.com.eg/en/properties/']
    def start_requests(self):
        # urls =['https://www.olx.com.eg/en/properties/apartments-duplex-for-sale/',
        #         'https://www.olx.com.eg/en/properties/apartments-duplex-for-rent/',
        #         'https://www.olx.com.eg/en/properties/villas-for-sale/',
        #         'https://www.olx.com.eg/en/properties/villas-for-rent/',
        #         'https://www.olx.com.eg/en/properties/vacation-homes-for-sale/',
        #         'https://www.olx.com.eg/en/properties/vacation-homes-for-rent/',
        #         'https://www.olx.com.eg/en/properties/commercial-for-sale/',
        #         'https://www.olx.com.eg/en/properties/commercial-for-rent/',
        #         'https://www.olx.com.eg/en/properties/buildings-lands-other/',
                # ]
        urls =['https://www.olx.com.eg/en/properties/apartments-duplex-for-sale/?search%5Border%5D=filter_float_price%3Aasc',
                'https://www.olx.com.eg/en/properties/apartments-duplex-for-sale/?search%5Border%5D=filter_float_price%3Adesc',
                'https://www.olx.com.eg/en/properties/apartments-duplex-for-sale/?search%5Border%5D=created_at%3Adesc',
                'https://www.olx.com.eg/en/properties/apartments-duplex-for-rent/?search%5Border%5D=filter_float_price%3Aasc',
                'https://www.olx.com.eg/en/properties/apartments-duplex-for-rent/?search%5Border%5D=filter_float_price%3Adesc',
                'https://www.olx.com.eg/en/properties/villas-for-sale/?search%5Border%5D=filter_float_price%3Aasc',
                'https://www.olx.com.eg/en/properties/villas-for-sale/?search%5Border%5D=filter_float_price%3Adesc',
                'https://www.olx.com.eg/en/properties/villas-for-rent/?search%5Border%5D=filter_float_price%3Aasc',
                'https://www.olx.com.eg/en/properties/villas-for-rent/?search%5Border%5D=filter_float_price%3Adesc',
                'https://www.olx.com.eg/en/properties/vacation-homes-for-sale/?search%5Border%5D=filter_float_price%3Aasc',
                'https://www.olx.com.eg/en/properties/vacation-homes-for-sale/?search%5Border%5D=filter_float_price%3Adesc',
                'https://www.olx.com.eg/en/properties/vacation-homes-for-rent/?search%5Border%5D=filter_float_price%3Aasc',
                'https://www.olx.com.eg/en/properties/vacation-homes-for-rent/?search%5Border%5D=filter_float_price%3Adesc',
                'https://www.olx.com.eg/en/properties/commercial-for-sale/?search%5Border%5D=filter_float_price%3Aasc',
                'https://www.olx.com.eg/en/properties/commercial-for-sale/?search%5Border%5D=filter_float_price%3Adesc',
                'https://www.olx.com.eg/en/properties/commercial-for-rent/?search%5Border%5D=filter_float_price%3Aasc',
                'https://www.olx.com.eg/en/properties/commercial-for-rent/?search%5Border%5D=filter_float_price%3Adesc',
                'https://www.olx.com.eg/en/properties/buildings-lands-other/?search%5Border%5D=filter_float_price%3Aasc',
                'https://www.olx.com.eg/en/properties/buildings-lands-other/?search%5Border%5D=filter_float_price%3Adesc']
        # urls = ['https://www.olx.com.eg/en/properties/apartments-duplex-for-sale/?search%5Border%5D=created_at%3Adesc',
        #         'https://www.olx.com.eg/en/properties/apartments-duplex-for-sale/?search%5Border%5D=created_at%3Adesc',
        #         'https://www.olx.com.eg/en/properties/apartments-duplex-for-rent/?search%5Border%5D=created_at%3Adesc',
        #         'https://www.olx.com.eg/en/properties/villas-for-sale/?search%5Border%5D=created_at%3Adesc',
        #         'https://www.olx.com.eg/en/properties/villas-for-rent/?search%5Border%5D=created_at%3Adesc',
        #         'https://www.olx.com.eg/en/properties/vacation-homes-for-sale/?search%5Border%5D=created_at%3Adesc',
        #         'https://www.olx.com.eg/en/properties/vacation-homes-for-rent/?search%5Border%5D=created_at%3Adesc',
        #         'https://www.olx.com.eg/en/properties/commercial-for-sale/?search%5Border%5D=created_at%3Adesc',
        #         'https://www.olx.com.eg/en/properties/commercial-for-rent/?search%5Border%5D=created_at%3Adesc',
        #         'https://www.olx.com.eg/en/properties/buildings-lands-other/?search%5Border%5D=created_at%3Adesc'
        #         ]


        for url in urls:
            yield Request(url,callback=self.parse,meta={'url':url},dont_filter=True)
    def parse(self, response):
        DEPTH=''
        SUB_CATEGORY_1 =''
        url = response.meta.get('url')
        featured_ads_link =response.xpath('//h2[contains(text(),"Featured ads")]/parent::div/a/@href').extract_first('') 
        if featured_ads_link:
            yield Request(featured_ads_link,callback=self.parse_featured,meta={'url':url},dont_filter=True)
        # else:
        if 'apartments-duplex-for-sale/' in url: 
            SUB_CATEGORY_1 ='Residential'  
        elif 'apartments-duplex-for-rent/' in url: 
            SUB_CATEGORY_1 ='Residential' 
        elif 'villas-for-sale' in url: 
            SUB_CATEGORY_1 ='Residential' 
        elif 'villas-for-rent' in url:
            SUB_CATEGORY_1 ='Residential'  
        elif 'vacation-homes-for-rent' in url: 
            SUB_CATEGORY_1 ='Residential'  
        elif '/vacation-homes-for-sale' in url: 
            SUB_CATEGORY_1 ='Residential'  
        elif 'commercial-for-sale' in url: 
            SUB_CATEGORY_1='Commercial' 
        elif 'commercial-for-rent' in url: 
            SUB_CATEGORY_1='Commercial'  
        elif 'commercial-for-rent' in url: 
            SUB_CATEGORY_1='Commercial' 
        elif 'buildings-lands-other' in url: 
            SUB_CATEGORY_1='Commercial' 
        else:
            SUB_CATEGORY_1 =''
                                                     
        sub_cat_links = response.xpath(
            '//a[@class="topLink tdnone "]/@href').extract()
        sub_loc_links = response.xpath(
            '//div[@id="locationLinks"]//a/@href').extract()

        if sub_loc_links:
            for link in sub_loc_links:
                link = link.strip().strip('#')
                if 'http' in link:
                    yield Request(url=link, callback=self.parse,meta={'url':url})

        if sub_cat_links:
            for link in sub_cat_links:
                link = link.strip().strip('#')
                if 'http' in link:
                    yield Request(url=link, callback=self.parse,meta={'url':url})

        links = response.xpath(
            '//div[@class="ads__item__info"]/a/@href').extract()
        next_page = response.xpath(
            '//span[@class="item fright"]/a/@href').extract_first()
        for link in links:
            items = OlxEgUrlItem(
                sub_category_1=SUB_CATEGORY_1,
                sub_category_2='',
                depth='',
                url=link.strip(),
            )
            yield items
        if next_page:
            yield Request(next_page, callback=self.parse,meta={'url':url})
    def parse_featured(self, response):
        DEPTH=''
        SUB_CATEGORY_1 =''
        url = response.meta.get('url')
        if 'apartments-duplex-for-sale/' in url: 
            SUB_CATEGORY_1 ='Residential'  
        elif 'apartments-duplex-for-rent/' in url: 
            SUB_CATEGORY_1 ='Residential' 
        elif 'villas-for-sale' in url: 
            SUB_CATEGORY_1 ='Residential' 
        elif 'villas-for-rent' in url:
            SUB_CATEGORY_1 ='Residential'  
        elif 'vacation-homes-for-rent' in url: 
            SUB_CATEGORY_1 ='Residential'  
        elif '/vacation-homes-for-sale' in url: 
            SUB_CATEGORY_1 ='Residential'  
        elif 'commercial-for-sale' in url: 
            SUB_CATEGORY_1='Commercial' 
        elif 'commercial-for-rent' in url: 
            SUB_CATEGORY_1='Commercial'  
        elif 'commercial-for-rent' in url: 
            SUB_CATEGORY_1='Commercial' 
        elif 'buildings-lands-other' in url: 
            SUB_CATEGORY_1='Commercial' 
        else:
            SUB_CATEGORY_1 =''                                             
        sub_cat_links = response.xpath(
            '//a[@class="topLink tdnone "]/@href').extract()
        sub_loc_links = response.xpath(
            '//div[@id="locationLinks"]//a/@href').extract()

        if sub_loc_links:
            for link in sub_loc_links:
                link = link.strip().strip('#')
                if 'http' in link:
                    yield Request(url=link, callback=self.parse_featured,meta={'url':url})

        if sub_cat_links:
            for link in sub_cat_links:
                link = link.strip().strip('#')
                if 'http' in link:
                    yield Request(url=link, callback=self.parse_featured,meta={'url':url})

        links = response.xpath(
            '//div[@class="ads__item__info"]/a/@href').extract()
        next_page = response.xpath(
            '//span[@class="item fright"]/a/@href').extract_first()
        for link in links:
            items = OlxEgUrlItem(
                sub_category_1=SUB_CATEGORY_1,
                sub_category_2='',
                depth='featured',
                url=link.strip(),
            )
            # print(items)
            yield items
        if next_page:
            yield Request(next_page, callback=self.parse_featured,meta={'url':url})