import os
import random
# from scrapy.conf import settings
# from scrapy import log
import base64
from aqarmap_eg.storm_proxy import parse_proxy
from scrapy.utils.project import get_project_settings
import logging

logger = logging.getLogger(__name__)

settings = get_project_settings()


class ProxyMiddleware(object):

    def process_request(self, request, spider):
        proxy = parse_proxy()
        proxies = proxy['proxies']
        request.meta['proxy'] = proxies['https']
        logger.info("Proxy added")
        # log.msg("Proxy added", level=log.DEBUG)


class RandomUserAgentMiddleware(object):

    def process_request(self, request, spider):
        ua = random.choice(settings.get('USER_AGENT_LIST'))
        if ua:
            request.headers.setdefault('User-Agent', ua)
        logger.debug("USER AGENT IS: " + ua)
        # log.msg("USER AGENT IS: " + ua, level=log.DEBUG)
