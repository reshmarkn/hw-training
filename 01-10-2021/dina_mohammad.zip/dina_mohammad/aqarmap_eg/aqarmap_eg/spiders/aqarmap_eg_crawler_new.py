# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
import io
import gzip

# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime
from scrapy.shell import inspect_response
from time import sleep
from xml.dom import minidom

from aqarmap_eg.items import *
from aqarmap_eg.settings import *

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

headers = {
		'upgrade-insecure-requests': '1',
		'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.119 Safari/537.36'}
	
class Aqarmap_EgCrawlerSpider(Spider):
	name = 'aqarmap_eg_crawler_new'

	allowed_domains = ['aqarmap.com.eg']
	handle_httpstatus_list = [503, 403]

	def start_requests(self):
		credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
		connection = pika.BlockingConnection(pika.ConnectionParameters(
			credentials=credentials, host=QUEUE_IP, socket_timeout=300))
		channel = connection.channel()
		while True:
			channel.basic_qos(prefetch_count=1)
			method, properties, url = channel.basic_get(queue=QUEUE_CAT_NAME)
			if not url.strip():
				break
			channel.basic_ack(delivery_tag=method.delivery_tag)
			url = str(url.strip(), encoding='utf-8')
			if url.strip():
				yield Request(url=url.strip(), callback=self.parse_cat, errback=lambda x: self.errback_httpbin(x, url.strip()))
		connection.close()


	def parse_cat(self, response):
		# inspect_response(response, self)
		# pagination = response.xpath('//a[@rel="next"]/@href').extract()
		if not response.status == 200:
			item = AqarmapEgCatUrlItem(
				url=response.url,
				)
			yield item
		else:
			property_urls = response.xpath('//section[contains(@class,"searchResults")]//a[@itemprop="url"]/@href').extract()
			for prop in property_urls:
				prop = response.urljoin(prop.strip())
				prop = prop.strip().replace('https://egypt.aqarmap.com/ar/','https://egypt.aqarmap.com/en/').strip()
				item = AqarmapEgUrlItem(
					url=prop,
					)
				yield item


	def errback_httpbin(self, failure, url):
		credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
		connection = pika.BlockingConnection(pika.ConnectionParameters(
			credentials=credentials, host=QUEUE_IP, socket_timeout=600))
		channel = connection.channel()
		channel.queue_declare(queue=QUEUE_CAT_NAME, durable=True)
		channel.basic_publish(
			exchange='', routing_key=QUEUE_CAT_NAME, body=url)
		connection.close()
