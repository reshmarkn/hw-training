# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
import urllib

# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime
from scrapy.shell import inspect_response
from rmq import RmqHandler

from aqarmap_eg.items import *
from aqarmap_eg.settings import *


handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False


class AqarmapEgSpider(Spider):
    name = 'aqarmap_eg'
    start_urls = ['https://egypt.aqarmap.com']
    allowed_domains = ['aqarmap.com.eg']

    headers = {'upgrade-insecure-requests': '1',
               'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36'}

    def start_requests(self):
        # credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        # connection = pika.BlockingConnection(pika.ConnectionParameters(
        #     credentials=credentials, host=QUEUE_IP, socket_timeout=300))
        # channel = connection.channel()
        # while True:
        #     channel.basic_qos(prefetch_count=1)
        #     method, properties, url = channel.basic_get(queue=QUEUE_NAME)
        #     if not url.strip():
        #         break
        #     channel.basic_ack(delivery_tag=method.delivery_tag)
        #     url = str(url.strip(), encoding='utf-8')
        #     if url.strip():
        rmqh = RmqHandler(QUEUE_NAME, ip=QUEUE_IP,user=QUEUE_USER, pwd=QUEUE_PASS)
        while True:
            count, data = rmqh.get()
            if not data:
                break
            if data:
                url = data
                if '/ar/' in url:
                    url = url.replace('/ar/','/en/')
                yield Request(url=url.strip(), callback=self.parse_property, errback=lambda x: self.errback_httpbin(x, url.strip()))
        # connection.close()

    def parse_property(self, response):
        #Grab XPATH
        user_id = ''
        ament_str = ''
        amenities = ''
        loc_cat = ''
        title = response.xpath('//h1//text()').extract()
        category = response.xpath(
            '//div[contains(@class,"listing_details_container")]//ul[@class="breadcrumb"]/li/a/span/text()').extract()
        category_url = response.xpath(
            '//ul[@class="breadcrumb"]/li/a/@href').extract()
        description = response.xpath(
            '//div[contains(@class,"listing_details_container")]//div[@class="listingDesc"]//text()').extract()
        id_url = response.xpath('//link[@rel="shortlink"]/@href').extract()
        location = response.xpath(
            '//label[@class="address"]/a/text()').extract()
        price = response.xpath(
            '//div[@class="listing-price-content"]/span[@class="integer"]/text()').extract()
        bedrooms_text = response.xpath(
            '//i[@class="fa fa-bed"]/following-sibling::span[@itemprop="numberOfRooms"]/text()').extract()
        bathrooms_text = response.xpath(
            '//img[@src="/images/bath.svg"]/following-sibling::span[@itemprop="numberOfRooms"]/text()').extract()
        broker_display_name = response.xpath(
            '//div[@class="sellerProperties"]/h4/text()').extract()
        area = response.xpath(
            '//img[@src="/images/size.svg"]/parent::label//text()').extract()
        name = response.xpath(
            '//div[@class="sellerProperties"]/h4/text()').extract_first('')
        
        property_text = response.xpath(
            '//i[@class="fa fa-building"]/parent::label//text()').extract()
        property_text = [x.strip() for x in property_text if x.strip() != '']
        property_type = property_text[0].strip() if property_text else ''


        # phone_number = response.xpath(
        #     '//div[@class="listing-phone hidden-sm hidden-xs "]/div[@ng-show="! showPhoneButton"]/a[@class="btn-lg phoneNumber"]/@data-number').extract()

        phone_number = response.xpath(
            '//div[@class="listing-phone hidden-sm hidden-xs "]/div[@ng-if="!showPhoneButton"]/a[@class="btn-lg phoneNumber"]/@data-number').extract()
        phone_number = ",".join([urllib.parse.unquote(x).strip()
                                 for x in phone_number]) if phone_number else ''

        latitude = response.xpath(
            '//span[@itemprop="latitude"]/text()').extract()
        longitude = response.xpath(
            '//span[@itemprop="longitude"]/text()').extract()
        published_at = response.xpath('//td[contains(text(),"Publish Date")]/following-sibling::td/text()').extract()
        updated_at = response.xpath('//p[contains(text(),"Last update:")]/text()').extract()
        
        # Clear Data
        title = [x.strip() for x in title] if title else ''
        title = [x.strip() for x in title if x] if title else ''
        title = ' '.join(title).strip().replace('Listing title', '').replace(
            'Find your property for sale and for rent', '').strip() if title else ''
        category = [x.strip() for x in category] if category else ''
        category = [x.strip()
                    for x in category if x] if category else ''
        # category = ' > '.join(category).strip() if category else ''
        loc_cat = category
        if loc_cat and len(loc_cat) >= 3:
            loc_cat = loc_cat[3:]
            loc_cat.reverse()
            loc_cat = ', '.join(loc_cat).strip() if loc_cat else ''
        else:
            loc_cat = ''

        if category and len(category) >= 2:
            category = category[1]
        else:
            category = ''
        category_url = category_url[1].strip() if category_url else ''

        if '/for-rent/' in category_url:
            category = 'rent'
            category_url = '/en/for-rent/property-type/'
        elif '/for-sale/' in category_url:
            category = 'sale'
            category_url = '/en/for-sale/property-type/'
        else:
            category_url = category_url
            category = category

        description = [x.strip() for x in description] if description else ''
        description = [x.strip()
                       for x in description if x] if description else ''
        description = ' '.join(description).strip().replace(
            'Listing Description', '').strip() if description else ''
        id_ = id_url[0].strip().strip(
            'https://egypt.aqarmap.com/').strip() if id_url else ''
        location = [x.strip() for x in location] if location else ''
        location = [x.strip()
                    for x in location if x] if location else ''
        location = ' '.join(location).strip() if location else ''
        location =  location + ', '+ loc_cat if loc_cat else location
        price = price[0].strip() if price else ''
        bedrooms = bedrooms_text[0] if bedrooms_text else ''
        # bedrooms = re.findall(r'\d+', bedrooms_text) if bedrooms_text else ''
        # bedrooms = bedrooms[0].strip() if bedrooms else ''
        bathrooms = bathrooms_text[0] if bathrooms_text else ''
        # bathrooms = re.findall(
        #     r'\d+', bathrooms_text) if bathrooms_text else ''
        # bathrooms = bathrooms[0].strip() if bathrooms else ''
        broker_display_name = broker_display_name[
            0].strip() if broker_display_name else ''
        img = response.xpath(
            '//div[@class="es-carousel"]/ul//li/a/picture/source/@data-srcset').extract()

        number_of_photos = len(set(img))
        area = ' '.join(''.join(area).split()) if area else ''
        name = name.strip() if name else ''
        user = response.xpath(
            '//div[@class="sellerProperties"]/p/a/@href').extract()
        if user:
            user = user[0]
            if 'user' in user:
                user_data = user.split('user/') if user else ''
                user_id = user_data[-1] if user_data else ''
        user_id = user_id if user_id else ''


        scraped_ts = (datetime.now()).strftime("%Y-%m-%d")
        latitude = latitude[0].strip() if latitude else ''
        longitude = longitude[0].strip() if longitude else ''

        published_at = ''.join(published_at).strip().split(' at ')[-1]
        updated_at = updated_at[0].strip().replace('Last update:','').strip() if updated_at else ''
        published_at = published_at if published_at else updated_at
        now = datetime.now()
        current = datetime(now.year, now.month, 1)
        next_month = datetime(now.year + int(now.month / 12), ((now.month % 12) + 1), 1)
        now_date_int = int(now.strftime("%d"))
        if now_date_int <=31 and now_date_int >=25:
            iteration_month = next_month.strftime("%m")
            iteration_year = next_month.strftime("%Y")
        else:
            iteration_month = now.strftime("%m")
            iteration_year = now.strftime("%Y")
        iteration_number = iteration_year + '_'+ iteration_month        
        url=response.url
        item = AqarmapEgItem(

            reference_number='',
            id=id_,
            url=response.url,
            broker_display_name=broker_display_name,
            broker=broker_display_name.upper(),
            category=category,
            category_url=category_url,
            title=title,
            property_type = property_type,
            description=description,
            location=location,
            price=price,
            currency='EGP',
            price_per='',
            bedrooms=bedrooms,
            bathrooms=bathrooms,
            furnished='',
            rera_permit_number='',
            dtcm_licence='',
            amenities='',
            scraped_ts=scraped_ts,
            details=area,
            agent_name='',
            number_of_photos=number_of_photos,
            user_id=user_id,
            phone_number=phone_number,
            date=scraped_ts,
            iteration_number=iteration_number,
            longitude=longitude,
            latitude=latitude,
            published_at=published_at,
        )
        if url:
            yield item
            # print(item)

    # Errorback to put failed urls back in queue
    def errback_httpbin(self, failure, url):
        credentials = pika.PlainCredentials(QUEUE_USER, QUEUE_PASS)
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            credentials=credentials, host=QUEUE_IP, socket_timeout=600))
        channel = connection.channel()
        channel.queue_declare(queue=QUEUE_NAME, durable=True)
        channel.basic_publish(
            exchange='', routing_key=QUEUE_NAME, body=url)
        connection.close()
