# -*- coding: utf-8 -*-
import scrapy
import re
import pika
import json
import logging
import io
import gzip

# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime
from scrapy.shell import inspect_response
from time import sleep
from xml.dom import minidom

from aqarmap_eg.items import *
from aqarmap_eg.settings import *

handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False

headers = {
		'upgrade-insecure-requests': '1',
		'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.119 Safari/537.36'}
	
class Aqarmap_EgCrawlerSpider(Spider):
	name = 'aqarmap_eg_sitemap'
	start_urls = [
				'https://aqarmap.com.eg/sitemap.neighborhood.xml',
				'https://aqarmap.com.eg/sitemap.search-results.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-0_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-1_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-2_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-3_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-4_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-5_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-6_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-7_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-8_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-9_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-10_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-11_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-12_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-13_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-14_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-15_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-16_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-17_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-18_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-19_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-20_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-21_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-22_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-23_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-24_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-25_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-26_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-27_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-28_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-29_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-30_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-31_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-32_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-33_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-34_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-35_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-36_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-37_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-38_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-39_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-40_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-41_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-42_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-43_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-44_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-45_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-46_0.xml',
				'https://aqarmap.com.eg/sitemap.search-results-locations-47_0.xml'

	]
	
	allowed_domains = ['aqarmap.com.eg']
	handle_httpstatus_list = [503, 403]
	def parse(self, response):
		xmldoc = minidom.parseString(response.body)
		LOCS = xmldoc.getElementsByTagName('loc')
		for loc in LOCS:
			url_ = loc.childNodes[0].data
			item = AqarmapEgCatUrlItem(
				url=url_.strip(),
			)
			yield item

