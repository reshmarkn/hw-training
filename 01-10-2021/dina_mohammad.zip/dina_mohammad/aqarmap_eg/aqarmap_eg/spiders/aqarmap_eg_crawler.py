import scrapy
import re
import pika
import json
import logging
import io
import gzip
# from dateutil import parser
from scrapy.spiders import Spider
from scrapy.selector import Selector
from scrapy.http import Request, FormRequest
from datetime import datetime
from scrapy.shell import inspect_response
from time import sleep
from xml.dom import minidom
from aqarmap_eg.items import *
from aqarmap_eg.settings import *
handler = logging.FileHandler('spider_error.log')
handler.setLevel('ERROR')
logging.root.addHandler(handler)
logger = logging.getLogger('pika')
logger.propagate = False
headers = {
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.119 Safari/537.36'}
class Aqarmap_EgCrawlerSpider(Spider):
    name = 'aqarmap_eg_crawler'
    allowed_domains = ['aqarmap.com.eg']
    handle_httpstatus_list = [503, 403]
    def start_requests(self):
        start_urls = [
                    # 'https://aqarmap.com.eg/en/for-sale/property-type/',
                    'https://aqarmap.com.eg/en/for-sale/shq-bhdyq/',
                    'https://aqarmap.com.eg/en/for-sale/rwf/',
                    'https://aqarmap.com.eg/en/for-sale/dwr-kml/',
                    'https://aqarmap.com.eg/en/for-sale/studio/',
                    'https://aqarmap.com.eg/en/for-sale/duplex/',
                    'https://aqarmap.com.eg/en/for-sale/penthouse/',
                    'https://aqarmap.com.eg/en/for-sale/furnished-apartment/',
                    'https://aqarmap.com.eg/en/for-sale/chalet/',
                    'https://aqarmap.com.eg/en/for-sale/villa/',
                    'https://aqarmap.com.eg/en/for-sale/land-or-farm/',
                    'https://aqarmap.com.eg/en/for-sale/building/',
                    'https://aqarmap.com.eg/en/for-sale/administrative/',
                    'https://aqarmap.com.eg/en/for-sale/commercial/',
                    'https://aqarmap.com.eg/en/for-sale/medical/',
                    'https://aqarmap.com.eg/en/for-sale/shared-rooms/',
                    'https://aqarmap.com.eg/en/for-sale/land-or-commercial/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/cairo/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/alexandria/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/north-coast/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/dakahlia/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/ain-elsokhna/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/red-sea/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/marsa-matruh/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/sharm-el-sheikh/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/ras-sidr/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/gharbia/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/el-minia/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/qalyubia/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/monufia/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/damietta/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/jnwb-syn/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/ismailia/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/suez/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/beheira/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/aswan/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/qina/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/asyut/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/kafr-el-sheikh/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/sharqia/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/luxor/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/beni-suef/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/port-said/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/new-valley/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/north-sinai/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/el-fayoum/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/sohag/',
                    'https://aqarmap.com.eg/en/for-sale/apartment/outside-egypt/',
                    'https://aqarmap.com.eg/en/for-rent/apartment/',
                    'https://aqarmap.com.eg/en/for-rent/furnished-apartment/',
                    'https://aqarmap.com.eg/en/for-rent/chalet/',
                    'https://aqarmap.com.eg/en/for-rent/villa/',
                    'https://aqarmap.com.eg/en/for-rent/land-or-farm/',
                    'https://aqarmap.com.eg/en/for-rent/building/',
                    'https://aqarmap.com.eg/en/for-rent/administrative/',
                    'https://aqarmap.com.eg/en/for-rent/commercial/',
                    'https://aqarmap.com.eg/en/for-rent/medical/',
                    'https://aqarmap.com.eg/en/for-rent/shared-rooms/',
                    'https://aqarmap.com.eg/en/for-rent/land-or-commercial/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/cairo/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/alexandria/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/north-coast/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/dakahlia/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/ain-elsokhna/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/red-sea/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/marsa-matruh/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/sharm-el-sheikh/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/ras-sidr/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/gharbia/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/el-minia/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/qalyubia/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/monufia/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/damietta/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/jnwb-syn/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/ismailia/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/suez/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/beheira/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/aswan/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/qina/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/asyut/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/kafr-el-sheikh/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/sharqia/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/luxor/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/beni-suef/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/port-said/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/new-valley/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/north-sinai/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/el-fayoum/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/sohag/',
                    # 'https://aqarmap.com.eg/en/for-rent/property-type/outside-egypt/'
                    ]
        for url in start_urls:
            print("########",url)
            meta = {'parent_url':url}
            yield Request(url=url, headers=headers, callback=self.parse, meta=meta)
    def parse(self, response):

        parent_url = response.meta.get('parent_url')
        commercial_list = [       
                    'https://aqarmap.com.eg/en/for-rent/land-or-farm/',
                    'https://aqarmap.com.eg/en/for-rent/building/',
                    'https://aqarmap.com.eg/en/for-rent/administrative/',
                    'https://aqarmap.com.eg/en/for-rent/commercial/',
                    'https://aqarmap.com.eg/en/for-rent/medical/',
                    'https://aqarmap.com.eg/en/for-rent/land-or-commercial/',
                    'https://aqarmap.com.eg/en/for-sale/land-or-farm/',
                    'https://aqarmap.com.eg/en/for-sale/building/',
                    'https://aqarmap.com.eg/en/for-sale/administrative/',
                    'https://aqarmap.com.eg/en/for-sale/commercial/',
                    'https://aqarmap.com.eg/en/for-sale/medical/',
                    'https://aqarmap.com.eg/en/for-sale/land-or-commercial/',
                    ]

        if parent_url in commercial_list:
            sub_category_1 = 'Commercial'
        else:
            sub_category_1 = 'Residential'

        if 'shared-rooms' in parent_url:
            sub_category_2 = 'Shared accommodation'
        else:
            sub_category_2 = ''
        # property_urls = response.xpath('//section[contains(@class,"searchResults")]//a[@itemprop="url"]/@href').extract()
        pagination = response.xpath('//a[@rel="next"]/@href').extract()
        property_urls =response.xpath('//section[@class="col-lg-9 col-md-9 col-sm-12 col-xs-12 searchResults"]//ul/div|//section[@class="col-lg-9 col-md-9 col-sm-12 col-xs-12 searchResults"]//div/a|//div[@class="small-card search-Result-Card col-lg-6 col-md-6 col-sm-12 col-xs-12"]')
        for i in property_urls:
            links = i.xpath('div/div/a[@itemprop="url"]/@href | @href').extract_first()
            base = 'https://aqarmap.com.eg'
            link = base + str(links)
            link = link.strip().replace('https://aqarmap.com.eg/ar/','https://aqarmap.com.eg/en/').strip()
            logo = i.xpath('div/div/a[@itemprop="url"]/div[@class="thumbnail-details thumb-detail "]/div[@class="featured-btn featured-label "]/text()').extract_first('')
            logo = ''.join(logo).replace('\n','').strip()

            item = AqarmapEgUrlItem(
                url=link,
                depth=logo,
                sub_category_1=sub_category_1,
                sub_category_2=sub_category_2
                )
            yield item    
        if property_urls:
            filter_list = ['/?sort=publishedAt&direction=asc',
                        '/?sort=publishedAt&direction=desc',
                        '/?sort=price&direction=asc',
                        '/?sort=price&direction=desc',
                        '/?sort=area&direction=asc',
                        '/?sort=area&direction=desc',
                    ]
            for fil_url in filter_list:
                filter_url = response.url.split('?')[0].rstrip('/') + fil_url
                yield Request(url=filter_url,headers=headers, callback=self.parse, meta={'parent_url':parent_url})
        if pagination:
            sleep(2)
            # print(pagination)
            pagination_url = response.urljoin(pagination[0].strip())
            yield Request(url=pagination_url,headers=headers, callback=self.parse, dont_filter=True,meta={'parent_url':parent_url})
        elif property_urls:
            sleep(2)
            current_page_no = re.findall('page=\d+',response.url)
            current_page_no = current_page_no[0].strip('page=') if current_page_no else ''
            current_page_no = int(current_page_no) if current_page_no else ''
            next_page_no = current_page_no + 1 if current_page_no else ''
            if next_page_no:
                # print("xxxx",next_page_no,"XXXXX")
                current_page_no = str(current_page_no)
                next_page_no = str(next_page_no)
                next_page = re.sub('page=%s'%(current_page_no), 'page=%s' %
                                  (next_page_no), response.url)
                yield Request(url=next_page,headers=headers, callback=self.parse,meta={'parent_url':parent_url})