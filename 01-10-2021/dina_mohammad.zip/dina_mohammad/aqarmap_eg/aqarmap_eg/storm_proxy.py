import random
import base64
# from scrapy.conf import settings
import random
import requests
from time import sleep
from scrapy.utils.project import get_project_settings
settings = get_project_settings()


def parse_proxy():

    # torr
    # PROXY_LIST = requests.get('http://68.183.58.145/microleaves',
    #                           headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
    # PROXY_LIST = requests.get(
    #     'http://68.183.58.145/torproxies', headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()

    PROXY_LIST = requests.get('http://68.183.58.145/stormproxies?type=3',
                              headers={"x-api-key": "_/&IWn<rJ5hDTdq"}).json()
    
    PROXY = random.choice(settings.get('PROXY_LIST'))
    proxies = {"http": "http://%s" % PROXY,
                       "https": "https://%s" % PROXY}

    user_agent = random.choice(settings.get('USER_AGENT_LIST'))
    headers = {'Accept-Encoding': 'gzip', 'User-Agent': user_agent,
               'Accept': 'application/json, text/javascript, */*; q=0.01', 'X-Requested-With': 'XMLHttpRequest'}
    return {'headers': headers, 'proxies': proxies}
