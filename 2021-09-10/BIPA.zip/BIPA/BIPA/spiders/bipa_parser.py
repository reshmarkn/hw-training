import scrapy

from scrapy.http import Request

import re

import json

from scrapy.exceptions import CloseSpider

# from ..items import BipaItem

import pika

headers = {
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "accept-encoding": "gzip, deflate, br",
        "accept-language": "en-US,en;q=0.9",
        "upgrade-insecure-requests": "1",
        "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36"
        }


class BipaParserSpider(scrapy.Spider):
    name = 'bipa_parser'
    

    def start_requests(self):

        credentials = pika.PlainCredentials('guest','guest')
        connection = pika.BlockingConnection(pika.ConnectionParameters( host='localhost', socket_timeout=300))
        channel = connection.channel()
        
        while True:
            channel.basic_qos(prefetch_count=1)
            method, properties, url = channel.basic_get(queue='bipa')
            if not url.strip():
                break
            channel.basic_ack(delivery_tag=method.delivery_tag)
            url = str(url.strip(), encoding='utf-8')
            if url.strip():
                link = url
                yield Request(url=link.strip(), callback=self.parse, headers=headers)

        connection.close()
        
    def parse(self, response):
        #XPATH

        product_url = response.url
        catagory_hierarchys = response.xpath("//ol[@id = 'breadcrumb']/li/a/text()").extract() 
        product_name = response.xpath("//meta[@property='og:title']/@content").extract_first()
        product_brand = response.xpath("//a[@class='pdp__cockpit--pbrand-link']/text()").extract_first() 
        image_url = response.xpath("//meta[@property='og:image']/@content").extract_first()   
        sku = response.xpath("//div[@class='pdp__cockpit-psku ']/text()").re_first(r'#\s*(.*)')  
        mrp = response.xpath("//span[@class='alternative-price']/text()").extract_first()   
        price = response.xpath("//div[@class='final-price']/text()").extract_first()
        quantity =response.xpath("//div[@class='pdp__cockpit--productcontent']/text()").extract()       
        product_description = response.xpath("//p[@class='description']/text()").extract()   
        product_info = response.xpath("//ul[@class='detail-desc']/li/text()").extract()  
        
        data = response.xpath('//script[@type="application/ld+json"]/text()').extract()
        json_data = json.loads(data[0])
        
        # review_count = json_data.get('mainEntity', {}).get('aggregateRating',{}).get('reviewCount', '')
        # availability = response.xpath("//div[@class='stockstatus isinstock pdp__cockpit-poptions--delivery-icon-box']/span/text()").extract_first()   
        availability = json_data.get('mainEntity',{}).get('offers',{}).get('availability','')
        var1 = availability.split('/')[-1]
        
        if var1.lower() ==  "LimitedAvailability" :
            is_sold_out = False
        else:
            is_sold_out = True


        # CLEAN

        product_category = ' > '.join(catagory_hierarchys) 
        
        quantity = ''.join(quantity).replace('\n','') if quantity else '' 
        product_quantity = ''.join(re.findall(r'\s*(.*)\ Stück',quantity))   
        product_description = ''.join(product_description) if product_description else '' 

        product_info = ','.join(product_info) 
        product_info = ''.join(product_info) 

        item = {}

        item['product_url'] = product_url
        item['catagory_hierarchys'] = product_category
        item['product_name'] = product_name
        item['product_brand'] = product_brand
        item['image_url'] = image_url
        item['sku'] = sku
        item['mrp'] = mrp
        item['price'] = price
        item['quantity'] = quantity
        item['product_description'] = product_description
        item['product_info'] = product_info
        item['is_sold_out'] = is_sold_out
        

        yield item


