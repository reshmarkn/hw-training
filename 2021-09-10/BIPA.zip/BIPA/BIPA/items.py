# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

# import scrapy


# class BipaItem(scrapy.Item):
    
#     _id = scrapy.Field()
#     product_url = scrapy.Field()
#     catagory_hierarchys  = scrapy.Field()
#     product_name = scrapy.Field()
#     product_brand = scrapy.Field()
#     image_url = scrapy.Field()
#     sku = scrapy.Field()
#     mrp = scrapy.Field()
#     price = scrapy.Field()
#     quantity = scrapy.Field()
#     product_description = scrapy.Field()
#     product_info = scrapy.Field()
#     is_sold_out = scrapy.Field()


 
       
        
       