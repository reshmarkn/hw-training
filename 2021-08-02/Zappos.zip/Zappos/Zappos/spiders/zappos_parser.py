import scrapy
from scrapy.http import Request
from scrapy.exceptions import CloseSpider
from ..items import ZapposparserItem

headers = {
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "accept-encoding": "gzip, deflate, br",
        "accept-language": "en-US,en;q=0.9",
        "upgrade-insecure-requests": "1",
        "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36"
        }

class ZapposSpider(scrapy.Spider):
    name = 'zappos_parser'

    def start_requests(self):
        
        links = ['https://www.zappos.com/p/asics-gel-cumulus-22-black-white/product/9399689/color/151',
                 'https://www.zappos.com/p/asics-gel-kayano-27-sheet-rock-pure-silver/product/9400280/color/840588',
                 'https://www.zappos.com/p/asics-gel-contend-7-sheet-rock-pink-salt/product/9462706/color/892004',
                 'https://www.zappos.com/p/asics-gel-contend-7-black-lilac-opal/product/9462706/color/893028',
                 'https://www.zappos.com/p/asics-gel-venture-8-mako-blue-pink-glow/product/9488707/color/907071',
                 'https://www.zappos.com/p/asics-gel-challenger-13-white-pure-silver/product/9514722/color/147270',
                 'https://www.zappos.com/p/asics-gt-2000-9-mako-blue-grey-floss/product/9434351/color/882314',
                 'https://www.zappos.com/p/asics-gel-kayano-27-mako-blue-hot-pink/product/9400280/color/870255',
                 'https://www.zappos.com/p/asics-gel-kayano-27-black-pure-silver/product/9400280/color/147392',
                 'https://www.zappos.com/p/asics-gel-contend-7-french-blue-champagne/product/9462706/color/893029']
    
        for url in links:
            yield Request(url, headers=headers) 
    
    def parse(self, response):
        
        #XPATH

        product_brand = response.xpath("//*[@id='overview']/h1/div/span[1]/a/span/text()").extract_first()
        product_name = response.xpath("//*[@id='overview']/h1/div/span[2]/text()").extract_first()
        product_price = response.xpath("//div[@id='productRecap']/div/div[2]//div/div/div/div/span[1]/span//text()").extract()
        product_discount = response.xpath("//div[@id='productRecap']/div/div[2]//div/div/div/div/span[2]/span[1]//text()").extract()
        product_MSRP = response.xpath("//div[@id='productRecap']/div/div[2]//div/div/div/div/span[2]/span[2]/span[2]//text()").extract_first()
        available_colours = response.xpath("//select[@id='pdp-color-select']/option//text()").extract()
        product_reviews = response.xpath("//a[@href='/product/review/9399689']/span[2]//text()").extract()
        product_image = response.xpath("//div[@id='productImages']/div/div/div/div/div/button/span/img/@src").extract_first()
        product_description =  response.xpath('//div[@itemprop="description"]//div/ul/li/text()').extract()

        
        #CLEAN

        product_price = ''.join(product_price).replace('$','') if product_price else ''
        product_discount = ''.join(product_discount) if product_discount else ''
        product_MSRP = ''.join(product_MSRP).replace('$','') if product_MSRP else ''
        product_reviews = ''.join(product_reviews).replace('$','') if product_reviews else ''
        product_description = ''.join(product_description) if product_description else ''

        item = ZapposparserItem()
        
        item['PRODUCT_BRAND'] = product_brand
        item['PRODUCT_NAME'] = product_name
        item['PRODUCT_PRICE'] = product_price
        item['PRODUCT_DISCOUNT'] = product_discount
        item['PRODUCT_MSRP'] = product_MSRP
        item['AVAILABLE_COLOURS'] = available_colours
        item['PRODUCT_REVIEWS'] = product_reviews
        item['PRODUCT_IMAGE'] = product_image
        item['PRODUCT_DESCRIPTION'] = product_description
        
        yield item
       