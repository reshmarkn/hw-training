import scrapy

from scrapy.http import Request

from scrapy.exceptions import CloseSpider

from Zappos.items import ZapposlinkcrawlerItem

headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.101 Safari/537.36'
    }

class ZapposLinksSpider(scrapy.Spider):

    name = 'zappos_link_crawler'
    base_urls = 'https://www.zappos.com'
    
    def start_requests(self):

        start_urls = 'https://www.zappos.com/asics-women-shoes/CK_XAVoBC8ABAeICAwELGA.zso'
        yield Request(start_urls, callback=self.parse, headers = headers)
    
    def parse(self, response):
       
        product_links = response.xpath("//div[@id='searchPage']/div/article/a/@href").extract()
        for link in product_links:
            product_url = 'https://www.zappos.com'+link

            item = ZapposlinkcrawlerItem()
            item['PRODUCT_URL'] = product_url
            yield item

        next_page = response.xpath("//div[@id='searchPagination']/div[2]/a[2]/@href").extract_first()
        if next_page:
            next_page_url = 'https://www.zappos.com'+next_page
            yield Request(next_page_url, headers=headers, callback=self.parse)

 



















