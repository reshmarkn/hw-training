# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from pymongo import MongoClient


class PerfumaniaPipeline:
    database = 'perfumania'
    collection = 'beauty'

    def __init__(self):
        self.client = MongoClient('localhost' ,27017)
        self.db = self.client[self.database]
        self.coll = self.db[self.collection]

    def process_item(self, item,spider):
        self.db[self.collection].insert_one(item)
        return item
    
    def process_urls(self, urls,spider):
        self.db[self.collection1].insert_one(urls)
        return urls

    def close_spider(self,spider):
        self.client.close()

class PerfumanialinksPipeline:
    database = 'perfumania'
    collection = 'links'

    def __init__(self):
        self.client = MongoClient('localhost' ,27017)
        self.db = self.client[self.database]
        self.coll = self.db[self.collection]
        