import scrapy

class PerfumaniaSpider(scrapy.Spider):

    name = 'perfumania'
    start_urls = ['https://perfumania.com/collections/beauty']
    headers = {
        'User-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        }
    
    def parse(self,response):

        links = ['https://perfumania.com/collections/beauty/products/re-nutriv-ultimate-lift-rejuvenating-soft-creme-by-estee-lauder-for-women-1-7-oz-cream?variant=34638159446149','https://perfumania.com/collections/beauty/products/phyto-replenish-oil-by-dermalogica-for-unisex-1-oz-oil?variant=34620682207365','https://perfumania.com/collections/beauty/products/eyewitness-eye-repair-cream-by-kiss-my-face-for-unisex-0-5-oz-cream?variant=34620693840005','https://perfumania.com/collections/beauty/products/cocoa-butter-skin-therapy-oil-by-palmers-for-unisex-5-1-oz-oil']
        for url in links:
            yield scrapy.Request(url, callback=self.parse_product,headers = self.headers)
    
    def parse_product(self, response):
        #XPATH
        product_brand = response.xpath("//div[@class='cm-vendor-product']/h3/a/text()").extract()
        product_availability = response.xpath("//div[@class='product-label online-only pdp']/strong/text()").extract_first().strip()
        product_name = response.xpath("//div[has-class('product-title')]/span/text()").extract_first().strip()
        product_price = response.xpath("//div[has-class('prices')]/span/text()").extract_first().strip()
        product_size = response.xpath("//label[@for='swatch-0-1-7-oz']/text()").extract()
        product_description = response.xpath("//div[@class='tab-content active']/div/p/text()").extract()
        product_image = response.xpath('//meta[@property="og:image"]/@content').extract_first()

        #CLEAN
        product_brand = ''.join(product_brand) if product_brand else ''
        product_availability  = ''.join(product_availability ) if product_availability else ''
        product_name = ''.join(product_name) if product_name else ''
        product_price = ''.join(product_price).replace('$','') if product_price else ''
        product_size = product_size[0].strip() if product_size else ''
        product_description = ''.join(product_description) if product_description else ''
        
        item={}
        
        item['PRODUCT_BRAND'] = product_brand
        item['PRODUCT_AVAILABILITY'] = product_availability
        item['PRODUCT_NAME'] = product_name
        item['PRODUCT_PRICE'] = product_price
        item['PRODUCT_SIZE'] = product_size
        item['PRODUCT_DESCRIPTION'] = product_description
        item['IMAGE_URL'] = product_image
        
        yield item


