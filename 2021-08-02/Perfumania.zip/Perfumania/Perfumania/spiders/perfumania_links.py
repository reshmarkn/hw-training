import scrapy
# from scrapy.shell import inspect_response
headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.101 Safari/537.36'
    }


class PerfumaniaLinksSpider(scrapy.Spider):
    name = 'perfumania_links'
    start_urls = ['https://perfumania.com/collections/beauty']
    base_urls = 'https://perfumania.com'

    def parse(self, response):
        # inspect_response(response, self)
        links = response.xpath('//div[@class="product-image"]/a/@href').extract()
        for link in links:
            urls = scrapy.Request(self.base_urls+link , headers=headers)
            yield urls
        
