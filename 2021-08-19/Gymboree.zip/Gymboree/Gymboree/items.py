# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class GymboreeLinkcrawlerItem(scrapy.Item):
    
    _id = scrapy.Field()
    product_url = scrapy.Field()
   
    
class GymboreeParserItem(scrapy.Item):

    _id = scrapy.Field()
    pdp_url = scrapy.Field()
    product_name = scrapy.Field()
    product_price = scrapy.Field()
    image_url = scrapy.Field()
    product_discount = scrapy.Field()
    product_reviews = scrapy.Field()
    product_quantity = scrapy.Field()
    product_description = scrapy.Field()
    product_afterpay = scrapy.Field()
    varients = scrapy.Field()
